﻿namespace Calendar.NET
{
    partial class CalendarDashBoard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlTabCalendar = new MetroFramework.Controls.MetroTabControl();
            this.ctrlPageMonth = new MetroFramework.Controls.MetroTabPage();
            this.ctrlPageDayView = new MetroFramework.Controls.MetroTabPage();
            this.ctrlPageEventList = new MetroFramework.Controls.MetroTabPage();
            this.ctrlCalendarMonth = new Calendar();
            this.ctrlCalendarDay = new Calendar();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ctrlTabCalendar.SuspendLayout();
            this.ctrlPageMonth.SuspendLayout();
            this.ctrlPageDayView.SuspendLayout();
            this.ctrlPageEventList.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctrlTabCalendar
            // 
            this.ctrlTabCalendar.Controls.Add(this.ctrlPageMonth);
            this.ctrlTabCalendar.Controls.Add(this.ctrlPageDayView);
            this.ctrlTabCalendar.Controls.Add(this.ctrlPageEventList);
            this.ctrlTabCalendar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTabCalendar.Location = new System.Drawing.Point(0, 0);
            this.ctrlTabCalendar.Name = "ctrlTabCalendar";
            this.ctrlTabCalendar.SelectedIndex = 0;
            this.ctrlTabCalendar.Size = new System.Drawing.Size(719, 485);
            this.ctrlTabCalendar.TabIndex = 0;
            this.ctrlTabCalendar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ctrlPageMonth
            // 
            this.ctrlPageMonth.Controls.Add(this.ctrlCalendarMonth);
            this.ctrlPageMonth.HorizontalScrollbarBarColor = true;
            this.ctrlPageMonth.Location = new System.Drawing.Point(4, 35);
            this.ctrlPageMonth.Name = "ctrlPageMonth";
            this.ctrlPageMonth.Size = new System.Drawing.Size(711, 446);
            this.ctrlPageMonth.TabIndex = 0;
            this.ctrlPageMonth.Text = "Month View";
            this.ctrlPageMonth.VerticalScrollbarBarColor = true;
            // 
            // ctrlPageDayView
            // 
            this.ctrlPageDayView.Controls.Add(this.ctrlCalendarDay);
            this.ctrlPageDayView.HorizontalScrollbarBarColor = true;
            this.ctrlPageDayView.Location = new System.Drawing.Point(4, 35);
            this.ctrlPageDayView.Name = "ctrlPageDayView";
            this.ctrlPageDayView.Size = new System.Drawing.Size(630, 385);
            this.ctrlPageDayView.TabIndex = 1;
            this.ctrlPageDayView.Text = "Day View";
            this.ctrlPageDayView.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ctrlPageDayView.VerticalScrollbarBarColor = true;
            // 
            // ctrlPageEventList
            // 
            this.ctrlPageEventList.Controls.Add(this.tableLayoutPanel1);
            this.ctrlPageEventList.HorizontalScrollbarBarColor = true;
            this.ctrlPageEventList.Location = new System.Drawing.Point(4, 35);
            this.ctrlPageEventList.Name = "ctrlPageEventList";
            this.ctrlPageEventList.Size = new System.Drawing.Size(630, 385);
            this.ctrlPageEventList.TabIndex = 2;
            this.ctrlPageEventList.Text = "EventList";
            this.ctrlPageEventList.VerticalScrollbarBarColor = true;
            // 
            // ctrlCalendarMonth
            // 
            this.ctrlCalendarMonth.AllowEditingEvents = true;
            this.ctrlCalendarMonth.CalendarDate = new System.DateTime(2019, 1, 24, 23, 21, 48, 35);
            this.ctrlCalendarMonth.CalendarView = CalendarViews.Month;
            this.ctrlCalendarMonth.DateHeaderFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarMonth.DayOfWeekFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarMonth.DaysFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarMonth.DayViewTimeFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarMonth.DimDisabledEvents = true;
            this.ctrlCalendarMonth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCalendarMonth.HighlightCurrentDay = true;
            this.ctrlCalendarMonth.LoadPresetHolidays = true;
            this.ctrlCalendarMonth.Location = new System.Drawing.Point(0, 0);
            this.ctrlCalendarMonth.Name = "ctrlCalendarMonth";
            this.ctrlCalendarMonth.ShowArrowControls = true;
            this.ctrlCalendarMonth.ShowDashedBorderOnDisabledEvents = true;
            this.ctrlCalendarMonth.ShowDateInHeader = true;
            this.ctrlCalendarMonth.ShowDisabledEvents = false;
            this.ctrlCalendarMonth.ShowEventTooltips = true;
            this.ctrlCalendarMonth.ShowTodayButton = true;
            this.ctrlCalendarMonth.Size = new System.Drawing.Size(711, 446);
            this.ctrlCalendarMonth.TabIndex = 2;
            this.ctrlCalendarMonth.TodayFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            // 
            // ctrlCalendarDay
            // 
            this.ctrlCalendarDay.AllowEditingEvents = true;
            this.ctrlCalendarDay.CalendarDate = new System.DateTime(2019, 1, 24, 23, 23, 16, 377);
            this.ctrlCalendarDay.CalendarView = CalendarViews.Day;
            this.ctrlCalendarDay.DateHeaderFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarDay.DayOfWeekFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarDay.DaysFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarDay.DayViewTimeFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarDay.DimDisabledEvents = true;
            this.ctrlCalendarDay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCalendarDay.HighlightCurrentDay = true;
            this.ctrlCalendarDay.LoadPresetHolidays = true;
            this.ctrlCalendarDay.Location = new System.Drawing.Point(0, 0);
            this.ctrlCalendarDay.Name = "ctrlCalendarDay";
            this.ctrlCalendarDay.ShowArrowControls = true;
            this.ctrlCalendarDay.ShowDashedBorderOnDisabledEvents = true;
            this.ctrlCalendarDay.ShowDateInHeader = true;
            this.ctrlCalendarDay.ShowDisabledEvents = false;
            this.ctrlCalendarDay.ShowEventTooltips = true;
            this.ctrlCalendarDay.ShowTodayButton = true;
            this.ctrlCalendarDay.Size = new System.Drawing.Size(630, 385);
            this.ctrlCalendarDay.TabIndex = 2;
            this.ctrlCalendarDay.TodayFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(630, 385);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.dataGridView1, 2);
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 119);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(624, 263);
            this.dataGridView1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox1, 2);
            this.groupBox1.Controls.Add(this.metroButton2);
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(624, 45);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Actions";
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(6, 16);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 0;
            this.metroButton1.Text = "Load";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(87, 16);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 1;
            this.metroButton2.Text = "Clear";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // groupBox2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox2, 2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(624, 59);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search Criteria";
            // 
            // CalendarDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ctrlTabCalendar);
            this.Name = "CalendarDashBoard";
            this.Size = new System.Drawing.Size(719, 485);
            this.ctrlTabCalendar.ResumeLayout(false);
            this.ctrlPageMonth.ResumeLayout(false);
            this.ctrlPageDayView.ResumeLayout(false);
            this.ctrlPageEventList.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl ctrlTabCalendar;
        private MetroFramework.Controls.MetroTabPage ctrlPageMonth;
        private MetroFramework.Controls.MetroTabPage ctrlPageDayView;
        private MetroFramework.Controls.MetroTabPage ctrlPageEventList;
        private Calendar ctrlCalendarMonth;
        private Calendar ctrlCalendarDay;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}
