﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace System.Windows.Forms
{
    public partial class frmSampleRibbon :Form
    {
        public frmSampleRibbon()
        {
            InitializeComponent();
            splitContainer1.Panel1Collapsed = true;
            splitContainer1.Panel1.Hide();
        }
    }
}
