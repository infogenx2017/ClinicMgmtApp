﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Login
    {
        public string CurrentUser { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsLoginSuceesfully { get; set; }

        public DataTable LoginApplication(string username, string password,int userType)
        {
            DB db = new DB();
            SqlParameter[] param = new SqlParameter[3];
            param[0] = new SqlParameter("@username", SqlDbType.VarChar, 20);
            param[0].Value = username;
            param[1] = new SqlParameter("@pass", SqlDbType.VarChar, 20);
            param[1].Value = password;
            param[2] = new SqlParameter("@userType", SqlDbType.Int, 20);
            param[2].Value = userType;
             
            DataTable tab = new DataTable();
            tab = db.getData("spr_login", param);
            db.closeConnection();
            return tab;
        }
    }

    public class LoginUser
    {
        public int Id  { get; set; }
        public string Type { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string FullName { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string DoctorCode { get; set; }
    }

    public class LoginHospital
    {
        public int Id { get; set; }
        public int Code { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public bool IsMaster { get; set; }
        public bool ContactNumber { get; set; }
        public string Email { get; set; }
        public string Website { get; set; }
    }
}
