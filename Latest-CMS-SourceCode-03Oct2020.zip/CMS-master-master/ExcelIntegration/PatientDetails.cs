﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelIntegration
{
    public class PatientDetails
    {
        public string SNo { get; set; }
        public string PatientName { get; set; }
        public string Address { get; set; }

        public string ContactNo { get; set; }
        public string Age { get; set; }

        public string PatienSextName { get; set; }
        public string ProvisDiagnosis { get; set; }

        public string Investigation { get; set; }
        public string FinalDiagnosis { get; set; }

        public string Treatment { get; set; }
        public string Result { get; set; }

        public string AddtionalInformation { get; set; }
        public string InitialOfMedOfficer { get; set; }
    }

    public class CommonDetails
    {
        public string RegistrationNo { get; set; }
        public string NameOfDoctor { get; set; }
        public string RegisterOfPatients { get; set; }
        public string Date { get; set; }

        public string Footer1 { get; set; } = "";
        public string Footer2 { get; set; } = "";
    }

    public class ExcelData
    {
        public CommonDetails CommonDetails { get; set; }

        public List<PatientDetails> PatientDetails { get; set; }

        public ExcelData()
        {
            CommonDetails = new CommonDetails();
            PatientDetails = new List<PatientDetails>();
        }

        public ExcelData(bool isMock) : this()
        {
            CommonDetails = new CommonDetails()
            {
                
                RegistrationNo = "78365GHJ76",
                NameOfDoctor = "Srinivasan MBBS",
                RegisterOfPatients = "RaguRam",
                Date = DateTime.Now.ToShortDateString(),
                Footer1 = "Note : If electronic records are maintained and / or existing registers capture this information,a monthly print",
                Footer2 = "outs / copy shall be taken authenticated by the hospital authorities"
            };

            PatientDetails = new List<PatientDetails>()
            {
                new PatientDetails()
                {
                    SNo="1",
                    PatientName ="Thirumalai Thangaraja",
                    Address ="4/120 Arch Street,Madiyanoor,Avudayanoor",
                    ContactNo ="7708934748",
                    Age ="27",
                    PatienSextName ="Male",
                    ProvisDiagnosis ="Fever Symptoms",
                    Investigation ="Fever Symptoms ,Fever Symptoms",
                    FinalDiagnosis ="Fever Symptoms",
                    Treatment ="Eye Operations",
                    Result ="Same Condition",
                    AddtionalInformation ="Have some problems at age 1",
                    InitialOfMedOfficer =""
                },
                    new PatientDetails()
                {
                        SNo="2",
                    PatientName ="Thirumalai Thangaraja",
                    Address ="4/120 Arch Street,Madiyanoor,Avudayanoor",
                    ContactNo ="7708934748",
                    Age ="27",
                    PatienSextName ="Male",
                    ProvisDiagnosis ="Fever Symptoms",
                    Investigation ="Fever Symptoms ,Fever Symptoms",
                    FinalDiagnosis ="Fever Symptoms",
                    Treatment ="Eye Operations",
                    Result ="Same Condition",
                    AddtionalInformation ="Have some problems at age 1",
                    InitialOfMedOfficer =""
                },

                           new PatientDetails()
                {
                               SNo="3",
                    PatientName ="Thirumalai Thangaraja",
                    Address ="4/120 Arch Street,Madiyanoor,Avudayanoor",
                    ContactNo ="7708934748",
                    Age ="27",
                    PatienSextName ="Male",
                    ProvisDiagnosis ="Fever Symptoms",
                    Investigation ="Fever Symptoms ,Fever Symptoms",
                    FinalDiagnosis ="Fever Symptoms",
                    Treatment ="Eye Operations",
                    Result ="Same Condition",
                    AddtionalInformation ="Have some problems at age 1",
                    InitialOfMedOfficer =""
                           }
            };
        }
    }
}
