﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExcelIntegration
{
    public class ExcelManager
    {
        public ExcelManager()
        {

        }

        public void GenerateExcel()
        {
            ExcelPackage package = null;
            ExcelData excelData = new ExcelData();
            try
            {
                var resourceName = Directory.GetCurrentDirectory() + "\\CMS.xlsx";
                //var resourceName = @"E:\F-DRIVE FILES\ExcelIntegration\CMS.xlsx";
                var fi = new FileInfo(resourceName);
                package = new ExcelPackage(fi);
                var workSheet = package.Workbook.Worksheets.First();

                FillExcelValues(excelData, workSheet);

                SaveFileDialog saveFileDialog_SaveExcel = new SaveFileDialog();
                saveFileDialog_SaveExcel.Filter = "Excel files (*.xlsx)|*.xlsx";
                var dialogResult = saveFileDialog_SaveExcel.ShowDialog();
                if (dialogResult == DialogResult.OK)
                {
                    package.SaveAs(new FileInfo(saveFileDialog_SaveExcel.FileName));
                    MessageBox.Show("Excel Generate Sucessfully");
                }
            }
            catch (Exception ex)
            {             
                MessageBox.Show(ex.Message);
            }
            finally
            {               
                package?.Dispose();
            }
           
        }


        public void GenerateExcel(ExcelData excelData)
        {
            ExcelPackage package = null;
           
            try
            {
                var resourceName = Directory.GetCurrentDirectory() + "\\CMS.xlsx";
                //var resourceName = @"E:\F-DRIVE FILES\ExcelIntegration\CMS.xlsx";
                var fi = new FileInfo(resourceName);
                package = new ExcelPackage(fi);
                var workSheet = package.Workbook.Worksheets.First();

                FillExcelValues(excelData, workSheet);

                SaveFileDialog saveFileDialog_SaveExcel = new SaveFileDialog();
                saveFileDialog_SaveExcel.Filter = "Excel files (*.xlsx)|*.xlsx";
                var dialogResult = saveFileDialog_SaveExcel.ShowDialog();
                if (dialogResult == DialogResult.OK)
                {
                    package.SaveAs(new FileInfo(saveFileDialog_SaveExcel.FileName));
                    MessageBox.Show("Excel Generate Sucessfully");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                package?.Dispose();
            }

        }

        private void FillExcelValues(ExcelData excelData, ExcelWorksheet workSheet)
        {
            workSheet.Cells[1, 11].Value = excelData.CommonDetails.RegistrationNo;
            workSheet.Cells[3, 3].Value = excelData.CommonDetails.NameOfDoctor;
            workSheet.Cells[4, 3].Value = excelData.CommonDetails.RegisterOfPatients;
            workSheet.Cells[5, 3].Value = excelData.CommonDetails.Date;

            int row = 7;
            foreach (var item in excelData.PatientDetails)
            {
                workSheet.Cells[row, 1].Value = item.SNo;
                workSheet.Cells[row, 2].Value = item.PatientName + Environment.NewLine + item.Address;
                workSheet.Cells[row, 3].Value = item.ContactNo;
                workSheet.Cells[row, 4].Value = item.Age;
                workSheet.Cells[row, 5].Value = item.PatienSextName;
                workSheet.Cells[row, 6].Value = item.ProvisDiagnosis;

                workSheet.Cells[row, 7].Value = item.Investigation;
                workSheet.Cells[row, 8].Value = item.FinalDiagnosis;
                workSheet.Cells[row, 9].Value = item.Treatment;
                workSheet.Cells[row, 10].Value = item.Result;
                workSheet.Cells[row, 11].Value = item.AddtionalInformation;
                workSheet.Cells[row, 12].Value = item.InitialOfMedOfficer;

                row++;
            }

            workSheet.Cells[row+1, 1].Value = excelData.CommonDetails.Footer1;
            workSheet.Cells[row+2, 1].Value = excelData.CommonDetails.Footer2;
        }
    }
}
