create table AllergyMaster(
Id int identity(1,1) PRIMARY KEY,
Name nvarchar(20),
Description nvarchar(200))

select * from AllergyMaster

insert into AllergyMaster(name,Description) values ('Skin Allergy','Skin Allergy')
insert into AllergyMaster(name,Description) values ('Alaway (ketotifen)','Alaway (ketotifen)')
insert into AllergyMaster(name,Description) values ('Alocril','Alocril (neodocromil sodium)')



create table LabInvestigation(
Id int identity(1,1) PRIMARY KEY,
Name nvarchar(20),
minAmount numeric(18,2),
MaxAmount numeric(18,2),
Description nvarchar(200)
)
