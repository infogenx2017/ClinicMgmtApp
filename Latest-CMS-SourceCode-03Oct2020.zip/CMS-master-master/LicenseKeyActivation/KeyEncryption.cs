﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LicenseKeyActivation
{
    public class KeyEncryption
    {
        private bool _isValidKey;
        private string _curKey;
        private string _msg;
        private int _days;
        private Tuple<bool, string> _keyInfo;
        private KeyDecryption _decryptKey;

        public KeyEncryption()
        {
            _isValidKey = false;
        }

        public KeyEncryption(string key)
            : this()
        {
            _curKey = key;
        }

        public Tuple<bool, string> ActivateLicenseKey()
        {
            LicenseGenerate();
            _keyInfo = new Tuple<bool, string>(_isValidKey, _msg);
            return _keyInfo;
        }

        private void LicenseGenerate()
        {
            _decryptKey = new KeyDecryption();

            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\ProgrammeExe", true);

            if (registryKey != null)
            {
                if (_decryptKey.DummyDecrypt(_curKey))
                {
                    string key = Convert.ToString(registryKey.GetValue("binaryIpOne"));
                    string prevKey = KeyAlgorithm.BSAlgorithm(key);
                    if (prevKey != _curKey)
                    {
                        _days = _decryptKey.Days;
                        ExecuteAlgorithm(registryKey);
                        GetLicenseActivateAlert();
                    }
                    else
                    {
                        GetExistKeyAlert();
                    }
                }
                else
                {
                    GetInvalidKeyAlert();
                }
            }
            else
            {
                if (_decryptKey.DummyDecrypt(_curKey))
                {
                    registryKey = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\ProgrammeExe", RegistryKeyPermissionCheck.Default);
                    _days = _decryptKey.Days;
                    ExecuteAlgorithm(registryKey);
                    GetLicenseActivateAlert();
                }
                else
                {
                    GetInvalidKeyAlert();
                }
            }
        }

        private void GetExistKeyAlert()
        {
            _msg = "The key is already used.\nSupport contact: 'Infogenex CMS'";
            _isValidKey = false;
        }

        private void GetLicenseActivateAlert()
        {
            _msg = "License is activated sucessfully.";
            _isValidKey = true;
        }

        private void GetInvalidKeyAlert()
        {
            _msg = "Invalid key.Please enter valid key.\nSupport contact:'Infogenex CMS'";
            _isValidKey = false;
        }

        private DateTime GetEndDate()
        {
            DateTime dt = DateTime.Today;
            DateTime endDate = dt.AddDays(_days);

            return endDate;
        }

        private void ExecuteAlgorithm(RegistryKey registryKey)
        {
            registryKey.SetValue("binaryIpOne", KeyAlgorithm.SBAlgorithm(_curKey), RegistryValueKind.String);
            registryKey.SetValue("binaryIpTwo", KeyAlgorithm.SBAlgorithm(Convert.ToString(DateTime.Today)), RegistryValueKind.String);
            registryKey.SetValue("binaryIpThree", KeyAlgorithm.SBAlgorithm(Convert.ToString(_days)), RegistryValueKind.String);
            registryKey.SetValue("binaryIpFour", KeyAlgorithm.SBAlgorithm(Convert.ToString(GetEndDate())), RegistryValueKind.String);

            registryKey.Close();
        }
    }
}
