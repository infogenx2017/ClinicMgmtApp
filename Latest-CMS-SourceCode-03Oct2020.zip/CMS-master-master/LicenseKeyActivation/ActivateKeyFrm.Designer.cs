﻿namespace LicenseKeyActivation
{
    partial class ActivateKeyFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlLblActKey = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtActKey = new MetroFramework.Controls.MetroTextBox();
            this.ctrlBtnActivate = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // ctrlLblActKey
            // 
            this.ctrlLblActKey.AutoSize = true;
            this.ctrlLblActKey.Location = new System.Drawing.Point(23, 96);
            this.ctrlLblActKey.Name = "ctrlLblActKey";
            this.ctrlLblActKey.Size = new System.Drawing.Size(86, 19);
            this.ctrlLblActKey.TabIndex = 0;
            this.ctrlLblActKey.Text = "Activate Key :";
            // 
            // ctrlTxtActKey
            // 
            this.ctrlTxtActKey.Location = new System.Drawing.Point(138, 96);
            this.ctrlTxtActKey.Name = "ctrlTxtActKey";
            this.ctrlTxtActKey.Size = new System.Drawing.Size(243, 23);
            this.ctrlTxtActKey.TabIndex = 1;
            // 
            // ctrlBtnActivate
            // 
            this.ctrlBtnActivate.Location = new System.Drawing.Point(280, 171);
            this.ctrlBtnActivate.Name = "ctrlBtnActivate";
            this.ctrlBtnActivate.Size = new System.Drawing.Size(101, 32);
            this.ctrlBtnActivate.TabIndex = 4;
            this.ctrlBtnActivate.Text = "Activate";
            this.ctrlBtnActivate.Click += new System.EventHandler(this.ctrlBtnActivate_Click);
            // 
            // ActivateKeyFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 265);
            this.Controls.Add(this.ctrlBtnActivate);
            this.Controls.Add(this.ctrlTxtActKey);
            this.Controls.Add(this.ctrlLblActKey);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ActivateKeyFrm";
            this.Text = "Key Activation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel ctrlLblActKey;
        private MetroFramework.Controls.MetroTextBox ctrlTxtActKey;
        private MetroFramework.Controls.MetroButton ctrlBtnActivate;
    }
}

