﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LicenseKeyActivation
{
    public class KeyDecryption
    {
        private Tuple<bool, string> keyInform;

        private bool isValid;

        private string msg;
        private string activeKey;

        private DateTime sDate;
        private DateTime eDate;

        private int _days;
        public int Days
        {
            get
            {
                return _days;
            }
            private set
            {
                _days = value;
            }
        }

        private char[] charValues = new char[] {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
        'P','Q','R','S','T','U','V','W','X','Y','Z'};

        public KeyDecryption()
        {
            sDate = new DateTime();
            _days = 0;
            eDate = new DateTime();
            activeKey = string.Empty;
            msg = string.Empty;
            isValid = false;
        }

        public Tuple<bool, string> CheckKeyActivation()
        {
            return DecryptKey();
        }

        public Tuple<bool, string> DecryptKey()
        {
            ReadKey();
            keyInform = new Tuple<bool, string>(isValid, msg);
            return keyInform;
        }

        private void ReadKey()
        {
            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\ProgrammeExe", true);

            if (registryKey != null)
            {
                string key = Convert.ToString(registryKey.GetValue("binaryIpOne"));
                if (!string.IsNullOrWhiteSpace(key))
                {
                    activeKey = KeyAlgorithm.BSAlgorithm(key);
                    string dateS = Convert.ToString(registryKey.GetValue("binaryIpTwo"));
                    if (!string.IsNullOrWhiteSpace(dateS))
                    {
                        sDate = Convert.ToDateTime(KeyAlgorithm.BSAlgorithm(dateS));
                        string countDays = Convert.ToString(registryKey.GetValue("binaryIpThree"));
                        if (!string.IsNullOrWhiteSpace(countDays))
                        {
                            _days = Convert.ToInt32(KeyAlgorithm.BSAlgorithm(countDays));
                            string dateE = Convert.ToString(registryKey.GetValue("binaryIpFour"));
                            if (!string.IsNullOrWhiteSpace(dateE))
                            {
                                eDate = Convert.ToDateTime(KeyAlgorithm.BSAlgorithm(dateE));
                                ValidateKey();
                            }
                            else
                            {
                                GetKeyActivationAlert();
                            }
                        }
                        else
                        {
                            GetKeyActivationAlert();
                        }
                    }
                    else
                    {
                        GetKeyActivationAlert();
                    }
                }
                else
                {
                    GetKeyActivationAlert();
                }
            }
            else
            {
                GetKeyActivationAlert();
            }
        }

        private void GetKeyActivationAlert()
        {
            isValid = false;
            msg = "License key is not activated.Please activate key.\nSupport contact: 'Infogenex CMS'";
        }

        private void ValidateKey()
        {
            //Check Date validation
            if ((DateTime.Today.Date < eDate) && (DateTime.Today.Date >= sDate))
            {
                ValidateActiveKey();
            }
            else
            {
                GetLicenseExpiredAlert();
            }
        }

        private void GetLicenseExpiredAlert()
        {
            isValid = false;
            msg = "Your license is expired.\nSupport contact: 'Infogenex CMS'";
        }

        private void ValidateActiveKey()
        {
            if (!string.IsNullOrWhiteSpace(activeKey))
            {
                DeGenerate(activeKey);
            }
            else
            {
                GetKeyActivationAlert();
            }
        }

        public bool DummyDecrypt(string activationKey)
        {
            DeGenerate(activationKey);
            return isValid;
        }

        private List<long> ConvertToListOfInt(long value)
        {
            int size = FindCount(value);
            long[] digits = new long[size];
            for (int i = size - 1; i >= 0; i--)
            {
                digits[i] = value % 10;
                value = value / 10;
            }
            return digits.ToList();
        }

        private int FindCount(long val)
        {
            return val < 10 ? 1
                : val < 100 ? 2
                : val < 1000 ? 3
                : val < 10000 ? 4
                : val < 100000 ? 5
                : val < 1000000 ? 6
                : val < 10000000 ? 7
                : val < 100000000 ? 8
                : val < 1000000000 ? 9
                : 10;
        }

        private void DeGenerate(string key)
        {
            StringBuilder firstKey = new StringBuilder();
            bool isFirstKey = false;
            int valOne = Array.IndexOf(charValues, key[0]);
            int valTwo = Array.IndexOf(charValues, key[1]);
            int charKeyOne = valOne + valTwo + 2;

            firstKey = firstKey.Append(key[3]);
            firstKey = firstKey.Append(key[4]);

            int numKeyOne = Convert.ToInt32(Convert.ToString(firstKey));
            if (numKeyOne == charKeyOne)
                isFirstKey = true;

            bool isSecondKey = false;
            StringBuilder secondKey = new StringBuilder();
            valOne = Array.IndexOf(charValues, key[6]);
            valTwo = Array.IndexOf(charValues, key[7]);
            int charKeyTwo = valOne + valTwo + 2;

            secondKey = secondKey.Append(key[9]);
            secondKey = secondKey.Append(key[10]);

            int numKeyTwo = Convert.ToInt32(Convert.ToString(secondKey));
            if (numKeyTwo == charKeyTwo)
                isSecondKey = true;

            if (isFirstKey && isSecondKey)
            {
                GetValidLicenseAlert();
                GetDays(key);
            }
            else
                GetInvalidLicenseAlert();
        }

        private void GetDays(string key)
        {
            if (key.Contains("LI"))
            {
                int index = key.IndexOf("LI");
                if (index > -1)
                {
                    string ds = key.Substring(index + 2, (key.Length - (index + 2)));
                    if (!string.IsNullOrWhiteSpace(ds))
                    {
                        _days = Convert.ToInt32(ds);
                    }
                }
            }
        }

        private void GetValidLicenseAlert()
        {
            isValid = true;
            msg = "Valid license key";
        }

        private void GetInvalidLicenseAlert()
        {
            isValid = false;
            msg = "InValid license key.Please activate key.\nContact 'Infogenex CMS'";
        }
    }
}
