﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LicenseKeyActivation
{
    public partial class ActivateKeyFrm : MetroFramework.Forms.MetroForm
    {
        private int _noOfDays;
        private string _actkey;
        private string _msg;

        private KeyEncryption _encryption;

        private Tuple<bool, string> _keyInfm;

        public Tuple<bool, string> KeyInform
        {
            get
            {
                return _keyInfm;
            }
            private set
            {
                _keyInfm = value;
            }
        }

        public ActivateKeyFrm()
        {
            InitializeComponent();
        }

        private string BinaryToString(string data)
        {
            List<Byte> byteList = new List<Byte>();

            for (int i = 0; i < data.Length; i += 8)
            {
                byteList.Add(Convert.ToByte(data.Substring(i, 8), 2));
            }
            return Encoding.ASCII.GetString(byteList.ToArray());
        }

        private void ctrlBtnActivate_Click(object sender, EventArgs e)
        {
            var stringKey = BinaryToString(ctrlTxtActKey.Text);
            _actkey = stringKey;
            if (!string.IsNullOrWhiteSpace(_actkey))
            {
                ActivateKey();
            }
            else
            {
                _msg = "Please enter key.";
                _keyInfm = new Tuple<bool, string>(false, _msg);
            }
        }

        private void ActivateKey()
        {
            _encryption = new KeyEncryption(_actkey);
            _keyInfm = _encryption.ActivateLicenseKey();
            if (_keyInfm.Item1 == true)
            {
                MessageBox.Show(_keyInfm.Item2, "Activate License - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show(_keyInfm.Item2, "Activate License - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ctrlTxtActKey.Focus();
                ctrlTxtActKey.Text = string.Empty;
            }
        }
    }
}
