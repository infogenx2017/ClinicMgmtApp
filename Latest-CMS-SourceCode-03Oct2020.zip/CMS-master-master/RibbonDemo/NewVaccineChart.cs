﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewVaccineChart : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public NewVaccineChart()
        {
            InitializeComponent();
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet(); DataTable dt = new DataTable();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VaccineChart_ID]
      ,A.Age
      ,V.Vaccine
,VC.VC_Government
      ,[VC_DueDate_indays]
  FROM [VC_std] VC 
  join [Age] A on A.Age_ID= VC.VC_Age 
  join [Vaccine] V on V.Vaccine_ID= VC.VC_Vaccine 
  order by A.Age_ID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds); //
                dt = ds.Tables[0];
                dt.Columns.Add("Government", System.Type.GetType("System.Boolean"));
                foreach (DataRow dr in dt.Rows)
                    dr[5] = dr[3].ToString() == "0" ? false : true;

                VaccineChartGrid.DataSource = dt;
                VaccineChartGrid.Columns[3].Visible = true;

            }
            LoadSerial();
        }

        void LoadGridContent(DataGridViewEditingControlShowingEventArgs e, string query, string ColName)
        {
            SqlDataReader dreader;
            SqlConnection conn = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            AutoCompleteStringCollection AgeSource = new AutoCompleteStringCollection();
            cmd.CommandText = query;
            conn.Open();
            dreader = cmd.ExecuteReader();
            if (dreader.HasRows == true)
            {
                while (dreader.Read())
                    AgeSource.Add(dreader[ColName].ToString());
            }
            else
            {
                MessageBox.Show("Data not Found");
            }
            dreader.Close();
            TextBox Medicine = e.Control as TextBox;
            //  Medicine.TextChanged += new EventHandler(Age_TextChanged);
            if (Medicine != null)
            {
                Medicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                Medicine.AutoCompleteCustomSource = AgeSource;
                Medicine.AutoCompleteSource = AutoCompleteSource.CustomSource;

            }
        }

        private void NewVaccineChart_Load(object sender, EventArgs e)
        {
            LoadGrid();
            dataGridView1_CellClick(null, null);
            //   txtvaccine.Focus();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;
            if (e != null) Rowidx = e.RowIndex;
            clear();
            int rowIndex = VaccineChartGrid.Rows[Rowidx].Index;
            VaccineChartGrid.Rows[Rowidx].Cells[0].Selected = true;

            if (VaccineChartGrid == null || e == null)
                return;
            if (VaccineChartGrid.Rows[Rowidx].Cells[0].Selected == true)
                if (Convert.ToString(VaccineChartGrid.Rows[Rowidx].Cells[0].Value) != String.Empty)
                    VaccineChartGrid.Rows[VaccineChartGrid.Rows.Count - 1].Cells[0].Value = VaccineChartGrid.Rows.Count.ToString();
            if ((bool)VaccineChartGrid.Rows[Rowidx].Cells[5].Selected == true)
            {
                VaccineChartGrid.Rows[Rowidx].Cells[3].Value = VaccineChartGrid.Rows[Rowidx].Cells[3].Value.ToString() == "0" ? "1" : "0";
                VaccineChartGrid.Rows[Rowidx].Cells[5].Value = VaccineChartGrid.Rows[Rowidx].Cells[3].Value.ToString() == "0" ? true : false;
                VaccineChartGrid.RefreshEdit(); VaccineChartGrid.Refresh();
            }
            //       if( ((DataGridViewCheckBoxCell)VaccineChartGrid.Rows[Rowidx].Cells[5]).State==DataGridViewElement)
            if (e.ColumnIndex == 5)
                foreach (DataGridViewRow dr in VaccineChartGrid.Rows)
                    if (dr.Cells[3].Value != null)
                        dr.Cells[5].Value = dr.Cells[3].Value.ToString() == "0" ? false : true;
            //if (e.ColumnIndex == 5)
            //{
            //    VaccineChartGrid.Rows[Rowidx].Cells[5].Value = !(bool)VaccineChartGrid.Rows[Rowidx].Cells[5].FormattedValue;
            //    VaccineChartGrid.Rows[Rowidx].Cells[3].Value = VaccineChartGrid.Rows[Rowidx].Cells[3].Value.ToString() == "0" ? "1" : "0";
            //}

            VaccineChartGrid.RefreshEdit(); VaccineChartGrid.Refresh();
        }
        private void clear()
        {
            lblRowID.Text = "";
            btnsave.Text = "Save";

        }
        private void LoadSerial()
        {
            int i = 1;
            foreach (DataGridViewRow row in VaccineChartGrid.Rows)
            {
                row.Cells[0].Value = i; i++;
                row.Cells[0].ReadOnly = true;

            }

        }
        private void VaccineChartGrid_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (VaccineChartGrid.CurrentCell.ColumnIndex == 1)
                LoadGridContent(e, @"Select Age from Age order by Age_ID asc", "Age");
            else if (VaccineChartGrid.CurrentCell.ColumnIndex == 2)
                LoadGridContent(e, @"Select Vaccine from Vaccine order by Vaccine_ID asc", "Vaccine");
            else
            {
                //TextBox prodCode = e.Control as TextBox;
                //if (prodCode != null)
                //{
                //    prodCode.AutoCompleteMode = AutoCompleteMode.None;
                //}
            }
        }


        public EventHandler Age_TextChanged { get; set; }

        private void VaccineChartGrid_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VaccineChartGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            LoadSerial();
        }

        private void VaccineChartGrid_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            LoadSerial();
        }

        private void VaccineChartGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            //LoadSerial();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (VaccineChartGrid.CurrentRow != null)
            {
                string _ID = GetVaccineID(VaccineChartGrid.CurrentRow.Cells[2].Value.ToString());
                int VaccineID = (_ID == "") ? 0 : Convert.ToInt32(_ID);
                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From VC_Std Where VC_Std.VC_Vaccine=@Vaccine", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Vaccine", VaccineID);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    clear();
                }
            }
        }

        public string GetAgeID(string Age)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Age_ID]
  FROM [Age] A where A.Age= '" + Age + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }
        public string GetVaccineID(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Vaccine_ID]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }
        private string SaveMathod(string ID, string Vaccine, string Age, string VCDate, int Government)
        {
            if (ID == "") ID = "0";
            using (con)
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("VC_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(ID));
                cmd.Parameters.AddWithValue("@vaccine", (Vaccine));
                cmd.Parameters.AddWithValue("@Age", (Age));
                cmd.Parameters.AddWithValue("@VC_DueDate", VCDate); cmd.Parameters.AddWithValue("@VC_Government", Government);
                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in VaccineChartGrid.Rows)
            {
                if (dr.Cells[2].Value != null)
                {
                    string ID = dr.Cells[0].Value.ToString();
                    string Vaccine = GetVaccineID(dr.Cells[2].Value.ToString().Trim());
                    string Age = GetAgeID(dr.Cells[1].Value.ToString().Trim());
                    int Govenment = Convert.ToInt32(dr.Cells[3].Value.ToString());
                    string VCDate = dr.Cells[4].Value.ToString();
                    SaveMathod(ID, Vaccine, Age, VCDate, Govenment);
                }
            }
            MessageBox.Show("Saved Successfully");
            LoadGrid();
            clear();

        }
    }
}
