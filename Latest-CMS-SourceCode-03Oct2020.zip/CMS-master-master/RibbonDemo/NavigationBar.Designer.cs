﻿namespace SVMApplication
{
    partial class NavigationBar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NavigationBar));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlToolStripDashboard = new System.Windows.Forms.ToolStrip();
            this.stripBtnDoctor = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.stripBtnPres = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.stripBtbPatient = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.stripBtnUsers = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.stripBtnExit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtnPin = new System.Windows.Forms.ToolStripButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.ctrlToolStripDashboard.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlToolStripDashboard, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.toolStrip1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(333, 472);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ctrlToolStripDashboard
            // 
            this.ctrlToolStripDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ctrlToolStripDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlToolStripDashboard.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ctrlToolStripDashboard.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stripBtnDoctor,
            this.toolStripSeparator1,
            this.stripBtnPres,
            this.toolStripSeparator2,
            this.stripBtbPatient,
            this.toolStripSeparator3,
            this.stripBtnUsers,
            this.toolStripSeparator4,
            this.stripBtnExit,
            this.toolStripSeparator5});
            this.ctrlToolStripDashboard.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.ctrlToolStripDashboard.Location = new System.Drawing.Point(0, 21);
            this.ctrlToolStripDashboard.Name = "ctrlToolStripDashboard";
            this.ctrlToolStripDashboard.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.ctrlToolStripDashboard.Size = new System.Drawing.Size(333, 451);
            this.ctrlToolStripDashboard.TabIndex = 1;
            this.ctrlToolStripDashboard.Text = "toolStrip1";
            this.ctrlToolStripDashboard.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // stripBtnDoctor
            // 
            this.stripBtnDoctor.AutoSize = false;
            this.stripBtnDoctor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.stripBtnDoctor.BackgroundImage = global::SVMApplication.Properties.Resources.doctors;
            this.stripBtnDoctor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtnDoctor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtnDoctor.Name = "stripBtnDoctor";
            this.stripBtnDoctor.Size = new System.Drawing.Size(230, 60);
            this.stripBtnDoctor.Text = "Doctors";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(331, 6);
            this.toolStripSeparator1.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // stripBtnPres
            // 
            this.stripBtnPres.AutoSize = false;
            this.stripBtnPres.BackgroundImage = global::SVMApplication.Properties.Resources.Booking;
            this.stripBtnPres.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtnPres.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtnPres.Name = "stripBtnPres";
            this.stripBtnPres.Size = new System.Drawing.Size(230, 60);
            this.stripBtnPres.Text = "toolStripButton1";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(331, 6);
            this.toolStripSeparator2.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // stripBtbPatient
            // 
            this.stripBtbPatient.AutoSize = false;
            this.stripBtbPatient.BackgroundImage = global::SVMApplication.Properties.Resources.patients;
            this.stripBtbPatient.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtbPatient.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtbPatient.Name = "stripBtbPatient";
            this.stripBtbPatient.Size = new System.Drawing.Size(230, 60);
            this.stripBtbPatient.Text = "toolStripButton1";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(331, 6);
            this.toolStripSeparator3.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // stripBtnUsers
            // 
            this.stripBtnUsers.AutoSize = false;
            this.stripBtnUsers.BackgroundImage = global::SVMApplication.Properties.Resources.usersbg;
            this.stripBtnUsers.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtnUsers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtnUsers.Name = "stripBtnUsers";
            this.stripBtnUsers.Size = new System.Drawing.Size(230, 60);
            this.stripBtnUsers.Text = "toolStripButton2";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(331, 6);
            this.toolStripSeparator4.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // stripBtnExit
            // 
            this.stripBtnExit.AutoSize = false;
            this.stripBtnExit.BackgroundImage = global::SVMApplication.Properties.Resources.exit;
            this.stripBtnExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stripBtnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.stripBtnExit.Name = "stripBtnExit";
            this.stripBtnExit.Size = new System.Drawing.Size(230, 60);
            this.stripBtnExit.Text = "toolStripButton1";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(331, 6);
            this.toolStripSeparator5.TextDirection = System.Windows.Forms.ToolStripTextDirection.Vertical90;
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnPin});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(333, 21);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbtnPin
            // 
            this.tsbtnPin.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnPin.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnPin.Image")));
            this.tsbtnPin.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnPin.Name = "tsbtnPin";
            this.tsbtnPin.Size = new System.Drawing.Size(23, 18);
            this.tsbtnPin.Text = "ToolStripButton1";
            this.tsbtnPin.ToolTipText = "Hide Navigation Panel";
            // 
            // NavigationBar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "NavigationBar";
            this.Size = new System.Drawing.Size(333, 472);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ctrlToolStripDashboard.ResumeLayout(false);
            this.ctrlToolStripDashboard.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStrip ctrlToolStripDashboard;
        private System.Windows.Forms.ToolStripButton stripBtnDoctor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton stripBtnPres;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton stripBtbPatient;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton stripBtnUsers;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton stripBtnExit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStrip toolStrip1;
        internal System.Windows.Forms.ToolStripButton tsbtnPin;
    }
}
