namespace SVMApplication
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.ribbonOrbMenuItem1 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator2 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton9 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton5 = new System.Windows.Forms.RibbonButton();
            this.ribbonOrbMenuItem2 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem3 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator8 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton8 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton10 = new System.Windows.Forms.RibbonButton();
            this.ribbonOrbMenuItem4 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator6 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonDescriptionMenuItem1 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem2 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem3 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem4 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem5 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonSeparator3 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonOrbMenuItem5 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator5 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonDescriptionMenuItem6 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem7 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonDescriptionMenuItem8 = new System.Windows.Forms.RibbonDescriptionMenuItem();
            this.ribbonOrbMenuItem6 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem7 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbMenuItem8 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonSeparator4 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonOrbMenuItem9 = new System.Windows.Forms.RibbonOrbMenuItem();
            this.ribbonOrbOptionButton1 = new System.Windows.Forms.RibbonOrbOptionButton();
            this.ribbonOrbOptionButton2 = new System.Windows.Forms.RibbonOrbOptionButton();
            this.ribbonOrbRecentItem1 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem2 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonOrbRecentItem3 = new System.Windows.Forms.RibbonOrbRecentItem();
            this.ribbonButton44 = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonCheckOld = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonPre = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonAppointment = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonSearch = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonDrug = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonPatient = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonCat = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonDig = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonMinMax = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonVaccine = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonbabyAge = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonVC = new System.Windows.Forms.RibbonButton();
            this.ctrlRibbHelp = new System.Windows.Forms.RibbonButton();
            this.ribbonTab4 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.ribbonButtonPrescription = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonAppointmentt = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonSearchh = new System.Windows.Forms.RibbonButton();
            this.ribbonTab2 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanelMaster = new System.Windows.Forms.RibbonPanel();
            this.ribbonButtonDrugg = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonPatientt = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonCategoryy = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonDiagnosiss = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonVaccinee = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonBabyAgee = new System.Windows.Forms.RibbonButton();
            this.ribbonButtonVCc = new System.Windows.Forms.RibbonButton();
            this.ribbonPanelAdmin = new System.Windows.Forms.RibbonPanel();
            this.ctrlBtnHospital = new System.Windows.Forms.RibbonButton();
            this.ribbonButton1 = new System.Windows.Forms.RibbonButton();
            this.ribbonBtnAdmin = new System.Windows.Forms.RibbonButton();
            this.panelMain = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.ribbonPanel11 = new System.Windows.Forms.RibbonPanel();
            this.lst = new System.Windows.Forms.RibbonButtonList();
            this.ribbonPanel2 = new System.Windows.Forms.RibbonPanel();
            this.ribbonPanel5 = new System.Windows.Forms.RibbonPanel();
            this.ribbonTab1 = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel1 = new System.Windows.Forms.RibbonPanel();
            this.ribbonPanel4 = new System.Windows.Forms.RibbonPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlTabHomeControl = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.ribbonButton2 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton18 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton4 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton46 = new System.Windows.Forms.RibbonButton();
            this.ribbonButton6 = new System.Windows.Forms.RibbonButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.ctrlTabHomeControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbon1
            // 
            this.ribbon1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            // 
            // 
            // 
            this.ribbon1.OrbDropDown.BorderRoundness = 8;
            this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem1);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem2);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem3);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem4);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonSeparator3);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem5);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem6);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem7);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem8);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonSeparator4);
            this.ribbon1.OrbDropDown.MenuItems.Add(this.ribbonOrbMenuItem9);
            this.ribbon1.OrbDropDown.Name = "";
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonOrbOptionButton1);
            this.ribbon1.OrbDropDown.OptionItems.Add(this.ribbonOrbOptionButton2);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem1);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem2);
            this.ribbon1.OrbDropDown.RecentItems.Add(this.ribbonOrbRecentItem3);
            this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 474);
            this.ribbon1.OrbDropDown.TabIndex = 0;
            this.ribbon1.OrbImage = null;
            this.ribbon1.OrbStyle = System.Windows.Forms.RibbonOrbStyle.Office_2010;
            this.ribbon1.OrbText = "FILE";
            this.ribbon1.OrbVisible = false;
            // 
            // 
            // 
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButton44);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonCheckOld);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonPre);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonAppointment);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonSearch);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonDrug);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonPatient);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonCat);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonDig);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonMinMax);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonVaccine);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonbabyAge);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ribbonButtonVC);
            this.ribbon1.QuickAcessToolbar.Items.Add(this.ctrlRibbHelp);
            this.ribbon1.RibbonTabFont = new System.Drawing.Font("Trebuchet MS", 9F);
            this.ribbon1.Size = new System.Drawing.Size(784, 150);
            this.ribbon1.TabIndex = 0;
            this.ribbon1.Tabs.Add(this.ribbonTab4);
            this.ribbon1.Tabs.Add(this.ribbonTab2);
            this.ribbon1.TabsMargin = new System.Windows.Forms.Padding(12, 26, 20, 0);
            this.ribbon1.Text = "ribbon1";
            this.ribbon1.ThemeColor = System.Windows.Forms.RibbonTheme.Green;
            // 
            // ribbonOrbMenuItem1
            // 
            this.ribbonOrbMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem1.DropDownItems.Add(this.ribbonSeparator2);
            this.ribbonOrbMenuItem1.DropDownItems.Add(this.ribbonButton9);
            this.ribbonOrbMenuItem1.DropDownItems.Add(this.ribbonButton5);
            this.ribbonOrbMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.Image")));
            this.ribbonOrbMenuItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem1.SmallImage")));
            this.ribbonOrbMenuItem1.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem1.Text = "New";
            // 
            // ribbonButton9
            // 
            this.ribbonButton9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.Image")));
            this.ribbonButton9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton9.SmallImage")));
            this.ribbonButton9.Text = "New Prescription";
            // 
            // ribbonButton5
            // 
            this.ribbonButton5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonButton5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.Image")));
            this.ribbonButton5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton5.SmallImage")));
            this.ribbonButton5.Text = "New Appointment";
            // 
            // ribbonOrbMenuItem2
            // 
            this.ribbonOrbMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.Image")));
            this.ribbonOrbMenuItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem2.SmallImage")));
            this.ribbonOrbMenuItem2.Text = "Clear";
            // 
            // ribbonOrbMenuItem3
            // 
            this.ribbonOrbMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem3.DropDownItems.Add(this.ribbonSeparator8);
            this.ribbonOrbMenuItem3.DropDownItems.Add(this.ribbonButton8);
            this.ribbonOrbMenuItem3.DropDownItems.Add(this.ribbonButton10);
            this.ribbonOrbMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.Image")));
            this.ribbonOrbMenuItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem3.SmallImage")));
            this.ribbonOrbMenuItem3.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem3.Text = "Save ";
            // 
            // ribbonButton8
            // 
            this.ribbonButton8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.Image")));
            this.ribbonButton8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton8.SmallImage")));
            this.ribbonButton8.Text = "Save Prescription";
            // 
            // ribbonButton10
            // 
            this.ribbonButton10.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.Image")));
            this.ribbonButton10.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton10.SmallImage")));
            this.ribbonButton10.Text = "Save Appointment";
            // 
            // ribbonOrbMenuItem4
            // 
            this.ribbonOrbMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonSeparator6);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem1);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem2);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem3);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem4);
            this.ribbonOrbMenuItem4.DropDownItems.Add(this.ribbonDescriptionMenuItem5);
            this.ribbonOrbMenuItem4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.Image")));
            this.ribbonOrbMenuItem4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem4.SmallImage")));
            this.ribbonOrbMenuItem4.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem4.Text = "Save as";
            // 
            // ribbonSeparator6
            // 
            this.ribbonSeparator6.Text = "Save a copy of the document";
            // 
            // ribbonDescriptionMenuItem1
            // 
            this.ribbonDescriptionMenuItem1.Description = "Save the document in the default file format";
            this.ribbonDescriptionMenuItem1.DescriptionBounds = new System.Drawing.Rectangle(46, 47, 311, 28);
            this.ribbonDescriptionMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem1.Image")));
            this.ribbonDescriptionMenuItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem1.SmallImage")));
            this.ribbonDescriptionMenuItem1.Text = "Word Document";
            // 
            // ribbonDescriptionMenuItem2
            // 
            this.ribbonDescriptionMenuItem2.Description = "Save the document as a template that can be used to format future documents";
            this.ribbonDescriptionMenuItem2.DescriptionBounds = new System.Drawing.Rectangle(46, 100, 311, 28);
            this.ribbonDescriptionMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem2.Image")));
            this.ribbonDescriptionMenuItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem2.SmallImage")));
            this.ribbonDescriptionMenuItem2.Text = "Word Template";
            // 
            // ribbonDescriptionMenuItem3
            // 
            this.ribbonDescriptionMenuItem3.Description = "Save a copy of the document that is fully compatible with  Word 93 - 2007";
            this.ribbonDescriptionMenuItem3.DescriptionBounds = new System.Drawing.Rectangle(46, 153, 311, 28);
            this.ribbonDescriptionMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem3.Image")));
            this.ribbonDescriptionMenuItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem3.SmallImage")));
            this.ribbonDescriptionMenuItem3.Text = "Word 97 - 2003";
            // 
            // ribbonDescriptionMenuItem4
            // 
            this.ribbonDescriptionMenuItem4.Description = "Learn about add-ins to save to other formats like XPS or PDF";
            this.ribbonDescriptionMenuItem4.DescriptionBounds = new System.Drawing.Rectangle(46, 206, 311, 28);
            this.ribbonDescriptionMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem4.Image")));
            this.ribbonDescriptionMenuItem4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem4.SmallImage")));
            this.ribbonDescriptionMenuItem4.Text = "Find add-ins for other file formats";
            // 
            // ribbonDescriptionMenuItem5
            // 
            this.ribbonDescriptionMenuItem5.Description = "Open the save as dialog to choose between the all available formats to save.";
            this.ribbonDescriptionMenuItem5.DescriptionBounds = new System.Drawing.Rectangle(46, 259, 311, 28);
            this.ribbonDescriptionMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem5.Image")));
            this.ribbonDescriptionMenuItem5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem5.SmallImage")));
            this.ribbonDescriptionMenuItem5.Text = "Other Formats";
            // 
            // ribbonOrbMenuItem5
            // 
            this.ribbonOrbMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonSeparator5);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem6);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem7);
            this.ribbonOrbMenuItem5.DropDownItems.Add(this.ribbonDescriptionMenuItem8);
            this.ribbonOrbMenuItem5.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.Image")));
            this.ribbonOrbMenuItem5.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem5.SmallImage")));
            this.ribbonOrbMenuItem5.Style = System.Windows.Forms.RibbonButtonStyle.SplitDropDown;
            this.ribbonOrbMenuItem5.Text = "Print";
            // 
            // ribbonSeparator5
            // 
            this.ribbonSeparator5.Text = "Preview and print the document";
            // 
            // ribbonDescriptionMenuItem6
            // 
            this.ribbonDescriptionMenuItem6.Description = "Select a printer, number of copies and other options before printing";
            this.ribbonDescriptionMenuItem6.DescriptionBounds = new System.Drawing.Rectangle(46, 45, 315, 28);
            this.ribbonDescriptionMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem6.Image")));
            this.ribbonDescriptionMenuItem6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem6.SmallImage")));
            this.ribbonDescriptionMenuItem6.Text = "Print";
            // 
            // ribbonDescriptionMenuItem7
            // 
            this.ribbonDescriptionMenuItem7.Description = "Send the document directly to the printer without making changes";
            this.ribbonDescriptionMenuItem7.DescriptionBounds = new System.Drawing.Rectangle(46, 97, 315, 28);
            this.ribbonDescriptionMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem7.Image")));
            this.ribbonDescriptionMenuItem7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem7.SmallImage")));
            this.ribbonDescriptionMenuItem7.Text = "Quick Print";
            // 
            // ribbonDescriptionMenuItem8
            // 
            this.ribbonDescriptionMenuItem8.Description = "Preview and make changes to pages before printing.";
            this.ribbonDescriptionMenuItem8.DescriptionBounds = new System.Drawing.Rectangle(46, 149, 315, 28);
            this.ribbonDescriptionMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonDescriptionMenuItem8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem8.Image")));
            this.ribbonDescriptionMenuItem8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonDescriptionMenuItem8.SmallImage")));
            this.ribbonDescriptionMenuItem8.Text = "Print Preview";
            // 
            // ribbonOrbMenuItem6
            // 
            this.ribbonOrbMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem6.Image")));
            this.ribbonOrbMenuItem6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem6.SmallImage")));
            this.ribbonOrbMenuItem6.Text = "Prepare";
            // 
            // ribbonOrbMenuItem7
            // 
            this.ribbonOrbMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem7.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem7.Image")));
            this.ribbonOrbMenuItem7.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem7.SmallImage")));
            this.ribbonOrbMenuItem7.Text = "Send";
            // 
            // ribbonOrbMenuItem8
            // 
            this.ribbonOrbMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem8.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem8.Image")));
            this.ribbonOrbMenuItem8.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem8.SmallImage")));
            this.ribbonOrbMenuItem8.Text = "Publish";
            // 
            // ribbonOrbMenuItem9
            // 
            this.ribbonOrbMenuItem9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left;
            this.ribbonOrbMenuItem9.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.Image")));
            this.ribbonOrbMenuItem9.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbMenuItem9.SmallImage")));
            this.ribbonOrbMenuItem9.Text = "Close";
            // 
            // ribbonOrbOptionButton1
            // 
            this.ribbonOrbOptionButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton1.Image")));
            this.ribbonOrbOptionButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton1.SmallImage")));
            this.ribbonOrbOptionButton1.Text = "Exit ";
            this.ribbonOrbOptionButton1.Click += new System.EventHandler(this.ribbonOrbOptionButton1_Click);
            // 
            // ribbonOrbOptionButton2
            // 
            this.ribbonOrbOptionButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton2.Image")));
            this.ribbonOrbOptionButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbOptionButton2.SmallImage")));
            this.ribbonOrbOptionButton2.Text = "Options";
            this.ribbonOrbOptionButton2.Click += new System.EventHandler(this.ribbonOrbOptionButton2_Click);
            // 
            // ribbonOrbRecentItem1
            // 
            this.ribbonOrbRecentItem1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.Image")));
            this.ribbonOrbRecentItem1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem1.SmallImage")));
            this.ribbonOrbRecentItem1.Text = "Recent Document 1";
            // 
            // ribbonOrbRecentItem2
            // 
            this.ribbonOrbRecentItem2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.Image")));
            this.ribbonOrbRecentItem2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem2.SmallImage")));
            this.ribbonOrbRecentItem2.Text = "Recent Document 2";
            // 
            // ribbonOrbRecentItem3
            // 
            this.ribbonOrbRecentItem3.Image = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.Image")));
            this.ribbonOrbRecentItem3.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonOrbRecentItem3.SmallImage")));
            this.ribbonOrbRecentItem3.Text = "Recent Document 3";
            // 
            // ribbonButton44
            // 
            this.ribbonButton44.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton44.Image")));
            this.ribbonButton44.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButton44.SmallImage = global::SVMApplication.Properties.Resources.Settings16;
            this.ribbonButton44.Text = "ribbonButton44";
            this.ribbonButton44.ToolTip = "Settings";
            this.ribbonButton44.ToolTipImage = global::SVMApplication.Properties.Resources.Settings16;
            this.ribbonButton44.ToolTipTitle = "Settings";
            this.ribbonButton44.Click += new System.EventHandler(this.ribbonButton44_Click);
            // 
            // ribbonButtonCheckOld
            // 
            this.ribbonButtonCheckOld.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonCheckOld.Image")));
            this.ribbonButtonCheckOld.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonCheckOld.SmallImage = global::SVMApplication.Properties.Resources.unCheck16;
            this.ribbonButtonCheckOld.Text = "";
            this.ribbonButtonCheckOld.ToolTip = "Old";
            this.ribbonButtonCheckOld.Click += new System.EventHandler(this.ribbonButtonCheckOld_Click);
            // 
            // ribbonButtonPre
            // 
            this.ribbonButtonPre.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonPre.Image")));
            this.ribbonButtonPre.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonPre.SmallImage = global::SVMApplication.Properties.Resources.pre16;
            this.ribbonButtonPre.Text = "";
            this.ribbonButtonPre.ToolTip = "To Create new Prescription please click here ..";
            this.ribbonButtonPre.ToolTipImage = global::SVMApplication.Properties.Resources.pre64;
            this.ribbonButtonPre.ToolTipTitle = "New Prescription";
            this.ribbonButtonPre.Click += new System.EventHandler(this.ribbonButton2_Click_1);
            // 
            // ribbonButtonAppointment
            // 
            this.ribbonButtonAppointment.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonAppointment.Image")));
            this.ribbonButtonAppointment.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonAppointment.SmallImage = global::SVMApplication.Properties.Resources.Appointment16;
            this.ribbonButtonAppointment.Text = "";
            this.ribbonButtonAppointment.ToolTip = "To Create new Appointment please click here ..";
            this.ribbonButtonAppointment.ToolTipImage = global::SVMApplication.Properties.Resources.Appointment64;
            this.ribbonButtonAppointment.ToolTipTitle = "New Appointment";
            this.ribbonButtonAppointment.Click += new System.EventHandler(this.ribbonButton46_Click);
            // 
            // ribbonButtonSearch
            // 
            this.ribbonButtonSearch.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonSearch.Image")));
            this.ribbonButtonSearch.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonSearch.SmallImage = global::SVMApplication.Properties.Resources.Findd16;
            this.ribbonButtonSearch.Text = "";
            this.ribbonButtonSearch.ToolTip = "To Search Patients details please click here ..";
            this.ribbonButtonSearch.ToolTipImage = global::SVMApplication.Properties.Resources.Findd64;
            this.ribbonButtonSearch.ToolTipTitle = "Search Patients";
            this.ribbonButtonSearch.Click += new System.EventHandler(this.ribbonButton4_Click_2);
            // 
            // ribbonButtonDrug
            // 
            this.ribbonButtonDrug.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonDrug.Image")));
            this.ribbonButtonDrug.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonDrug.SmallImage = global::SVMApplication.Properties.Resources.Drug16;
            this.ribbonButtonDrug.Text = "";
            this.ribbonButtonDrug.ToolTip = "To Add, Edit, Delete the Drug Details; Please click here ... ";
            this.ribbonButtonDrug.ToolTipImage = global::SVMApplication.Properties.Resources.Drug64;
            this.ribbonButtonDrug.ToolTipTitle = "Drug Master";
            this.ribbonButtonDrug.Click += new System.EventHandler(this.ribbonButton1_Click);
            // 
            // ribbonButtonPatient
            // 
            this.ribbonButtonPatient.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonPatient.Image")));
            this.ribbonButtonPatient.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonPatient.SmallImage = global::SVMApplication.Properties.Resources.patient16;
            this.ribbonButtonPatient.Text = "";
            this.ribbonButtonPatient.ToolTip = "To Add, Edit, Delete the Patient Details; Please click here ... ";
            this.ribbonButtonPatient.ToolTipImage = global::SVMApplication.Properties.Resources.patient64;
            this.ribbonButtonPatient.ToolTipTitle = "Patient Master";
            this.ribbonButtonPatient.Click += new System.EventHandler(this.ribbonButton3_Click);
            // 
            // ribbonButtonCat
            // 
            this.ribbonButtonCat.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonCat.Image")));
            this.ribbonButtonCat.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonCat.SmallImage = global::SVMApplication.Properties.Resources.cat16;
            this.ribbonButtonCat.Text = "";
            this.ribbonButtonCat.ToolTip = "To Add, Edit, Delete the Category Details; Please click here ... ";
            this.ribbonButtonCat.ToolTipImage = global::SVMApplication.Properties.Resources.cat64;
            this.ribbonButtonCat.ToolTipTitle = "Category Master";
            this.ribbonButtonCat.Click += new System.EventHandler(this.ribbonButton14_Click);
            // 
            // ribbonButtonDig
            // 
            this.ribbonButtonDig.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonDig.Image")));
            this.ribbonButtonDig.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonDig.SmallImage = global::SVMApplication.Properties.Resources.dig16;
            this.ribbonButtonDig.Text = "";
            this.ribbonButtonDig.ToolTip = "To Add, Edit, Delete the Diagnosis Details; Please click here ... ";
            this.ribbonButtonDig.ToolTipImage = global::SVMApplication.Properties.Resources.dig64;
            this.ribbonButtonDig.ToolTipTitle = "Diagnosis Master";
            this.ribbonButtonDig.Click += new System.EventHandler(this.ribbonButton15_Click);
            // 
            // ribbonButtonMinMax
            // 
            this.ribbonButtonMinMax.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonMinMax.Image")));
            this.ribbonButtonMinMax.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonMinMax.SmallImage = global::SVMApplication.Properties.Resources.maximize16;
            this.ribbonButtonMinMax.Text = "";
            this.ribbonButtonMinMax.ToolTip = "To Maximize Ribbon";
            this.ribbonButtonMinMax.ToolTipImage = global::SVMApplication.Properties.Resources.maximize16;
            this.ribbonButtonMinMax.ToolTipTitle = "Maximize";
            this.ribbonButtonMinMax.Click += new System.EventHandler(this.ribbonButtonMinMax_Click);
            // 
            // ribbonButtonVaccine
            // 
            this.ribbonButtonVaccine.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonVaccine.Image")));
            this.ribbonButtonVaccine.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonVaccine.SmallImage = global::SVMApplication.Properties.Resources.vaccine16;
            this.ribbonButtonVaccine.Text = "";
            this.ribbonButtonVaccine.ToolTip = "To Add, Edit, Delete the Vaccine Details; Please click here ... ";
            this.ribbonButtonVaccine.ToolTipImage = global::SVMApplication.Properties.Resources.vaccine64;
            this.ribbonButtonVaccine.ToolTipTitle = "Vaccine Master";
            this.ribbonButtonVaccine.Click += new System.EventHandler(this.ribbonButtonVaccine_Click);
            // 
            // ribbonButtonbabyAge
            // 
            this.ribbonButtonbabyAge.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonbabyAge.Image")));
            this.ribbonButtonbabyAge.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonbabyAge.SmallImage = global::SVMApplication.Properties.Resources.baby16;
            this.ribbonButtonbabyAge.Text = "";
            this.ribbonButtonbabyAge.ToolTip = "To Add, Edit, Delete the Age Details; Please click here ... ";
            this.ribbonButtonbabyAge.ToolTipImage = global::SVMApplication.Properties.Resources.baby64;
            this.ribbonButtonbabyAge.ToolTipTitle = "Baby Age Details";
            this.ribbonButtonbabyAge.Click += new System.EventHandler(this.ribbonButtonbabyAge_Click);
            // 
            // ribbonButtonVC
            // 
            this.ribbonButtonVC.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButtonVC.Image")));
            this.ribbonButtonVC.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ribbonButtonVC.SmallImage = global::SVMApplication.Properties.Resources.vc16;
            this.ribbonButtonVC.Text = "";
            this.ribbonButtonVC.ToolTip = "To Add, Edit, Delete the Vaccine Chart Details; Please click here ... ";
            this.ribbonButtonVC.ToolTipImage = global::SVMApplication.Properties.Resources.vc64;
            this.ribbonButtonVC.ToolTipTitle = "Vaccine Chart Details";
            this.ribbonButtonVC.Click += new System.EventHandler(this.ribbonButtonVCc_Click);
            // 
            // ctrlRibbHelp
            // 
            this.ctrlRibbHelp.Image = ((System.Drawing.Image)(resources.GetObject("ctrlRibbHelp.Image")));
            this.ctrlRibbHelp.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.ctrlRibbHelp.SmallImage = global::SVMApplication.Properties.Resources.vaccine16;
            this.ctrlRibbHelp.Text = "ribbonButton3";
            this.ctrlRibbHelp.Click += new System.EventHandler(this.ctrlRibbHelp_Click_1);
            // 
            // ribbonTab4
            // 
            this.ribbonTab4.Panels.Add(this.ribbonPanel3);
            this.ribbonTab4.Text = "HOME";
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.Items.Add(this.ribbonButtonPrescription);
            this.ribbonPanel3.Items.Add(this.ribbonButtonAppointmentt);
            this.ribbonPanel3.Items.Add(this.ribbonButtonSearchh);
            this.ribbonPanel3.Text = "";
            // 
            // ribbonButtonPrescription
            // 
            this.ribbonButtonPrescription.Image = global::SVMApplication.Properties.Resources.pre48;
            this.ribbonButtonPrescription.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonPrescription.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonPrescription.SmallImage")));
            this.ribbonButtonPrescription.Text = "Prescription";
            this.ribbonButtonPrescription.Click += new System.EventHandler(this.ribbonButton2_Click_1);
            // 
            // ribbonButtonAppointmentt
            // 
            this.ribbonButtonAppointmentt.Image = global::SVMApplication.Properties.Resources.Appointment48;
            this.ribbonButtonAppointmentt.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonAppointmentt.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonAppointmentt.SmallImage")));
            this.ribbonButtonAppointmentt.Text = "Appointment";
            this.ribbonButtonAppointmentt.Click += new System.EventHandler(this.ribbonButton46_Click);
            // 
            // ribbonButtonSearchh
            // 
            this.ribbonButtonSearchh.Image = global::SVMApplication.Properties.Resources.Findd48;
            this.ribbonButtonSearchh.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonSearchh.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonSearchh.SmallImage")));
            this.ribbonButtonSearchh.Text = "Search";
            this.ribbonButtonSearchh.Click += new System.EventHandler(this.ribbonButton4_Click_2);
            // 
            // ribbonTab2
            // 
            this.ribbonTab2.Panels.Add(this.ribbonPanelMaster);
            this.ribbonTab2.Panels.Add(this.ribbonPanelAdmin);
            this.ribbonTab2.Text = "MASTER";
            // 
            // ribbonPanelMaster
            // 
            this.ribbonPanelMaster.ButtonMoreVisible = false;
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonDrugg);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonPatientt);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonCategoryy);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonDiagnosiss);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonVaccinee);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonBabyAgee);
            this.ribbonPanelMaster.Items.Add(this.ribbonButtonVCc);
            this.ribbonPanelMaster.Text = "";
            // 
            // ribbonButtonDrugg
            // 
            this.ribbonButtonDrugg.Image = global::SVMApplication.Properties.Resources.Drug48;
            this.ribbonButtonDrugg.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonDrugg.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Medium;
            this.ribbonButtonDrugg.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonDrugg.SmallImage")));
            this.ribbonButtonDrugg.Text = "Drug";
            this.ribbonButtonDrugg.Click += new System.EventHandler(this.ribbonButton1_Click);
            // 
            // ribbonButtonPatientt
            // 
            this.ribbonButtonPatientt.Image = global::SVMApplication.Properties.Resources.patient48;
            this.ribbonButtonPatientt.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonPatientt.SmallImage = global::SVMApplication.Properties.Resources.patient16;
            this.ribbonButtonPatientt.Text = "Patient";
            this.ribbonButtonPatientt.Click += new System.EventHandler(this.ribbonButton3_Click);
            // 
            // ribbonButtonCategoryy
            // 
            this.ribbonButtonCategoryy.Image = global::SVMApplication.Properties.Resources.cat48;
            this.ribbonButtonCategoryy.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonCategoryy.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonCategoryy.SmallImage")));
            this.ribbonButtonCategoryy.Text = "Category";
            this.ribbonButtonCategoryy.Click += new System.EventHandler(this.ribbonButton14_Click);
            // 
            // ribbonButtonDiagnosiss
            // 
            this.ribbonButtonDiagnosiss.Image = global::SVMApplication.Properties.Resources.dig48;
            this.ribbonButtonDiagnosiss.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonDiagnosiss.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonDiagnosiss.SmallImage")));
            this.ribbonButtonDiagnosiss.Text = "Diagnosis";
            this.ribbonButtonDiagnosiss.Click += new System.EventHandler(this.ribbonButton15_Click);
            // 
            // ribbonButtonVaccinee
            // 
            this.ribbonButtonVaccinee.Image = global::SVMApplication.Properties.Resources.vaccine48;
            this.ribbonButtonVaccinee.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonVaccinee.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonVaccinee.SmallImage")));
            this.ribbonButtonVaccinee.Text = "Vaccine";
            this.ribbonButtonVaccinee.Click += new System.EventHandler(this.ribbonButtonVaccine_Click);
            // 
            // ribbonButtonBabyAgee
            // 
            this.ribbonButtonBabyAgee.Image = global::SVMApplication.Properties.Resources.baby48;
            this.ribbonButtonBabyAgee.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonBabyAgee.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonBabyAgee.SmallImage")));
            this.ribbonButtonBabyAgee.Text = "Age";
            this.ribbonButtonBabyAgee.Click += new System.EventHandler(this.ribbonButtonbabyAge_Click);
            // 
            // ribbonButtonVCc
            // 
            this.ribbonButtonVCc.Image = global::SVMApplication.Properties.Resources.vc48;
            this.ribbonButtonVCc.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButtonVCc.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButtonVCc.SmallImage")));
            this.ribbonButtonVCc.Text = "Vaccine Chart";
            this.ribbonButtonVCc.Click += new System.EventHandler(this.ribbonButtonVCc_Click);
            // 
            // ribbonPanelAdmin
            // 
            this.ribbonPanelAdmin.Items.Add(this.ctrlBtnHospital);
            this.ribbonPanelAdmin.Items.Add(this.ribbonBtnAdmin);
            this.ribbonPanelAdmin.Text = "";
            // 
            // ctrlBtnHospital
            // 
            this.ctrlBtnHospital.DropDownItems.Add(this.ribbonButton1);
            this.ctrlBtnHospital.Image = global::SVMApplication.Properties.Resources.vaccine48;
            this.ctrlBtnHospital.SmallImage = ((System.Drawing.Image)(resources.GetObject("ctrlBtnHospital.SmallImage")));
            this.ctrlBtnHospital.Text = "Hospital";
            this.ctrlBtnHospital.Click += new System.EventHandler(this.ribbonButtonHospital_Click);
            // 
            // ribbonButton1
            // 
            this.ribbonButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.Image")));
            this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
            this.ribbonButton1.Text = "ribbonButton1";
            // 
            // ribbonBtnAdmin
            // 
            this.ribbonBtnAdmin.Image = global::SVMApplication.Properties.Resources.patient48;
            this.ribbonBtnAdmin.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonBtnAdmin.SmallImage")));
            this.ribbonBtnAdmin.Text = "User";
            this.ribbonBtnAdmin.Click += new System.EventHandler(this.ribbonBtnAdmin_Click);
            // 
            // panelMain
            // 
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(200, 100);
            this.panelMain.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Location = new System.Drawing.Point(0, 539);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(784, 30);
            this.statusStrip1.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 6000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // ribbonPanel11
            // 
            this.ribbonPanel11.ButtonMoreVisible = false;
            this.ribbonPanel11.Text = "";
            // 
            // lst
            // 
            this.lst.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.lst.FlowToBottom = false;
            this.lst.ItemsSizeInDropwDownMode = new System.Drawing.Size(7, 5);
            this.lst.MaxSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.lst.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Compact;
            this.lst.Text = "ribbonButtonList1";
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.Text = "Search";
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.ButtonMoreVisible = false;
            this.ribbonPanel5.Text = "Appointment";
            // 
            // ribbonTab1
            // 
            this.ribbonTab1.Panels.Add(this.ribbonPanel1);
            this.ribbonTab1.Panels.Add(this.ribbonPanel5);
            this.ribbonTab1.Panels.Add(this.ribbonPanel2);
            this.ribbonTab1.Panels.Add(this.ribbonPanel4);
            this.ribbonTab1.Panels.Add(this.ribbonPanel11);
            this.ribbonTab1.Text = "HOME";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.ButtonMoreVisible = false;
            this.ribbonPanel1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPanel1.Image")));
            this.ribbonPanel1.Text = "Prescription";
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.FlowsTo = System.Windows.Forms.RibbonPanelFlowDirection.Right;
            this.ribbonPanel4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPanel4.Image")));
            this.ribbonPanel4.Text = "Today visited Pacients";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlTabHomeControl, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 150);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(784, 569);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // ctrlTabHomeControl
            // 
            this.ctrlTabHomeControl.Controls.Add(this.metroTabPage1);
            this.ctrlTabHomeControl.Controls.Add(this.metroTabPage2);
            this.ctrlTabHomeControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTabHomeControl.Location = new System.Drawing.Point(3, 3);
            this.ctrlTabHomeControl.Name = "ctrlTabHomeControl";
            this.ctrlTabHomeControl.SelectedIndex = 0;
            this.ctrlTabHomeControl.Size = new System.Drawing.Size(778, 533);
            this.ctrlTabHomeControl.TabIndex = 0;
            this.ctrlTabHomeControl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ctrlTabHomeControl.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ctrlTabHomeControl.SelectedIndexChanged += new System.EventHandler(this.ctrlTabHomeControl_SelectedIndexChanged);
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(770, 494);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "metroTabPage1";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 35);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(770, 494);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "metroTabPage2";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            // 
            // ribbonButton2
            // 
            this.ribbonButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.Image")));
            this.ribbonButton2.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
            this.ribbonButton2.Text = "New";
            this.ribbonButton2.Click += new System.EventHandler(this.ribbonButton2_Click_1);
            // 
            // ribbonButton18
            // 
            this.ribbonButton18.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.Image")));
            this.ribbonButton18.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton18.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton18.SmallImage")));
            this.ribbonButton18.Text = "Alert!";
            this.ribbonButton18.Visible = false;
            // 
            // ribbonButton4
            // 
            this.ribbonButton4.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.Image")));
            this.ribbonButton4.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton4.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton4.SmallImage")));
            this.ribbonButton4.Text = "Search";
            this.ribbonButton4.Click += new System.EventHandler(this.ribbonButton4_Click_2);
            // 
            // ribbonButton46
            // 
            this.ribbonButton46.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.Image")));
            this.ribbonButton46.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton46.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton46.SmallImage")));
            this.ribbonButton46.Text = "New";
            this.ribbonButton46.ToolTip = "Find";
            this.ribbonButton46.Click += new System.EventHandler(this.ribbonButton46_Click);
            // 
            // ribbonButton6
            // 
            this.ribbonButton6.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.Image")));
            this.ribbonButton6.MinSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large;
            this.ribbonButton6.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton6.SmallImage")));
            this.ribbonButton6.Text = "New";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 719);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.ribbon1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 758);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Infogenx CMS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseClick);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ctrlTabHomeControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        protected System.Windows.Forms.Ribbon ribbon1;
        private System.Windows.Forms.RibbonButton ribbonButton44;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem1;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem2;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem3;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem4;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator3;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem5;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem6;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem7;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem8;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator4;
        private System.Windows.Forms.RibbonOrbMenuItem ribbonOrbMenuItem9;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem1;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem2;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem3;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem4;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem5;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator5;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem6;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem7;
        private System.Windows.Forms.RibbonDescriptionMenuItem ribbonDescriptionMenuItem8;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator6;
        private System.Windows.Forms.RibbonOrbOptionButton ribbonOrbOptionButton1;
        private System.Windows.Forms.RibbonOrbOptionButton ribbonOrbOptionButton2;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem1;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem2;
        private System.Windows.Forms.RibbonOrbRecentItem ribbonOrbRecentItem3;
        public System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.RibbonTab ribbonTab2;
        private System.Windows.Forms.RibbonPanel ribbonPanelMaster;
        private System.Windows.Forms.RibbonButton ribbonButtonDrugg;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator2;
        private System.Windows.Forms.RibbonButton ribbonButton9;
        private System.Windows.Forms.RibbonButton ribbonButton5;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator8;
        private System.Windows.Forms.RibbonButton ribbonButton8;
        private System.Windows.Forms.RibbonButton ribbonButton10;
        private System.Windows.Forms.RibbonButton ribbonButton2;
        private System.Windows.Forms.RibbonPanel ribbonPanel11;
        private System.Windows.Forms.RibbonButton ribbonButton18;
        private System.Windows.Forms.RibbonPanel ribbonPanel4;
        private System.Windows.Forms.RibbonButtonList lst;
        private System.Windows.Forms.RibbonPanel ribbonPanel2;
        private System.Windows.Forms.RibbonButton ribbonButton4;
        private System.Windows.Forms.RibbonPanel ribbonPanel5;
        private System.Windows.Forms.RibbonButton ribbonButton46;
        private System.Windows.Forms.RibbonPanel ribbonPanel1;
        private System.Windows.Forms.RibbonButton ribbonButton6;
        private System.Windows.Forms.RibbonTab ribbonTab1;
        private System.Windows.Forms.RibbonTab ribbonTab4;
        private System.Windows.Forms.RibbonPanel ribbonPanel3;
        private System.Windows.Forms.RibbonButton ribbonButtonPrescription;
        private System.Windows.Forms.RibbonButton ribbonButtonCheckOld;
        private System.Windows.Forms.RibbonButton ribbonButtonPre;
        private System.Windows.Forms.RibbonButton ribbonButtonDrug;
        private System.Windows.Forms.RibbonButton ribbonButtonPatient;
        private System.Windows.Forms.RibbonButton ribbonButtonAppointment;
        private System.Windows.Forms.RibbonButton ribbonButtonSearch;
        private System.Windows.Forms.RibbonButton ribbonButtonDig;
        private System.Windows.Forms.RibbonButton ribbonButtonCat;
        private System.Windows.Forms.RibbonButton ribbonButtonMinMax;
        private System.Windows.Forms.RibbonButton ribbonButtonAppointmentt;
        private System.Windows.Forms.RibbonButton ribbonButtonSearchh;
        private System.Windows.Forms.RibbonButton ribbonButtonVaccine;
        private System.Windows.Forms.RibbonButton ribbonButtonbabyAge;
        private System.Windows.Forms.RibbonButton ribbonButtonVC;
        private System.Windows.Forms.RibbonButton ribbonButtonPatientt;
        private System.Windows.Forms.RibbonButton ribbonButtonCategoryy;
        private System.Windows.Forms.RibbonButton ribbonButtonDiagnosiss;
        private System.Windows.Forms.RibbonButton ribbonButtonVaccinee;
        private System.Windows.Forms.RibbonButton ribbonButtonBabyAgee;
        private System.Windows.Forms.RibbonButton ribbonButtonVCc;
        private System.Windows.Forms.RibbonPanel ribbonPanelAdmin;
        private System.Windows.Forms.RibbonButton ctrlBtnHospital;
        private System.Windows.Forms.RibbonButton ribbonButton1;
        private System.Windows.Forms.RibbonButton ribbonBtnAdmin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroTabControl ctrlTabHomeControl;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private System.Windows.Forms.RibbonButton ctrlRibbHelp;
    }
}