﻿using MetroFramework.Drawing;

namespace SVMApplication
{
    partial class NewDiagnosis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtDiagnosisName = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.txtClinicalNotes = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.txtAdviceTamil = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.txtAdviceEnglish = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.btnCloe = new MetroFramework.Controls.MetroButton();
            this.DiagnosisGrid = new System.Windows.Forms.DataGridView();
            this.btnNew = new MetroFramework.Controls.MetroButton();
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.ctrlAddClinical = new System.Windows.Forms.PictureBox();
            this.ctrlAddAdviceEnglish = new System.Windows.Forms.PictureBox();
            this.ctrlAddAdviceTamil = new System.Windows.Forms.PictureBox();
            this.metroPanel1.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddClinical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddAdviceEnglish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddAdviceTamil)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 244);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(71, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Diagnosis :";
            // 
            // txtDiagnosisName
            // 
            this.txtDiagnosisName.Location = new System.Drawing.Point(100, 243);
            this.txtDiagnosisName.Name = "txtDiagnosisName";
            this.txtDiagnosisName.PromptText = "Please enter diagnosis ...";
            this.txtDiagnosisName.Size = new System.Drawing.Size(726, 23);
            this.txtDiagnosisName.TabIndex = 1;
            this.txtDiagnosisName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtDiagnosisName_KeyDown);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.txtClinicalNotes);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 295);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(388, 311);
            this.metroPanel1.TabIndex = 2;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // txtClinicalNotes
            // 
            this.txtClinicalNotes.Location = new System.Drawing.Point(3, 3);
            this.txtClinicalNotes.Multiline = true;
            this.txtClinicalNotes.Name = "txtClinicalNotes";
            this.txtClinicalNotes.PromptText = "Please enter Clinical Notes ...";
            this.txtClinicalNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtClinicalNotes.Size = new System.Drawing.Size(382, 305);
            this.txtClinicalNotes.TabIndex = 2;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.metroPanel2.Controls.Add(this.txtAdviceTamil);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(417, 295);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(409, 144);
            this.metroPanel2.TabIndex = 2;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // txtAdviceTamil
            // 
            this.txtAdviceTamil.Location = new System.Drawing.Point(3, 3);
            this.txtAdviceTamil.Multiline = true;
            this.txtAdviceTamil.Name = "txtAdviceTamil";
            this.txtAdviceTamil.PromptText = "Please enter Advice Tamil ...";
            this.txtAdviceTamil.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAdviceTamil.Size = new System.Drawing.Size(403, 138);
            this.txtAdviceTamil.TabIndex = 3;
            // 
            // metroPanel3
            // 
            this.metroPanel3.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.metroPanel3.Controls.Add(this.txtAdviceEnglish);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(417, 464);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(409, 142);
            this.metroPanel3.TabIndex = 2;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // txtAdviceEnglish
            // 
            this.txtAdviceEnglish.Location = new System.Drawing.Point(3, 3);
            this.txtAdviceEnglish.Multiline = true;
            this.txtAdviceEnglish.Name = "txtAdviceEnglish";
            this.txtAdviceEnglish.PromptText = "Please enter Advice English ...";
            this.txtAdviceEnglish.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAdviceEnglish.Size = new System.Drawing.Size(403, 136);
            this.txtAdviceEnglish.TabIndex = 4;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 273);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(95, 19);
            this.metroLabel2.TabIndex = 0;
            this.metroLabel2.Text = "Clinical Notes :";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(417, 273);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(89, 19);
            this.metroLabel3.TabIndex = 0;
            this.metroLabel3.Text = "Advice Tamil :";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(417, 442);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(99, 19);
            this.metroLabel4.TabIndex = 0;
            this.metroLabel4.Text = "Advice English :";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(586, 618);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(667, 618);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnCloe
            // 
            this.btnCloe.Location = new System.Drawing.Point(748, 618);
            this.btnCloe.Name = "btnCloe";
            this.btnCloe.Size = new System.Drawing.Size(75, 23);
            this.btnCloe.TabIndex = 5;
            this.btnCloe.Text = "Close";
            this.btnCloe.Click += new System.EventHandler(this.btnCloe_Click);
            // 
            // DiagnosisGrid
            // 
            this.DiagnosisGrid.AllowUserToAddRows = false;
            this.DiagnosisGrid.AllowUserToDeleteRows = false;
            this.DiagnosisGrid.AllowUserToResizeRows = false;
            this.DiagnosisGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DiagnosisGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DiagnosisGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DiagnosisGrid.Location = new System.Drawing.Point(23, 63);
            this.DiagnosisGrid.Name = "DiagnosisGrid";
            this.DiagnosisGrid.RowHeadersVisible = false;
            this.DiagnosisGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DiagnosisGrid.Size = new System.Drawing.Size(803, 164);
            this.DiagnosisGrid.TabIndex = 6;
            this.DiagnosisGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DiagnosisGrid_CellClick);
            this.DiagnosisGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DiagnosisGrid_CellContentClick);
            this.DiagnosisGrid.SelectionChanged += new System.EventHandler(this.DiagnosisGrid_SelectionChanged);
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(505, 618);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 4;
            this.btnNew.Text = "New";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(23, 618);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(21, 19);
            this.lblRowID.TabIndex = 0;
            this.lblRowID.Text = "....";
            this.lblRowID.Visible = false;
            // 
            // ctrlAddClinical
            // 
            this.ctrlAddClinical.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlAddClinical.BackColor = System.Drawing.Color.Transparent;
            this.ctrlAddClinical.Image = global::SVMApplication.Properties.Resources.Add16;
            this.ctrlAddClinical.Location = new System.Drawing.Point(394, 279);
            this.ctrlAddClinical.Name = "ctrlAddClinical";
            this.ctrlAddClinical.Size = new System.Drawing.Size(16, 16);
            this.ctrlAddClinical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ctrlAddClinical.TabIndex = 219;
            this.ctrlAddClinical.TabStop = false;
            this.ctrlAddClinical.Click += new System.EventHandler(this.ctrlAddClinical_Click);
            // 
            // ctrlAddAdviceEnglish
            // 
            this.ctrlAddAdviceEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlAddAdviceEnglish.BackColor = System.Drawing.Color.Transparent;
            this.ctrlAddAdviceEnglish.Image = global::SVMApplication.Properties.Resources.Add16;
            this.ctrlAddAdviceEnglish.Location = new System.Drawing.Point(807, 445);
            this.ctrlAddAdviceEnglish.Name = "ctrlAddAdviceEnglish";
            this.ctrlAddAdviceEnglish.Size = new System.Drawing.Size(16, 16);
            this.ctrlAddAdviceEnglish.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ctrlAddAdviceEnglish.TabIndex = 219;
            this.ctrlAddAdviceEnglish.TabStop = false;
            this.ctrlAddAdviceEnglish.Click += new System.EventHandler(this.ctrlAddAdviceEnglish_Click);
            // 
            // ctrlAddAdviceTamil
            // 
            this.ctrlAddAdviceTamil.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlAddAdviceTamil.BackColor = System.Drawing.Color.Transparent;
            this.ctrlAddAdviceTamil.Image = global::SVMApplication.Properties.Resources.Add16;
            this.ctrlAddAdviceTamil.Location = new System.Drawing.Point(807, 279);
            this.ctrlAddAdviceTamil.Name = "ctrlAddAdviceTamil";
            this.ctrlAddAdviceTamil.Size = new System.Drawing.Size(16, 16);
            this.ctrlAddAdviceTamil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ctrlAddAdviceTamil.TabIndex = 219;
            this.ctrlAddAdviceTamil.TabStop = false;
            this.ctrlAddAdviceTamil.Click += new System.EventHandler(this.ctrlAddAdviceTamil_Click);
            // 
            // NewDiagnosis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 663);
            this.Controls.Add(this.ctrlAddAdviceTamil);
            this.Controls.Add(this.ctrlAddAdviceEnglish);
            this.Controls.Add(this.ctrlAddClinical);
            this.Controls.Add(this.DiagnosisGrid);
            this.Controls.Add(this.btnCloe);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.metroPanel2);
            this.Controls.Add(this.metroPanel3);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtDiagnosisName);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.metroLabel1);
            this.MaximizeBox = false;
            this.Name = "NewDiagnosis";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Diagnosis ...";
            this.Load += new System.EventHandler(this.NewDiagnosis_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddClinical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddAdviceEnglish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlAddAdviceTamil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtDiagnosisName;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroTextBox txtClinicalNotes;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroTextBox txtAdviceTamil;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroTextBox txtAdviceEnglish;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroButton btnCloe;
        private System.Windows.Forms.DataGridView DiagnosisGrid;
        private MetroFramework.Controls.MetroButton btnNew;
        private MetroFramework.Controls.MetroLabel lblRowID;
        private System.Windows.Forms.PictureBox ctrlAddClinical;
        private System.Windows.Forms.PictureBox ctrlAddAdviceEnglish;
        private System.Windows.Forms.PictureBox ctrlAddAdviceTamil;
    }
}