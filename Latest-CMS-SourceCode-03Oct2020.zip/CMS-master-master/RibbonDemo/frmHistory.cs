﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmHistory : MetroFramework.Forms.MetroForm
    {
        PersonalInformation personalInformation = null;
        bool isOldChecked = false;
       
        public frmHistory(ref PersonalInformation personalInfo,bool isOld)
        {
            InitializeComponent();
            personalInformation = personalInfo;
            isOldChecked = isOld;


        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            personalInformation.BirthHistory = ctrltxtBirthHistory.Text;
            personalInformation.FamilyHistory = ctrltxtFamilyHistory.Text;
            personalInformation.PastIllness = ctrltxtillness.Text;
            this.DialogResult = DialogResult.OK;
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void FrmHistory_Load(object sender, EventArgs e)
        {
            if (true)
            {
                ctrltxtBirthHistory.Text = personalInformation.BirthHistory;
                ctrltxtFamilyHistory.Text = personalInformation.FamilyHistory;
                ctrltxtillness.Text = personalInformation.PastIllness;
            }
        }
    }
}
