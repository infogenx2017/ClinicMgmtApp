﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace SVMApplication
{
    public partial class NewDiagnosis : MetroFramework.Forms.MetroForm
    {
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public string Clinicalfilelocation = ConfigurationManager.AppSettings["Clinicalfilelocation"].ToString();
        public string AdviceTamilfilelocation = ConfigurationManager.AppSettings["AdviceTamilfilelocation"].ToString();
        public string AdviceEnglishfilelocation = ConfigurationManager.AppSettings["AdviceEnglishfilelocation"].ToString();

        public NewDiagnosis()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                using (con)
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    SqlCommand cmd = new SqlCommand("SPUI_Diagnosis_new", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RowId", lblRowID.Text);
                    cmd.Parameters.AddWithValue("@Diagnosis", txtDiagnosisName.Text);
                    cmd.Parameters.AddWithValue("@Remark", "");
                    System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                    rtBox.Text = txtClinicalNotes.Text;
                    cmd.Parameters.AddWithValue("@DiagnosisHTML", rtBox.Rtf);
                    rtBox.Text = txtAdviceTamil.Text;
                    cmd.Parameters.AddWithValue("@AdviceTamil", rtBox.Rtf);
                    rtBox.Text = txtAdviceEnglish.Text;
                    cmd.Parameters.AddWithValue("@AdviceEnglish", rtBox.Rtf);
                    cmd.ExecuteNonQuery();
                    LoadGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void NewDiagnosis_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("SELECT  [RowId],[Diagnosis],[Remark],[DiagnosisHTML] as [Clinical Notes],[AdviceTamil],[AdviceEnglish]  FROM [Diagnosis] order by Diagnosis", con);
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DiagnosisGrid.DataSource = ds.Tables[0];
                }
                con.Close();
            }
            DiagnosisGrid.Rows[0].Selected = true;
        }

        private void DeleteRow(string lblRowID)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("delete [Diagnosis] where RowId =" + lblRowID, con);
                con.Open();
                cmd.ExecuteScalar();
                con.Close();
            }
        }

        private void DiagnosisGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if ( e.RowIndex > 0)
            {
                int _selecteRow = e.RowIndex;
                DataGridView _dgv = ((DataGridView)sender);
                lblRowID.Text = _dgv.Rows[_selecteRow].Cells[0].Value.ToString();
                txtDiagnosisName.Text = _dgv.Rows[_selecteRow].Cells[1].Value.ToString();
                System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[3].Value.ToString();
                txtClinicalNotes.Text = rtBox.Text;
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[4].Value.ToString();
                txtAdviceTamil.Text = rtBox.Text;
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[5].Value.ToString();
                txtAdviceEnglish.Text = rtBox.Text;
            }
        }

        private void DiagnosisGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView _dgv = ((DataGridView)sender);
            if (_dgv.SelectedRows.Count > 0 && e.RowIndex > 0)
            {
                int _selecteRow = e.RowIndex;
                lblRowID.Text = _dgv.Rows[_selecteRow].Cells[0].Value.ToString();
                txtDiagnosisName.Text = _dgv.Rows[_selecteRow].Cells[1].Value.ToString();
                System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[3].Value.ToString();
                txtClinicalNotes.Text = rtBox.Text;
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[4].Value.ToString();
                txtAdviceTamil.Text = rtBox.Text;
                rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[5].Value.ToString();
                txtAdviceEnglish.Text = rtBox.Text;
            }
        }

        private void btnCloe_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearALL();
            txtDiagnosisName.Focus();
        }

        private void ClearALL()
        {
            txtAdviceEnglish.Text = "";
            txtAdviceTamil.Text = "";
            txtClinicalNotes.Text = "";
            txtDiagnosisName.Text = "";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select max(RowId) from [Diagnosis]", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    int id = Convert.ToInt32(dr[0].ToString());
                    id = id + 1;
                    lblRowID.Text = id.ToString();
                }
                dr.Close();
                con.Close();
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteRow(lblRowID.Text);
            LoadGrid();
        }
        private void ctrlAddClinical_Click(object sender, EventArgs e)
        {
            AddfilesinTextBox(Clinicalfilelocation, txtClinicalNotes);
        }
        private void AddfilesinTextBox(string location, MetroFramework.Controls.MetroTextBox txt)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = location;
            openFileDialog1.Title = "Browse rtf Files";

            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;

            openFileDialog1.DefaultExt = "rtf";
            openFileDialog1.Filter = "Rtf files (*.rtf)|*.rtf";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            openFileDialog1.ReadOnlyChecked = true;
            openFileDialog1.ShowReadOnly = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Create the RichTextBox. (Requires a reference to System.Windows.Forms.)
                System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();

                // Get the contents of the RTF file. When the contents of the file are   
                // stored in the string (rtfText), the contents are encoded as UTF-16.  
                //List<string> rtfText = System.IO.File.ReadLines(openFileDialog1.FileName);

                rtBox.LoadFile(openFileDialog1.FileName);
                if (txt.Text == "") txt.Text = rtBox.Text.Replace("\n", System.Environment.NewLine);
                else
                    if (DialogResult.Yes == MessageBox.Show("Do you want to replace the Text?", "S V Medical Center", MessageBoxButtons.YesNo))
                        txt.Text = rtBox.Text.Replace("\n", System.Environment.NewLine);
                    else
                        txt.AppendText(rtBox.Text.Replace("\n", System.Environment.NewLine));
                txt.Focus();
            }
        }
        private void ctrlAddAdviceTamil_Click(object sender, EventArgs e)
        {
            AddfilesinTextBox(AdviceTamilfilelocation, txtAdviceTamil);
        }

        private void ctrlAddAdviceEnglish_Click(object sender, EventArgs e)
        {
            AddfilesinTextBox(AdviceEnglishfilelocation, txtAdviceEnglish);
        }

        private void DiagnosisGrid_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                DataGridView _dgv = ((DataGridView)sender);
                if (_dgv.SelectedRows.Count > 0)
                {
                    int _selecteRow = _dgv.SelectedRows[0].Index;
                    lblRowID.Text = _dgv.Rows[_selecteRow].Cells[0].Value.ToString();
                    txtDiagnosisName.Text = _dgv.Rows[_selecteRow].Cells[1].Value.ToString();
                    System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                    rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[3].Value.ToString();
                    txtClinicalNotes.Text = rtBox.Text;
                    rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[4].Value.ToString();
                    txtAdviceTamil.Text = rtBox.Text;
                    rtBox.Rtf = _dgv.Rows[_selecteRow].Cells[5].Value.ToString();
                    txtAdviceEnglish.Text = rtBox.Text;
                }
            }
            catch (Exception ex)
            {

                
            }
           
        }

        private void TxtDiagnosisName_KeyDown(object sender, KeyEventArgs e)
        {
            if(Keys.F3==e.KeyCode)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(constr))
                    {
                        DataTable dt = DiagnosisGrid.DataSource as DataTable;
                        con.Open();
                        SqlCommand cmd = new SqlCommand($"select top 1 * from Diagnosis where Diagnosis like'" +
                            $"{txtDiagnosisName.Text.Trim()}%' order by Diagnosis", con);
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            int id = Convert.ToInt32(dr[0].ToString());
                            var results = (from myRow in dt.AsEnumerable()
                                           where myRow.Field<int>("RowId") == id
                                           select myRow).FirstOrDefault();
                            if (results != null)
                            {
                                DiagnosisGrid.ClearSelection();
                                DiagnosisGrid.Rows[dt.Rows.IndexOf(results)].Selected = true;
                                DiagnosisGrid.FirstDisplayedScrollingRowIndex = DiagnosisGrid.SelectedRows[0].Index;
                            }
                        }
                        dr.Close();
                        con.Close();
                    }
                }
                catch (Exception)
                {

                }
              


               
               

             
                
            }
        }
    }
}
