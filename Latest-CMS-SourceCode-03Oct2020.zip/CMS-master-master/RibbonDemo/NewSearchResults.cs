﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class NewSearchResults : UserControl
    {
        public NewSearchResults()
        {
            InitializeComponent();
        }

        private void ctrldataGridSearch_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
