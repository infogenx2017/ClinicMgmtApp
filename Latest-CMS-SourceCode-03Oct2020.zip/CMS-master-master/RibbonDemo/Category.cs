﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class Category : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
        public Category()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtcat.Text != "" && txtcat.Text != "" && txtamt.Text != "")
            {
                if (btnsave.Text == "Save")
                {
                    if (CheckName())
                    {
                        btnsave.Text = "Update";
                        MessageBox.Show("Category Already exist");
                        return;
                    }
                    else
                    {
                        SaveMathod();
                        MessageBox.Show("Saved Successfully");
                    }
                }
                else
                {
                    SaveMathod();

                    MessageBox.Show("Updated Successfully");
                }
                LoadGrid();
                clear();
            }
            else
            {
                MessageBox.Show("Please Fill All Records");
            }
        }

        private bool CheckName()
        {
            bool rtnval = false;
            try
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select RowID,Category,Amount from AmountCategory Where Category=@category";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@category", txtcat.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rtnval = true;
                    lblRowID.Text = ds.Tables[0].Rows[0]["RowID"].ToString();
                    txtcat.Text = ds.Tables[0].Rows[0]["Category"].ToString();
                    txtamt.Text = ds.Tables[0].Rows[0]["Amount"].ToString();
                }
            }
            catch { lblRowID.Text = "1"; }
            return rtnval;
        }

        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select RowID,Category,Amount from AmountCategory order by RowID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                CategoryGrid.DataSource = ds.Tables[0];

            }


        }

        private string SaveMathod()
        {

            using (con)
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Category_SP", con);
                lblRowID.Text = (CategoryGrid.Rows.Count + 1).ToString();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RowID", lblRowID.Text);
                cmd.Parameters.AddWithValue("@Category", txtcat.Text);
                cmd.Parameters.AddWithValue("@Amount", txtamt.Text);

                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void clear()
        {
            lblRowID.Text = "";
            txtcat.Text = "";
            txtamt.Text = "";
            btnsave.Text = "Save";

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;
            if (e != null) Rowidx = e.RowIndex;
            clear();
            int rowIndex = CategoryGrid.Rows[Rowidx].Index;
            CategoryGrid.Rows[Rowidx].Cells[0].Selected = true;

            if (CategoryGrid == null)
                return;
            if (CategoryGrid.Rows[Rowidx].Cells[0].Selected == true)
            {

                if (Convert.ToString(CategoryGrid.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {

                    lblRowID.Text = CategoryGrid.Rows[Rowidx].Cells[0].Value.ToString();
                    txtcat.Text = CategoryGrid.Rows[Rowidx].Cells[1].Value.ToString();
                    txtamt.Text = CategoryGrid.Rows[Rowidx].Cells[2].Value.ToString();


                    btnsave.Text = "Update";
                }
                else
                    clear();
            }
            else
                clear();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtcat.Text != "" && lblRowID.Text != "")
            {
                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From AmountCategory Where RowID =@ROWID", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@RowID", lblRowID.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    clear();
                }
                else
                {
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void Category_Load(object sender, EventArgs e)
        {
            LoadGrid();
            dataGridView1_CellClick(null, null);
            txtcat.Focus();

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            //string res;
            //res = Convert.ToString(MessageBox.Show("Are You want to Exit", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information));
            //if (res == "Yes")
            //{
            this.Close();
            //}
            //else
            //{
            //}
        }

        private void txtcat_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

            }
            else if (e.KeyCode == Keys.Escape)
            {
                CategoryGrid.Focus();
            }
        }

        private void txtamt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtcat.Focus();
            }
        }

        private void btnclear_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                btnsave.Focus();
            }
        }

        private void button3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                btndelete.Focus();
            }
        }

        private void btndelete_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
                return;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                btnclear.Focus();
            }
        }

        private void btnsave_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
                return;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtamt.Focus();
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                btnexit.Focus();
            }
        }


    }
}
