﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;

namespace SVMApplication
{
    public partial class frmReortViewer : Form
    {
       // PrescriptionPrint prescriptionPrint = null;
        public DataSet PrescriptionDataset = null;
        public bool IsDirectPrint = false;
       
        public frmReortViewer()
        {
            InitializeComponent();
          //  prescriptionPrint = new PrescriptionPrint();
            PrescriptionDataset = new DataSet();
        }

        private void frmReortViewer_Load(object sender, EventArgs e)
        {
            if (IsDirectPrint)
                DirectPrintChecked();
            else
                ReportPrintwithPreview();
        }

        private void ReportPrintwithPreview()
        {
            var res = PrescriptionDataset.Tables["Details"];
            var res1 = PrescriptionDataset.Tables["Drugdetails"];


            var cr = new ReportDocument();
            cr.Load(@"C:\Report\PrescriptionPrint.rpt");
            cr.Database.Tables[0].SetDataSource(PrescriptionDataset.Tables["Details"]);
            cr.Database.Tables["Drugdetails"].SetDataSource(PrescriptionDataset.Tables["Drugdetails"]);
            ctrlViwerPrescritionreportViewer.ReportSource = null;
            ctrlViwerPrescritionreportViewer.ReportSource = cr;
            ctrlViwerPrescritionreportViewer.Refresh();


            foreach (var item in cr.Database.Tables)
            {
               
            } 

            //PrescriptionPrint rprt = new PrescriptionPrint();
            //rprt.Database.Tables["Details"].SetDataSource(PrescriptionDataset.Tables["Details"]);
            //rprt.Database.Tables["Drugdetails"].SetDataSource(PrescriptionDataset.Tables["Drugdetails"]);
            //ctrlViwerPrescritionreportViewer.ReportSource = null;
            //ctrlViwerPrescritionreportViewer.ReportSource = rprt;
            //ctrlViwerPrescritionreportViewer.Refresh();
            
        }


        private void DirectPrintChecked()
        {
            
            var rprt = new ReportDocument();
            rprt.Load(@"C:\Report\PrescriptionPrint.rpt");
            rprt.Database.Tables["Details"].SetDataSource(PrescriptionDataset.Tables["Details"]);
            rprt.Database.Tables["Drugdetails"].SetDataSource(PrescriptionDataset.Tables["Drugdetails"]);


            ctrlViwerPrescritionreportViewer.ReportSource = rprt;
            ctrlViwerPrescritionreportViewer.Refresh();
            rprt.PrintToPrinter(1, true, 1, 1);
            //ctrlViwerPrescritionreportViewer.Visible = false;
        }
    }
}
