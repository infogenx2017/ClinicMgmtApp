﻿namespace SVMApplication
{
    partial class frmNewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_CANCEL = new System.Windows.Forms.Button();
            this.BTN_ADD_CUSTOMER = new System.Windows.Forms.Button();
            this.ctrlTxtEMAIL = new System.Windows.Forms.TextBox();
            this.ctrlTxtUSERNAME = new System.Windows.Forms.TextBox();
            this.ctrlTxtFULLNAME = new System.Windows.Forms.TextBox();
            this.ctrlTxtTEL = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ctrlTxtPASSWORD = new System.Windows.Forms.TextBox();
            this.ctrlCbxUserType = new MetroFramework.Controls.MetroComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ctrlLblDoctorCode = new System.Windows.Forms.Label();
            this.ctrlTxtDoctorCode = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(94, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 20);
            this.label4.TabIndex = 26;
            this.label4.Text = "Email : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(113, 220);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Tel : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 20);
            this.label2.TabIndex = 24;
            this.label2.Text = "Full Name : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(55, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 23;
            this.label1.Text = "Username : ";
            // 
            // BTN_CANCEL
            // 
            this.BTN_CANCEL.BackColor = System.Drawing.Color.Black;
            this.BTN_CANCEL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.BTN_CANCEL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(74)))));
            this.BTN_CANCEL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.BTN_CANCEL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_CANCEL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_CANCEL.ForeColor = System.Drawing.Color.White;
            this.BTN_CANCEL.Location = new System.Drawing.Point(207, 378);
            this.BTN_CANCEL.Name = "BTN_CANCEL";
            this.BTN_CANCEL.Size = new System.Drawing.Size(75, 32);
            this.BTN_CANCEL.TabIndex = 22;
            this.BTN_CANCEL.Text = "Cancel";
            this.BTN_CANCEL.UseVisualStyleBackColor = false;
            this.BTN_CANCEL.Click += new System.EventHandler(this.BTN_CANCEL_Click);
            // 
            // BTN_ADD_CUSTOMER
            // 
            this.BTN_ADD_CUSTOMER.BackColor = System.Drawing.Color.Black;
            this.BTN_ADD_CUSTOMER.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.BTN_ADD_CUSTOMER.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(74)))));
            this.BTN_ADD_CUSTOMER.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(178)))), ((int)(((byte)(255)))));
            this.BTN_ADD_CUSTOMER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_ADD_CUSTOMER.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_ADD_CUSTOMER.ForeColor = System.Drawing.Color.White;
            this.BTN_ADD_CUSTOMER.Location = new System.Drawing.Point(297, 378);
            this.BTN_ADD_CUSTOMER.Name = "BTN_ADD_CUSTOMER";
            this.BTN_ADD_CUSTOMER.Size = new System.Drawing.Size(75, 32);
            this.BTN_ADD_CUSTOMER.TabIndex = 21;
            this.BTN_ADD_CUSTOMER.Text = "Add";
            this.BTN_ADD_CUSTOMER.UseVisualStyleBackColor = false;
            this.BTN_ADD_CUSTOMER.Click += new System.EventHandler(this.ctrlBtnAddUser_Click);
            // 
            // ctrlTxtEMAIL
            // 
            this.ctrlTxtEMAIL.Location = new System.Drawing.Point(182, 265);
            this.ctrlTxtEMAIL.Name = "ctrlTxtEMAIL";
            this.ctrlTxtEMAIL.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtEMAIL.TabIndex = 20;
            // 
            // ctrlTxtUSERNAME
            // 
            this.ctrlTxtUSERNAME.Location = new System.Drawing.Point(182, 87);
            this.ctrlTxtUSERNAME.Name = "ctrlTxtUSERNAME";
            this.ctrlTxtUSERNAME.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtUSERNAME.TabIndex = 19;
            // 
            // ctrlTxtFULLNAME
            // 
            this.ctrlTxtFULLNAME.Location = new System.Drawing.Point(182, 130);
            this.ctrlTxtFULLNAME.Name = "ctrlTxtFULLNAME";
            this.ctrlTxtFULLNAME.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtFULLNAME.TabIndex = 18;
            // 
            // ctrlTxtTEL
            // 
            this.ctrlTxtTEL.Location = new System.Drawing.Point(182, 220);
            this.ctrlTxtTEL.Name = "ctrlTxtTEL";
            this.ctrlTxtTEL.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtTEL.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(61, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 20);
            this.label5.TabIndex = 28;
            this.label5.Text = "Password : ";
            // 
            // ctrlTxtPASSWORD
            // 
            this.ctrlTxtPASSWORD.Location = new System.Drawing.Point(182, 177);
            this.ctrlTxtPASSWORD.Name = "ctrlTxtPASSWORD";
            this.ctrlTxtPASSWORD.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtPASSWORD.TabIndex = 27;
            // 
            // ctrlCbxUserType
            // 
            this.ctrlCbxUserType.FormattingEnabled = true;
            this.ctrlCbxUserType.ItemHeight = 23;
            this.ctrlCbxUserType.Location = new System.Drawing.Point(182, 304);
            this.ctrlCbxUserType.Name = "ctrlCbxUserType";
            this.ctrlCbxUserType.Size = new System.Drawing.Size(189, 29);
            this.ctrlCbxUserType.TabIndex = 29;
            this.ctrlCbxUserType.SelectedIndexChanged += new System.EventHandler(this.ctrlCbxUserType_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.TabIndex = 30;
            this.label6.Text = "User Type :";
            // 
            // ctrlLblDoctorCode
            // 
            this.ctrlLblDoctorCode.AutoSize = true;
            this.ctrlLblDoctorCode.BackColor = System.Drawing.Color.Transparent;
            this.ctrlLblDoctorCode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ctrlLblDoctorCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlLblDoctorCode.Location = new System.Drawing.Point(52, 338);
            this.ctrlLblDoctorCode.Name = "ctrlLblDoctorCode";
            this.ctrlLblDoctorCode.Size = new System.Drawing.Size(109, 20);
            this.ctrlLblDoctorCode.TabIndex = 32;
            this.ctrlLblDoctorCode.Text = "User Code : ";
            this.ctrlLblDoctorCode.Visible = false;
            // 
            // ctrlTxtDoctorCode
            // 
            this.ctrlTxtDoctorCode.Location = new System.Drawing.Point(182, 340);
            this.ctrlTxtDoctorCode.MaxLength = 3;
            this.ctrlTxtDoctorCode.Name = "ctrlTxtDoctorCode";
            this.ctrlTxtDoctorCode.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtDoctorCode.TabIndex = 31;
            this.ctrlTxtDoctorCode.Visible = false;
            // 
            // frmNewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 434);
            this.Controls.Add(this.ctrlLblDoctorCode);
            this.Controls.Add(this.ctrlTxtDoctorCode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ctrlCbxUserType);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ctrlTxtPASSWORD);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_CANCEL);
            this.Controls.Add(this.BTN_ADD_CUSTOMER);
            this.Controls.Add(this.ctrlTxtEMAIL);
            this.Controls.Add(this.ctrlTxtUSERNAME);
            this.Controls.Add(this.ctrlTxtFULLNAME);
            this.Controls.Add(this.ctrlTxtTEL);
            this.Name = "frmNewUser";
            this.Text = "New User";
            this.Load += new System.EventHandler(this.frmNewUser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_CANCEL;
        private System.Windows.Forms.Button BTN_ADD_CUSTOMER;
        private System.Windows.Forms.TextBox ctrlTxtEMAIL;
        private System.Windows.Forms.TextBox ctrlTxtUSERNAME;
        private System.Windows.Forms.TextBox ctrlTxtFULLNAME;
        private System.Windows.Forms.TextBox ctrlTxtTEL;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ctrlTxtPASSWORD;
        private MetroFramework.Controls.MetroComboBox ctrlCbxUserType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label ctrlLblDoctorCode;
        private System.Windows.Forms.TextBox ctrlTxtDoctorCode;
    }
}