﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using SVMApplication.Helper;

namespace SVMApplication
{
    public partial class NewAppointment : UserControl
    {
        int escapes = 0;
        
        public static string SetValueForEpresNo = "";
        public static string AppointmentNo = "";
        string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        string prescno = "", appointmentno = "", patientno = "";
        NewPrescription _pres = null;
        // int tableCount = 0;
        int yearDiff;
        int monthdiff;
        int daysdiff;
        string MaxSeq = string.Empty;
        string ApNo = string.Empty;
        AutoCompleteStringCollection appNo; public MainForm mAinFOrm = null;
        PersonalInformation personalInformation = new PersonalInformation();
       

        public string DoctorCode
        {
            get
            {

                if (string.IsNullOrWhiteSpace(ctrlCbxDoctor.GetSelectedValueAsString()))
                    return AppMain.DoctorCode;
                else
                    return ctrlCbxDoctor.GetSelectedValueAsString();
            }
        }

        public NewAppointment(NewPrescription pres)
        {
            InitializeComponent();
            mAinFOrm = pres.mAinFOrm;
            txtPhoneNo.MaxLength = 10;
            _pres = pres;
        }

        bool Save()
        {
            try
            {
                frmConfirmSave _frmConfirmSave = new frmConfirmSave();
                if (DialogResult.OK == _frmConfirmSave.ShowDialog())
                {
                    int status = 1;
                    status = ctrlCbxStatus.GetSelectedValueAsInt();
                    
                    SqlConnection con = new SqlConnection(constr);
                    {
                        prescno = txtPresNo.Text;
                        patientno = txtpatiantID.Text;
                        appointmentno = cmb_apno.Text;

                        SqlCommand cmd = new SqlCommand("SPUI_Prescription_NEW", con);
                        con.Open();
                        cmd.Parameters.AddWithValue("@EPresNo", txtPresNo.Text);
                        cmd.Parameters.AddWithValue("@ApNo", Convert.ToInt32(cmb_apno.Text));
                        cmd.Parameters.AddWithValue("@UpressNo", txtPresNo.Text);
                        cmd.Parameters.AddWithValue("@PatiantID", txtpatiantID.Text);
                        cmd.Parameters.AddWithValue("@Name", txtname.Text);
                        cmd.Parameters.AddWithValue("@LastName", "");
                        cmd.Parameters.AddWithValue("@MiddleName", "");
                        cmd.Parameters.AddWithValue("@Gender", genderComboBox.Text);
                        cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Text);
                        cmd.Parameters.AddWithValue("@DateDetails", Convert.ToString(ctrlDateDOB.Value.ToString("yyyy/MM/dd")));
                        cmd.Parameters.AddWithValue("@Age", txtage.Text);
                        cmd.Parameters.AddWithValue("@Temp", numericUpDown1.Text);
                        cmd.Parameters.AddWithValue("@Weigt", txtweight.Text);
                        cmd.Parameters.AddWithValue("@Height", txtheight.Text);
                        cmd.Parameters.AddWithValue("@BMI", txtbmi.Text);
                        cmd.Parameters.AddWithValue("@Headcircum", txthead.Text);
                        cmd.Parameters.AddWithValue("@Status", status);
                        cmd.Parameters.AddWithValue("@UHID_Value", ctrlTxtUHID.Text);
                       
                        cmd.Parameters.Add("@DateOfBirth", SqlDbType.DateTime).Value = Convert.ToString(ctrlDateDOB.Value);
                        cmd.Parameters.Add("@ReviewDate", SqlDbType.DateTime).Value = Convert.ToString(_frmConfirmSave.ctrlDateReview.Value);


                        string XMlDt1 = "";
                        cmd.Parameters.Add("@cby", SqlDbType.VarChar).Value = "111";
                        cmd.Parameters.Add("@XmlString", SqlDbType.VarChar).Value = XMlDt1;
                        cmd.Parameters.Add("@DiagnosisRowID", SqlDbType.VarChar).Value = "";
                        cmd.Parameters.Add("@DiagnosisHTML", SqlDbType.VarChar).Value = "";
                        cmd.Parameters.Add("@DiagnosisAdvice", SqlDbType.VarChar).Value = "";
                        cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = Convert.ToString(txtdatetime.Text);
                        cmd.Parameters.Add("@CategoryID", SqlDbType.VarChar).Value = _frmConfirmSave.cbCategory.SelectedValue;
                        cmd.Parameters.Add("@AmountRecived", SqlDbType.VarChar).Value = 0;
                        cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtAddress.Text;
                        
                        cmd.Parameters.AddWithValue("@Hospital_ID", AppMain.HospitalId);


                        cmd.Parameters.AddWithValue("@DoctorCode", DoctorCode);

                        cmd.Parameters.AddWithValue("@CashType", _frmConfirmSave.CashType);
                        cmd.Parameters.AddWithValue("@HaveInsurance", _frmConfirmSave.HaveInsurance);


                        cmd.Parameters.AddWithValue("@FullAddress", personalInformation.FullAddress = ctrlTxtFullAddress.Text);
                        cmd.Parameters.AddWithValue("@AllergicDrugs ", personalInformation.AllergicDrugs);
                        cmd.Parameters.AddWithValue("@BirthHistory ", personalInformation.BirthHistory);
                        cmd.Parameters.AddWithValue("@PastIllness ", personalInformation.PastIllness);
                        cmd.Parameters.AddWithValue("@FamilyHistory ", personalInformation.FamilyHistory);
                        cmd.Parameters.AddWithValue("@LabInvestigations ", personalInformation.LabInvestigations);
                        cmd.Parameters.AddWithValue("@AddtionalInformation ", personalInformation.AddtionalInformation);

                        if (_frmConfirmSave.FinalDiagonisID > 0)
                            cmd.Parameters.AddWithValue("@FinalDiagnosisId ", _frmConfirmSave.FinalDiagonisID);

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.ExecuteNonQuery();
                        updateauto();
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {
            TextBox richTextBoxGuess = ((TextBox)sender);

            if (richTextBoxGuess.Text.Length <= 0) return;
            string s = richTextBoxGuess.Text.Substring(0, 1);
            if (s != s.ToUpper())
            {
                int curSelStart = richTextBoxGuess.SelectionStart;
                int curSelLength = richTextBoxGuess.SelectionLength;
                richTextBoxGuess.SelectionStart = 0;
                richTextBoxGuess.SelectionLength = 1;
                richTextBoxGuess.SelectedText = s.ToUpper();
                richTextBoxGuess.SelectionStart = curSelStart;
                richTextBoxGuess.SelectionLength = curSelLength;
            }
        }

        private void txtheight_TextChanged(object sender, EventArgs e)
        {
            if (txtweight.Text != "" && txtheight.Text != "")
                CalculateBMI(Convert.ToDouble(txtweight.Text), Convert.ToDouble(txtheight.Text));
        }
        void CalculateBMI(double w, double h)
        {
            txtbmi.Text = Math.Round((w / (h * h)) * 10000, 2).ToString();
        }

        private void autonumber()
        {
            int count = 0, sno = 0, newno = 0;
            SqlConnection con = new SqlConnection(constr);
        Loop:
            SqlCommand cmd = new SqlCommand("select count(*) from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            count = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            SqlCommand cmd1 = new SqlCommand("select sno from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            sno = Convert.ToInt32(cmd1.ExecuteScalar());
            con.Close();

            if (count == 0)
            {
                cmb_apno.Text = "1";

            }
            else
            {
                newno = sno + 1;
                int present = 0;
                SqlCommand cmd3 = new SqlCommand("select count(*) from regappform3 where convert(date,Date)=Convert(date,getdate()) and ApNo='" + newno.ToString() + "'", con);
                con.Open();
                present = Convert.ToInt32(cmd3.ExecuteScalar());
                con.Close();

                if (present == 0)
                {
                    cmb_apno.Text = newno.ToString();

                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("update autogenerate set sno=sno+1 where convert(date,date)=Convert(date,getdate())", con);
                    con.Open();
                    cmd2.ExecuteNonQuery();
                    con.Close();
                    goto Loop;
                }

            }
        }

        private void updateauto()
        {
            int count = 0, sno = 0;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand("select count(*) from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            count = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            SqlCommand cmd1 = new SqlCommand("select sno from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            sno = Convert.ToInt32(cmd1.ExecuteScalar());
            con.Close();

            if (count == 0)
            {
                SqlCommand cmd2 = new SqlCommand("insert into autogenerate values(getdate(),1)", con);
                con.Open();
                cmd2.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                if (Convert.ToInt32(cmb_apno.Text) == sno + 1)
                {
                    SqlCommand cmd2 = new SqlCommand("update autogenerate set sno='" + Convert.ToInt32(cmb_apno.Text) + "' where convert(date,date)=Convert(date,getdate())", con);
                    con.Open();
                    cmd2.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    SqlCommand cmdc = new SqlCommand("select count(*) from regappform3 where Convert(date,Date)=Convert(date,getdate()) and ApNo='" + cmb_apno.Text + "' ", con);
                    con.Open();
                    count = Convert.ToInt32(cmdc.ExecuteScalar());
                    con.Close();

                    if (count == 0)
                    {

                    }
                    else
                    {
                        MessageBox.Show("Appointment Number Aleady Exits");
                    }
                }
            }
        }




        private void ClearData()
        {
            LoadDefaultvalues();
        }

       

        public void NewAppointment_Load(object sender, EventArgs e)
        {
            if (sender != null)
                return;
            ctrlDateDOB.MaxDate = DateTime.Now;
            txtdatetime.Text = DateTime.Now.ToString();
            txtdateSearch.Text = DateTime.Now.ToString();
            genderComboBox.SelectedIndex = 0;
            new GeneralMethods().DoctorNameLoad(ref ctrlCbxDoctor);
            GetData();
            autonumber();
            //loadFrid(txtdateSearch.Value);

            // FillDropDown();
            LoadDefaultvalues();
            LoadAppointmntGrid();
            List<Control> LabelControl = new List<Control>();
            List<Control> OtherControl = new List<Control>();
            UpdatePrescriptionControls(ref LabelControl, ref OtherControl, tableLayoutPanel1);
            foreach (Control c in LabelControl)
                UpdateColorLabels(c);
            foreach (Control c in OtherControl)
                UpdateColorControls(c);
            txtname.Focus();
            chkOld_CheckedChanged(this, null);
        }
        private void UpdatePrescriptionControls(ref List<Control> LabelControl, ref List<Control> OtherControl, TableLayoutPanel _tableLayoutPanel)
        {
            Control _c = null;
            Control _oc = null;

            foreach (Control c in _tableLayoutPanel.Controls)
                if ((c.Name.Contains("label") || c.Name.Contains("chk") || c.Name.Contains("btn")) && c.Enabled)
                { LabelControl.Add(c); _c = c; }
                else if (c.Name.Contains("table"))
                {
                    if (_tableLayoutPanel.Name.ToString() != "tableLayoutPanel1" && _tableLayoutPanel.Name.ToString() != "tableLayoutPanel2")
                        LabelControl.Add(_tableLayoutPanel); _c = _tableLayoutPanel;
                    UpdatePrescriptionControls(ref LabelControl, ref OtherControl, (TableLayoutPanel)c);
                }
                else if (!c.Name.Contains("label") && !c.Name.Contains("chk") && !c.Name.Contains("btn"))
                { OtherControl.Add(c); _oc = c; }

        }
        public void GetData()
        {
            SqlConnection con = new SqlConnection(constr);

            {
                con.Open();
                //txtdatetime.Text = DateTime.Now.ToString();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("select * from Presnew1", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Presnew1");

                //ctrldataGridPrescription1.DataSource = ds.Tables["Presnew1"];
                string Query = "if (select COUNT(*) from regappform3 where year(date)=@Year and MONTH(Date)=@Month)>0 " +
                               "     select isnull(max(right(EPresNo,2)),0)+1 from regappform3 where year(date)=@Year and MONTH(Date)=@Month and EPresNo!='Direct'  " +
                               " else  " +
                               "     select 1";
                cmd = new SqlCommand(Query, con);
                var month = Convert.ToDateTime(txtdatetime.Text).Month;
                var year = Convert.ToDateTime(txtdatetime.Text).Year;
                cmd.Parameters.AddWithValue("@Month", month);
                cmd.Parameters.AddWithValue("@Year", year);
                MaxSeq = Convert.ToString(cmd.ExecuteScalar());
                if (string.IsNullOrEmpty(MaxSeq))
                    MaxSeq = "1";
                //Query = "if (select sno from autogenerate where convert(date,Date)=convert(date,@Date) )>0 " +
                //               "     select sno from autogenerate where convert(date,Date)=convert(date,@Date)  " +
                //               " else  " +
                //               "     select 1";

                Query = "if (select COUNT(*) from regappform3 where  convert(date,Date)=convert(date,@Date))>0 " +
                              "    select isnull(MAX(cast(ApNo as int)),0)+1 from regappform3 where( convert(date,Date)=convert(date,@Date) And Hospital_Id=@ID and DoctorCode=@doctorCode )" +
                              " else  " +
                              "     select 1";
                cmd = new SqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@ID", AppMain.HospitalId);
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txtdatetime.Text));
                ApNo = Convert.ToString(cmd.ExecuteScalar());
                cmb_apno.Text = ApNo;



                string querry = "select EPresNo from regappform3 where year(date)=@Year and MONTH(Date)=@Month and Hospital_id=@hosp_id and DoctorCode=@doctorCode ";
                cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@Month", month);
                cmd.Parameters.AddWithValue("@Year", year);
                cmd.Parameters.AddWithValue("@hosp_id", AppMain.HospitalId);
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds, "EpresNo");

                List<int> id = new List<int>();
                foreach (DataRow item in ds.Tables["EpresNo"].Rows)
                {

                    try
                    {
                        string[] var = item[0].ToString().Split('-');
                        id.Add(Convert.ToInt32(var[var.Length - 1]));

                    }
                    catch
                    {

                    }
                }
                MaxSeq = string.Empty;
                if (id.Count == 0)
                    MaxSeq = "1";
                else
                    MaxSeq = Convert.ToString((id.Max() + 1));

                if (string.IsNullOrEmpty(ApNo))
                    ApNo = "1";

                cmd = new SqlCommand("select * from Presnew1", con);
                sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Presnew1");
                Query = "Select isnull(MAX(cast(substring(PatiantID,5,5) as int)),0)+1 from regappform3 where Hospital_id=@hosp_id and DoctorCode=@doctorCode ";
                cmd = new SqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@hosp_id", AppMain.HospitalId);
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                string MaxSeqpAT = Convert.ToString(cmd.ExecuteScalar());
                if (string.IsNullOrEmpty(MaxSeq))
                    MaxSeqpAT = "1";
                //txtpatiantID.Text = "SV" + MaxSeqpAT.PadLeft(3, '0');
                txtpatiantID.Text = $"{DoctorCode} - " + MaxSeqpAT;
                con.Close();
            }
            txtPresNo.Text = string.Concat(Convert.ToDateTime(txtdatetime.Text).Year.ToString(), "-", Convert.ToDateTime(txtdatetime.Text).Month.ToString().PadLeft(2, '0'), "-", MaxSeq.PadLeft(2, '0'));
            cmb_apno.Text = ApNo;
        }
        public void UpdateColorLabels(Control myControl)
        {
            if (!myControl.Name.Contains("btn"))
            {
                myControl.BackColor = Properties.Settings.Default.LBackColor;
                myControl.ForeColor = Properties.Settings.Default.LFontColor;
            }
            myControl.Font = new Font(Properties.Settings.Default.LFontFamily, Properties.Settings.Default.LFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorLabels(subC);

        }
        public void UpdateColorControls(Control myControl)
        {
            myControl.BackColor = Properties.Settings.Default.CBackColor;
            myControl.ForeColor = Properties.Settings.Default.CFontColor;
            myControl.Font = new Font(Properties.Settings.Default.CFontFamily, Properties.Settings.Default.CFontSize);
            myControl.KeyUp += new KeyEventHandler(myControl_KeyUp);
            foreach (Control subC in myControl.Controls)
                UpdateColorControls(subC);
            tableLayoutPanel1.BackColor = Properties.Settings.Default.CBackColor;
        }
        void myControl_KeyUp(object sender, KeyEventArgs e)
        {
            if (!e.Handled)
                if ((e.Control == true || e.Alt == true) && e.KeyCode == Keys.S)
                { Save(); e.Handled = true; }
                else if (e.Alt == true && e.KeyCode == Keys.C)
                { btnClear_Click(); e.Handled = true; }
                else if ((e.Control == true || e.Alt == true) && e.KeyCode == Keys.O)
                { chkOld.Checked = (!chkOld.Checked); e.Handled = true; }
                else if (e.KeyCode == Keys.F1)
                { NewDiagnosis _dia = new NewDiagnosis(); _dia.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F2)
                { Category _cat = new Category(); _cat.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F3)
                {
                    //MainForm.DoVisible(false, true); e.Handled = true;
                }
                else if (e.KeyCode == Keys.F4)
                {
                   // MainForm.DoVisible(true); e.Handled = true;
                }
                else if  (e.KeyCode == Keys.F6)
                {
                    if (this.ActiveControl == txtAddress)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.Area, txtAddress.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtAddress.Text = "";
                            AddressLoad();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == txtname)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.Name, txtname.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtname.Text = "";
                            nameload();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == txtPhoneNo)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.PhoneNo, txtPhoneNo.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtPhoneNo.Text = "";
                            phoneload();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == ctrlTxtUHID)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.UHID, ctrlTxtUHID.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            ctrlTxtUHID.Text = "";
                            UHIDLoad();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == ctrlTxtFullAddress)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.FullAddress, ctrlTxtFullAddress.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            ctrlTxtFullAddress.Text = "";
                        }
                        e.Handled = true;
                    }
                }
        }

        void loadFrid(DateTime _dt)
        {
           
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                //SqlCommand cmd = new SqlCommand(" select A.EPresNo,ApNo,PatiantID,Name,PhoneNo ,date,case when isnull(B.Icode,'')='' then 'Pending' " +
                //                                " else 'Visited' end Status  " +
                //                                " from regappform3 [A] left Join Prescription_DT[B] On A.EPresNo=B.EPresNo and isnull(Icode,'')<>''  " +
                //                                " where  convert(date,Date)=@Date ", con);

                //SqlCommand cmd = new SqlCommand(" select distinct A.ApNo,A.EPresNo,Name+' '+LastName as FullName,A.PatiantID,A.Status," +
                //                               " c.Category,A.AmountRecived as TotalAmount,C.Amount as Fee,case when A.AmountRecived='0.00' then 0.00 else A.AmountRecived-C.Amount end as Others  " +
                //                               " from regappform3 [A] , Prescription_DT[B],AmountCategory c where A.EPresNo=B.EPresNo     " +
                //                               " and  convert(date,Date)=@Date and A.CategoryID=c.RowID ", con);

                SqlCommand cmd = new SqlCommand(" select distinct CAST(A.ApNo AS int) as [App No],A.EPresNo,Name as FullName,A.PatiantID,A.Status," +
                                              " c.Category,A.AmountRecived as TotalAmount,C.Amount as Fee,case when A.AmountRecived='0.00' then 0.00 else A.AmountRecived-C.Amount end as Others  " +
                                              " from regappform3 [A] , Prescription_DT[B],AmountCategory c where      " +
                                              "   convert(date,Date)=@Date and A.CategoryID=c.RowID order by [App No]", con);

                cmd.Parameters.AddWithValue("@Date", _dt.ToString("yyyy/MM/dd")); SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                AppointMentList.DataSource = ds.Tables[0];
                con.Close();
            }


        }

        private void LoadAppointmntGrid()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                SqlCommand cmd = new SqlCommand("Sp_GetAppointment", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@type", ctrlCbxStatus.Text);
                cmd.Parameters.AddWithValue("@dCode", DoctorCode);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                AppointMentList.DataSource = table;
            }
        }

        public void nameload()
        {
            
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("select Name from regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtname.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void AddressLoad()
        {           
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT distinct Address FROM regappform3 where (address!='' And Hospital_Id=@ID and DoctorCode =@doctorCode)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtAddress.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void IDLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                txtpatiantID.Text = "";
                SqlCommand cmd = new SqlCommand("SELECT PatiantID FROM [regappform3] where (PatiantID!='' And Hospital_Id=@ID And DoctorCode =@doctorCode)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();

                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                txtpatiantID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }   

        private void txtname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "N", txtpatiantID.Text.StartsWith(DoctorCode) ? txtpatiantID.Text : $"{DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);

            }
        }
        private void txtPhoneNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "P", txtpatiantID.Text.StartsWith(DoctorCode) ? txtpatiantID.Text : $"{DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);


            }
        }
        private void txtpatiantID_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "I", txtpatiantID.Text.StartsWith(DoctorCode) ? txtpatiantID.Text : $"{DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);

            }
        }

        void LoadOldPrescription1(DateTime from, DateTime to, bool _considerDate, string _considerField, string id = "", string Epresno = "", string name = "", string phoneNumber = "", string UHID = null)
        {

            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            if (_considerField.ToUpper() == "P")
            { name = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "N")
            { phoneNumber = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "E")
            { phoneNumber = ""; name = ""; id = ""; }
            if (_considerField.ToUpper() == "I")
            { phoneNumber = ""; name = ""; Epresno = ""; }
            string _datefilter = (_considerDate) ? " or( Date between '" + from.ToString("yyyy/MM/dd") + "' and '" + to.AddDays(1).ToString("yyyy/MM/dd") + "')" : "";

            //string querry1 = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,
            //                    Age,DateOfBirth,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo " +
            //                " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
            //                " where (A.PhoneNo like '" + phoneNumber + "'" +
            //                " or A.Name like N'" + name +
            //                "' or A.EPresNo like N'" + Epresno + "' or A.UHID like N'" + UHID +
            //                "' or A.PatiantID like N'" + id + "')" + _datefilter
            //                + "order by EPresNo desc";

            string querry = "";
            if (_considerField.ToUpper() == "P")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PhoneNo like '{phoneNumber}') order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "E")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.EPresNo like '{Epresno}') order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "N")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.Name like '{name}') order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "I")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PatiantID like '{id}') order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "UH")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.UHID like '{UHID}') order by EPresNo desc";
            }
            SqlCommand cmd = new SqlCommand(querry, con);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable resultTable = ds.Tables[0];
            int searchIndex = 0;
            //if (resultTable.Rows.Count>1)
            //{             
            //    frmSearchUserConfirmation frm = new frmSearchUserConfirmation(resultTable);
            //    frm.ShowDialog();
            //    searchIndex = frm.SelectedIndex;
            //}
            if (resultTable.Rows.Count > 0)
            {
                // txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                txtAddress.Text = resultTable.Rows[searchIndex]["Address"].ToString();
                txtpatiantID.Text = resultTable.Rows[searchIndex]["PatiantID"].ToString();
                txtname.Text = resultTable.Rows[searchIndex]["Name"].ToString();
                genderComboBox.Text = resultTable.Rows[searchIndex]["Gender"].ToString();
                if (resultTable.Columns.Contains("DateOfBirth"))
                    if (resultTable.Rows[searchIndex]["DateOfBirth"].ToString() != "")
                        ctrlDateDOB.Value = Convert.ToDateTime(resultTable.Rows[searchIndex]["DateOfBirth"].ToString());
                //txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                //txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                //txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                //txtmiddleName.Text = ds.Tables[0].Rows[0]["MiddleName"].ToString();
                //txtlastname.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
                txtPhoneNo.Text = resultTable.Rows[searchIndex]["PhoneNo"].ToString();
                ctrlTxtUHID.Text = resultTable.Rows[searchIndex]["UHID"].ToString();
                
            }

        }
        void LoadOldPrescription(DateTime from, DateTime to, bool _considerDate, string _considerField, string id = "", string Epresno = "", string name = "", string phoneNumber = "", string UHID = null)
        {

            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            if (_considerField.ToUpper() == "P")
            { name = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "N")
            { phoneNumber = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "E")
            { phoneNumber = ""; name = ""; id = ""; }
            if (_considerField.ToUpper() == "I")
            { phoneNumber = ""; name = ""; Epresno = ""; }
            string _datefilter = (_considerDate) ? " or( Date between '" + from.ToString("yyyy/MM/dd") + "' and '" + to.AddDays(1).ToString("yyyy/MM/dd") + "')" : "";

            //string querry1 = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,
            //                    Age,DateOfBirth,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo " +
            //                " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
            //                " where (A.PhoneNo like '" + phoneNumber + "'" +
            //                " or A.Name like N'" + name +
            //                "' or A.EPresNo like N'" + Epresno + "' or A.UHID like N'" + UHID +
            //                "' or A.PatiantID like N'" + id + "')" + _datefilter
            //                + "order by EPresNo desc";

            string querry = "";
            if (_considerField.ToUpper() == "P")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PhoneNo like '{phoneNumber}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "E")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID ,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.EPresNo like '{Epresno}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "N")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID ,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.Name like '{name}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "I")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PatiantID like '{id}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "UH")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.UHID like '{UHID}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }

            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable resultTable = ds.Tables[0];
            int searchIndex = 0;
            //if (resultTable.Rows.Count>1)
            //{             
            //    frmSearchUserConfirmation frm = new frmSearchUserConfirmation(resultTable);
            //    frm.ShowDialog();
            //    searchIndex = frm.SelectedIndex;
            //}
            if (resultTable.Rows.Count > 0)
            {
                // txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                txtAddress.Text = resultTable.Rows[searchIndex]["Address"].ToString();
                txtpatiantID.Text = resultTable.Rows[searchIndex]["PatiantID"].ToString();
                txtname.Text = resultTable.Rows[searchIndex]["Name"].ToString();
                genderComboBox.Text = resultTable.Rows[searchIndex]["Gender"].ToString();
                if (resultTable.Columns.Contains("DateOfBirth"))
                    if (resultTable.Rows[searchIndex]["DateOfBirth"].ToString() != "")
                        ctrlDateDOB.Value = Convert.ToDateTime(resultTable.Rows[searchIndex]["DateOfBirth"].ToString());
                //txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                //txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                //txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                //txtmiddleName.Text = ds.Tables[0].Rows[0]["MiddleName"].ToString();
                //txtlastname.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
                txtPhoneNo.Text = resultTable.Rows[searchIndex]["PhoneNo"].ToString();
                ctrlTxtUHID.Text = resultTable.Rows[searchIndex]["UHID"].ToString();


                personalInformation.FullAddress = resultTable.Rows[searchIndex]["FullAddress"]?.ToString();
                personalInformation.AllergicDrugs = resultTable.Rows[searchIndex]["AllergicDrugs"]?.ToString();
                personalInformation.BirthHistory = resultTable.Rows[searchIndex]["BirthHistory"]?.ToString();
                personalInformation.PastIllness = resultTable.Rows[searchIndex]["PastIllness"]?.ToString();
                personalInformation.FamilyHistory = resultTable.Rows[searchIndex]["FamilyHistory"]?.ToString();
                personalInformation.LabInvestigations = resultTable.Rows[searchIndex]["LabInvestigations"]?.ToString();
                personalInformation.AddtionalInformation = resultTable.Rows[searchIndex]["AddtionalInformation"]?.ToString();


                ctrlTxtFullAddress.Text = personalInformation.FullAddress;
                //new GeneralMethods().LoadCheckedValues(personalInformation.AllergicDrugs, ref ctrlCbxAlergy);



            }

        }
        private void ctrlTxtUHID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                //  chkOld_CheckedChanged(null, null);
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "UH", txtpatiantID.Text.StartsWith(DoctorCode) ? txtpatiantID.Text : $"{DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text, ctrlTxtUHID.Text);


            }
        }

        

        public void phoneload()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT PhoneNo FROM regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtPhoneNo.AutoCompleteCustomSource = MyCollection;

                con.Close();
            }
        }

        public void UHIDLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT UHID FROM regappform3 where Hospital_Id=@ID and  DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                        MyCollection.Add(reader.GetString(0));
                }
                ctrlTxtUHID.AutoCompleteCustomSource = MyCollection;

                con.Close();
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            loadFrid(txtdateSearch.Value);
        }


        DataSet LoadBasedonEPresNo()
        {
            DataSet ds = new DataSet();
            try
            {
                string _Selectedvalue = txtPresNo.Text;
                if (_Selectedvalue != "")
                {
                    SqlConnection con = new SqlConnection(constr);

                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                    string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Age,DateOfBirth,ReviewDate,A.HeadCircum,A.DiagnosisHTML,A.CategoryID,A.DiagnosisAdvice,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo,A.Address,A.UHID " +
                                    "A.Height,A.Weigt,A.BMI,A.Temp,B.Diagnosis from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                                    " where A.EPresNo=@EPresno;  select  row_number() over (order by EPresNo) as SNo, " +
                                    " Icode[Medicine],Qty[Quantity],Dose[Dose],devideDose[dividedDoses],Instruction[Instructions],Interval[Interval],InstructionEnglish[InstructionEnglish],InstructionTamil[InstructionTamil] " +
                                    " from Prescription_DT where EPresNo=@EPresNo";
                    SqlCommand cmd = new SqlCommand(querry, con);
                    cmd.Parameters.AddWithValue("@EPresno", _Selectedvalue);
                    //cmd.Parameters.AddWithValue("@phoneno", txtPhoneNo.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return ds;
        }

        private void AppointmentGrid_DoubleClick(object sender, EventArgs e)
        {

            _pres.SetOldPrescriptions(LoadBasedonEPresNo());
            _pres.Dock = DockStyle.Fill;
            _pres.BringToFront();
            _pres.Visible = true;
            this.Visible = false;
            //((MainForm)this.Parent).panelMain.Controls.Clear();
            //((MainForm)this.Parent).panelMain.Controls.Add(MainForm.t);

        }

        private void AppointmentGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void LoadPatiantDetails(string EpresNo, string apno)
        {
            try
            {
                DataSet ds = new DataSet();
                string _Selectedvalue = EpresNo;
                if (_Selectedvalue != "")
                {
                    SqlConnection con = new SqlConnection(constr);

                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                    string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Age,DateOfBirth,ReviewDate,A.HeadCircum,A.DiagnosisHTML,A.CategoryID,A.DiagnosisAdvice,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo,A.Address, " +
                                    "A.Height,A.Weigt,A.BMI,A.Temp,B.Diagnosis,AmountRecived from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                                    " where A.EPresNo=@EPresno;  select  row_number() over (order by EPresNo) as SNo, " +
                                    " Icode[Medicine],Qty[Quantity],Dose[Dose],devideDose[dividedDoses],Instruction[Instructions],Interval[Interval],InstructionEnglish[InstructionEnglish],InstructionTamil[InstructionTamil] " +
                                    " from Prescription_DT where EPresNo=@EPresNo";
                    SqlCommand cmd = new SqlCommand(querry, con);
                    cmd.Parameters.AddWithValue("@EPresno", _Selectedvalue);
                    //cmd.Parameters.AddWithValue("@phoneno", txtPhoneNo.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    SetValueForEpresNo = EpresNo;
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                    cmb_apno.Text = ds.Tables[0].Rows[0]["ApNo"].ToString();
                    txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    genderComboBox.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                    // dateTimePicker1.Text = ds.Tables[0].Rows[0]["DateDetails"].ToString();
                    txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                    txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
                    txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
                    txtbmi.Text = ds.Tables[0].Rows[0]["BMI"].ToString();
                    txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                    txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                    txthead.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
                    txtPhoneNo.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
                    txtAmountRecived.Text = ds.Tables[0].Rows[0]["AmountRecived"].ToString();
                    // txt_date.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                    txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();

                }
                else
                {
                    genderComboBox.Text = "Male";
                    txtage.Text = "";
                    txtweight.Text = "";
                    txtheight.Text = "";
                    txtbmi.Text = "";
                    txthead.Text = "";
                    txtdatetime.Text = DateTime.Now.ToString(); ;
                    txtAmountRecived.Text = "";
                    txtAddress.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btncategory_Click(object sender, EventArgs e)
        {
            Category _cat = new Category();
            _cat.ShowDialog();
        }

        public void btnClear_Click(bool skipOld=false)
        {
            ClearData();
            //chkOld.Checked = true;
            //  numericUpDown1.ResetText();
            numericUpDown1.Value = 98;
            txtpatiantID.Enabled = chkOld.Checked;// txtpatiantID.Enabled = false;
            cmb_apno.Text = "";
            txtname.Text = "";
            ctrlDateDOB.Text = "";
            txtage.Text = "";
            txtweight.Text = "";
            txtheight.Text = "";
            txtbmi.Text = "";
            txtPresNo.Text = "";
            txthead.Text = "";

            if(!skipOld)
            chkOld.Checked = false;

            cb_language.SelectedIndex = 1;
            txtbmi.ReadOnly = false;
            txtbmi.ForeColor = Properties.Settings.Default.CFontColor;
            txtPhoneNo.Text = "";
            txtAddress.Text = "";
            ctrlTxtUHID.Text = "";
            FillDropDownAppNo();
            GetData();
            autonumber();           
            genderComboBox.SelectedIndex = 0;
            ctrlTxtFullAddress.Text = "";
            personalInformation = new PersonalInformation();
            //ctrlDateDOB.Value = DateTime.Now;

        }

        public void FillDropDownAppNo()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                cmb_apno.DataSource = null;
                //SqlCommand cmd = new SqlCommand("select ApNo,PatiantID from regappform3 where Convert(date,Date)=Convert(date,getDate())  order by Cast(ApNo as int) asc ", con);//and EPresNo=''
                SqlCommand cmd = new SqlCommand("select ApNo, PatiantID from regappform3 where (Convert(date, Date) = Convert(date, getDate()) and Hospital_Id = @hospID and DoctorCode = @doctorCode)  order by Cast(ApNo as int) asc", con);
                cmd.Parameters.AddWithValue("@hospID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", DoctorCode);
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);

                cmb_apno.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
                cmb_apno.ValueMember = "ApNo";
                cmb_apno.DisplayMember = "ApNo";
                con.Close();
            }

        }


        private void chkOld_CheckedChanged(object sender, EventArgs e)
        {
            if (mAinFOrm != null)
            {
                if (((Ribbon)mAinFOrm?.Controls[1]).QuickAcessToolbar.Items.Count > 0)
                {
                    object _control = ((Ribbon)mAinFOrm.Controls[1]).QuickAcessToolbar.Items[2];
                    if (chkOld.Checked)
                    {
                        ((RibbonButton)_control).SmallImage = Properties.Resources.Check16;
                        ((RibbonButton)_control).SmallImage.Tag = "Checked";
                        ((RibbonButton)_control).ToolTipImage = Properties.Resources.Check16;
                        ((RibbonButton)_control).ToolTipTitle = "Old";
                        ((RibbonButton)_control).ToolTipTitle = "To Enable Old; Please click here ...";
                    }
                    else
                    {
                        ((RibbonButton)_control).SmallImage = Properties.Resources.unCheck16;
                        ((RibbonButton)_control).SmallImage.Tag = "Unchecked";
                        ((RibbonButton)_control).ToolTipImage = Properties.Resources.unCheck16;
                        ((RibbonButton)_control).ToolTipTitle = "New";
                        ((RibbonButton)_control).ToolTipTitle = "To Disable Old; Please click here ...";
                    }
                }
            }
            if (chkOld.Checked == true)
            {
                // txtpatiantID.Text = "";
                txtpatiantID.Enabled = true;
                //   txtpatiantID.Enabled = false;
                txtpatiantID.Focus();
            }
            else
            {
                ClearOldValues();
                GetData();
                autonumber();
                txtpatiantID.Enabled = false;
                cmb_apno.Focus();
                //  txtpatiantID.Enabled = false;
            }
        }
        private void ClearOldValues()
        {
            genderComboBox.SelectedIndex = 0;
            cb_language.SelectedIndex = 1;
            btnClear_Click();
        }
        public void DateDifference(DateTime d1, DateTime d2)
        {
            int[] monthDay = new int[12] { 31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            int year;
            int month;
            int day;

            DateTime fromDate;


            DateTime toDate;

            int increment;

            if (d1 > d2)
            {
                fromDate = d2;
                toDate = d1;
            }
            else
            {
                fromDate = d1;
                toDate = d2;
            }

            /// 
            /// Day Calculation
            /// 
            increment = 0;

            if (fromDate.Day > toDate.Day)
            {
                increment = monthDay[fromDate.Month - 1];

            }
            /// if it is february month
            /// if it's to day is less then from day
            if (increment == -1)
            {
                if (DateTime.IsLeapYear(fromDate.Year))
                {
                    // leap year february contain 29 days
                    increment = 29;
                }
                else
                {
                    increment = 28;
                }
            }
            if (increment != 0)
            {
                day = (toDate.Day + increment) - fromDate.Day;
                increment = 1;
            }
            else
            {
                day = toDate.Day - fromDate.Day;
            }

            ///
            ///month calculation
            ///
            if ((fromDate.Month + increment) > toDate.Month)
            {
                month = (toDate.Month + 12) - (fromDate.Month + increment);
                increment = 1;
            }
            else
            {
                month = (toDate.Month) - (fromDate.Month + increment);
                increment = 0;
            }

            ///
            /// year calculation
            ///
            year = toDate.Year - (fromDate.Year + increment);

            yearDiff = year;
            monthdiff = month;
            daysdiff = day;

        }
        private void ctrlDateDOB_ValueChanged(object sender, EventArgs e)
        {

            DateTime todaydate = DateTime.Now.Date; ;
            DateTime clickedDate = ctrlDateDOB.Value.Date;

            //CalculateDate(todaydate, clickedDate);
            DateDifference(todaydate, clickedDate);
            //txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon " + daysdiff + "Days";

            if (yearDiff > 0 && monthdiff > 0 && daysdiff > 0)
            {
                txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon " + daysdiff + "Days";
            }
            else if (yearDiff > 0 && monthdiff > 0 && daysdiff == 0)
            {
                txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon ";
            }
            else if (yearDiff > 0 && monthdiff == 0 && daysdiff > 0)
            {
                txtage.Text = yearDiff + "Yrs " + daysdiff + "Days";
            }
            else if (yearDiff > 0 && monthdiff == 0 && daysdiff == 0)
            {
                txtage.Text = yearDiff + "Yrs ";
            }
            else if (yearDiff == 0 && monthdiff > 0 && daysdiff > 0)
            {
                txtage.Text = monthdiff + "Mon " + daysdiff + "Days";
            }
            else if (yearDiff == 0 && monthdiff > 0 && daysdiff == 0)
            {
                txtage.Text = monthdiff + "Mon ";
            }
            else if (yearDiff == 0 && monthdiff == 0 && daysdiff > 0)
            {
                txtage.Text = daysdiff + "Days";
            }
            else if (yearDiff == 0 && monthdiff == 0 && daysdiff == 0)
            {
                txtage.Text = daysdiff + "Days";
            }



            if (yearDiff <= 5)
                txthead.Enabled = true;
            else
                txthead.Enabled = false;

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            ClearOldValues();
        }


        public void btnsaveapp_Click(object sender, EventArgs e)
        {
            try
            {
                string _save = "";
                _save = _save + ((cmb_apno.Text != "") ? "" : "App No, ");
                _save = _save + ((txtname.Text != "") ? "" : "Name, ");
                _save = _save + ((txtage.Text != "") ? "" : "Age, ");

                if (_save == "")
                {
                    if (Save())
                    {
                        MessageBox.Show("Prescription has saved successfully!");
                        //NewAppointment_Load(this, null);
                        btnClear_Click();
                        LoadAppointmntGrid();
                    }
                }
                else
                {
                    MessageBox.Show("Please fill " + _save.ToString().Remove(_save.Length - 2, 2) + " details :(");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void CtrlCbxDoctor_SelectedIndexChanged(object sender, EventArgs e)
        {

            btnClear_Click(true);
            IDLoad();
            GetData();
            autonumber();
            LoadAppointmntGrid();
            FillDropDownAppNo();
        }

        private void ctrlBtnDeleteAppointmrnt_Click(object sender, EventArgs e)
        {
            if (AppointMentList.SelectedRows.Count <= 0)
                return;

            SqlConnection con = new SqlConnection(constr);
            DialogResult result = MessageBox.Show("Do You Want to delete the Curent User?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result.Equals(DialogResult.OK))
            {
                using (con)
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    var id = AppointMentList.Rows[AppointMentList.SelectedRows[0].Index].Cells[0].Value.ToString();
                    SqlCommand cmd = new SqlCommand("Delete from regappform3 where EpresNo=@EpresNo", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@EpresNo", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully");
                }

                LoadAppointmntGrid();
            }
        }

        public void PatientStatusLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        private void LoadDefaultvalues()
        {
            nameload();
            IDLoad();
            AddressLoad();
            phoneload();
            UHIDLoad();
            PatientStatusLoad();
            FillDropDownAppNo();

        }
    }
}
