﻿using ClassLibrary;
using SVMApplication.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmNewUser : MetroFramework.Forms.MetroForm
    {
        User user = new User();
        public frmNewUser()
        {
            InitializeComponent();
            this.ActiveControl = ctrlTxtUSERNAME;
        }

        private void ctrlBtnAddUser_Click(object sender, EventArgs e)
        {
            if(ctrlCbxUserType.Text.ToLower()=="doctor")
            {
                if (string.IsNullOrWhiteSpace(ctrlTxtDoctorCode.Text))
                {
                    MessageBox.Show("Doctor Code must be enter", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            if(ctrlTxtUSERNAME.Text == string.Empty || ctrlTxtFULLNAME.Text == string.Empty || ctrlTxtPASSWORD.Text == string.Empty || ctrlTxtTEL.Text == string.Empty || ctrlTxtEMAIL.Text == string.Empty)
            {
                MessageBox.Show("One Or More Fields Are Empty", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                user.insertUser(ctrlTxtUSERNAME.Text, ctrlTxtFULLNAME.Text, 
                    ctrlTxtPASSWORD.Text, ctrlTxtTEL.Text, ctrlTxtEMAIL.Text,
                    ctrlCbxUserType.GetSelectedValueAsInt(),ctrlTxtDoctorCode.Text);
                MessageBox.Show("New User Inserted Successfully", "New User", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
           
        }

        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PANEL_CLOSE_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LoadUserType()
        {
            UserType t = new UserType();

            DataTable dataTable = t.GetUserType();

            ctrlCbxUserType.Items.Clear();

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                ComboboxItem item = new ComboboxItem();
                item.Value = Convert.ToInt32(dataTable.Rows[i]["typeID"]);
                item.Text = (dataTable.Rows[i]["typeName"].ToString());

                ctrlCbxUserType.Items.Add(item);
            }

            if (ctrlCbxUserType.Items.Count > 0)
                ctrlCbxUserType.SelectedIndex = 0;
        }

        private void frmNewUser_Load(object sender, EventArgs e)
        {
            LoadUserType();
        }

        private void ctrlCbxUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ctrlCbxUserType.GetSelectedText().ToLower()=="doctor")
            {
                ctrlLblDoctorCode.Visible = true;
                ctrlTxtDoctorCode.Visible = true;
            }
            else
            {
                ctrlLblDoctorCode.Visible = false;
                ctrlTxtDoctorCode.Visible = false;
            }
        }
    }
}
