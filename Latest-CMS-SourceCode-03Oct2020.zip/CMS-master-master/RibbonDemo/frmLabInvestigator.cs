﻿using LicenseKeyActivation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace SVMApplication
{
    partial class frmLabInvestigator : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
       public bool IsModified = false;
        public frmLabInvestigator()
        {
            InitializeComponent();

        }

        private void CtrlAddBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ctrlTxtName.Text) && !string.IsNullOrWhiteSpace(ctrlTxtDescription.Text) &&
               !string.IsNullOrWhiteSpace(ctrlTxtMinAmount.Text) && !string.IsNullOrWhiteSpace(ctrlTxtMaxAmount.Text))
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("select count(*) from LabInvestigation where Name=@Name and minAmount=@MinAmount and @MaxAmount=@MaxAmount and Description=@Description", con);
                cmd.Parameters.AddWithValue("@Name", ctrlTxtName.Text);
                cmd.Parameters.AddWithValue("@MinAmount", ctrlTxtMinAmount.Text);
                cmd.Parameters.AddWithValue("@MaxAmount", ctrlTxtMaxAmount.Text);
                cmd.Parameters.AddWithValue("@Description", ctrlTxtDescription.Text);

                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {
                    ctrlAddBtn.Text = "Update";
                    MessageBox.Show("LabInvestigation is already exist");
                    return;
                }
                else
                {
                    SaveMathod();                    
                    IsModified = true;
                    LoadGrid();
                    Clear();
                }
            }
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string querry = @"select * from LabInvestigation order by Id asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                ctrlGridLabInvest.DataSource = ds.Tables[0];
            }
        }
        private void SaveMathod()
        {
            try
            {
                using (con)
                {
                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    if (ctrlAddBtn.Text == "Update")
                    {

                        SqlCommand cmd = new SqlCommand(" update LabInvestigation set Name=@Name,minAmount=@MinAmount,MaxAmount=@MaxAmount,Description=@Description where Name=@OriginalName", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Name", ctrlTxtName.Text);
                        cmd.Parameters.AddWithValue("@MinAmount", ctrlTxtMinAmount.Text);
                        cmd.Parameters.AddWithValue("@MaxAmount", ctrlTxtMaxAmount.Text);
                        cmd.Parameters.AddWithValue("@Description", ctrlTxtDescription.Text);
                        cmd.Parameters.AddWithValue("@OriginalName", labName);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Updated Successfully");
                    }
                    else
                    {
                        SqlCommand cmd = new SqlCommand("Sp_LabInvestigation", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Name", ctrlTxtName.Text);
                        cmd.Parameters.AddWithValue("@MinAmount", ctrlTxtMinAmount.Text);
                        cmd.Parameters.AddWithValue("@MaxAmount", ctrlTxtMaxAmount.Text);

                        cmd.Parameters.AddWithValue("@Description", ctrlTxtDescription.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Saved Successfully");
                    }
                }
            }
            catch (Exception ed)
            {
                MessageBox.Show(ed.ToString());
                
            }
         
        }
         
        private void FrmLabInvestigator_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void CtrlDeleteBtn_Click(object sender, EventArgs e)
        {
            if (ctrlGridLabInvest.SelectedRows.Count > 0)
            {
                var id = ctrlGridLabInvest.Rows[ctrlGridLabInvest.SelectedRows[0].Index].Cells[0].Value.ToString();

                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("delete from LabInvestigation where Id=@id", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(id));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                        IsModified = true;
                    }
                    LoadGrid();
                    Clear();
                }

            }
        }
 


        private void Clear()
        {
            ctrlTxtName.Text = "";
            ctrlTxtMinAmount.Text = "";
            ctrlTxtMaxAmount.Text = "";
            ctrlTxtDescription.Text = "";
            ctrlAddBtn.Text = "Save";
        }
        string labName = "";
        private void CtrlGridLabInvest_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;

            if (e != null) Rowidx = e.RowIndex;

            if (Rowidx < 0)
                return;

            Clear();

            int rowIndex = ctrlGridLabInvest.Rows[Rowidx].Index;
            ctrlGridLabInvest.Rows[Rowidx].Cells[0].Selected = true;

            if (ctrlGridLabInvest == null)
                return;
            if (ctrlGridLabInvest.Rows[Rowidx].Cells[0].Selected == true)
            {

                if (Convert.ToString(ctrlGridLabInvest.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {                     
                    ctrlTxtName.Text = ctrlGridLabInvest.Rows[Rowidx].Cells[1].Value.ToString();
                    labName= ctrlGridLabInvest.Rows[Rowidx].Cells[1].Value.ToString();
                    ctrlTxtMinAmount.Text = ctrlGridLabInvest.Rows[Rowidx].Cells[2].Value.ToString();
                    ctrlTxtMaxAmount.Text = ctrlGridLabInvest.Rows[Rowidx].Cells[3].Value.ToString();
                    ctrlTxtDescription.Text = ctrlGridLabInvest.Rows[Rowidx].Cells[4].Value.ToString();
                    ctrlAddBtn.Text = "Update";
                }
                else
                    Clear();
            }
            else
                Clear();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CtrlTxtMaxAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (!char.IsControl(e.KeyChar)
              && !char.IsDigit(e.KeyChar)
              && e.KeyChar != '.')
                {
                    e.Handled = true;
                }

                // only allow one decimal point
                if (e.KeyChar == '.'
                    && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
            catch (Exception)
            {

            }
           
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Clear();
        }


        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
            base.OnKeyDown(e);
        }
    }
}
