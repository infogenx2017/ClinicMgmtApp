﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace SVMApplication
{
    public partial class NewDrug : UserControl
    {
        private string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();

        public NewDrug()
        {
            InitializeComponent();
            strength1_ComboBox.Items.Add("mg");
            strength1_ComboBox.Items.Add("mcg");
            strength1_ComboBox.Items.Add("gm");
            strength_ComboBox.Items.Add(".ml");
            strength_ComboBox.Items.Add("ml");
            strength_ComboBox.Items.Add("Tab");
            strength_ComboBox.Items.Add("Drops");
            strength_ComboBox.SelectedIndex = 0;
        }

        private void datadgv()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("select ROW_NUMBER() over (ORDER BY Drug) AS Sno,Icode,Drug as Medicine,StrMg,StrML,Dose,DivDose,str1U,Str2U,Dqty,Inst,Duration,DrugBased,DrugType from Drug order by Drug asc", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Drug");
                dataGridView1.DataSource = ds.Tables["Drug"];
                dataGridView1.Columns[0].Width = 50;
                dataGridView1.Columns[1].Width = 50;
                dataGridView1.Columns[2].Width = 320;
                dataGridView1.Columns[3].Width = 50;
                dataGridView1.Columns[4].Width = 50;
                dataGridView1.Columns[5].Width = 50;
                dataGridView1.Columns[6].Width = 160;
                dataGridView1.Columns[7].Width = 50;
                dataGridView1.Columns[8].Width = 50;
                dataGridView1.Columns[9].Width = 50;
                dataGridView1.Columns[10].Width = 270;
                dataGridView1.Columns[11].Width = 50;
                dataGridView1.Columns[12].Width = 50;
                dataGridView1.Columns[13].Width = 50;
                con.Close();
            }
        }

        private void drug_Load(object sender, EventArgs e)
        {
            autoinc();
            txt_Itemcode.Enabled = false;
            datadgv();
            FillDropDown();
            medicineload();
            this.Focus();
            dataGridView1_CellClick(null, null);
        }

        public void medicineload()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT Drug FROM Drug", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                Drug_ComboBox.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void autoinc()
        {
            int id = 0;
            string id_final = "";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select *  from Drug", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                SqlCommand cmd = new SqlCommand("select max(Sno) from Drug", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    id = Convert.ToInt32(dr[0].ToString());
                    id = id + 1;
                    id_final = Convert.ToString(id);
                    txt_Itemcode.Text = id_final.ToString();
                    txt_Itemcode.Enabled = false;
                }
                else
                {
                }
                dr.Close();
            }
            else
            {
                id = id + 1;
                id_final = Convert.ToString(id);
                txt_Itemcode.Text = id_final.ToString();
                txt_Itemcode.Enabled = false;
            }
        }

        public void BtnNew_Click(object sender, EventArgs e)
        {
            ClearData();
            autoinc();
            txt_Itemcode.Enabled = false;
        }
        private DataTable SetInitialRow()
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dtRow;
                dt.Columns.Add("FromYear");
                dt.Columns.Add("FromMonth");
                dt.Columns.Add("ToYear");
                dt.Columns.Add("ToMonth");
                dt.Columns.Add("DoseInUnits");
                // dt.Columns.Add("Remark");
                int Count = 1;
                for (int i = 0; i < Count; i++)
                {
                    dtRow = dt.NewRow();
                    dt.Rows.Add(dtRow);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }
        private DataTable SaveBeforeGetdata()
        {
            //try
            //{
            DataTable dtCurrentTable = SetInitialRow();
            DataRow drCurrentRow = null;
            for (int i = 0; i < dgv_date.Rows.Count; i++)
            {
                if (Convert.ToString(dgv_date.Rows[i].Cells[1].Value) != "")
                {
                    dtCurrentTable.Rows[i]["FromYear"] = dgv_date.Rows[i].Cells[0].Value;
                    dtCurrentTable.Rows[i]["FromMonth"] = dgv_date.Rows[i].Cells[1].Value;
                    dtCurrentTable.Rows[i]["ToYear"] = dgv_date.Rows[i].Cells[2].Value;
                    dtCurrentTable.Rows[i]["ToMonth"] = dgv_date.Rows[i].Cells[3].Value;
                    dtCurrentTable.Rows[i]["DoseInUnits"] = dgv_date.Rows[i].Cells[4].Value;
                    // dtCurrentTable.Rows[i]["Remark"] = dgv_date.Rows[i].Cells[0].Value;
                    if (dtCurrentTable.Rows.Count < dgv_date.Rows.Count)
                    {
                        drCurrentRow = dtCurrentTable.NewRow();
                        dtCurrentTable.Rows.Add(drCurrentRow);
                    }
                }
            }
            return dtCurrentTable;
        }
        public void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_Itemcode.Text != "" &&
                    Drug_ComboBox.Text != "" &&
                    Interval_ComboBox.Text != "" &&
                    txt_DefaultQty.Text != "" &&
                    Duration.Text != "" &&
                    cbdrugtype.Text != "" &&
                    txtinstruction.Text != "" &&
                    txttamil.Text != "" &&
                    (cbdrugtype.Text.ToUpper() == "VACCINE" ||
                    (txt1_strength.Text != "" &&
                    strength1_ComboBox.Text != "" &&
                    txt2_strength.Text != "" &&
                    strength_ComboBox.Text != "")
                    ))
                {

                    SqlConnection con = new SqlConnection(constr);
                    //if (txt_Itemcode.Text == "" || Drug_ComboBox.Text == "" || txt1_strength.Text == "" || txt2_strength.Text == "" || txt_Dose.Text == "" || Interval_ComboBox.Text == "" || txt_DefaultQty.Text == "" || txtinstruction.Text == "" || Duration.Text == "")
                    //{
                    SqlCommand cmd = new SqlCommand("declare @XmlString1 xml= @XmlString  " +
                                                    " insert into Drug(Icode,Drug,StrMg,StrML,Dose,DivDose,str1U,Str2U,Dqty,Inst,Duration,DrugBased,DrugType,Insttamil,Fixeddose)" +
                                                    " values(@Icode,@Drug,@StrMg,@StrML,@Dose,@DivDose,@str1U,@Str2U,@Dqty,@Inst,@Duration,@DrugBased,@DrugType,@Insttamil,@Fixeddose)" +
                                                    " delete from DrugAgeBased where ICode=@Icode " +
                                                   "  Insert Into dbo.DrugAgeBased (ICode,FromYear,FromMonth,ToYear,ToMonth,DoseInUnits) " +
                                                   "  SELECT 			" +
                                                   "  @Icode, " +
                                                   "  ParamValues.ID.value('FromYear[1]','VARCHAR(MAX)')," +
                                                   "  ParamValues.ID.value('FromMonth[1]','VARCHAR(MAX)')," +
                                                   "  ParamValues.ID.value('ToYear[1]','VARCHAR(MAX)')," +
                                                   "  ParamValues.ID.value('ToMonth[1]','VARCHAR(MAX)')," +
                                                   "  ParamValues.ID.value('DoseInUnits[1]','VARCHAR(MAX)')" +
                                                   " FROM @XmlString1.nodes('/DocumentElement/DrugAgeBased') as ParamValues(ID)  ", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Icode", Convert.ToInt32(txt_Itemcode.Text));
                    cmd.Parameters.AddWithValue("@Drug", Drug_ComboBox.Text);
                    cmd.Parameters.AddWithValue("@StrMg", txt1_strength.Text == "" ? 0 : Convert.ToDouble(txt1_strength.Text));
                    cmd.Parameters.AddWithValue("@StrML", txt2_strength.Text == "" ? 0 : Convert.ToDouble(txt2_strength.Text));
                    cmd.Parameters.AddWithValue("@Dose", txt_Dose.Text == "" ? 0 : Convert.ToDouble(txt_Dose.Text));
                    cmd.Parameters.AddWithValue("@DivDose", Interval_ComboBox.Text);
                    cmd.Parameters.AddWithValue("@str1U", strength_ComboBox.Text);
                    cmd.Parameters.AddWithValue("@Str2U", strength1_ComboBox.Text);
                    cmd.Parameters.AddWithValue("@Dqty", txt_DefaultQty.Text == "" ? 0 : Convert.ToDouble(txt_DefaultQty.Text));
                    cmd.Parameters.AddWithValue("@Inst", txtinstruction.Text);
                    cmd.Parameters.AddWithValue("@Insttamil", txttamil.Text);
                    cmd.Parameters.AddWithValue("@Duration", Duration.Text);
                    cmd.Parameters.AddWithValue("@Fixeddose", txtfdose.Text);
                    //cmd.Parameters.AddWithValue("@FromAge", txtfromAge.Text == "" ? "0" : txtfromAge.Text);
                    //cmd.Parameters.AddWithValue("@ToAge", txtToAge.Text == "" ? "0" : txtToAge.Text);
                    if (Rdofixed.Checked)
                        cmd.Parameters.AddWithValue("@DrugBased", 1);
                    else if (RdoAgebased.Checked)
                        cmd.Parameters.AddWithValue("@DrugBased", 2);
                    else if (RdoWeightbased.Checked)
                        cmd.Parameters.AddWithValue("@DrugBased", 3);
                    cmd.Parameters.AddWithValue("@DrugType", cbdrugtype.SelectedValue);

                    string XMlDt1 = "";
                    DataTable dtCurrentTable = SaveBeforeGetdata();
                    dtCurrentTable.TableName = "DrugAgeBased";

                    using (StringWriter sw = new StringWriter())
                    {
                        dtCurrentTable.WriteXml(sw);
                        XMlDt1 = sw.ToString();
                    }
                    cmd.Parameters.Add("@XmlString", SqlDbType.VarChar).Value = XMlDt1;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Records Inserted");
                    con.Close();
                    datadgv();
                    ClearData();
                    txt_Dose.Visible = true;
                    txtfdose.Visible = false;
                    txtfdose.Text = "0";

                    //}
                    //else
                    //{
                    //    MessageBox.Show("Please Fill All Records");

                    //}
                }
                else
                {
                    MessageBox.Show("Please Fill All Records");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void BtnRemove_Click(object sender, EventArgs e)
        {
            string res;
            res = Convert.ToString(MessageBox.Show("Are You want to Delete", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information));
            if (res == "Yes")
            {
                SqlConnection con = new SqlConnection(constr);
                if (txt_Itemcode.Text != "")
                {
                    SqlCommand cmd = new SqlCommand("Delete from Drug where Icode=@Icode", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Icode", txt_Itemcode.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Records Deleted successfully");
                    con.Close();
                    ClearData();
                    txt_Itemcode.Text = "";
                }
                datadgv();
            }
            else
            {
            }
        }

        public void BtnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            //if (txt_Itemcode.Text == "")
            //{
            SqlCommand cmd = new SqlCommand(" declare @XmlString1 xml= @XmlString  " +
                                            "  update Drug set Drug=@Drug,StrMg=@StrMg,StrML=@StrML,Dose=@Dose,DivDose=@DivDose, " +
                                            " str1U=@str1U,Str2U=@Str2U,Dqty=@Dqty,Inst=@Inst,Duration=N'" + Duration.Text + "'" +
                                            " ,DrugBased=@DrugBased,DrugType=@DrugType,Insttamil=@Insttamil,Fixeddose=@Fixeddose  where Icode=@Icode  " +
                                            "  delete from DrugAgeBased where ICode=@Icode " +
                                            "  Insert Into dbo.DrugAgeBased (ICode,FromYear,FromMonth,ToYear,ToMonth,DoseInUnits) " +
                                            "  SELECT 			" +
                                            "  @Icode, " +
                                            "  ParamValues.ID.value('FromYear[1]','VARCHAR(MAX)')," +
                                            "  ParamValues.ID.value('FromMonth[1]','VARCHAR(MAX)')," +
                                            "  ParamValues.ID.value('ToYear[1]','VARCHAR(MAX)')," +
                                            "  ParamValues.ID.value('ToMonth[1]','VARCHAR(MAX)')," +
                                            "  ParamValues.ID.value('DoseInUnits[1]','VARCHAR(MAX)')" +
                                            " FROM @XmlString1.nodes('/DocumentElement/DrugAgeBased') as ParamValues(ID) ", con);
            con.Open();
            cmd.Parameters.AddWithValue("@Icode", txt_Itemcode.Text);
            cmd.Parameters.AddWithValue("@Drug", Drug_ComboBox.Text);
            cmd.Parameters.AddWithValue("@StrMg", txt1_strength.Text == "" ? 0 : Convert.ToDouble(txt1_strength.Text));
            cmd.Parameters.AddWithValue("@StrML", txt2_strength.Text == "" ? 0 : Convert.ToDouble(txt2_strength.Text));
            cmd.Parameters.AddWithValue("@Dose", txt_Dose.Text == "" ? 0 : Convert.ToDouble(txt_Dose.Text));
            cmd.Parameters.AddWithValue("@DivDose", Interval_ComboBox.Text);
            cmd.Parameters.AddWithValue("@str1U", strength_ComboBox.Text);
            cmd.Parameters.AddWithValue("@Str2U", strength1_ComboBox.Text);
            cmd.Parameters.AddWithValue("@Dqty", txt_DefaultQty.Text == "" ? 0 : Convert.ToDouble(txt_DefaultQty.Text));
            cmd.Parameters.AddWithValue("@Inst", txtinstruction.Text);
            cmd.Parameters.AddWithValue("@Duration",  Duration.Text );
            cmd.Parameters.AddWithValue("@Fixeddose", txtfdose.Text);
            cmd.Parameters.AddWithValue("@Insttamil",  txttamil.Text);
            //cmd.Parameters.AddWithValue("@FromAge", txtfromAge.Text == "" ? "0" : txtfromAge.Text);
            //cmd.Parameters.AddWithValue("@ToAge", txtToAge.Text == "" ? "0" : txtToAge.Text);
            if (Rdofixed.Checked)
                cmd.Parameters.AddWithValue("@DrugBased", 1);
            else if (RdoAgebased.Checked)
                cmd.Parameters.AddWithValue("@DrugBased", 2);
            else if (RdoWeightbased.Checked)
                cmd.Parameters.AddWithValue("@DrugBased", 3);
            cmd.Parameters.AddWithValue("@DrugType", cbdrugtype.SelectedValue);
            string XMlDt1 = "";
            DataTable dtCurrentTable = SaveBeforeGetdata();
            dtCurrentTable.TableName = "DrugAgeBased";

            using (StringWriter sw = new StringWriter())
            {
                dtCurrentTable.WriteXml(sw);
                XMlDt1 = sw.ToString();
            }
            cmd.Parameters.Add("@XmlString", SqlDbType.VarChar).Value = XMlDt1;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated successfully");
            con.Close();
            datadgv();
            txt_Itemcode.Text = "";
            ClearData();
            //}
            //else
            //{
            //    MessageBox.Show("Please select record to update");
            //}
        }

        private void ClearData()
        {
            Duration.Text = "";
            Drug_ComboBox.Text = "";
            txt1_strength.Text = "";
            txt2_strength.Text = ""; txttamil.Text = "";
            txt_Dose.Text = "";
            Interval_ComboBox.SelectedIndex = -1;
            strength_ComboBox.Text = "";
            strength1_ComboBox.Text = "";
            txt_DefaultQty.Text = "";
            txtinstruction.Text = "";
            cbdrugtype.Text = "";
            //RdoWeightbased.Checked = true;
            dgv_date.DataSource = SetInitialRow();
            txtfdose.Visible = false;
            txt_Dose.Visible = true;
            txtfdose.Text = "";
            //txtfromAge.Text = "";
            //txtToAge.Text = "";
        }

        private void Interval_ComboBox_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (Interval_ComboBox.SelectedIndex == 2)
            {
                Duration.Text = "6 hrly";
            }
            else if (Interval_ComboBox.SelectedIndex == 3)
            {
                Duration.Text = "8 hrly";
            }
            else if (Interval_ComboBox.SelectedIndex == 4)
            {
                Duration.Text = "12 hrly";
            }
            else if (Interval_ComboBox.SelectedIndex == 5)
            {
                Duration.Text = "24 hrly";
            }
            else if (Interval_ComboBox.SelectedIndex == 1)
            {
                Duration.Text = "As Needed";
            }
            else if (Interval_ComboBox.SelectedIndex == 0)
            {
                Duration.Text = " ";
            }
        }

        private void txt_Itemcode_Leave(object sender, EventArgs e)
        {
            FillRecord();
        }

        void FillRecord()
        {
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            {
                SqlCommand cmd = new SqlCommand("select Drug,StrMg,StrML,Dose,DivDose,str1U,Str2U,Dqty,Inst,Duration,DrugBased,DrugType,Insttamil,Fixeddose from Drug where Icode ='" + txt_Itemcode.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Drug_ComboBox.Text = dr[0].ToString();
                    txt1_strength.Text = dr[1].ToString();
                    txt2_strength.Text = dr[2].ToString();
                    txt_Dose.Text = dr[3].ToString();
                    Interval_ComboBox.Text = dr[4].ToString();
                    strength_ComboBox.Text = dr[5].ToString();
                    strength1_ComboBox.Text = dr[6].ToString();
                    txt_DefaultQty.Text = dr[7].ToString();
                    txtinstruction.Text = dr[8].ToString();
                    Duration.Text = dr[9].ToString();
                    txttamil.Text = dr[12].ToString();
                    txtfdose.Text = dr[13].ToString();
                    //txtfromAge.Text = dr[10].ToString();
                    //txtToAge.Text = dr[11].ToString();
                    if (dr[10].ToString() == "1")
                    {
                        Rdofixed.Checked = true;
                    }
                    else if (dr[10].ToString() == "2")
                    {
                        RdoAgebased.Checked = true;
                    }
                    else
                    {
                        RdoWeightbased.Checked = true;
                    }
                    if (dr[11].ToString() != "")
                        cbdrugtype.SelectedValue = dr[11].ToString();
                    fillAgeBased(txt_Itemcode.Text);




                    dr.Close();
                    con.Close();
                }
            }
        }

        void fillAgeBased(string icODE)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from DrugAgeBased where ICode=@ICode ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                cmd.Parameters.AddWithValue("@ICode", icODE);
                da.Fill(ds);
                con.Close();
                dgv_date.DataSource = null;
                dgv_date.AutoGenerateColumns = true;
                dgv_date.DataSource = ds.Tables[0];
            }
        }
        private void btn_clr_Click(object sender, EventArgs e)
        {
            ClearData();
            txt_Itemcode.Enabled = true;
            txt_Itemcode.Text = "";
            txtfdose.Text = "";
            txttamil.Text = "";
            txtfdose.Visible = false;
            txt_Dose.Visible = true;
        }

        void FillDropDown()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select RowID,DrugTypeName from DrugType ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
                cbdrugtype.DropDownStyle = ComboBoxStyle.DropDown;
                cbdrugtype.AutoCompleteSource = AutoCompleteSource.ListItems;
                cbdrugtype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;

                cbdrugtype.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
                cbdrugtype.ValueMember = "RowID";
                cbdrugtype.DisplayMember = "DrugTypeName";
            }

        }

        private void Rdofixed_CheckedChanged(object sender, EventArgs e)
        {
            dgv_date.Visible = false;
            if (Rdofixed.Checked == true)
            {
                txtfdose.Visible = true;
                txt_Dose.Visible = false;
            }
            else
            {
                txtfdose.Visible = false;
                txt_Dose.Visible = true;
            }
        }

        private void RdoAgebased_CheckedChanged(object sender, EventArgs e)
        {
            dgv_date.Visible = true;
        }

        private void RdoWeightbased_CheckedChanged(object sender, EventArgs e)
        {
            dgv_date.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (sender == null) { if (dataGridView1.Rows.Count > 0) txt_Itemcode.Text = dataGridView1.Rows[0].Cells[1].Value.ToString(); FillRecord(); return; }
            if (e.RowIndex < 0) return;
            int rowIndex = dataGridView1.Rows[e.RowIndex].Index;

            if (dataGridView1 == null)
                return;
            //if (dataGridView1.Rows[e.RowIndex].Cells[0].Selected == true)
            //{
            txt_Itemcode.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            //A.RowID,A.Name,A.Remark,A.DtRowID,B.Name
            if (dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString() != "")
                FillRecord();
            else
                ClearData();
            //}
            //else
            //    ClearData();
        }

        private void BtnAddDrugType_Click(object sender, EventArgs e)
        {

            //ParentForm.WindowState = FormWindowState.Minimized;

            //DrugType DT = new DrugType();
            //DT.ShowDialog();
            // DT.BringToFront();

        }

        private void Drug_ComboBox_TextChanged(object sender, EventArgs e)
        {
            //FillRecordbasedonmedicine();
        }

        void FillRecordbasedonmedicine()
        {
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            {
                SqlCommand cmd = new SqlCommand("select Drug,StrMg,StrML,Dose,DivDose,str1U,Str2U,Dqty,Inst,Duration,DrugBased,DrugType,Icode from Drug where Drug ='" + Drug_ComboBox.Text + "'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txt_Itemcode.Text = dr[12].ToString();
                    Drug_ComboBox.Text = dr[0].ToString();
                    txt1_strength.Text = dr[1].ToString();
                    txt2_strength.Text = dr[2].ToString();
                    txt_Dose.Text = dr[3].ToString();
                    Interval_ComboBox.Text = dr[4].ToString();
                    strength_ComboBox.Text = dr[5].ToString();
                    strength1_ComboBox.Text = dr[6].ToString();
                    txt_DefaultQty.Text = dr[7].ToString();
                    txtinstruction.Text = dr[8].ToString();
                    Duration.Text = dr[9].ToString();
                    //txtfromAge.Text = dr[10].ToString();
                    //txtToAge.Text = dr[11].ToString();
                    if (dr[10].ToString() == "1")
                    {
                        Rdofixed.Checked = true;
                    }
                    else if (dr[10].ToString() == "2")
                    {
                        RdoAgebased.Checked = true;
                    }
                    else
                    {
                        RdoWeightbased.Checked = true;
                    }
                    if (dr[11].ToString() != "")
                        cbdrugtype.SelectedValue = dr[11].ToString();
                    fillAgeBased(txt_Itemcode.Text);
                    dr.Close();
                    con.Close();
                }
            }
        }

        private void Drug_ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                FillRecordbasedonmedicine();
            }

            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                Interval_ComboBox.Focus();
            }
        }

        private void Interval_ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                Drug_ComboBox.Focus();
            }
        }

        private void txt_DefaultQty_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                Interval_ComboBox.Focus();
            }
        }

        private void txt1_strength_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txt_DefaultQty.Focus();
            }
        }

        private void strength1_ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txt1_strength.Focus();
            }
        }

        private void txt2_strength_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                strength1_ComboBox.Focus();
            }
        }

        private void strength_ComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txt2_strength.Focus();
            }
        }

        private void txtfdose_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                strength_ComboBox.Focus();
            }
        }

        private void cbdrugtype_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtinstruction.Focus();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                if (txtfdose.Visible == true)
                {
                    txtfdose.Focus();
                }
                else
                {
                    txt_Dose.Focus();
                }
            }
        }

        private void txtinstruction_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txttamil.Focus();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                cbdrugtype.Focus();
            }
        }

        private void txttamil_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtinstruction.Focus();
            }
        }

        private void txt_Dose_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                strength_ComboBox.Focus();
            }
        }

        private void btndrugtype_Click(object sender, EventArgs e)
        {
            DrugType _drty = new DrugType();
            _drty.ShowDialog();
        }

        private void NewDrug_VisibleChanged(object sender, EventArgs e)
        {
            dataGridView1_CellClick(null, null);
        }


        private void cbdrugtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbdrugtype.Text.ToUpper() == "VACCINE")
                Interval_ComboBox.SelectedIndex = 0;
        }

    }
}
