﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewPatient : MetroFramework.Controls.MetroUserControl
    {
        SqlConnection con = null; NewPrescription _pres = null;
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public NewPatient(NewPrescription pres)
        {
            InitializeComponent();
            _pres = pres;
        }

        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string querry = @"SELECT  
      DISTINCT [PatiantID]
      ,[Name]
      ,[Gender]
      ,[PhoneNo]
      ,[Address]
      ,[DateOfBirth]
  FROM [regappform3] order by PatiantID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                PatientGrid.DataSource = ds.Tables[0];

            }
        }

        public void NewPatient_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }


        private void PatientGrid_DoubleClick(object sender, EventArgs e)
        {
            DataGridView _dgv = ((DataGridView)sender);
            DataSet ds = _pres.LoadOldPrescriptionDS(new DateTime(), new DateTime(), false, " ", _dgv.SelectedRows[0].Cells[0].Value.ToString());

            if (ds.Tables[0].Rows.Count == 0) { MessageBox.Show("No Data to Display!"); return; }
            OpView _op = new OpView(ds);
            _op.ShowDialog();
        }
    }
}
