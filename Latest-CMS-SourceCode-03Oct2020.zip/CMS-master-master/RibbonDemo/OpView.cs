﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class OpView : MetroFramework.Forms.MetroForm
    {
        string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        private string diagonishHtml = string.Empty;
        private string advisceHtml = string.Empty;
        private string Yet2Save = " - Yet to Save.";
        int yearDiff;
        int monthdiff;
        int daysdiff;
        public OpView(DataSet ds)
        {
            InitializeComponent();
            LoadOldpres(ds);
        }
        private void GetData(string selectCommand)
        {
            SqlConnection con = new SqlConnection(constr);

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter sda = new SqlDataAdapter("select * from PresItem$", con);
            SqlCommandBuilder combuild = new SqlCommandBuilder(sda);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            prescriptionGrid.DataSource = prescriptionGrid;

        }

        private void btnexport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Updated");
        }

        private void txtheight_TextChanged(object sender, EventArgs e)
        {
            if (txtheight.Text != "" && txtweight.Text != "")
                calculatebmi(Convert.ToDouble(txtheight.Text), Convert.ToDouble(txtweight.Text));

        }

        private void txtweight_TextChanged(object sender, EventArgs e)
        {
            if (txtheight.Text != "" && txtweight.Text != "")
                calculatebmi(Convert.ToDouble(txtheight.Text), Convert.ToDouble(txtweight.Text));


        }
        void calculatebmi(double w, double h)
        {
            txtbmi.Text = Math.Round((w / (h * h)) * 10000, 2).ToString();

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            string res;
            res = Convert.ToString(MessageBox.Show("Are You want to Exit", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information));
            if (res == "Yes")
            {
                this.Close();
            }
            else
            {
            }
        }

        private void OpView_Load(object sender, EventArgs e)
        {
            FillDropDown();

        }

        private string FloatingConverter(string value)
        {
            string output = "";
            try
            {
                if (double.Parse(value) == Convert.ToInt32(double.Parse(value)))
                {
                    output = Convert.ToInt32(double.Parse(value)).ToString("D");
                }
                else
                {
                    output = value;
                }

            }
            catch
            {
                output = value;
            }
            return output;
        }

        private void listBox2_Click(object sender, EventArgs e)
        {
            LoadBasedonEPresNo();
        }

        public void DateDifference(DateTime d1, DateTime d2)
        {
            int[] monthDay = new int[12] { 31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            int year;
            int month;
            int day;

            DateTime fromDate;


            DateTime toDate;

            int increment;

            if (d1 > d2)
            {
                fromDate = d2;
                toDate = d1;
            }
            else
            {
                fromDate = d1;
                toDate = d2;
            }

            /// 
            /// Day Calculation
            /// 
            increment = 0;

            if (fromDate.Day > toDate.Day)
            {
                increment = monthDay[fromDate.Month - 1];

            }
            /// if it is february month
            /// if it's to day is less then from day
            if (increment == -1)
            {
                if (DateTime.IsLeapYear(fromDate.Year))
                {
                    // leap year february contain 29 days
                    increment = 29;
                }
                else
                {
                    increment = 28;
                }
            }
            if (increment != 0)
            {
                day = (toDate.Day + increment) - fromDate.Day;
                increment = 1;
            }
            else
            {
                day = toDate.Day - fromDate.Day;
            }

            ///
            ///month calculation
            ///
            if ((fromDate.Month + increment) > toDate.Month)
            {
                month = (toDate.Month + 12) - (fromDate.Month + increment);
                increment = 1;
            }
            else
            {
                month = (toDate.Month) - (fromDate.Month + increment);
                increment = 0;
            }

            ///
            /// year calculation
            ///
            year = toDate.Year - (fromDate.Year + increment);

            yearDiff = year;
            monthdiff = month;
            daysdiff = day;

        }

        //DataSet LoadBasedonEPresNo(int res)
        //{
        //    DataSet ds = new DataSet();
        //    try
        //    {
        //        if (ctrllistbxEpresNo.SelectedValue.ToString().Contains(Yet2Save))
        //            btnEdit.Enabled = true;
        //        else
        //            btnEdit.Enabled = false;
        //        string _Selectedvalue = ctrllistbxEpresNo.SelectedValue.ToString().Replace(Yet2Save, "");
        //        if (_Selectedvalue != "")
        //        {
        //            SqlConnection con = new SqlConnection(constr);

        //            con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
        //            if (con.State == ConnectionState.Closed)
        //                con.Open();
        //            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
        //            string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Age,DateOfBirth,ReviewDate,A.HeadCircum,A.DiagnosisHTML,A.CategoryID,A.DiagnosisAdvice,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo,A.Address, " +
        //                            "A.Height,A.Weigt,A.BMI,A.Temp,B.Diagnosis from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
        //                            " where A.EPresNo=@EPresno;  select  row_number() over (order by EPresNo) as SNo, " +
        //                            " Icode[Medicine],Qty[Quantity],Dose[Dose],devideDose[dividedDoses],Instruction[Instructions],Interval[Interval],InstructionEnglish[InstructionEnglish],InstructionTamil[InstructionTamil] " +
        //                            " from Prescription_DT where EPresNo=@EPresNo";
        //            SqlCommand cmd = new SqlCommand(querry, con);
        //            cmd.Parameters.AddWithValue("@EPresno", _Selectedvalue);
        //            //cmd.Parameters.AddWithValue("@phoneno", txtPhoneNo.Text);
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            da.Fill(ds);
        //            if (ds.Tables[0].Rows.Count > 0)
        //            {
        //                txtepressno.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
        //                txtpatientid.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
        //                txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString() + ' ' + ds.Tables[0].Rows[0]["LastName"].ToString();
        //                txtgender.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
        //                txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
        //                string reviewDate = ds.Tables[0].Rows[0]["ReviewDate"].ToString();
        //                try
        //                {
        //                    var res = reviewDate.Split(' ');
        //                    string iDate = res[0];
        //                    DateTime oDate = Convert.ToDateTime(iDate);
        //                    ctrlTxtReviewDate.Text = oDate.Day.ToString("00") + "/" + oDate.Month + "/" + oDate.Year;


        //                }
        //                catch
        //                {
        //                    ctrlTxtReviewDate.Text = ds.Tables[0].Rows[0]["ReviewDate"].ToString();
        //                }

        //                string visiteddate = ds.Tables[0].Rows[0]["Date"].ToString();
        //                ctrltxtVisitDate.Text = visiteddate;
        //                txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
        //                txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
        //                txtbmi.Text = ds.Tables[0].Rows[0]["BMI"].ToString();
        //                txttemp.Text = ds.Tables[0].Rows[0]["Temp"].ToString();
        //                txtHC.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
        //                txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
        //                txtDiagnosis.Text = ds.Tables[0].Rows[0]["Diagnosis"].ToString();

        //                System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
        //                rtBox.Rtf = ds.Tables[0].Rows[0]["DiagnosisHTML"].ToString();
        //                diagonishHtml = rtBox.Text;
        //                rtBox.Rtf = ds.Tables[0].Rows[0]["DiagnosisAdvice"].ToString();
        //                advisceHtml = rtBox.Text;

        //                prescriptionGrid.DataSource = ds.Tables[1];
        //                prescriptionGrid.Columns[0].Width = 30;
        //                prescriptionGrid.Columns[1].Width = 300;
        //                prescriptionGrid.Columns[2].Width = 50;
        //                prescriptionGrid.Columns[3].Width = 50;
        //                prescriptionGrid.RowHeadersVisible = false;
        //                try
        //                {
        //                    cbCategory.SelectedIndex = Convert.ToInt32(ds.Tables[0].Rows[0]["CategoryID"].ToString());
        //                }
        //                catch
        //                {
        //                }
        //                prescriptionGrid.AutoGenerateColumns = false;
        //            }
        //            else
        //            {
        //                txtepressno.Text = "";
        //                txtpatientid.Text = "";
        //                txtgender.Text = "";
        //                txtname.Text = "";
        //                txtage.Text = "";
        //                ctrltxtVisitDate.Text = "";
        //                txtheight.Text = "";
        //                txtweight.Text = "";
        //                txtbmi.Text = "";
        //                txttemp.Text = "";
        //                prescriptionGrid.DataSource = null;
        //                prescriptionGrid.AutoGenerateColumns = false;
        //                txtHC.Text = "";
        //                txtAddress.Text = "";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    return ds;
        //}

        DataSet LoadBasedonEPresNo()
        {
            DataSet ds = new DataSet();
            try
            {
                if (ctrllistbxEpresNo.SelectedValue.ToString().Contains(Yet2Save))
                    btnEdit.Enabled = true;
                else
                    btnEdit.Enabled = false;
                string _Selectedvalue = ctrllistbxEpresNo.SelectedValue.ToString().Replace(Yet2Save, "");
                if (_Selectedvalue != "")
                {
                    SqlConnection con = new SqlConnection(constr);

                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                    SqlCommand cmd = new SqlCommand("Sp_LoadPrescription", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EpresNo", _Selectedvalue);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtepressno.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                        txtpatientid.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                        txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString() + ' ' + ds.Tables[0].Rows[0]["LastName"].ToString();
                        txtgender.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                        txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                        string reviewDate = ds.Tables[0].Rows[0]["ReviewDate"].ToString();
                        try
                        {
                            var res = reviewDate.Split(' ');
                            string iDate = res[0];
                            DateTime oDate = Convert.ToDateTime(iDate);
                            ctrlTxtReviewDate.Text = oDate.Day.ToString("00") + "/" + oDate.Month + "/" + oDate.Year;
                        }
                        catch
                        {
                            ctrlTxtReviewDate.Text = ds.Tables[0].Rows[0]["ReviewDate"].ToString();
                        }

                        string visiteddate = ds.Tables[0].Rows[0]["Date"].ToString();
                        ctrltxtVisitDate.Text = visiteddate;
                        txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
                        txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
                        txtbmi.Text = ds.Tables[0].Rows[0]["BMI"].ToString();
                        txttemp.Text = ds.Tables[0].Rows[0]["Temp"].ToString();
                        txtHC.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
                        txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                        txtDiagnosis.Text = ds.Tables[0].Rows[0]["Diagnosis"].ToString();

                        System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                        rtBox.Rtf = ds.Tables[0].Rows[0]["DiagnosisHTML"].ToString();
                        diagonishHtml = rtBox.Text;
                        rtBox.Rtf = ds.Tables[0].Rows[0]["DiagnosisAdvice"].ToString();
                        advisceHtml = rtBox.Text;

                        prescriptionGrid.DataSource = ds.Tables[1];
                        prescriptionGrid.Columns[0].Width = 30;
                        prescriptionGrid.Columns[1].Width = 300;
                        prescriptionGrid.Columns[2].Width = 50;
                        prescriptionGrid.Columns[3].Width = 50;
                        prescriptionGrid.RowHeadersVisible = false;
                        try
                        {
                            cbCategory.SelectedIndex = Convert.ToInt32(ds.Tables[0].Rows[0]["CategoryID"].ToString());
                        }
                        catch
                        {
                        }
                        prescriptionGrid.AutoGenerateColumns = false;
                    }
                    else
                    {
                        txtepressno.Text = "";
                        txtpatientid.Text = "";
                        txtgender.Text = "";
                        txtname.Text = "";
                        txtage.Text = "";
                        ctrltxtVisitDate.Text = "";
                        txtheight.Text = "";
                        txtweight.Text = "";
                        txtbmi.Text = "";
                        txttemp.Text = "";
                        prescriptionGrid.DataSource = null;
                        prescriptionGrid.AutoGenerateColumns = false;
                        txtHC.Text = "";
                        txtAddress.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return ds;
        }

        void FillDropDown()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select RowID,Category,Amount from AmountCategory ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbCategory.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
                cbCategory.ValueMember = "RowID";
                cbCategory.DisplayMember = "Category";

                con.Close();
            }

        }

        bool Allvaluefilled(string _lstvalue)
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();

                string query = "select  row_number() over (order by EPresNo) as SNo, " +
                                       " Icode[Medicine],Qty[Quantity],Dose[Dose],devideDose[dividedDoses],Instruction[Instructions],Interval[Interval],InstructionEnglish[InstructionEnglish],InstructionTamil[InstructionTamil] " +
                                       " from Prescription_DT where EPresNo=@EPresNo";



                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@EPresno", _lstvalue.ToString());
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                con.Close();
                if (ds.Tables[0].Rows.Count < 2)
                    return false;
                else
                    return true;
            }

        }

        private void txtepressno_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtDiagnosis.Focus();
            }
        }

        private void txtname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtepressno.Focus();
            }
        }

        private void txtage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtname.Focus();
            }
        }

        private void txtgender_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtage.Focus();
            }
        }

        private void txtheight_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtgender.Focus();
            }
        }

        private void txtweight_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtheight.Focus();
            }
        }

        private void txtpatientid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtweight.Focus();
            }
        }

        private void txtvisitdate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtpatientid.Focus();
            }
        }

        private void txtbmi_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ctrltxtVisitDate.Focus();
            }
        }

        private void txttemp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtbmi.Focus();
            }
        }

        private void textBox16_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txttemp.Focus();
            }
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            try
            {
                if (prescriptionGrid.Rows.Count > 0)
                {
                    DataSet ds = new DataSet();
                    DataTable details = new DataTable("Details");
                    DataTable drugDetails = new DataTable("Drugdetails");
                    CreatePrescriptionTable(details, drugDetails);


                    DataRow dRow = details.NewRow();
                    dRow["FullName"] = txtname.Text;
                    dRow["Address"] = txtAddress.Text;
                    dRow["Temp"] = FloatingConverter(txttemp.Text);
                    dRow["Pres"] = txtepressno.Text;
                    dRow["PatientID"] = txtpatientid.Text;
                    dRow["Height"] = FloatingConverter(txtheight.Text);
                    dRow["Weight"] = FloatingConverter(txtweight.Text);
                    dRow["Dignosis"] = txtDiagnosis.Text;
                    dRow["Age"] = txtage.Text;
                    dRow["Gender"] = txtgender.Text;
                    dRow["HC"] = txtHC.Text;
                    dRow["ReviewDate"] = ctrlTxtReviewDate.Text;
                    dRow["VisitedDate"] = ctrltxtVisitDate.Text;
                    dRow["Advice"] = advisceHtml.Replace("\n", "$$");
                    dRow["ClinicalNotes"] = diagonishHtml;
                    dRow["Category"] = cbCategory.Text;

                    details.Rows.Add(dRow);

                    foreach (DataGridViewRow item in prescriptionGrid.Rows)
                    {
                        try
                        {
                            int index = prescriptionGrid.Rows.IndexOf(item);
                            var medicine = (index + 1) + "." + prescriptionGrid.Rows[index].Cells["Medicine"].Value;
                            var quantity = prescriptionGrid.Rows[index].Cells["Quantity"].Value;
                            var dose = prescriptionGrid.Rows[index].Cells["Dose"].Value;
                            var dividedDose = prescriptionGrid.Rows[index].Cells["DividedDoses"].Value;
                            var interval = prescriptionGrid.Rows[index].Cells["Interval"].Value;

                            //var instruction = dataGridView1.Rows[index].Cells["Instructions"].Value;               
                            var instruction = prescriptionGrid.Rows[index].Cells["InstructionTamil"].Value;
                            instruction = prescriptionGrid.Rows[index].Cells["InstructionEnglish"].Value;
                            var intervalFrequency = dividedDose.ToString() + " - " + instruction.ToString(); ;// "Every " + instruction.ToString() + " - " + dividedDose.ToString();

                            if (interval.ToString().StartsWith("As"))
                                intervalFrequency = dividedDose.ToString();
                            // "Every " + instruction.ToString() + " - " + dividedDose.ToString();
                            else
                                intervalFrequency = dividedDose.ToString() + " - " + interval.ToString(); ;// "Every " + instruction.ToString() + " - " + dividedDose.ToString();
                            if (!string.IsNullOrEmpty(quantity.ToString()) && !(string.IsNullOrEmpty(dose.ToString())))
                                drugDetails.Rows.Add(medicine, quantity, dose, interval, dividedDose, interval, instruction, intervalFrequency);
                        }
                        catch
                        {
                        }

                    }

                    ds.Tables.Add(details);
                    ds.Tables.Add(drugDetails);
                    frmReortViewer viewer = new frmReortViewer();
                    viewer.PrescriptionDataset = ds;
                    viewer.IsDirectPrint = directprintcheckbox.Checked;
                    if (!viewer.IsDirectPrint)
                        if (DialogResult.Yes == MessageBox.Show("Do you want to print using Printer? ", "S V Medical Center", MessageBoxButtons.YesNo))
                            viewer.IsDirectPrint = true;
                        else
                            viewer.IsDirectPrint = false;
                    viewer.MinimizeBox = true;
                    viewer.Show();

                    //  LoadPrescriptionPrint(ds);
                }
                else
                {
                    MessageBox.Show("Please choose valid data");
                }
            }
            catch
            {
            }
        }

        private static void CreatePrescriptionTable(DataTable details, DataTable drugDetails)
        {
            details.Columns.Add("FullName", typeof(string));
            details.Columns.Add("Address", typeof(string));
            details.Columns.Add("Temp", typeof(string));
            details.Columns.Add("Pres", typeof(string));
            details.Columns.Add("Height", typeof(string));
            details.Columns.Add("Weight", typeof(string));
            details.Columns.Add("Dignosis", typeof(string));
            details.Columns.Add("Advice", typeof(string));
            details.Columns.Add("Age", typeof(string));
            details.Columns.Add("Gender", typeof(string));
            details.Columns.Add("HC", typeof(string));
            details.Columns.Add("ReviewDate", typeof(string));
            details.Columns.Add("ClinicalNotes", typeof(string));
            details.Columns.Add("Category", typeof(string));
            details.Columns.Add("PatientID", typeof(string));
            details.Columns.Add("NameWithID", typeof(string));
            details.Columns.Add("VisitedDate", typeof(string));



            drugDetails.Columns.Add("Medicine", typeof(string));
            drugDetails.Columns.Add("Nos", typeof(double));
            drugDetails.Columns.Add("Dose", typeof(string));
            drugDetails.Columns.Add("Interval", typeof(string));
            drugDetails.Columns.Add("Frequency", typeof(string));
            drugDetails.Columns.Add("Duration", typeof(string));
            drugDetails.Columns.Add("Description", typeof(string));
            drugDetails.Columns.Add("IntervalFrequency", typeof(string));
        }

        private void LoadPrescriptionPrint(DataSet prescriptionValues)
        {
            frmReortViewer viewer = new frmReortViewer();
            viewer.PrescriptionDataset = prescriptionValues;
            viewer.IsDirectPrint = directprintcheckbox.Checked;
            if (!viewer.IsDirectPrint)
                if (DialogResult.Yes == MessageBox.Show("Do you want to print using Printer? ", "S V Medical Center", MessageBoxButtons.YesNo))
                    viewer.IsDirectPrint = true;
                else
                    viewer.IsDirectPrint = false;
            viewer.MinimizeBox = true;
            viewer.Show();

        }

        private void txtepressno_TextChanged(object sender, EventArgs e)
        {

        }

        #region IN6TECH
        private void LoadOldpres(DataSet ds)
        {
            //SqlConnection con = new SqlConnection(constr);

            //SqlCommand cmd = new SqlCommand();

            //string querys = "select EPresNo,ApNo from regappform3 where Date between '" + from.ToString("yyyy/MM/dd") + "' and '" + to.AddDays(1).ToString("yyyy/MM/dd") + "' order by EPresNo desc";
            //SqlCommand cmd1 = new SqlCommand(querys, con);

            //DataSet ds = new DataSet();
            //ds.Tables.Add("Epresnoload");
            //SqlDataAdapter da = new SqlDataAdapter(cmd1);

            //SqlCommandBuilder sqb = new SqlCommandBuilder(da);

            //da.Fill(ds, "Epresnoload");

            int i = 0;
            //List<string> strlst = new List<string>();
            //foreach (System.Data.DataRowView drv in ctrllistbxEpresNo.Items)
            //{
            //    string str = drv.Row.ItemArray[0].ToString();
            //    strlst.Add(str);
            //}
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                //string str = drv.Row.ItemArray[0].ToString();
                if (dr[0].ToString() != "")
                    if (!Allvaluefilled(dr[0].ToString()))
                        ds.Tables[0].Rows[i][0] = (dr[0].ToString() + Yet2Save);
                i++;
            }
            ctrllistbxEpresNo.DataSource = ds.Tables[0];
            ctrllistbxEpresNo.DisplayMember = "EPresNo";
            ctrllistbxEpresNo.ValueMember = "EPresNo";
            ctrltxtTotalNoOfpatient.Text = ctrllistbxEpresNo.Items.Count.ToString();
            LoadBasedonEPresNo();
        }
        #endregion

        private void ctrllistbxEpresNo_DoubleClick(object sender, EventArgs e)
        {
            if (ctrllistbxEpresNo.SelectedValue.ToString().Contains(Yet2Save))
            {
                if (this.ParentForm is MainForm)
                {
                    MainForm form = (MainForm)this.ParentForm;
                    form.newPrescription.SetOldPrescriptions(LoadBasedonEPresNo());
                    form.newPrescription.Dock = DockStyle.Fill;
                    form.newPrescription.BringToFront();
                    this.Close();
                }
            }
        }
    }
}
