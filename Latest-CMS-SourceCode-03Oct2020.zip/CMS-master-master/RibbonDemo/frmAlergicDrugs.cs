﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LicenseKeyActivation;

namespace SVMApplication
{
    public partial class frmAlergicDrugs : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
       public bool IsModified = false;
        public frmAlergicDrugs()
        {
            InitializeComponent();
            this.TopMost = true;
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string querry = @"select Name,Description from AllergyMaster order by Id asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                ctrlGridAlergicDrugs.DataSource = ds.Tables[0];
                
            }
        }
         
        private void FrmAlergicDrugs_Load(object sender, EventArgs e)
        {
            LoadGrid();            
            ctrlTxtAlergicDrugName.Focus();

        }

        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ((TextBox)sender).Focus();
            }
        }
        string drugName = "";
        private void CtrlGridAlergicDrugs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;

            if (e != null) Rowidx = e.RowIndex;

            if (Rowidx < 0)
                return;

            Clear();

            int rowIndex = ctrlGridAlergicDrugs.Rows[Rowidx].Index;
            ctrlGridAlergicDrugs.Rows[Rowidx].Cells[0].Selected = true;

            if (ctrlGridAlergicDrugs == null)
                return;
            if (ctrlGridAlergicDrugs.Rows[Rowidx].Cells[0].Selected == true)
            {

                if (Convert.ToString(ctrlGridAlergicDrugs.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {


                    ctrlTxtAlergicDrugName.Text = ctrlGridAlergicDrugs.Rows[Rowidx].Cells[0].Value.ToString();
                    drugName = ctrlGridAlergicDrugs.Rows[Rowidx].Cells[0].Value.ToString();
                    ctrlTxtDescption.Text = ctrlGridAlergicDrugs.Rows[Rowidx].Cells[1].Value.ToString();
                    ctrlAddButton.Text = "Update";
                }
                else
                    Clear();
            }
            else
                Clear();
        }
        private void Clear()
        {
            ctrlAddButton.Text = "Save";
            ctrlTxtAlergicDrugName.Text = "";
            ctrlTxtDescption.Text = "";             
        }       
        private void CtrlAddButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ctrlTxtAlergicDrugName.Text))
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cm = new SqlCommand("select count(*) from AllergyMaster where Name=@alergyName and Description=@desc", con);
                cm.Parameters.AddWithValue("@alergyName", ctrlTxtAlergicDrugName.Text);
                cm.Parameters.AddWithValue("@desc", ctrlTxtDescption.Text);
                int count = Convert.ToInt32(cm.ExecuteScalar());

                if (count>0)
                {
                    ctrlAddButton.Text = "Update";
                    MessageBox.Show("Alergy is already exist");
                    return;
                }
                else
                {
                    SaveMethod();
   
                    LoadGrid();
                    ctrlAddButton.Text = "Save";
                    IsModified = true;
                    Clear();
                }



            }
        }      
        private string SaveMethod()
        {

            using (con)
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();

                if (ctrlAddButton.Text == "Update")
                {

                    SqlCommand cmd = new SqlCommand(" update AllergyMaster set Name = @Name,Description = @Description where Name = @OriginalName", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Name", ctrlTxtAlergicDrugName.Text);
                    cmd.Parameters.AddWithValue("@Description", ctrlTxtDescption.Text);
                    cmd.Parameters.AddWithValue("@OriginalName", drugName);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated Successfully");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("Sp_Allergy", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", ctrlTxtAlergicDrugName.Text);
                    cmd.Parameters.AddWithValue("@Description", ctrlTxtDescption.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Added Successfully");
                }
            }
            return "";
        }

        
        private void CtrlDeleteButton_Click(object sender, EventArgs e)
        {
            if (ctrlGridAlergicDrugs.SelectedRows.Count > 0)
            {
              

                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete from AllergyMaster where Name=@alergyName and Description=@desc", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@alergyName", ctrlTxtAlergicDrugName.Text);
                        cmd.Parameters.AddWithValue("@desc", ctrlTxtDescption.Text);
                        cmd.ExecuteNonQuery();
                        IsModified = true;
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    Clear();
                }

            }

        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                Close();
            }
            base.OnKeyDown(e);
        }

    }
}
