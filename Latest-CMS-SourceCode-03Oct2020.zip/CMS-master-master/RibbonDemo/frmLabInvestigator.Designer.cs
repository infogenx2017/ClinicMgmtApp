﻿namespace SVMApplication
{
    partial class frmLabInvestigator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLabInvestigator));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlGridLabInvest = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlLblName = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtName = new MetroFramework.Controls.MetroTextBox();
            this.ctrlTxtDescription = new MetroFramework.Controls.MetroTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlLblMin = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtMinAmount = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblMax = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtMaxAmount = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblDescription = new MetroFramework.Controls.MetroLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ctrlAddBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlDeleteBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridLabInvest)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 92.39374F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.606264F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlGridLabInvest, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.toolStrip1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 60);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 185F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(557, 339);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ctrlGridLabInvest
            // 
            this.ctrlGridLabInvest.AllowUserToAddRows = false;
            this.ctrlGridLabInvest.AllowUserToDeleteRows = false;
            this.ctrlGridLabInvest.AllowUserToResizeColumns = false;
            this.ctrlGridLabInvest.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridLabInvest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlGridLabInvest, 2);
            this.ctrlGridLabInvest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridLabInvest.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridLabInvest.Location = new System.Drawing.Point(3, 212);
            this.ctrlGridLabInvest.MultiSelect = false;
            this.ctrlGridLabInvest.Name = "ctrlGridLabInvest";
            this.ctrlGridLabInvest.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridLabInvest.Size = new System.Drawing.Size(551, 124);
            this.ctrlGridLabInvest.TabIndex = 4;
            this.ctrlGridLabInvest.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CtrlGridLabInvest_CellClick);
            // 
            // groupBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox1, 2);
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(551, 179);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.43678F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.56322F));
            this.tableLayoutPanel2.Controls.Add(this.ctrlLblName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ctrlTxtName, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.ctrlTxtDescription, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.ctrlLblDescription, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.125F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.875F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(545, 160);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // ctrlLblName
            // 
            this.ctrlLblName.AutoSize = true;
            this.ctrlLblName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlLblName.Location = new System.Drawing.Point(3, 0);
            this.ctrlLblName.Name = "ctrlLblName";
            this.ctrlLblName.Size = new System.Drawing.Size(138, 29);
            this.ctrlLblName.TabIndex = 0;
            this.ctrlLblName.Text = "Name";
            // 
            // ctrlTxtName
            // 
            this.ctrlTxtName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtName.Location = new System.Drawing.Point(147, 3);
            this.ctrlTxtName.Name = "ctrlTxtName";
            this.ctrlTxtName.Size = new System.Drawing.Size(395, 23);
            this.ctrlTxtName.TabIndex = 2;
            // 
            // ctrlTxtDescription
            // 
            this.ctrlTxtDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtDescription.Location = new System.Drawing.Point(147, 32);
            this.ctrlTxtDescription.Name = "ctrlTxtDescription";
            this.ctrlTxtDescription.Size = new System.Drawing.Size(395, 70);
            this.ctrlTxtDescription.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.groupBox2, 2);
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(147, 108);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(395, 49);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Controls.Add(this.ctrlLblMin, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.ctrlTxtMinAmount, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.ctrlLblMax, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.ctrlTxtMaxAmount, 3, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(389, 30);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // ctrlLblMin
            // 
            this.ctrlLblMin.AutoSize = true;
            this.ctrlLblMin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlLblMin.Location = new System.Drawing.Point(3, 0);
            this.ctrlLblMin.Name = "ctrlLblMin";
            this.ctrlLblMin.Size = new System.Drawing.Size(91, 30);
            this.ctrlLblMin.TabIndex = 0;
            this.ctrlLblMin.Text = "Min ";
            // 
            // ctrlTxtMinAmount
            // 
            this.ctrlTxtMinAmount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtMinAmount.Location = new System.Drawing.Point(100, 3);
            this.ctrlTxtMinAmount.Name = "ctrlTxtMinAmount";
            this.ctrlTxtMinAmount.Size = new System.Drawing.Size(91, 24);
            this.ctrlTxtMinAmount.TabIndex = 1;
            this.ctrlTxtMinAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CtrlTxtMaxAmount_KeyPress);
            // 
            // ctrlLblMax
            // 
            this.ctrlLblMax.AutoSize = true;
            this.ctrlLblMax.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlLblMax.Location = new System.Drawing.Point(197, 0);
            this.ctrlLblMax.Name = "ctrlLblMax";
            this.ctrlLblMax.Size = new System.Drawing.Size(91, 30);
            this.ctrlLblMax.TabIndex = 1;
            this.ctrlLblMax.Text = "Max";
            // 
            // ctrlTxtMaxAmount
            // 
            this.ctrlTxtMaxAmount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtMaxAmount.Location = new System.Drawing.Point(294, 3);
            this.ctrlTxtMaxAmount.Name = "ctrlTxtMaxAmount";
            this.ctrlTxtMaxAmount.Size = new System.Drawing.Size(92, 24);
            this.ctrlTxtMaxAmount.TabIndex = 2;
            this.ctrlTxtMaxAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CtrlTxtMaxAmount_KeyPress);
            // 
            // ctrlLblDescription
            // 
            this.ctrlLblDescription.AutoSize = true;
            this.ctrlLblDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlLblDescription.Location = new System.Drawing.Point(3, 29);
            this.ctrlLblDescription.Name = "ctrlLblDescription";
            this.ctrlLblDescription.Size = new System.Drawing.Size(138, 76);
            this.ctrlLblDescription.TabIndex = 1;
            this.ctrlLblDescription.Text = "Description";
            // 
            // toolStrip1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.toolStrip1, 2);
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctrlAddBtn,
            this.toolStripSeparator2,
            this.ctrlDeleteBtn,
            this.toolStripSeparator1,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 185);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(557, 24);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // ctrlAddBtn
            // 
            this.ctrlAddBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlAddBtn.Image = ((System.Drawing.Image)(resources.GetObject("ctrlAddBtn.Image")));
            this.ctrlAddBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlAddBtn.Name = "ctrlAddBtn";
            this.ctrlAddBtn.Size = new System.Drawing.Size(35, 21);
            this.ctrlAddBtn.Text = "Save";
            this.ctrlAddBtn.Click += new System.EventHandler(this.CtrlAddBtn_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 24);
            // 
            // ctrlDeleteBtn
            // 
            this.ctrlDeleteBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlDeleteBtn.Image = ((System.Drawing.Image)(resources.GetObject("ctrlDeleteBtn.Image")));
            this.ctrlDeleteBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlDeleteBtn.Name = "ctrlDeleteBtn";
            this.ctrlDeleteBtn.Size = new System.Drawing.Size(44, 21);
            this.ctrlDeleteBtn.Text = "Delete";
            this.ctrlDeleteBtn.Click += new System.EventHandler(this.CtrlDeleteBtn_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 24);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(38, 21);
            this.toolStripButton1.Text = "Clear";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(499, 19);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 2;
            this.metroButton1.Text = "Close";
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // frmLabInvestigator
            // 
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(597, 419);
            this.ControlBox = false;
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmLabInvestigator";
            this.Load += new System.EventHandler(this.FrmLabInvestigator_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridLabInvest)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

 
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private MetroFramework.Controls.MetroLabel ctrlLblName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtDescription;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private MetroFramework.Controls.MetroLabel ctrlLblMin;
        private MetroFramework.Controls.MetroTextBox ctrlTxtMinAmount;
        private MetroFramework.Controls.MetroLabel ctrlLblMax;
        private MetroFramework.Controls.MetroTextBox ctrlTxtMaxAmount;
        private MetroFramework.Controls.MetroLabel ctrlLblDescription;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton ctrlAddBtn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton ctrlDeleteBtn;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.DataGridView ctrlGridLabInvest;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
    }
}
