﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace SVMApplication
{
    public static class StaticIN6
    {

        public static void UpdateColorLabels(Control myControl)
        {
            if (!myControl.Name.Contains("btn"))
            {
                myControl.BackColor = Properties.Settings.Default.LBackColor;
                myControl.ForeColor = Properties.Settings.Default.LFontColor;
            }
            myControl.Font = new Font(Properties.Settings.Default.LFontFamily, Properties.Settings.Default.LFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorLabels(subC);

        }

        public static void UpdateColorControls(Control myControl, NewPrescription _pre)
        {

            myControl.BackColor = Properties.Settings.Default.CBackColor;
            myControl.ForeColor = Properties.Settings.Default.CFontColor;

            if (myControl.Name.ToString().ToUpper() == "TXTCLINICAL" || myControl.Name.ToString().ToUpper() == "TXTADVICE" || myControl.Name.ToString().ToUpper() == "ctrldataGridPrescription".ToUpper())
                myControl.Font = new Font(Properties.Settings.Default.CFontFamily, Properties.Settings.Default.CSFontSize);
            else
                myControl.Font = new Font(Properties.Settings.Default.CFontFamily, Properties.Settings.Default.CFontSize);
            // myControl.KeyPress +=new KeyPressEventHandler(myControl_KeyPress);// += new KeyEventHandler(myControl_KeyUp);
            myControl.KeyUp += new KeyEventHandler(_pre.myControl_KeyUp);
            foreach (Control subC in myControl.Controls)
                UpdateColorControls(subC, _pre);
         //   tableLayoutPanel1.BackColor = Properties.Settings.Default.CBackColor;
        }


    }
}
