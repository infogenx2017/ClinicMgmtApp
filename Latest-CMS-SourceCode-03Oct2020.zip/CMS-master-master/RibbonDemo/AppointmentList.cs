﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using SVMApplication.Helper;
using System.Configuration;

namespace SVMApplication
{
    public partial class AppointmentList : UserControl
    {
        string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public AppointmentList()
        {
            InitializeComponent();
        }

        private void AppointmentList_Load(object sender, EventArgs e)
        {
            timer1.Start();
            PatientStatusLoad();
            LoadAppointmntGrid();
        }

        public void PatientStatusLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }
                ctrlCbxStatus.Items.Add(new ComboboxItem(-1,"ALL"));
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        private void ctrlCbxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadAppointmntGrid();
        }

        private void LoadAppointmntGrid()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                SqlCommand cmd = new SqlCommand("Sp_GetAppointment", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@type", ctrlCbxStatus.Text);
                cmd.Parameters.AddWithValue("@dCode", AppMain.DoctorCode);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                ctrlGridAppointmentList.DataSource = table;
                ctrlGridAppointmentList.ClearSelection();
            }
        }

        private void ctrlBtnOpenPrescrition_Click(object sender, EventArgs e)
        {
            if (ctrlGridAppointmentList.SelectedRows.Count <= 0)
                return;

            if (this.ParentForm is MainForm)
            {
                MainForm form = (MainForm)this.ParentForm;
                DataSet ds = new DataSet();
                SqlConnection con = new SqlConnection(constr);
                {
                    var id = ctrlGridAppointmentList.Rows[ctrlGridAppointmentList.SelectedRows[0].Index].Cells["Epres NO"].Value.ToString();
                    SqlCommand cmd = new SqlCommand("Sp_LoadPrescription", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@EpresNo", id);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(ds);
                    form.newPrescription.SetOldPrescriptions(ds);
                    form.DoVisible(true);
                }
               
            }
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            if (ctrlGridAppointmentList.SelectedRows.Count <= 0)
                return;

            SqlConnection con = new SqlConnection(constr);
            DialogResult result = MessageBox.Show("Do You Want to delete the Curent User?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result.Equals(DialogResult.OK))
            {
                using (con)
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    var id = ctrlGridAppointmentList.Rows[ctrlGridAppointmentList.SelectedRows[0].Index].Cells[0].Value.ToString();
                    SqlCommand cmd = new SqlCommand("Delete from regappform3 where EpresNo=@EpresNo", con);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@EpresNo", id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully");
                }

                LoadAppointmntGrid();
            }
        }

        private void CtrlGridAppointmentList_DoubleClick(object sender, EventArgs e)
        {
            if (ctrlGridAppointmentList.SelectedRows.Count > 0)
                ctrlBtnOpenPrescrition_Click(null, null);
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                //int index = -1;
                //if(ctrlGridAppointmentList.SelectedRows.Count>0)
                //index = ctrlGridAppointmentList.SelectedRows[0].Index;

                LoadAppointmntGrid();

                //if (ctrlGridAppointmentList.Rows.Count > 0 && ctrlGridAppointmentList.Rows.Count > index)
                //{
                //    ctrlGridAppointmentList.ClearSelection();
                //    ctrlGridAppointmentList.Rows[index].Selected = true;
                //}
            }
            catch (Exception es)
            {

               
            }
        }
    }
}
