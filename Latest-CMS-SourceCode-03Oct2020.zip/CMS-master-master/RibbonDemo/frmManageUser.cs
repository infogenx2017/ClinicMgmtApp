﻿using ClassLibrary;
using SVMApplication.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmManageUser : MetroFramework.Forms.MetroForm
    {
        User user = new User();
        public frmManageUser()
        {
            InitializeComponent();
            ctrlGridUser.DataSource = user.getUsers();
        }

        private void ctrlGridUser_Click(object sender, EventArgs e)
        {
            ctrlTxtID.Text       = ctrlGridUser.CurrentRow.Cells[0].Value.ToString();
            ctrlTxtUserName.Text = ctrlGridUser.CurrentRow.Cells[1].Value.ToString();
            ctrlTxtFullName.Text = ctrlGridUser.CurrentRow.Cells[3].Value.ToString();
            ctrlTxtTEL.Text      = ctrlGridUser.CurrentRow.Cells[4].Value.ToString();
            ctrlTxtPassword.Text = ctrlGridUser.CurrentRow.Cells[2].Value.ToString();
            ctrlTxtEmail.Text    = ctrlGridUser.CurrentRow.Cells[5].Value.ToString();

            ctrlCbxUserType.SelectedIndex = -1;
            int userType = -1;
            int.TryParse(ctrlGridUser.CurrentRow.Cells[6].Value.ToString(),out userType);
            ctrlCbxUserType.Text = new UserType().GetUserType(userType);
            ctrlTxtDoctorCode.Text = ctrlGridUser.CurrentRow.Cells[7].Value.ToString();
        }

        private void ctrlBtnNewUser_Click(object sender, EventArgs e)
        {
            frmNewUser fnu = new frmNewUser();
            fnu.ShowDialog();
            ctrlGridUser.DataSource = user.getUsers();
        }

        private void ctrlBtnDelete_Click(object sender, EventArgs e)
        {
            
            if(ctrlTxtID.Text != string.Empty)
            {
                if (MessageBox.Show("Do You Want To Delete This User", "Delete User", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    user.deleteUser(Convert.ToInt32(ctrlTxtID.Text));
                    MessageBox.Show("User Deleted Successfully", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ctrlGridUser.DataSource = user.getUsers();
                }
            }
            else
            {
                MessageBox.Show("Select the User You Want To Delete");
            }
            

            
        }

        private void CtrlBtnUpdate_Click(object sender, EventArgs e)
        {
            if (ctrlTxtID.Text != string.Empty)
            {
                user.updateUser(ctrlTxtUserName.Text, ctrlTxtFullName.Text, ctrlTxtPassword.Text,
                    ctrlTxtTEL.Text,
                    ctrlTxtEmail.Text, Convert.ToInt32(ctrlTxtID.Text),ctrlCbxUserType.GetSelectedValueAsInt(),ctrlTxtDoctorCode.Text);
                MessageBox.Show("User Updated Successfully", "Update User Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ctrlGridUser.DataSource = user.getUsers();
            }

            else
            {
                MessageBox.Show("Select the User You Want To Update");
            }
        }


        private void LoadUserType()
        {
            UserType t = new UserType();

            DataTable dataTable = t.GetUserType();

            ctrlCbxUserType.Items.Clear();

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                ComboboxItem item = new ComboboxItem();
                item.Value = Convert.ToInt32(dataTable.Rows[i]["typeID"]);
                item.Text = (dataTable.Rows[i]["typeName"].ToString());

                ctrlCbxUserType.Items.Add(item);
            }


        }


        private void PANEL_CLOSE_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmManageUser_Load(object sender, EventArgs e)
        {
            LoadUserType();
        }
    }
}
