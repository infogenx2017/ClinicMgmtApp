﻿namespace SVMApplication
{
    partial class NewPatient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PatientGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.PatientGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // PatientGrid
            // 
            this.PatientGrid.AllowUserToAddRows = false;
            this.PatientGrid.AllowUserToDeleteRows = false;
            this.PatientGrid.AllowUserToOrderColumns = true;
            this.PatientGrid.AllowUserToResizeRows = false;
            this.PatientGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PatientGrid.ColumnHeadersHeight = 34;
            this.PatientGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PatientGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.PatientGrid.Location = new System.Drawing.Point(0, 0);
            this.PatientGrid.Name = "PatientGrid";
            this.PatientGrid.RowHeadersVisible = false;
            this.PatientGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PatientGrid.Size = new System.Drawing.Size(788, 473);
            this.PatientGrid.TabIndex = 2;
            this.PatientGrid.DoubleClick += new System.EventHandler(this.PatientGrid_DoubleClick);
            // 
            // NewPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.PatientGrid);
            this.Name = "NewPatient";
            this.Size = new System.Drawing.Size(788, 473);
            this.Load += new System.EventHandler(this.NewPatient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PatientGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView PatientGrid;
    }
}
