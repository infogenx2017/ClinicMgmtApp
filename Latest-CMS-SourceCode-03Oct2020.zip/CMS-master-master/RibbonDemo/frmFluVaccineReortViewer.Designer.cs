﻿namespace SVMApplication
{
    partial class frmFluVaccineReortViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlViwerPrescritionreportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // ctrlViwerPrescritionreportViewer
            // 
            this.ctrlViwerPrescritionreportViewer.ActiveViewIndex = -1;
            this.ctrlViwerPrescritionreportViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlViwerPrescritionreportViewer.Cursor = System.Windows.Forms.Cursors.Default;
            this.ctrlViwerPrescritionreportViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlViwerPrescritionreportViewer.Location = new System.Drawing.Point(0, 0);
            this.ctrlViwerPrescritionreportViewer.Name = "ctrlViwerPrescritionreportViewer";
            this.ctrlViwerPrescritionreportViewer.Size = new System.Drawing.Size(870, 414);
            this.ctrlViwerPrescritionreportViewer.TabIndex = 0;
            // 
            // frmReortViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 414);
            this.Controls.Add(this.ctrlViwerPrescritionreportViewer);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmReortViewer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmReortViewer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmReortViewer_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer ctrlViwerPrescritionreportViewer;

    }
}