﻿namespace SVMApplication
{
    partial class NewVaccine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtgap = new MetroFramework.Controls.MetroTextBox();
            this.btnsave = new MetroFramework.Controls.MetroButton();
            this.btnclear = new MetroFramework.Controls.MetroButton();
            this.btndelete = new MetroFramework.Controls.MetroButton();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.VaccineGrid = new System.Windows.Forms.DataGridView();
            this.txtAge = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtvaccine = new MetroFramework.Controls.MetroTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.VaccineGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(18, 228);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(14, 19);
            this.lblRowID.TabIndex = 18;
            this.lblRowID.Text = "1";
            this.lblRowID.Visible = false;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(20, 211);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(51, 19);
            this.metroLabel1.TabIndex = 19;
            this.metroLabel1.Text = "Vaccine";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(20, 243);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(79, 19);
            this.metroLabel2.TabIndex = 20;
            this.metroLabel2.Text = "Vaccine Gap";
            // 
            // txtgap
            // 
            this.txtgap.Location = new System.Drawing.Point(88, 240);
            this.txtgap.Name = "txtgap";
            this.txtgap.PromptText = "Enter Gap";
            this.txtgap.Size = new System.Drawing.Size(273, 23);
            this.txtgap.TabIndex = 21;
            this.txtgap.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(44, 299);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 23;
            this.btnsave.Text = "Save";
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(124, 299);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(75, 23);
            this.btnclear.TabIndex = 24;
            this.btnclear.Text = "New";
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(206, 299);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 25;
            this.btndelete.Text = "Delete";
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnexit
            // 
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(286, 299);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 23);
            this.btnexit.TabIndex = 26;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // VaccineGrid
            // 
            this.VaccineGrid.AllowUserToAddRows = false;
            this.VaccineGrid.AllowUserToDeleteRows = false;
            this.VaccineGrid.AllowUserToOrderColumns = true;
            this.VaccineGrid.AllowUserToResizeRows = false;
            this.VaccineGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.VaccineGrid.ColumnHeadersHeight = 34;
            this.VaccineGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.VaccineGrid.Location = new System.Drawing.Point(18, 52);
            this.VaccineGrid.Name = "VaccineGrid";
            this.VaccineGrid.RowHeadersVisible = false;
            this.VaccineGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.VaccineGrid.Size = new System.Drawing.Size(343, 150);
            this.VaccineGrid.TabIndex = 17;
            this.VaccineGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(88, 270);
            this.txtAge.Name = "txtAge";
            this.txtAge.PromptText = "Enter Age Limit";
            this.txtAge.Size = new System.Drawing.Size(273, 23);
            this.txtAge.TabIndex = 21;
            this.txtAge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(20, 272);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(65, 19);
            this.metroLabel3.TabIndex = 20;
            this.metroLabel3.Text = "Age Limit";
            // 
            // txtvaccine
            // 
            this.txtvaccine.Location = new System.Drawing.Point(88, 211);
            this.txtvaccine.Name = "txtvaccine";
            this.txtvaccine.PromptText = "Enter Vaccine";
            this.txtvaccine.Size = new System.Drawing.Size(273, 23);
            this.txtvaccine.TabIndex = 22;
            this.txtvaccine.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // NewVaccine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 340);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtgap);
            this.Controls.Add(this.txtvaccine);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.VaccineGrid);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "NewVaccine";
            this.Padding = new System.Windows.Forms.Padding(15, 49, 15, 16);
            this.Text = "Vaccine";
            this.Load += new System.EventHandler(this.NewVaccine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VaccineGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRowID;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtgap;
        private MetroFramework.Controls.MetroButton btnsave;
        private MetroFramework.Controls.MetroButton btnclear;
        private MetroFramework.Controls.MetroButton btndelete;
        private MetroFramework.Controls.MetroButton btnexit;
        private System.Windows.Forms.DataGridView VaccineGrid;
        private MetroFramework.Controls.MetroTextBox txtAge;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtvaccine;
    }
}