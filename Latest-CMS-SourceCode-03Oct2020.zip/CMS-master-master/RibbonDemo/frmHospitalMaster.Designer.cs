﻿namespace SVMApplication
{
    partial class frmHospitalMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHospitalMaster));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlGridHospital = new System.Windows.Forms.DataGridView();
            this.ctrlMasterStrip = new System.Windows.Forms.ToolStrip();
            this.ctrlBtnExit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlBtnMaster = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlbtnDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlNewBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlSaveBtn = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ctrlTxtWebsite = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblWebsite = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtEmail = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblEmail = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtContact = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblContact = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtAddress = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblAddress = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtCity = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblCity = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtCode = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblCode = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtName = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblName = new MetroFramework.Controls.MetroLabel();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridHospital)).BeginInit();
            this.ctrlMasterStrip.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 95.56962F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.43038F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlGridHospital, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.ctrlMasterStrip, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 60);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.58065F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.41935F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(790, 397);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // ctrlGridHospital
            // 
            this.ctrlGridHospital.AllowUserToAddRows = false;
            this.ctrlGridHospital.AllowUserToDeleteRows = false;
            this.ctrlGridHospital.AllowUserToResizeRows = false;
            this.ctrlGridHospital.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridHospital.ColumnHeadersHeight = 34;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlGridHospital, 2);
            this.ctrlGridHospital.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridHospital.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridHospital.Location = new System.Drawing.Point(3, 3);
            this.ctrlGridHospital.Name = "ctrlGridHospital";
            this.ctrlGridHospital.RowHeadersVisible = false;
            this.ctrlGridHospital.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridHospital.Size = new System.Drawing.Size(784, 171);
            this.ctrlGridHospital.TabIndex = 0;
            this.ctrlGridHospital.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ctrlGridHospital_CellClick);
            this.ctrlGridHospital.DoubleClick += new System.EventHandler(this.ctrlGridHospital_DoubleClick);
            // 
            // ctrlMasterStrip
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlMasterStrip, 2);
            this.ctrlMasterStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ctrlMasterStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctrlBtnExit,
            this.toolStripSeparator2,
            this.ctrlBtnMaster,
            this.toolStripSeparator3,
            this.ctrlbtnDelete,
            this.toolStripSeparator1,
            this.ctrlNewBtn,
            this.toolStripSeparator4,
            this.ctrlSaveBtn});
            this.ctrlMasterStrip.Location = new System.Drawing.Point(0, 372);
            this.ctrlMasterStrip.Name = "ctrlMasterStrip";
            this.ctrlMasterStrip.Size = new System.Drawing.Size(790, 25);
            this.ctrlMasterStrip.TabIndex = 2;
            this.ctrlMasterStrip.Text = "toolStrip1";
            // 
            // ctrlBtnExit
            // 
            this.ctrlBtnExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ctrlBtnExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlBtnExit.Image = ((System.Drawing.Image)(resources.GetObject("ctrlBtnExit.Image")));
            this.ctrlBtnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlBtnExit.Name = "ctrlBtnExit";
            this.ctrlBtnExit.Size = new System.Drawing.Size(29, 22);
            this.ctrlBtnExit.Text = "Exit";
            this.ctrlBtnExit.Click += new System.EventHandler(this.ctrlBtnExit_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // ctrlBtnMaster
            // 
            this.ctrlBtnMaster.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ctrlBtnMaster.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlBtnMaster.Image = ((System.Drawing.Image)(resources.GetObject("ctrlBtnMaster.Image")));
            this.ctrlBtnMaster.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlBtnMaster.Name = "ctrlBtnMaster";
            this.ctrlBtnMaster.Size = new System.Drawing.Size(82, 22);
            this.ctrlBtnMaster.Text = "Set As Master";
            this.ctrlBtnMaster.Click += new System.EventHandler(this.ctrlBtnMaster_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // ctrlbtnDelete
            // 
            this.ctrlbtnDelete.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ctrlbtnDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlbtnDelete.Image = ((System.Drawing.Image)(resources.GetObject("ctrlbtnDelete.Image")));
            this.ctrlbtnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlbtnDelete.Name = "ctrlbtnDelete";
            this.ctrlbtnDelete.Size = new System.Drawing.Size(44, 22);
            this.ctrlbtnDelete.Text = "Delete";
            this.ctrlbtnDelete.Click += new System.EventHandler(this.ctrlbtnDelete_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // ctrlNewBtn
            // 
            this.ctrlNewBtn.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ctrlNewBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlNewBtn.Image = ((System.Drawing.Image)(resources.GetObject("ctrlNewBtn.Image")));
            this.ctrlNewBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlNewBtn.Name = "ctrlNewBtn";
            this.ctrlNewBtn.Size = new System.Drawing.Size(35, 22);
            this.ctrlNewBtn.Text = "New";
            this.ctrlNewBtn.Click += new System.EventHandler(this.ctrlNewBtn_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // ctrlSaveBtn
            // 
            this.ctrlSaveBtn.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.ctrlSaveBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlSaveBtn.Image = ((System.Drawing.Image)(resources.GetObject("ctrlSaveBtn.Image")));
            this.ctrlSaveBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlSaveBtn.Name = "ctrlSaveBtn";
            this.ctrlSaveBtn.Size = new System.Drawing.Size(35, 22);
            this.ctrlSaveBtn.Text = "Save";
            this.ctrlSaveBtn.Click += new System.EventHandler(this.ctrlSaveBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ctrlTxtWebsite);
            this.groupBox1.Controls.Add(this.ctrlLblWebsite);
            this.groupBox1.Controls.Add(this.ctrlTxtEmail);
            this.groupBox1.Controls.Add(this.ctrlLblEmail);
            this.groupBox1.Controls.Add(this.ctrlTxtContact);
            this.groupBox1.Controls.Add(this.ctrlLblContact);
            this.groupBox1.Controls.Add(this.ctrlTxtAddress);
            this.groupBox1.Controls.Add(this.ctrlLblAddress);
            this.groupBox1.Controls.Add(this.ctrlTxtCity);
            this.groupBox1.Controls.Add(this.ctrlLblCity);
            this.groupBox1.Controls.Add(this.ctrlTxtCode);
            this.groupBox1.Controls.Add(this.ctrlLblCode);
            this.groupBox1.Controls.Add(this.ctrlTxtName);
            this.groupBox1.Controls.Add(this.ctrlLblName);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 180);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(748, 189);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HOSPITAL";
            // 
            // ctrlTxtWebsite
            // 
            this.ctrlTxtWebsite.Location = new System.Drawing.Point(458, 75);
            this.ctrlTxtWebsite.MaxLength = 555;
            this.ctrlTxtWebsite.Name = "ctrlTxtWebsite";
            this.ctrlTxtWebsite.PromptText = "Website Name";
            this.ctrlTxtWebsite.Size = new System.Drawing.Size(271, 23);
            this.ctrlTxtWebsite.TabIndex = 13;
            // 
            // ctrlLblWebsite
            // 
            this.ctrlLblWebsite.AutoSize = true;
            this.ctrlLblWebsite.Location = new System.Drawing.Point(373, 79);
            this.ctrlLblWebsite.Name = "ctrlLblWebsite";
            this.ctrlLblWebsite.Size = new System.Drawing.Size(55, 19);
            this.ctrlLblWebsite.TabIndex = 12;
            this.ctrlLblWebsite.Text = "Website";
            // 
            // ctrlTxtEmail
            // 
            this.ctrlTxtEmail.Location = new System.Drawing.Point(458, 46);
            this.ctrlTxtEmail.MaxLength = 555;
            this.ctrlTxtEmail.Name = "ctrlTxtEmail";
            this.ctrlTxtEmail.PromptText = "Email";
            this.ctrlTxtEmail.Size = new System.Drawing.Size(271, 23);
            this.ctrlTxtEmail.TabIndex = 11;
            // 
            // ctrlLblEmail
            // 
            this.ctrlLblEmail.AutoSize = true;
            this.ctrlLblEmail.Location = new System.Drawing.Point(373, 50);
            this.ctrlLblEmail.Name = "ctrlLblEmail";
            this.ctrlLblEmail.Size = new System.Drawing.Size(41, 19);
            this.ctrlLblEmail.TabIndex = 10;
            this.ctrlLblEmail.Text = "Email";
            // 
            // ctrlTxtContact
            // 
            this.ctrlTxtContact.Location = new System.Drawing.Point(458, 17);
            this.ctrlTxtContact.MaxLength = 15;
            this.ctrlTxtContact.Name = "ctrlTxtContact";
            this.ctrlTxtContact.PromptText = "Contact Number";
            this.ctrlTxtContact.Size = new System.Drawing.Size(271, 23);
            this.ctrlTxtContact.TabIndex = 9;
            // 
            // ctrlLblContact
            // 
            this.ctrlLblContact.AutoSize = true;
            this.ctrlLblContact.Location = new System.Drawing.Point(373, 21);
            this.ctrlLblContact.Name = "ctrlLblContact";
            this.ctrlLblContact.Size = new System.Drawing.Size(76, 19);
            this.ctrlLblContact.TabIndex = 8;
            this.ctrlLblContact.Text = "Contact No";
            // 
            // ctrlTxtAddress
            // 
            this.ctrlTxtAddress.Location = new System.Drawing.Point(80, 104);
            this.ctrlTxtAddress.MaxLength = 1500;
            this.ctrlTxtAddress.Multiline = true;
            this.ctrlTxtAddress.Name = "ctrlTxtAddress";
            this.ctrlTxtAddress.PromptText = "Enter Address";
            this.ctrlTxtAddress.Size = new System.Drawing.Size(649, 69);
            this.ctrlTxtAddress.TabIndex = 7;
            this.ctrlTxtAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // ctrlLblAddress
            // 
            this.ctrlLblAddress.AutoSize = true;
            this.ctrlLblAddress.Location = new System.Drawing.Point(6, 108);
            this.ctrlLblAddress.Name = "ctrlLblAddress";
            this.ctrlLblAddress.Size = new System.Drawing.Size(56, 19);
            this.ctrlLblAddress.TabIndex = 6;
            this.ctrlLblAddress.Text = "Address";
            // 
            // ctrlTxtCity
            // 
            this.ctrlTxtCity.Location = new System.Drawing.Point(80, 75);
            this.ctrlTxtCity.MaxLength = 150;
            this.ctrlTxtCity.Name = "ctrlTxtCity";
            this.ctrlTxtCity.PromptText = "Enter City";
            this.ctrlTxtCity.Size = new System.Drawing.Size(273, 23);
            this.ctrlTxtCity.TabIndex = 5;
            this.ctrlTxtCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // ctrlLblCity
            // 
            this.ctrlLblCity.AutoSize = true;
            this.ctrlLblCity.Location = new System.Drawing.Point(6, 79);
            this.ctrlLblCity.Name = "ctrlLblCity";
            this.ctrlLblCity.Size = new System.Drawing.Size(31, 19);
            this.ctrlLblCity.TabIndex = 4;
            this.ctrlLblCity.Text = "City";
            // 
            // ctrlTxtCode
            // 
            this.ctrlTxtCode.Location = new System.Drawing.Point(80, 46);
            this.ctrlTxtCode.MaxLength = 10;
            this.ctrlTxtCode.Name = "ctrlTxtCode";
            this.ctrlTxtCode.PromptText = "Hospital Code";
            this.ctrlTxtCode.Size = new System.Drawing.Size(273, 23);
            this.ctrlTxtCode.TabIndex = 3;
            this.ctrlTxtCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // ctrlLblCode
            // 
            this.ctrlLblCode.AutoSize = true;
            this.ctrlLblCode.Location = new System.Drawing.Point(6, 50);
            this.ctrlLblCode.Name = "ctrlLblCode";
            this.ctrlLblCode.Size = new System.Drawing.Size(41, 19);
            this.ctrlLblCode.TabIndex = 2;
            this.ctrlLblCode.Text = "Code";
            // 
            // ctrlTxtName
            // 
            this.ctrlTxtName.Location = new System.Drawing.Point(80, 17);
            this.ctrlTxtName.MaxLength = 500;
            this.ctrlTxtName.Name = "ctrlTxtName";
            this.ctrlTxtName.PromptText = "Hospital Name";
            this.ctrlTxtName.Size = new System.Drawing.Size(273, 23);
            this.ctrlTxtName.TabIndex = 1;
            this.ctrlTxtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // ctrlLblName
            // 
            this.ctrlLblName.AutoSize = true;
            this.ctrlLblName.Location = new System.Drawing.Point(6, 21);
            this.ctrlLblName.Name = "ctrlLblName";
            this.ctrlLblName.Size = new System.Drawing.Size(45, 19);
            this.ctrlLblName.TabIndex = 0;
            this.ctrlLblName.Text = "Name";
            // 
            // frmHospitalMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 477);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmHospitalMaster";
            this.ShowInTaskbar = false;
            this.Text = "Hospital Master";
            this.Load += new System.EventHandler(this.frmHospitalMaster_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridHospital)).EndInit();
            this.ctrlMasterStrip.ResumeLayout(false);
            this.ctrlMasterStrip.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView ctrlGridHospital;
        private System.Windows.Forms.ToolStrip ctrlMasterStrip;
        private System.Windows.Forms.ToolStripButton ctrlSaveBtn;
        private System.Windows.Forms.ToolStripButton ctrlNewBtn;
        private System.Windows.Forms.ToolStripButton ctrlbtnDelete;
        private System.Windows.Forms.ToolStripButton ctrlBtnExit;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroLabel ctrlLblName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtName;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private MetroFramework.Controls.MetroTextBox ctrlTxtAddress;
        private MetroFramework.Controls.MetroLabel ctrlLblAddress;
        private MetroFramework.Controls.MetroTextBox ctrlTxtCity;
        private MetroFramework.Controls.MetroLabel ctrlLblCity;
        private MetroFramework.Controls.MetroTextBox ctrlTxtCode;
        private MetroFramework.Controls.MetroLabel ctrlLblCode;
        private System.Windows.Forms.ToolStripButton ctrlBtnMaster;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private MetroFramework.Controls.MetroTextBox ctrlTxtWebsite;
        private MetroFramework.Controls.MetroLabel ctrlLblWebsite;
        private MetroFramework.Controls.MetroTextBox ctrlTxtEmail;
        private MetroFramework.Controls.MetroLabel ctrlLblEmail;
        private MetroFramework.Controls.MetroTextBox ctrlTxtContact;
        private MetroFramework.Controls.MetroLabel ctrlLblContact;
    }
}