using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Data.SqlClient;
using SVMApplication.Helper;
using MetroFramework;

namespace SVMApplication
{
    public partial class MainForm : RibbonForm
    {
        public NewPrescription newPrescription = null;
        private DashboardView DashboardView = null;
        public static NewDrug newDrug = null;
        public static Settingscs _set = null;
        public static NewAppointment newAppoinment = null;
        public static NewPatient newPatient = null;
        private ToolStripLabel lbl_live_time = null;
        private SplashScreen splashScreen = null;

        public MainForm()
        {
            InitializeComponent();
      
        }

     

        private void ActiveTabChanged(object sender,EventArgs e)
        {
            UpdateMasterHospital();
            ribbon1.Minimized = true;
        }

        private  void UpdateMasterHospital()
        {
            if (newPrescription.Visible)
            {
                if (AppMain.IsMasterChanged)
                {
                    newPrescription.btnClear_Click();
                    newPrescription.LoadDefaultDropDownValues();
                    AppMain.IsMasterChanged = false;
                }

            }
        }



        public MainForm(SplashScreen _Splash)
        {
            InitializeComponent();
            newPrescription = new NewPrescription(this);
            DashboardView = new DashboardView();
            DashboardView.Dock = DockStyle.Fill;
            newAppoinment = new NewAppointment(newPrescription);
            newDrug = new NewDrug();
            newPatient = new NewPatient(newPrescription);
            lbl_live_time = new ToolStripLabel();
            InitLists();

            splashScreen = _Splash;
            StartPosition = FormStartPosition.CenterScreen;

            this.FormClosing += new FormClosingEventHandler(MainForm_FormClosing);
            newPrescription.Dock = DockStyle.Fill;
            newPrescription.Prescription_Load(null, null);

            newAppoinment.Dock = DockStyle.Fill;
            newAppoinment.NewAppointment_Load(null, null);

            PanelInitialization();

            newDrug.Dock = DockStyle.Fill;          
            newDrug.BtnNew_Click(null, null);
            panelMain.Controls.Add(newDrug);

            newPatient.Dock = DockStyle.Fill;
            newPatient.NewPatient_Load(null, null);
            panelMain.Controls.Add(newPatient);

            TabPageInitialization();
            ThemeColoring();
            //ribbon1.Minimized = true;
        }

       

        public void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            splashScreen.Close();
        }

        private void PanelInitialization()
        {
            this.panelMain.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panelMain.Location = new System.Drawing.Point(526, 3);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(231, 113);
            this.panelMain.TabIndex = 1;
            panelMain.Dock = DockStyle.Fill;
        }

        private void TabPageInitialization()
        {
            ctrlTabHomeControl.TabPages.Clear();
            TabPage dashBoard = new TabPage("Dashboard ");           
            TabPage prescription = new TabPage("Prescription ");
            TabPage appointment = new TabPage("Appointment ");
            TabPage Panel = new TabPage("Others ");

          



            dashBoard.Controls.Add(DashboardView);
            dashBoard.Update();
            prescription.Controls.Add(newPrescription);
            appointment.Controls.Add(newAppoinment);          
            Panel.Controls.Add(panelMain);

            ctrlTabHomeControl.TabPages.Add(dashBoard); //0
            ctrlTabHomeControl.TabPages.Add(prescription);//1
            ctrlTabHomeControl.TabPages.Add(appointment);//2
            ctrlTabHomeControl.TabPages.Add(Panel);//3
            if (AppMain.LoginUser.Type.ToLower() == "admin")
            {
            }
            else if (AppMain.LoginUser.Type.ToLower() == "reception")
            {
                DashboardView.Enabled = false;
                newPrescription.Enabled = false;
                panelMain.Enabled = false;

                ribbonPanel3.Enabled = false;
                ribbonPanelMaster.Enabled = false;
                ribbonPanelAdmin.Enabled = false;

                //(this.ribbonButton44).Enabled = false;
                //(this.ribbonButtonCheckOld).Enabled = false;
                (this.ribbonButtonPre).Enabled = false;
                (this.ribbonButtonAppointment).Enabled = false;
                (this.ribbonButtonSearch).Enabled = false;
                (this.ribbonButtonDrug).Enabled = false;
                (this.ribbonButtonPatient).Enabled = false;
                (this.ribbonButtonCat).Enabled = false;
                (this.ribbonButtonDig).Enabled = false;
                //(this.ribbonButtonMinMax).Enabled = false;
                (this.ribbonButtonVaccine).Enabled = false;
                (this.ribbonButtonbabyAge).Enabled = false;
                (this.ribbonButtonVC).Enabled = false;
                //(this.ctrlRibbHelp).Enabled = false;
            }
            else if (AppMain.LoginUser.Type.ToLower() == "doctor")
            {
                panelMain.Enabled = false;
                ribbonPanelMaster.Enabled = false;
                ribbonPanelAdmin.Enabled = false;
                //(this.ribbonButton44).Enabled = false;
                //(this.ribbonButtonCheckOld).Enabled = false;
                (this.ribbonButtonPre).Enabled = false;
                (this.ribbonButtonAppointment).Enabled = false;
                (this.ribbonButtonSearch).Enabled = false;
                (this.ribbonButtonDrug).Enabled = false;
                (this.ribbonButtonPatient).Enabled = false;
                (this.ribbonButtonCat).Enabled = false;
                (this.ribbonButtonDig).Enabled = false;
                //(this.ribbonButtonMinMax).Enabled = false;
                (this.ribbonButtonVaccine).Enabled = false;
                (this.ribbonButtonbabyAge).Enabled = false;
                (this.ribbonButtonVC).Enabled = false;
                //(this.ctrlRibbHelp).Enabled = false;
            }
            else
            {
                DashboardView.Enabled = false;
                newPrescription.Enabled = false;
                newAppoinment.Enabled = false;
                panelMain.Enabled = false;

                ribbonPanel3.Enabled = false;
                ribbonPanelMaster.Enabled = false;
                ribbonPanelAdmin.Enabled = false;

                (this.ribbonButton44).Enabled = false;
                (this.ribbonButtonCheckOld).Enabled = false;
                (this.ribbonButtonPre).Enabled = false;
                (this.ribbonButtonAppointment).Enabled = false;
                (this.ribbonButtonSearch).Enabled = false;
                (this.ribbonButtonDrug).Enabled = false;
                (this.ribbonButtonPatient).Enabled = false;
                (this.ribbonButtonCat).Enabled = false;
                (this.ribbonButtonDig).Enabled = false;
                //(this.ribbonButtonMinMax).Enabled = false;
                (this.ribbonButtonVaccine).Enabled = false;
                (this.ribbonButtonbabyAge).Enabled = false;
                (this.ribbonButtonVC).Enabled = false;
                //(this.ctrlRibbHelp).Enabled = false;
            }


            ctrlTabHomeControl.SizeMode = TabSizeMode.Fixed;
            ctrlTabHomeControl.TextAlign = ContentAlignment.MiddleLeft;
            ctrlTabHomeControl.FontWeight = MetroTabControlWeight.Bold;

        }

        public void DoVisible(bool Prescription = false, bool Drug = false, bool Appointment = false, bool Patient = false, bool dashBoard = false)
        {
            if (Prescription)
            {
                ctrlTabHomeControl.SelectedIndex = 1;
            }
            else if (Appointment)
            {
                ctrlTabHomeControl.SelectedIndex = 2;
            }
            else if (dashBoard)
            {
                ctrlTabHomeControl.SelectedIndex = 0;
            }
            else
            {
                newDrug.Visible = Drug;
                newPatient.Visible = Patient;
                ctrlTabHomeControl.SelectedIndex = 3;
            }


        }
        private static void ThemeColoring()
        {
            // vTheme.ColorTable = new RibbonProfesionalRendererColorTableBlack();
            RibbonProfesionalRendererColorTable _convert = new RibbonProfesionalRendererColorTable();
            Color color = Properties.Settings.Default.CBackColor;
            string ColorBackHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.CFontColor;
            string ColorFontHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.RBackColor;
            string ColorTabHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.RFontColor;
            string ColorTabSelHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            System.Windows.Forms.Theme.ColorTable = new CustomColorTable(ColorFontHex, ColorBackHex, ColorTabHex, ColorTabSelHex);
        }
        private Color GetRandomColor(Random r)
        {
            if (r == null)
            {
                r = new Random(DateTime.Now.Millisecond);
            }

            return Color.FromKnownColor((KnownColor)r.Next(1, 150));
        }
        public void InitLists()
        {
            Image[] images = new Image[255];
            List<string> _Namelst = TodayVisited();
            List<string> _PatiantIDlst = TodayVisitedPatiantID();
            RibbonProfessionalRenderer rend = new RibbonProfessionalRenderer();
            BackColor = Theme.ColorTable.RibbonBackground;
            Random r = new Random();
            lst.Buttons.Clear();
            #region Color Squares
            using (GraphicsPath path = RibbonProfessionalRenderer.RoundRectangle(new Rectangle(3, 3, 39, 26), 4))
            {
                using (GraphicsPath outer = RibbonProfessionalRenderer.RoundRectangle(new Rectangle(0, 0, 48, 32), 4))
                {
                    for (int i = 0; i < _PatiantIDlst.Count; i++)
                    {
                        Bitmap b = new Bitmap(48, 32);

                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.SmoothingMode = SmoothingMode.AntiAlias;

                            using (SolidBrush br = new SolidBrush(Color.FromArgb(255, i * (255 / images.Length), 0)))
                            {
                                g.FillPath(br, path);
                            }

                            using (Pen p = new Pen(Color.White, 3))
                            {
                                g.DrawPath(p, path);
                            }

                            g.DrawPath(Pens.Wheat, path);

                            g.DrawString((i + 1).ToString(), Font, Brushes.White, new Point(15, 10));
                        }

                        images[i] = b;
                        TextBox txt = new TextBox();
                        RibbonButton btn = new RibbonButton();
                        btn.Image = b;
                        btn.Text = _PatiantIDlst[i];

                        btn.ToolTip = _Namelst[i];
                        btn.Click += new EventHandler(btn_Click);
                        lst.Buttons.Add(btn);

                    }
                }
            }

            //lst.DropDownItems.Add(new RibbonSeparator("Available styles"));
            RibbonButtonList lst2 = new RibbonButtonList();
            lst.DropDownItems.Clear();
            for (int i = 0; i < _PatiantIDlst.Count; i++)
            {
                RibbonButton btn = new RibbonButton();
                btn.Image = images[i];
                btn.Text = _PatiantIDlst[i];
                btn.ToolTip = _Namelst[i];
                btn.Click += new EventHandler(btn_Click);
                lst2.Buttons.Add(btn);
            }
            lst.DropDownItems.Add(lst2);
            //lst.DropDownItems.Add(new RibbonButton("Save selection as a new quick style..."));
            //lst.DropDownItems.Add(new RibbonButton("Erase Format"));
            //lst.DropDownItems.Add(new RibbonButton("Apply style..."));
            #endregion


           


        }        
        void btn_Click(object sender, EventArgs e)
        {
            //RibbonButton _rb = ((RibbonButton)sender);
            //DoVisible(true);
            //DataSet ds = t.LoadOldPrescriptionDS(ctrlSearchfrom.Value, ctrlSearchto.Value, false, " ", _rb.Text);

            //if (ds.Tables[0].Rows.Count == 0) { MessageBox.Show("No Data to Display!"); return; }
            //OpView _op = new OpView(ds);
            //_op.ShowDialog();
        }

        public List<string> TodayVisited()
        {
            List<string> MyCollection = new List<string>();
            using (SqlConnection con = new SqlConnection(newPrescription.constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT Name FROM [regappform3] where convert(varchar(10), Date,120) =  CONVERT(date, getdate())", con);
                //  SqlCommand cmd = new SqlCommand("SELECT Name FROM [regappform3] where convert(varchar(10), Date,120) =  '2017-12-01'", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                //txtpatiantID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
            return MyCollection;
        }
        public List<string> TodayVisitedPatiantID()
        {
            List<string> MyCollection = new List<string>();
            using (SqlConnection con = new SqlConnection(newPrescription.constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT PatiantID FROM [regappform3] where convert(varchar(10), Date,120) =  CONVERT(date, getdate())  order by Date desc", con);
                //  SqlCommand cmd = new SqlCommand("SELECT Name FROM [regappform3] where convert(varchar(10), Date,120) =  '2017-12-01'", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                //txtpatiantID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
            return MyCollection;
        }
        public List<string> TodayVisitedEpres()
        {
            List<string> MyCollection = new List<string>();
            using (SqlConnection con = new SqlConnection(newPrescription.constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT PatiantID FROM [regappform3] where convert(varchar(10), Date,120) =  CONVERT(date, getdate())  order by Date desc", con);
                //  SqlCommand cmd = new SqlCommand("SELECT Name FROM [regappform3] where convert(varchar(10), Date,120) =  '2017-12-01'", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                //txtpatiantID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
            return MyCollection;
        }
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.ribbon1.ActiveTabChanged += ActiveTabChanged;
            lbl_live_time.Alignment = ToolStripItemAlignment.Left;
            statusStrip1.Items.Add(lbl_live_time);
            // lbl_live_time.Margin = new Padding(750, 3, 3, 3);
            lbl_live_time.Dock = DockStyle.Right;
            statusStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            lbl_live_time.BackColor = Color.Transparent;
            lbl_live_time.Text = "<b>DATE : <\b>" + DateTime.Now.ToString("dd/MM/yyyy") + " TIME : " + DateTime.Now.ToString("hh:mm:ss tt");
            lbl_live_time.Font = new Font("Arial", 10);
            timer1.Start();
            //dashBoardViewClick(null, null);
            //ribbonButton2_Click_1(null, null);
            _set = new Settingscs(newPrescription.tableLayoutPanel1, ribbon1);
            UpdateColorRibbons(ribbon1);
            ribbon1.ThemeColor = RibbonTheme.Black;
            ribbon1.Minimized = true;
        }

        private void ribbonOrbOptionButton1_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void ribbonButton2_Click_1(object sender, EventArgs e) // New Prescription
        {
            newPrescription.Prescription_Load(null, null);
            DoVisible(true);
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.Control == true || e.KeyCode == Keys.S)
            //    t.btnSave_Click();
            //else if (e.Control == true || e.KeyCode == Keys.P)
            //    t.btnPrint_Click();
            //else if (e.Control == true || e.KeyCode == Keys.C)
            //    t.btnClear_Click();
        }

        private void ribbonButton6_Click(object sender, EventArgs e) // Save Button
        {
            newPrescription.btnPrint_Click();
        }

        private void ribbonButton48_Click(object sender, EventArgs e) //Goto Button
        {
            //Sri_Venkateswara_Hospital.BtnMainPage _old = new Sri_Venkateswara_Hospital.BtnMainPage();
            //_old.Show();
        }

        private void ribbonButton1_Click(object sender, EventArgs e) // Drug Button
        {
            DoVisible(false, true);
        }

        private void ribbonButton4_Click(object sender, EventArgs e) //Add Drug Button
        {
            newDrug.BtnAdd_Click(null, null);
        }

        private void ribbonButton16_Click(object sender, EventArgs e) //Modify Drug Button
        {
            newDrug.BtnUpdate_Click(null, null);
        }

        private void ribbonButton17_Click(object sender, EventArgs e) //Delete Drug Button
        {
            newDrug.BtnRemove_Click(null, null);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbl_live_time.Text = "DATE : " + DateTime.Now.ToString("dd/MM/yyyy") + " TIME : " + DateTime.Now.ToString("hh:mm:ss tt");
            lbl_live_time.Font = new Font("Arial", 10);
            //InitLists();
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            //lbl_live_time.Text = "DATE : " + DateTime.Now.ToString("dd/MM/yyyy") + " TIME : " + DateTime.Now.ToString("hh:mm:ss tt");
            //lbl_live_time.Font = new Font("Arial", 10);
            InitLists();
        }

        private void ribbonOrbOptionButton2_Click(object sender, EventArgs e) //Option Button
        {
            _set.TopMost = true;
            _set.WindowState = FormWindowState.Normal;
            _set.BringToFront();
            _set.Show();
        }

        private void ribbonButton45_Click(object sender, EventArgs e)
        {
           // MetroFramework.Demo.MainForm _m = new MetroFramework.Demo.MainForm();
           // _m.Show();
        }

        private void ribbonButton44_Click(object sender, EventArgs e)  // Settings Button
        {
            _set.TopMost = true;
            _set.WindowState = FormWindowState.Normal;
            _set.BringToFront();
            _set.Show();
        }

        public void UpdateColorRibbons(Control myControl)
        {
            myControl.BackColor = Properties.Settings.Default.RBackColor;
            myControl.ForeColor = Properties.Settings.Default.RFontColor;
            myControl.Font = new Font(Properties.Settings.Default.RFontFamily, Properties.Settings.Default.RFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorRibbons(subC);
            //   ribbon1.BackColor = Properties.Settings.Default.RBackColor;
        }

        private void ribbonButton46_Click(object sender, EventArgs e) // Appointment Button
        {
            newAppoinment.NewAppointment_Load(null, null);
            DoVisible(false, false, true);
        }

        private void ribbonButton14_Click(object sender, EventArgs e) // Category Button
        {
            Category _cat = new Category();
            _cat.ShowDialog();
        }

        private void ribbonButton15_Click(object sender, EventArgs e)
        {
            NewDiagnosis _newdiagnosis = new NewDiagnosis();
            _newdiagnosis.ShowDialog();
        }

        private void ribbonButton4_Click_1(object sender, EventArgs e)
        {
            newAppoinment.btnsaveapp_Click(null, null);
        }

        private void ribbonButton3_Click(object sender, EventArgs e)
        {
            newPatient.NewPatient_Load(null, null);
            DoVisible(false, false, false, true);
        }

        private void txtSearchID_KeyUp(object sender, KeyEventArgs e)
        {
            if (!e.Handled)
                if (e.KeyCode == Keys.F1)
                { NewDiagnosis _dia = new NewDiagnosis(); _dia.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F2)
                { Category _cat = new Category(); _cat.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F3)
                { DoVisible(false, true); e.Handled = true; }
                else if (e.KeyCode == Keys.F4)
                { DoVisible(true); e.Handled = true; }
        }

        private void ribbonButton4_Click_2(object sender, EventArgs e) //Sea
        {
            Search _newSearchs = new Search(newPrescription);
            _newSearchs.Show();
        }

        private void ribbonButtonCheckOld_Click(object sender, EventArgs e)
        {
            object _control = newPrescription.Controls.Find("chkOld", true)[0];
            object _control1 = newAppoinment.Controls.Find("chkOld", true)[0];
            if (ribbonButtonCheckOld.SmallImage.Tag == "Checked")
            {
                ((CheckBox)_control).Checked = false; ((CheckBox)_control1).Checked = false;
                ribbonButtonCheckOld.SmallImage = Properties.Resources.unCheck16;
                ribbonButtonCheckOld.ToolTipImage = Properties.Resources.unCheck16;
                ribbonButtonCheckOld.SmallImage.Tag = "Unchecked";
                ribbonButtonCheckOld.ToolTipTitle = "New";
                ribbonButtonCheckOld.ToolTipTitle = "To Disable Old; Please click here ...";
            }
            else
            {
                ((CheckBox)_control).Checked = true; ((CheckBox)_control1).Checked = true;
                ribbonButtonCheckOld.SmallImage = Properties.Resources.Check16;
                ribbonButtonCheckOld.ToolTipImage = Properties.Resources.Check16;
                ribbonButtonCheckOld.SmallImage.Tag = "Checked";
                ribbonButtonCheckOld.ToolTipTitle = "Old";
                ribbonButtonCheckOld.ToolTipTitle = "To Enable Old; Please click here ...";
            }


        }

        private void MainForm_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void ribbonButtonMinMax_Click(object sender, EventArgs e)
        {
            if (ribbon1.Minimized)
            {
                ribbonButtonMinMax.SmallImage = Properties.Resources.minimize16;
                ribbonButtonMinMax.ToolTipImage = Properties.Resources.minimize16;
                ribbon1.Minimized = false;
                ribbonButtonMinMax.ToolTip = "To Minimize Ribbon";
                ribbonButtonMinMax.ToolTipTitle = "Minimizen";
            }
            else
            {
                ribbonButtonMinMax.SmallImage = Properties.Resources.maximize16;
                ribbonButtonMinMax.ToolTipImage = Properties.Resources.maximize16;
                ribbon1.Minimized = true;
                ribbonButtonMinMax.ToolTip = "To Maximize Ribbon";
                ribbonButtonMinMax.ToolTipTitle = "Maximize";
            }
        }


        private void ribbonButtonVaccine_Click(object sender, EventArgs e)
        {
            NewVaccine _newVaccine = new NewVaccine();
            _newVaccine.Show();
        }

        private void ribbonButtonbabyAge_Click(object sender, EventArgs e)
        {
            NewAge _newAge = new NewAge();
            _newAge.Show();
        }

        private void ribbonButtonVCc_Click(object sender, EventArgs e)
        {
            NewVaccineChart _newVaccineChart = new NewVaccineChart();
            _newVaccineChart.Show();
        }

        private void ribbonButtonHospital_Click(object sender, EventArgs e)
        {
            frmHospitalMaster frmHospital = new frmHospitalMaster();
            frmHospital.ShowDialog();
            UpdateMasterHospital();
        }

       

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.F4))
            {
                this.MainForm_FormClosing(this, null);
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

     
       

        private void stripBtnUsers_Click(object sender, EventArgs e)
        {
            ribbonBtnAdmin_Click(this, null);
        }

        private void ribbonBtnAdmin_Click(object sender, EventArgs e)
        {
            frmManageUser frmManageUser = new frmManageUser();
            frmManageUser.ShowDialog();
        }

        private void dashBoardViewClick(object sender, EventArgs e) // New Prescription
        {

            DoVisible(false,false,false,false,true);
        }

        private void stripBtnPres_Click(object sender, EventArgs e)
        {

        }

        private void stripBtnDoctor_Click(object sender, EventArgs e)
        {

        }

        private void ctrlTabHomeControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ctrlTabHomeControl.TabPages.Count > 0)
            {
                DashboardView view = ctrlTabHomeControl.TabPages[0].Controls[0] as DashboardView;
                view?.LoadChartData();
            }
        }

        private void ctrlRibbHelp_Click_1(object sender, EventArgs e)
        {
            frmAboutbox frmAboutbox = new frmAboutbox();
            frmAboutbox.ShowDialog();
        }
    }
}