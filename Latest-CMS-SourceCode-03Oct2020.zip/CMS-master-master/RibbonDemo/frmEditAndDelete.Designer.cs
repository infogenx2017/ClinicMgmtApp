﻿namespace SVMApplication
{
    partial class frmEditAndDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlTxtKeyValue = new MetroFramework.Controls.MetroTextBox();
            this.ctrlTxtUpdate = new MetroFramework.Controls.MetroButton();
            this.ctrlTxtDelete = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtReplaceBy = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // ctrlTxtKeyValue
            // 
            this.ctrlTxtKeyValue.Location = new System.Drawing.Point(102, 58);
            this.ctrlTxtKeyValue.Multiline = true;
            this.ctrlTxtKeyValue.Name = "ctrlTxtKeyValue";
            this.ctrlTxtKeyValue.Size = new System.Drawing.Size(281, 42);
            this.ctrlTxtKeyValue.TabIndex = 0;
            // 
            // ctrlTxtUpdate
            // 
            this.ctrlTxtUpdate.Location = new System.Drawing.Point(227, 155);
            this.ctrlTxtUpdate.Name = "ctrlTxtUpdate";
            this.ctrlTxtUpdate.Size = new System.Drawing.Size(75, 23);
            this.ctrlTxtUpdate.TabIndex = 1;
            this.ctrlTxtUpdate.Text = "Update";
            this.ctrlTxtUpdate.Click += new System.EventHandler(this.CtrlTxtUpdate_Click);
            // 
            // ctrlTxtDelete
            // 
            this.ctrlTxtDelete.Location = new System.Drawing.Point(308, 155);
            this.ctrlTxtDelete.Name = "ctrlTxtDelete";
            this.ctrlTxtDelete.Size = new System.Drawing.Size(75, 23);
            this.ctrlTxtDelete.TabIndex = 2;
            this.ctrlTxtDelete.Text = "Delete";
            this.ctrlTxtDelete.Click += new System.EventHandler(this.CtrlTxtDelete_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 62);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(59, 19);
            this.metroLabel1.TabIndex = 3;
            this.metroLabel1.Text = "KeyValue";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(23, 110);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(73, 19);
            this.metroLabel2.TabIndex = 5;
            this.metroLabel2.Text = "Replace by";
            // 
            // ctrlTxtReplaceBy
            // 
            this.ctrlTxtReplaceBy.Location = new System.Drawing.Point(102, 106);
            this.ctrlTxtReplaceBy.Multiline = true;
            this.ctrlTxtReplaceBy.Name = "ctrlTxtReplaceBy";
            this.ctrlTxtReplaceBy.Size = new System.Drawing.Size(281, 42);
            this.ctrlTxtReplaceBy.TabIndex = 4;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(146, 155);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 6;
            this.metroButton1.Text = "Close";
            this.metroButton1.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // frmEditAndDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 192);
            this.ControlBox = false;
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.ctrlTxtReplaceBy);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.ctrlTxtDelete);
            this.Controls.Add(this.ctrlTxtUpdate);
            this.Controls.Add(this.ctrlTxtKeyValue);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmEditAndDelete";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Edit and Replcae";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox ctrlTxtKeyValue;
        private MetroFramework.Controls.MetroButton ctrlTxtUpdate;
        private MetroFramework.Controls.MetroButton ctrlTxtDelete;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox ctrlTxtReplaceBy;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}