﻿using ClassLibrary;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication.Helper
{
    public static class AppMain
    {
        public static string DbName ="srivm";
        public static string DbUser = "sa";
        public static string DbPassword = "svm";

        public static string DoctorCode = "SV";
        public static int HospitalId = 1;
        public static bool IsMasterChanged = false;
        public static SqlConnection SqlCon;
        public static LoginUser LoginUser = new LoginUser();
        public static LoginHospital LoginHospital = new LoginHospital();
        static AppMain()
        {
            SqlCon = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
            LoadCredentials();
            LoadDefaultValues();         
        }

        private static void LoadCredentials()
        {
            //< add key = "DatabaseName" value = "srivm" />
            //< add key = "UserID" value = "sa" />
            //< add key = "Password" value = "database" />
            DbName = ConfigurationManager.AppSettings["DatabaseName"];
            DbUser = ConfigurationManager.AppSettings["UserID"];
            DbPassword = ConfigurationManager.AppSettings["Password"];
        }

        private static void LoadDefaultValues()
        {
            if (SqlCon.State == ConnectionState.Closed)
                SqlCon.Open();

            //string query = "select code from Hospital where master=1";
            //SqlCommand cmd = new SqlCommand(query, SqlCon);
            DoctorCode = "SV";

            string query = "select Hospital_ID,Name,City,Address,Website from Hospital where Master=@code";
            SqlCommand cmd  = new SqlCommand(query, SqlCon);
            cmd.Parameters.AddWithValue("@code", 1);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.HasRows)
            {
                while (reader.Read())
                {
                    LoginHospital.Id = reader.GetInt32(0);
                    LoginHospital.Name = reader.GetString(1);
                    LoginHospital.City = reader.GetString(2);
                    LoginHospital.Address = reader.GetString(3);
                    LoginHospital.Website = reader.GetString(4);
                }
                reader.NextResult();
            }

            HospitalId = LoginHospital.Id;
            if (HospitalId <= 0)
                HospitalId = 1;

        }

        public static int GetSelectedValueAsInt(this MetroFramework.Controls.MetroComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return Convert.ToInt32((ctrlCbxUserType.SelectedItem as ComboboxItem).Value);
            else
                return -1;
        }

        public static string GetSelectedValueAsString(this MetroFramework.Controls.MetroComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return ((ctrlCbxUserType.SelectedItem as ComboboxItem).Value).ToString();
            else
                return "";
        }

        public static string GetSelectedText(this MetroFramework.Controls.MetroComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return (ctrlCbxUserType.SelectedItem as ComboboxItem).Text;
            else
                return "";
        }

        public static int GetSelectedValueAsInt(this ComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return Convert.ToInt32((ctrlCbxUserType.SelectedItem as ComboboxItem).Value);
            else
                return -1;
        }

        public static string GetSelectedValueAsString(this ComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return ((ctrlCbxUserType.SelectedItem as ComboboxItem).Value).ToString();
            else
                return "";
        }

        public static string GetSelectedText(this ComboBox ctrlCbxUserType)
        {
            if (ctrlCbxUserType.SelectedItem != null)
                return (ctrlCbxUserType.SelectedItem as ComboboxItem).Text;
            else
                return "";
        }
    }
}
