﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SVMApplication.Helper
{
    
    public class ComboboxItem
    {
        public string Text { get; set; }
        public object Value { get; set; }

        public ComboboxItem()
        {
           
        }

        public ComboboxItem(object _value,string _text)
        {
            Value = _value;
            Text = _text;
        }
        public override string ToString()
        {
            return Text;
        }       
    }
}
