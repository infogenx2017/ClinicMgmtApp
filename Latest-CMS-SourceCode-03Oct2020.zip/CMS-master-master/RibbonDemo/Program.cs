using LicenseKeyActivation;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SVMApplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new BlackForm());
            //Application.Run(new MainForm());
            //Application.Run(new TestForm());
            //Application.Run(new HostForm());

            //Kevin Carbis - this form is excluded from the project so it will compile but is included in the sample code
            //Simply add this form to the project once you have downloaded the Qios controls and add a reference to it
            //Application.Run(new QiosCaptionTest());

            //frmSampleRibbon frmSampleRibbon = new frmSampleRibbon();
            //frmSampleRibbon.ShowDialog();
            //return;
#if HASP
            KeyValidation();
#endif
#if HASPD
            Application.Run(new SplashScreen());
#endif
        }

        static void KeyValidation()
        {
            try
            {
                KeyDecryption _decryption = new KeyDecryption();
                Tuple<bool, string> validKey = _decryption.CheckKeyActivation();
                if (validKey.Item1)
                {
                    KeyAlgorithm.Days = _decryption.Days;
                    //Call Main Frm
                    Application.Run(new SplashScreen());
                }
                else
                {
                    MessageBox.Show(validKey.Item2, "Activate License - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ActivateKeyFrm activateLicenseWindow = new ActivateKeyFrm();
                    if (activateLicenseWindow.ShowDialog() == DialogResult.OK)
                    {
                        if (activateLicenseWindow.KeyInform.Item1 == true)
                        {
                            KeyAlgorithm.Days = _decryption.Days;
                            Application.Run(new SplashScreen());
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
        }
    }
}