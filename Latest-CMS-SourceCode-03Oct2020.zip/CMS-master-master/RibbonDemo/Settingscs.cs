﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class Settingscs : MetroFramework.Forms.MetroForm
    {
        TableLayoutPanel _mv = null; static List<Control> LabelControl = new List<Control>(); Control _c = null;
        static List<Control> OtherControl = new List<Control>(); Control _oc = null; Ribbon _rib = null;
        static List<Control> RibbonControl = new List<Control>(); Control _r = null;

        public Settingscs(TableLayoutPanel mv, Ribbon rib)
        {
            InitializeComponent();
            _mv = mv;
            _rib = rib;
            LabelControl = new List<Control>();
            OtherControl = new List<Control>();
            UpdatePrescriptionControls(ref LabelControl, ref OtherControl, _mv);

            RibbonControl.Add(_rib);
            this.FormClosing += new FormClosingEventHandler(Settingscs_FormClosing);
        }
        private void UpdatePrescriptionControls(ref List<Control> LabelControl, ref List<Control> OtherControl, TableLayoutPanel _tableLayoutPanel)
        {
            Control _c = null;
            Control _oc = null;

            foreach (Control c in _tableLayoutPanel.Controls)
                if ((c.Name.Contains("label") || c.Name.Contains("chk") || c.Name.Contains("btn")) && c.Enabled)
                { LabelControl.Add(c); _c = c; }
                else if (c.Name.Contains("table"))
                {
                    if (_tableLayoutPanel.Name.ToString() != "tableLayoutPanel1" && _tableLayoutPanel.Name.ToString() != "tableLayoutPanel2")
                        LabelControl.Add(_tableLayoutPanel); _c = _tableLayoutPanel;
                    UpdatePrescriptionControls(ref LabelControl, ref OtherControl, (TableLayoutPanel)c);
                }
                else if (!c.Name.Contains("label") && !c.Name.Contains("chk") && !c.Name.Contains("btn"))
                { OtherControl.Add(c); _oc = c; }

        }
        void Settingscs_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void propertyGrid1_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {

        }

        public void UpdateColorLabels(Control myControl, bool ApplySettings = true)
        {
            if (ApplySettings)
            {
                Properties.Settings.Default.LBackColor = _lBackColor.BackColor;
                Properties.Settings.Default.LFontColor = _lFontColor.BackColor;
                Properties.Settings.Default.LFontSize = float.Parse(metroTextBoxLabel.Text);
                Properties.Settings.Default.LFontFamily = metroComboBoxLabel.Text;
                Properties.Settings.Default.Save();
            } if (!myControl.Name.Contains("btn"))
            {
                myControl.BackColor = Properties.Settings.Default.LBackColor;
                myControl.ForeColor = Properties.Settings.Default.LFontColor;
            }
            myControl.Font = new Font(Properties.Settings.Default.LFontFamily, Properties.Settings.Default.LFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorLabels(subC, ApplySettings);

        }

        public void UpdateColorControls(Control myControl, bool ApplySettings = true)
        {
            if (ApplySettings)
            {
                Properties.Settings.Default.CBackColor = _CBackColor.BackColor;
                Properties.Settings.Default.CFontColor = _CFontColor.BackColor;
                Properties.Settings.Default.CFontSize = float.Parse(metroTextBoxControl.Text);
                Properties.Settings.Default.CSFontSize = float.Parse(metroTextBoxSControl.Text);
                Properties.Settings.Default.CFontFamily = metroComboBoxControl.Text;
                Properties.Settings.Default.Save();
            }
            myControl.BackColor = Properties.Settings.Default.CBackColor;
            myControl.ForeColor = Properties.Settings.Default.CFontColor;
            if (myControl.Name.ToString().ToUpper() == "TXTCLINICAL")
                myControl.Font = new Font(Properties.Settings.Default.CFontFamily, Properties.Settings.Default.CSFontSize);
            else
                myControl.Font = new Font(Properties.Settings.Default.CFontFamily, Properties.Settings.Default.CFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorControls(subC, ApplySettings);
            _mv.BackColor = Properties.Settings.Default.CBackColor;

        }

        public void UpdateColorRibbons(Control myControl, bool ApplySettings = true)
        {
            if (ApplySettings)
            {
                Properties.Settings.Default.RBackColor = _RBackColor.BackColor;
                Properties.Settings.Default.RFontColor = _RFontColor.BackColor;
                Properties.Settings.Default.RFontSize = float.Parse(metroTextBoxRibbon.Text);
                Properties.Settings.Default.RFontFamily = metroComboBoxRibbon.Text;
                Properties.Settings.Default.Save();
            }
            myControl.BackColor = Properties.Settings.Default.RBackColor;
            myControl.ForeColor = Properties.Settings.Default.RFontColor;
            myControl.Font = new Font(Properties.Settings.Default.RFontFamily, Properties.Settings.Default.RFontSize);
            foreach (Control subC in myControl.Controls)
                UpdateColorControls(subC, ApplySettings);
            //  _rib.BackColor = Properties.Settings.Default.RBackColor;

        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            foreach (Control c in LabelControl)
                UpdateColorLabels(c);
            foreach (Control c in OtherControl)
                UpdateColorControls(c);
            foreach (Control c in RibbonControl)
                UpdateColorRibbons(c);
            Color color = Properties.Settings.Default.CBackColor;
            string ColorBackHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.CFontColor;
            string ColorFontHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.RBackColor;
            string ColorTabHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            color = Properties.Settings.Default.RFontColor;
            string ColorTabSelHex = String.Format("#{0:X2}{1:X2}{2:X2}", color.R, color.G, color.B);
            System.Windows.Forms.Theme.ColorTable = new CustomColorTable(ColorFontHex, ColorBackHex, ColorTabHex, ColorTabSelHex);
            this.Close();
        }

        private void Settingscs_Load(object sender, EventArgs e)
        {
            Properties.Settings.Default.Upgrade();
            List<string> fontlabel = new List<string>();
            List<string> fontControl = new List<string>();
            List<string> fontRibbon = new List<string>();
            foreach (FontFamily font in System.Drawing.FontFamily.Families)
            {
                // Label _name = new Label();
                //_name.Text= font.Name;
                //_name.Font = new System.Drawing.Font(font.Name, _name.Size);

                fontlabel.Add(font.Name); fontControl.Add(font.Name); fontRibbon.Add(font.Name);
            }
            metroComboBoxLabel.DataSource = fontlabel;

            metroComboBoxLabel.SelectedItem = Properties.Settings.Default.LFontFamily;
            this._lBackColor.BackColor = Properties.Settings.Default.LBackColor;
            this._lBackColor.ForeColor = Properties.Settings.Default.LBackColor;
            this._lFontColor.BackColor = Properties.Settings.Default.LFontColor;
            this._lFontColor.ForeColor = Properties.Settings.Default.LFontColor;
            metroTextBoxLabel.Text = Properties.Settings.Default.LFontSize.ToString();

            metroComboBoxControl.DataSource = fontControl;
            metroComboBoxControl.SelectedItem = Properties.Settings.Default.CFontFamily;
            this._CBackColor.BackColor = Properties.Settings.Default.CBackColor;
            this._CBackColor.ForeColor = Properties.Settings.Default.CBackColor;
            this._CFontColor.BackColor = Properties.Settings.Default.CFontColor;
            this._CFontColor.ForeColor = Properties.Settings.Default.CFontColor;
            metroTextBoxControl.Text = Properties.Settings.Default.CFontSize.ToString();
            metroTextBoxSControl.Text = Properties.Settings.Default.CSFontSize.ToString();
            metroComboBoxRibbon.DataSource = fontRibbon;
            metroComboBoxRibbon.SelectedItem = Properties.Settings.Default.RFontFamily;
            this._RBackColor.BackColor = Properties.Settings.Default.RBackColor;
            this._RBackColor.ForeColor = Properties.Settings.Default.RBackColor;
            this._RFontColor.BackColor = Properties.Settings.Default.RFontColor;
            this._RFontColor.ForeColor = Properties.Settings.Default.RFontColor;
            metroTextBoxRibbon.Text = Properties.Settings.Default.RFontSize.ToString();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Color_Click(object sender, EventArgs e)
        {
            if (sender is Button)
                PickColor((Button)sender);
        }

        private void PickColor(Button _btn)
        {
            ColorDialog _c = new ColorDialog();
            _c.AnyColor = true;
            _c.AllowFullOpen = true;
            if (_c.ShowDialog() == DialogResult.OK)
                _btn.BackColor = _c.Color;
        }

        private void metroTextBoxLabel_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void metroTextBoxLabel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
                e.Handled = true;
        }

        private void btnDefaults_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Upgrade();
            Properties.Settings.Default.LBackColor = Color.FromKnownColor(KnownColor.ControlDarkDark);
            Properties.Settings.Default.LFontColor = Color.FromKnownColor(KnownColor.ButtonFace);
            Properties.Settings.Default.LFontSize = 10;
            Properties.Settings.Default.LFontFamily = System.Drawing.FontFamily.Families[12].Name;

            Properties.Settings.Default.CBackColor = Color.FromKnownColor(KnownColor.White); ;
            Properties.Settings.Default.CFontColor = Color.FromKnownColor(KnownColor.Black); ;
            Properties.Settings.Default.CFontSize = 10;
            Properties.Settings.Default.CFontFamily = System.Drawing.FontFamily.Families[12].Name;

            Properties.Settings.Default.RBackColor = Color.FromKnownColor(KnownColor.White); ;
            Properties.Settings.Default.RFontColor = Color.FromKnownColor(KnownColor.Black); ;
            Properties.Settings.Default.RFontSize = 10;
            Properties.Settings.Default.RFontFamily = System.Drawing.FontFamily.Families[12].Name;

            Properties.Settings.Default.Save();
            foreach (Control c in LabelControl)
                UpdateColorLabels(c, false);
            foreach (Control c in OtherControl)
                UpdateColorControls(c, false);
            foreach (Control c in RibbonControl)
                UpdateColorRibbons(c, false);
            Settingscs_Load(null, null);
        }
    }
}
