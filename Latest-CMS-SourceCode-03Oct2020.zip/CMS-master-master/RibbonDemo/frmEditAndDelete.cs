﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmEditAndDelete : MetroFramework.Forms.MetroForm
    {
        private Editmode editmode;
        private string keyValue = "";

        public frmEditAndDelete()
        {
            InitializeComponent();
        }

        public frmEditAndDelete(Editmode editmo,String key)
         {
            InitializeComponent();
            this.Text = $"Edit And Delete - {editmo.ToString() }";
            editmode = editmo;
            keyValue = key;
            ctrlTxtKeyValue.Text = keyValue;
        }

        private void CtrlTxtUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ctrlTxtReplaceBy.Text)|| string.IsNullOrWhiteSpace(ctrlTxtKeyValue.Text))
            {
                MessageBox.Show("Please Enter valid Entry for Replacing");
                ctrlTxtReplaceBy.Focus();
                return;
            }
            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
            using (con)
            {
                
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Sp_UPdateAndDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@modeTextbox",Convert.ToInt32(editmode));
                cmd.Parameters.AddWithValue("@mode", 1);
                cmd.Parameters.AddWithValue("@keyvalue", ctrlTxtKeyValue.Text);
                cmd.Parameters.AddWithValue("@replacedBy", ctrlTxtReplaceBy.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show(editmode.ToString() + " Updated Sucessfully");
                this.DialogResult = DialogResult.OK;
            }
        }

        private void CtrlTxtDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ctrlTxtKeyValue.Text))
            {
                MessageBox.Show("Please Enter valid Entry for Delete");
                ctrlTxtKeyValue.Focus();
                return;
            }
            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
            using (con)
            {
                DialogResult res= MessageBox.Show("Are you sure want to Delete","Information",MessageBoxButtons.OKCancel);
                if (res != DialogResult.OK)
                    return;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Sp_UPdateAndDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@modeTextbox", Convert.ToInt32(editmode));
                cmd.Parameters.AddWithValue("@mode", 2);
                cmd.Parameters.AddWithValue("@keyvalue", ctrlTxtKeyValue.Text);
                cmd.Parameters.AddWithValue("@replacedBy", ctrlTxtReplaceBy.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show(editmode.ToString() + " Deleted Sucessfully");
                this.DialogResult = DialogResult.OK;
            }

        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }

    public enum Editmode
    {
        None,
        Name,
        PhoneNo,
        Area,
        UHID,
        FullAddress
    }

    public enum Action
    {
        None,
        Edit,
        Delete
    }
}
