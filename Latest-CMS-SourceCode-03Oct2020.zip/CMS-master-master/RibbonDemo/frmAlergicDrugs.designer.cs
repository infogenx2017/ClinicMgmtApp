﻿namespace SVMApplication
{
    partial class frmAlergicDrugs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAlergicDrugs));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrllblAlergicName = new MetroFramework.Controls.MetroLabel();
            this.ctrllblDescription = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtAlergicDrugName = new MetroFramework.Controls.MetroTextBox();
            this.ctrlTxtDescption = new MetroFramework.Controls.MetroTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ctrlGridAlergicDrugs = new System.Windows.Forms.DataGridView();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.ctrlAddButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlDeleteButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridAlergicDrugs)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.toolStrip1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 60);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.87431F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.12568F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 239F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(646, 412);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel2, 2);
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.65289F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 78.34711F));
            this.tableLayoutPanel2.Controls.Add(this.ctrllblAlergicName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.ctrllblDescription, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ctrlTxtAlergicDrugName, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.ctrlTxtDescption, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 94F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(640, 133);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // ctrllblAlergicName
            // 
            this.ctrllblAlergicName.AutoSize = true;
            this.ctrllblAlergicName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrllblAlergicName.Location = new System.Drawing.Point(3, 0);
            this.ctrllblAlergicName.Name = "ctrllblAlergicName";
            this.ctrllblAlergicName.Size = new System.Drawing.Size(132, 35);
            this.ctrllblAlergicName.TabIndex = 0;
            this.ctrllblAlergicName.Text = "Alergic Drug Name";
            // 
            // ctrllblDescription
            // 
            this.ctrllblDescription.AutoSize = true;
            this.ctrllblDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrllblDescription.Location = new System.Drawing.Point(3, 35);
            this.ctrllblDescription.Name = "ctrllblDescription";
            this.ctrllblDescription.Size = new System.Drawing.Size(132, 98);
            this.ctrllblDescription.TabIndex = 1;
            this.ctrllblDescription.Text = "Description";
            // 
            // ctrlTxtAlergicDrugName
            // 
            this.ctrlTxtAlergicDrugName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtAlergicDrugName.Location = new System.Drawing.Point(141, 3);
            this.ctrlTxtAlergicDrugName.MaxLength = 100;
            this.ctrlTxtAlergicDrugName.Name = "ctrlTxtAlergicDrugName";
            this.ctrlTxtAlergicDrugName.Size = new System.Drawing.Size(496, 29);
            this.ctrlTxtAlergicDrugName.TabIndex = 2;
            // 
            // ctrlTxtDescption
            // 
            this.ctrlTxtDescption.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtDescption.Location = new System.Drawing.Point(141, 38);
            this.ctrlTxtDescption.MaxLength = 200;
            this.ctrlTxtDescption.Multiline = true;
            this.ctrlTxtDescption.Name = "ctrlTxtDescption";
            this.ctrlTxtDescption.Size = new System.Drawing.Size(496, 92);
            this.ctrlTxtDescption.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.groupBox1, 2);
            this.groupBox1.Controls.Add(this.ctrlGridAlergicDrugs);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 175);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(640, 234);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // ctrlGridAlergicDrugs
            // 
            this.ctrlGridAlergicDrugs.AllowUserToAddRows = false;
            this.ctrlGridAlergicDrugs.AllowUserToDeleteRows = false;
            this.ctrlGridAlergicDrugs.AllowUserToResizeColumns = false;
            this.ctrlGridAlergicDrugs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridAlergicDrugs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ctrlGridAlergicDrugs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridAlergicDrugs.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridAlergicDrugs.Location = new System.Drawing.Point(3, 16);
            this.ctrlGridAlergicDrugs.MultiSelect = false;
            this.ctrlGridAlergicDrugs.Name = "ctrlGridAlergicDrugs";
            this.ctrlGridAlergicDrugs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridAlergicDrugs.Size = new System.Drawing.Size(634, 215);
            this.ctrlGridAlergicDrugs.TabIndex = 2;
            this.ctrlGridAlergicDrugs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CtrlGridAlergicDrugs_CellClick);
            // 
            // toolStrip1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.toolStrip1, 2);
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctrlAddButton,
            this.toolStripSeparator2,
            this.ctrlDeleteButton,
            this.toolStripSeparator1,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 139);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(646, 33);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // ctrlAddButton
            // 
            this.ctrlAddButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlAddButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlAddButton.Name = "ctrlAddButton";
            this.ctrlAddButton.Size = new System.Drawing.Size(35, 30);
            this.ctrlAddButton.Text = "Save";
            this.ctrlAddButton.Click += new System.EventHandler(this.CtrlAddButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // ctrlDeleteButton
            // 
            this.ctrlDeleteButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ctrlDeleteButton.Image = ((System.Drawing.Image)(resources.GetObject("ctrlDeleteButton.Image")));
            this.ctrlDeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ctrlDeleteButton.Name = "ctrlDeleteButton";
            this.ctrlDeleteButton.Size = new System.Drawing.Size(44, 30);
            this.ctrlDeleteButton.Text = "Delete";
            this.ctrlDeleteButton.Click += new System.EventHandler(this.CtrlDeleteButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(38, 30);
            this.toolStripButton1.Text = "Clear";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton1.Location = new System.Drawing.Point(556, 22);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 1;
            this.metroButton1.Text = "Close";
            this.metroButton1.Visible = false;
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // frmAlergicDrugs
            // 
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(686, 492);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAlergicDrugs";
            this.Text = "Alergy Drugs";
            this.Load += new System.EventHandler(this.FrmAlergicDrugs_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridAlergicDrugs)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroLabel ctrlLblCmpName;
        private MetroFramework.Controls.MetroLabel ctrlLblLicense;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroLabel ctrllblAlergicName;
        private MetroFramework.Controls.MetroLabel ctrllblDescription;
        private MetroFramework.Controls.MetroTextBox ctrlTxtAlergicDrugName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtDescption;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton ctrlAddButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton ctrlDeleteButton;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.DataGridView ctrlGridAlergicDrugs;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
    }
}