﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewVaccine : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
        public NewVaccine()
        {
            InitializeComponent();
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select * from Vaccine order by Vaccine_ID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                VaccineGrid.DataSource = ds.Tables[0];

            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtvaccine.Text != "" && txtAge.Text != "" && txtgap.Text != "")
            {
                if (btnsave.Text == "Save")
                {
                    if (CheckName())
                    {
                        btnsave.Text = "Update";
                        MessageBox.Show("Vaccine already exist");
                        return;
                    }
                    else
                    {
                        SaveMathod();
                        MessageBox.Show("Saved Successfully");
                    }
                }
                else
                {
                    SaveMathod();

                    MessageBox.Show("Updated Successfully");
                }
                LoadGrid();
                clear();
            }
            else
            {
                MessageBox.Show("Please Fill All Records");
            }
        }

        private bool CheckName()
        {
            bool rtnval = false;
            try
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select Vaccine_ID,vaccine,VaccineAgeLimit,VaccineGap from Vaccine Where vaccine=@vaccine";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@vaccine", txtvaccine.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rtnval = true;
                    lblRowID.Text = ds.Tables[0].Rows[0]["Vaccine_ID"].ToString();
                    txtvaccine.Text = ds.Tables[0].Rows[0]["vaccine"].ToString();
                    txtgap.Text = ds.Tables[0].Rows[0]["VaccineGap"].ToString();
                    txtAge.Text = ds.Tables[0].Rows[0]["VaccineAgeLimit"].ToString();
                }
            }
            catch { lblRowID.Text = lblRowID.Text = VaccineGrid.Rows!=null?(VaccineGrid.Rows.Count + 1).ToString():"1"; }
            return rtnval;
        }


        private string SaveMathod()
        {

            using (con)
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Vaccine_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Vaccine_ID", Convert.ToInt32(lblRowID.Text));
                cmd.Parameters.AddWithValue("@vaccine", txtvaccine.Text);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.Parameters.AddWithValue("@Gap", txtgap.Text);
                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void clear()
        {
            lblRowID.Text = ""; txtvaccine.Text = "";
            txtAge.Text = "";
            txtgap.Text = "";
            btnsave.Text = "Save";

        }

        private void NewVaccine_Load(object sender, EventArgs e)
        {
            LoadGrid();
            dataGridView1_CellClick(null, null);
            txtvaccine.Focus();
        }
        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ((TextBox)sender).Focus();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;
            if (e != null) Rowidx = e.RowIndex;
            clear();
            int rowIndex = VaccineGrid.Rows[Rowidx].Index;
            VaccineGrid.Rows[Rowidx].Cells[0].Selected = true;

            if (VaccineGrid == null)
                return;
            if (VaccineGrid.Rows[Rowidx].Cells[0].Selected == true)
            {

                if (Convert.ToString(VaccineGrid.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {

                    lblRowID.Text = VaccineGrid.Rows[Rowidx].Cells[0].Value.ToString();
                    txtvaccine.Text = VaccineGrid.Rows[Rowidx].Cells[1].Value.ToString();
                    txtgap.Text = VaccineGrid.Rows[Rowidx].Cells[2].Value.ToString();
                    txtAge.Text = VaccineGrid.Rows[Rowidx].Cells[3].Value.ToString();

                    btnsave.Text = "Update";
                }
                else
                    clear();
            }
            else
                clear();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtvaccine.Text != "" && lblRowID.Text != "")
            {
                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From Vaccine Where Vaccine_ID =@Vaccine_ID", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Vaccine_ID", Convert.ToInt32(lblRowID.Text));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    clear();
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
            lblRowID.Text = (VaccineGrid.Rows.Count+1).ToString();
        }


    }
}
