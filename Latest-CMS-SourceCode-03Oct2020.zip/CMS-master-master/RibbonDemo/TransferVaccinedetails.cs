﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class TransferVaccinedetails : MetroFramework.Forms.MetroForm
    {
        // SqlConnection con = null;
        string CurrentDayVaccine = string.Empty; string NextVaccine = string.Empty; NewPrescription ObjPrescription = null; string NextVaccineDueDate = string.Empty; string PendingVaccine = string.Empty;
        public TransferVaccinedetails(NewPrescription _ObjPrescription, string _CurrentDayVaccine, string _NextVaccine, string _NextVaccineDueDate, string _PendingVaccine)
        {
            InitializeComponent(); NextVaccine = _NextVaccine; CurrentDayVaccine = _CurrentDayVaccine; PendingVaccine = _PendingVaccine; NextVaccineDueDate = _NextVaccineDueDate;
            txt2A.Text = (NextVaccine != "" ? "Next vaccine : " + NextVaccine + Environment.NewLine  : "");
            txt2A.Text = txt2A.Text + (NextVaccineDueDate != "" ? "Next Vaccine DueDate : " + NextVaccineDueDate + Environment.NewLine  : "");
            txt2A.Text = txt2A.Text + (PendingVaccine != "" ? "Pending Vaccine : " + PendingVaccine + Environment.NewLine : "");
            txt2CN.Text = CurrentDayVaccine != "" ? "Current day vaccine : " + CurrentDayVaccine + Environment.NewLine : "";
            ObjPrescription = _ObjPrescription;
        }

        private void btnokay_Click(object sender, EventArgs e)
        {
            ObjPrescription.AddAdvice(txt2A.Text);
            ObjPrescription.AddClinicalNotes(txt2CN.Text);
            this.Close();
        }

    }
}
