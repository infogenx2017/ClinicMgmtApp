﻿namespace SVMApplication
{
    partial class NewVaccineChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.btnsave = new MetroFramework.Controls.MetroButton();
            this.btndelete = new MetroFramework.Controls.MetroButton();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.VaccineChartGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.VaccineChartGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(-1, 484);
            this.lblRowID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(14, 20);
            this.lblRowID.TabIndex = 28;
            this.lblRowID.Text = "1";
            this.lblRowID.Visible = false;
            // 
            // btnsave
            // 
            this.btnsave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnsave.Location = new System.Drawing.Point(225, 601);
            this.btnsave.Margin = new System.Windows.Forms.Padding(4);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(182, 28);
            this.btnsave.TabIndex = 35;
            this.btnsave.Text = "Save";
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btndelete
            // 
            this.btndelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btndelete.Location = new System.Drawing.Point(415, 601);
            this.btndelete.Margin = new System.Windows.Forms.Padding(4);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(182, 28);
            this.btndelete.TabIndex = 37;
            this.btndelete.Text = "Delete";
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnexit
            // 
            this.btnexit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(605, 601);
            this.btnexit.Margin = new System.Windows.Forms.Padding(4);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(182, 28);
            this.btnexit.TabIndex = 38;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // VaccineChartGrid
            // 
            this.VaccineChartGrid.AllowUserToOrderColumns = true;
            this.VaccineChartGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.VaccineChartGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.VaccineChartGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.VaccineChartGrid.ColumnHeadersHeight = 34;
            this.VaccineChartGrid.Location = new System.Drawing.Point(35, 64);
            this.VaccineChartGrid.Margin = new System.Windows.Forms.Padding(4);
            this.VaccineChartGrid.Name = "VaccineChartGrid";
            this.VaccineChartGrid.RowHeadersVisible = false;
            this.VaccineChartGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.VaccineChartGrid.Size = new System.Drawing.Size(752, 518);
            this.VaccineChartGrid.TabIndex = 27;
            this.VaccineChartGrid.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.VaccineChartGrid_CellBeginEdit);
            this.VaccineChartGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.VaccineChartGrid.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellEndEdit);
            this.VaccineChartGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellValueChanged);
            this.VaccineChartGrid.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.VaccineChartGrid_EditingControlShowing);
            this.VaccineChartGrid.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.VaccineChartGrid_RowsAdded);
            // 
            // NewVaccineChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 650);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.VaccineChartGrid);
            this.MaximizeBox = false;
            this.Name = "NewVaccineChart";
            this.Text = "Vaccine Chart Details ...";
            this.Load += new System.EventHandler(this.NewVaccineChart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VaccineChartGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRowID;
        private MetroFramework.Controls.MetroButton btnsave;
        private MetroFramework.Controls.MetroButton btndelete;
        private MetroFramework.Controls.MetroButton btnexit;
        private System.Windows.Forms.DataGridView VaccineChartGrid;
    }
}