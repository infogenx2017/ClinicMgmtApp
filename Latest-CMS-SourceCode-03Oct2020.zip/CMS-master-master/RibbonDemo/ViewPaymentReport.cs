﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using SVMApplication.Helper;

namespace SVMApplication
{
    public partial class ViewPaymentReport : UserControl
    {
        string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public ViewPaymentReport()
        {
            InitializeComponent();
        }

        public void PatientStatusLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        private void ctrlChkToday_CheckedChanged(object sender, EventArgs e)
        {
            if (ctrlChkToday.Checked)
            {
                ctrlChkAdvance.Checked = false;
            }
        }

        private void ctrlChkAdvance_CheckedChanged(object sender, EventArgs e)
        {
            if (ctrlChkAdvance.Checked)
            {
                ctrlChkToday.Checked = false;
            }
        }

        private void ctrlBtnSearch_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void Search()
        {
            GetPaymentDetails();
            GetPaymentAmount();
        }

        private void GetPaymentDetails()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                SqlCommand cmd = new SqlCommand("GetPaymentDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();


                cmd.Parameters.AddWithValue("@type", ctrlCbxStatus.Text);
                cmd.Parameters.AddWithValue("@dCode", AppMain.DoctorCode);
                cmd.Parameters.AddWithValue("@serach", ctrlChkAdvance.Checked ? 'B' : 'A');
                cmd.Parameters.AddWithValue("@start", ctrlDateStart.Value);
                cmd.Parameters.AddWithValue("@end", ctrlDateEnd.Value);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                ctrlGridAppointmentList.DataSource = table;
            }
        }
        private void GetPaymentAmount()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                SqlCommand cmd = new SqlCommand("GetPaymentDetailsAmount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();


                cmd.Parameters.AddWithValue("@type", ctrlCbxStatus.Text);
                cmd.Parameters.AddWithValue("@dCode", AppMain.DoctorCode);
                cmd.Parameters.AddWithValue("@serach", ctrlChkAdvance.Checked ? 'B' : 'A');
                cmd.Parameters.AddWithValue("@start", ctrlDateStart.Value);
                cmd.Parameters.AddWithValue("@end", ctrlDateEnd.Value);

                
                var res =Convert.ToString( cmd.ExecuteScalar());

                if (!string.IsNullOrWhiteSpace(res))
                    ctrlLblAmount.Text = res.ToString();
                else
                    ctrlLblAmount.Text = "0.00";
            }
        }

        private void ViewPAyment_Load(object sender, EventArgs e)
        {
            PatientStatusLoad();
            Search();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            ctrlGridAppointmentList.DataSource = null;
            ctrlLblAmount.Text = 0.00.ToString();
        }

        private void ctrlCbxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            Search();
        }
    }
}
