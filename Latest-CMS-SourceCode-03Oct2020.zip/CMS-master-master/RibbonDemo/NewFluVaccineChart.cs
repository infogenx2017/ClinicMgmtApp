﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewFluVaccineBirthChart : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null; string DOB = string.Empty; new string Name = string.Empty; string Id = string.Empty; string Gender = string.Empty;
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public bool isGovernment = false; public bool isFluChecked = false;
        public string GivenPlace = string.Empty;
        public DateTimePicker oDateTimePicker = new DateTimePicker(); public bool isCellChanged = false; DataGridViewTextBoxEditingControl tb = null;
        public NewPrescription ObjPrescription = null; string CurrentDayVaccine = string.Empty; string NextVaccine = string.Empty; string NextVaccineDueDate = string.Empty; string PendingVaccine = string.Empty;
        public NewFluVaccineBirthChart(NewPrescription _ObjPrescription, string _DOB, string _Name, string _Id, string _Gender)
        {
            InitializeComponent();
            DOB = _DOB; Name = _Name; Id = _Id; Gender = _Gender; ObjPrescription = _ObjPrescription;
        }

        private void SaveFluMathod(string PatiantID, string Vaccine, string Age, string DueDate, string GDate, string RDate)
        {
            //string VaccineID = GetVaccineID(Vaccine);
            //string AgeID = GetAgeID(Age);
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("SAVE_FLU_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@vaccine", Vaccine);
                cmd.Parameters.AddWithValue("@Age", Age);
                cmd.Parameters.AddWithValue("@PatiantID", PatiantID);
                if (DueDate != "")
                    cmd.Parameters.AddWithValue("@DueDate", Convert.ToDateTime(DueDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@DueDate", SqlDbType.DateTime).Value = dt; }
                if (GDate != "")
                    cmd.Parameters.AddWithValue("@GivenDate", Convert.ToDateTime(GDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@GivenDate", SqlDbType.DateTime).Value = dt; } 
                if (RDate != "")
                    cmd.Parameters.AddWithValue("@RDate", Convert.ToDateTime(RDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@RDate", SqlDbType.DateTime).Value = dt; }
                cmd.ExecuteNonQuery();

            }
        }

        private int CalculateAgeinMonth(DateTime dateOfBirth)
        {
            int age = 0;
            age = DateTime.Now.Year - dateOfBirth.Year;
            if (dateOfBirth > DateTime.Now.AddYears(-age)) age--;
            return ((age * 12) + DateTime.Now.Month);
        }

        void LoadFluGrid()
        {
            DataSet ds = new DataSet();
            using (con)
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("FLU_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB));
                cmd.Parameters.AddWithValue("@P_ID", (Id));
                cmd.Parameters.AddWithValue("@P_Name", (Name));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

            }
            if (ds.Tables[0].Rows.Count <= 0)
            {
                FluFirstDose.Enabled = true; int StepYear = 10;
                DateTime FirstDose = Convert.ToDateTime(FluFirstDose.Value);
                DateTime StepDate = DateTime.Now.AddYears(StepYear); int FluCount = 3;
                int AgeinMonth = CalculateAgeinMonth(Convert.ToDateTime(DOB));
                while (StepDate.Year != Convert.ToDateTime(FirstDose).Year)
                {
                    DateTime? nulldt = null;
                    if (AgeinMonth >= 6 && AgeinMonth <= 108 && FluCount == 3)
                    {
                        ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "FLU – 1st dose", Convert.ToDateTime(FirstDose).AddYears(FluCount - 3).Date, nulldt, lblID.Text);

                        ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "FLU – 2nd dose", Convert.ToDateTime(FirstDose).AddMonths(1).Date, nulldt, lblID.Text);
                        FirstDose = Convert.ToDateTime(FluFirstDose.Value).AddMonths(1);
                    }
                    else
                        ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "FLU - " + Convert.ToDateTime(FirstDose).AddYears(FluCount - 3).Year.ToString(), Convert.ToDateTime(FirstDose).AddYears(FluCount - 3).Date, nulldt, lblID.Text);


                    FluCount++;
                    StepDate = StepDate.AddYears(-1);
                }
            }
            else FluFirstDose.Enabled = false;
            FluChartGrid.DataSource = ds.Tables[0];

            FluChartGrid.Columns[5].Visible = false;
            FluChartGrid.Columns[1].Visible = false;
            FluChartGrid.Columns[0].Visible = false;
        }

        void LoadTyphoidGrid()
        {
            DataSet ds = new DataSet();
            using (con)
            {

                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("TYPHOID_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB));
                cmd.Parameters.AddWithValue("@P_ID", (Id));
                cmd.Parameters.AddWithValue("@P_Name", (Name));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

            }
            if (ds.Tables[0].Rows.Count <= 0)
            {
                TyphoidFirstDose.Enabled = true; int StepYear = 30;
                DateTime FirstDose = Convert.ToDateTime(TyphoidFirstDose.Value);
                DateTime StepDate = FirstDose; int FluCount = 3; int StepTyphoid = 0;
                while (StepDate.Year != Convert.ToDateTime(FirstDose).AddYears(StepYear).Year && StepDate.Year <= Convert.ToDateTime(FirstDose).AddYears(StepYear).Year)
                {
                    DateTime? nulldt = null;
                    if (checkRegular.Checked)
                        ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "Typhoid - " + StepDate.Year.ToString(), StepDate.Date, nulldt, lblID.Text);
                    else
                    {
                        if (FluCount == 3)
                        {
                            ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "Typhoid – Primary dose", StepDate.Date, nulldt, lblID.Text);
                            StepDate = StepDate.AddMonths(14);
                            ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "Typhoid - Booster dose", StepDate.Date, nulldt, lblID.Text);
                        }
                        else
                            ds.Tables[0].Rows.Add((ds.Tables[0].Rows.Count + 1).ToString(), (FluCount - 2).ToString() + " Years", "Typhoid - " + StepDate.Year.ToString(), StepDate.Date, nulldt, lblID.Text);
                        StepTyphoid = 10;
                    }
                    FluCount++;
                    if (StepTyphoid == 0) StepTyphoid = StepTyphoid + 3;
                    StepDate = StepDate.AddYears((StepTyphoid));
                }
            }
            else TyphoidFirstDose.Enabled = false;
            TypoidChartGrid.DataSource = ds.Tables[0];
            TypoidChartGrid.Columns[5].Visible = false;
            TypoidChartGrid.Columns[1].Visible = false;
            TypoidChartGrid.Columns[0].Visible = false;
        }

        public string GetAgeID(string Age)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Age_ID]
  FROM [Age] A where A.Age= '" + Age + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineID(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Vaccine_ID]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineGap(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VaccineGap]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineAgeLimit(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VaccineAgeLimit]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        private void SaveTyphoidMathod(string PatiantID, string Vaccine, string Age, string DueDate, string GDate,string RDate)
        {
            //string VaccineID = GetVaccineID(Vaccine);
            //string AgeID = GetAgeID(Age);
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("SAVE_TYPHOID_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@vaccine", Vaccine);
                cmd.Parameters.AddWithValue("@Age", Age);
                cmd.Parameters.AddWithValue("@PatiantID", PatiantID);
                if (DueDate != "")
                    cmd.Parameters.AddWithValue("@DueDate", Convert.ToDateTime(DueDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@DueDate", SqlDbType.DateTime).Value = dt; }
                if (GDate != "")
                    cmd.Parameters.AddWithValue("@GivenDate", Convert.ToDateTime(GDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@GivenDate", SqlDbType.DateTime).Value = dt; }
                if (RDate != "")
                    cmd.Parameters.AddWithValue("@RDate", Convert.ToDateTime(RDate));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@RDate", SqlDbType.DateTime).Value = dt; }
                cmd.ExecuteNonQuery();

            }
        }

        void LoadGridContent(DataGridViewEditingControlShowingEventArgs e, string query, string ColName)
        {
            SqlDataReader dreader;
            SqlConnection conn = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            AutoCompleteStringCollection AgeSource = new AutoCompleteStringCollection();
            cmd.CommandText = query;
            conn.Open();
            dreader = cmd.ExecuteReader();
            if (dreader.HasRows == true)
                while (dreader.Read())
                    AgeSource.Add(dreader[ColName].ToString());
            dreader.Close();
            TextBox Medicine = e.Control as TextBox;
            //  Medicine.TextChanged += new EventHandler(Age_TextChanged);
            if (Medicine != null)
            {
                Medicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                Medicine.AutoCompleteCustomSource = AgeSource;
                Medicine.AutoCompleteSource = AutoCompleteSource.CustomSource;

            }
        }

        private void NewVaccineChart_Load(object sender, EventArgs e)
        {
            string iDate = DOB.ToString();
            DateTime oDate = Convert.ToDateTime(iDate);
            lblDOB.Text = oDate.Day.ToString("00") + "/" + oDate.Month + "/" + oDate.Year;
            lblName.Text = Name; lblID.Text = Id; LblGender.Text = Gender;
            LoadFluGrid(); LoadTyphoidGrid();
        }

        private void ChangeColorCell(DataGridViewCell dc, Color FColor, Color BColor)
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.BackColor = BColor;
            style.ForeColor = FColor;
            dc.Style = style;
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in FluChartGrid.Rows)
            {
                string Vaccine = (dr.Cells[2].Value.ToString().Trim());
                string Age = (dr.Cells[1].Value.ToString().Trim());
                string VCDate = dr.Cells[3].Value.ToString();
                string GDate = dr.Cells[4].Value.ToString();
                string RDate = dr.Cells[6].Value.ToString();
                SaveFluMathod(lblID.Text, Vaccine, Age, VCDate, GDate,RDate);
            }
            foreach (DataGridViewRow dr in TypoidChartGrid.Rows)
            {
                string Vaccine = (dr.Cells[2].Value.ToString().Trim());
                string Age = (dr.Cells[1].Value.ToString().Trim());
                string VCDate = dr.Cells[3].Value.ToString();
                string GDate = dr.Cells[4].Value.ToString();
                string RDate = dr.Cells[6].Value.ToString();
                SaveTyphoidMathod(lblID.Text, Vaccine, Age, VCDate, GDate,RDate);
            }
            frmFluVaccineReortViewer viewer = new frmFluVaccineReortViewer(Convert.ToDateTime(lblDOB.Text), lblID.Text, lblName.Text);
            //viewer.DOB=Convert.ToDateTime(DOB);
            //viewer.PatientID = lblID.Text;
            viewer.MinimizeBox = true;
            if (DialogResult.Yes == MessageBox.Show("Do you want to print using Printer? ", "S V Medical Center", MessageBoxButtons.YesNo))
                viewer.IsDirectPrint = true;
            else
                viewer.IsDirectPrint = false;
            viewer.Show();
            this.Close();
        }

        public string GetGovernment(string Vaccine)
        {
            string _return = string.Empty;
            string VaccineID = GetVaccineID(Vaccine);
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VC_Government]
  FROM [VC_Std] A where A.VC_Vaccine= '" + VaccineID + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        private void checkRegular_CheckedChanged(object sender, EventArgs e)
        {
            chechtyphoid.Checked = !checkRegular.Checked; LoadTyphoidGrid();
        }

        private void chechtyphoid_CheckedChanged(object sender, EventArgs e)
        {
            checkRegular.Checked = !chechtyphoid.Checked; LoadTyphoidGrid();
        }

        private void TyphoidFirstDose_ValueChanged(object sender, EventArgs e)
        {
            LoadTyphoidGrid();
        }

        private void FluFirstDose_ValueChanged(object sender, EventArgs e)
        {
            LoadFluGrid();
        }

        private void btnFluReset_Click(object sender, EventArgs e)
        {
            DeleteFluGrid("FluTrans");
            FluFirstDose.Enabled = true;
            LoadFluGrid();
        }

        private void DeleteFluGrid(string TableName)
        {
            using (con)
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("delete [" + TableName + "] where PatiantID ='" + lblID.Text + "'", con);
                cmd.ExecuteNonQuery();

            }
        }

        private void btntyphoidReset_Click(object sender, EventArgs e)
        {
            DeleteFluGrid("TyphoidTrans");
            TyphoidFirstDose.Enabled = true;
            LoadTyphoidGrid();
        }
    }
}
