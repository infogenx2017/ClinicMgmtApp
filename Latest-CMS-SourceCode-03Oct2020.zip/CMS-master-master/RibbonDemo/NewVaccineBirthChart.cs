﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewVaccineBirthChart : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null; string DOB = string.Empty; string Name = string.Empty; string Id = string.Empty; string Gender = string.Empty;
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public bool isGovernment = false;
        public string GivenPlace = string.Empty;
        public DateTimePicker oDateTimePicker = new DateTimePicker(); public bool isCellChanged = false; DataGridViewTextBoxEditingControl tb = null;
        public NewPrescription ObjPrescription = null; string CurrentDayVaccine = string.Empty; string NextVaccine = string.Empty; string NextVaccineDueDate = string.Empty; string PendingVaccine = string.Empty;
        public NewVaccineBirthChart(NewPrescription _ObjPrescription, string _DOB, string _Name, string _Id, string _Gender)
        {
            InitializeComponent();
            DOB = _DOB; Name = _Name; Id = _Id; Gender = _Gender; ObjPrescription = _ObjPrescription;
        }

        void LoadGrid()
        {
            try
            {
                using (con)
                {
                    DataSet ds = new DataSet();
                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                    SqlCommand cmd = new SqlCommand("VBC_SP", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(DOB));
                    cmd.Parameters.AddWithValue("@P_ID", (Id));
                    cmd.Parameters.AddWithValue("@P_Name", (Name));
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    VaccineChartGrid.DataSource = ds.Tables[0];

                }
                LoadPending();
                LoadSerial();
            }
            catch (Exception)
            {

                
            }
         
        }

        public string GetAgeID(string Age)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Age_ID]
  FROM [Age] A where A.Age= '" + Age + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineID(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [Vaccine_ID]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineGap(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VaccineGap]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        public string GetVaccineAgeLimit(string Vaccine)
        {
            string _return = string.Empty;
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VaccineAgeLimit]
  FROM [Vaccine] A where A.Vaccine= '" + Vaccine + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        private void SaveMathod(string PatiantID, string Vaccine, string Age, string VCDate, string Remark, string MDOB, string GDOB, string Status)
        {
            //string VaccineID = GetVaccineID(Vaccine);
            //string AgeID = GetAgeID(Age);
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();

                SqlCommand cmd = new SqlCommand("SAVE_VBC_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@vaccineID", Convert.ToInt32(Vaccine));
                cmd.Parameters.AddWithValue("@AgeID", Convert.ToInt32(Age));
                cmd.Parameters.AddWithValue("@PatiantID", PatiantID);
                cmd.Parameters.AddWithValue("@Remark", (Remark));
                if (MDOB != "")
                    cmd.Parameters.AddWithValue("@ModifiedDueDate", Convert.ToDateTime(MDOB));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@ModifiedDueDate", SqlDbType.DateTime).Value = dt; }
                if (GDOB != "")
                    cmd.Parameters.AddWithValue("@GivenDate", Convert.ToDateTime(GDOB));
                else
                { DateTime? dt = null; cmd.Parameters.Add("@GivenDate", SqlDbType.DateTime).Value = dt; }
                cmd.Parameters.AddWithValue("@Status", (Status)); cmd.ExecuteNonQuery();

            }
        }

        private void LoadPending()
        {
            // Pending
        }

        void LoadGridContent(DataGridViewEditingControlShowingEventArgs e, string query, string ColName)
        {
            SqlDataReader dreader;
            SqlConnection conn = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.Text;
            AutoCompleteStringCollection AgeSource = new AutoCompleteStringCollection();
            cmd.CommandText = query;
            conn.Open();
            dreader = cmd.ExecuteReader();
            if (dreader.HasRows == true)
                while (dreader.Read())
                    AgeSource.Add(dreader[ColName].ToString());
            dreader.Close();
            TextBox Medicine = e.Control as TextBox;
            //  Medicine.TextChanged += new EventHandler(Age_TextChanged);
            if (Medicine != null)
            {
                Medicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                Medicine.AutoCompleteCustomSource = AgeSource;
                Medicine.AutoCompleteSource = AutoCompleteSource.CustomSource;

            }
        }

        private void NewVaccineChart_Load(object sender, EventArgs e)
        {
            string iDate = DOB.ToString();
            DateTime oDate = Convert.ToDateTime(iDate);
            lblDOB.Text = oDate.Day.ToString("00") + "/" + oDate.Month + "/" + oDate.Year;
            lblName.Text = Name; lblID.Text = Id; LblGender.Text = Gender;
            LoadGrid();
            dataGridView1_CellClick(null, null);
            //   txtvaccine.Focus();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int Rowidx = 0;
                if (e != null) Rowidx = e.RowIndex != -1 ? e.RowIndex : 0;
                clear();
                int rowIndex = VaccineChartGrid.Rows[Rowidx].Index;
                VaccineChartGrid.Rows[Rowidx].Cells[0].Selected = true;

                if (VaccineChartGrid == null)
                    return;
                if (VaccineChartGrid.Rows[Rowidx].Cells[0].Selected == true)
                    if (Convert.ToString(VaccineChartGrid.Rows[Rowidx].Cells[0].Value) != String.Empty)
                        VaccineChartGrid.Rows[VaccineChartGrid.Rows.Count - 1].Cells[0].Value = VaccineChartGrid.Rows.Count.ToString();
            }
            catch (Exception)
            {

               
            }
     



        }

        private void ChangeColorCell(DataGridViewCell dc, Color FColor, Color BColor)
        {
            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.BackColor = BColor;
            style.ForeColor = FColor;
            dc.Style = style;
        }

        private void dateTimePicker_OnTextChange(object sender, EventArgs e)
        {
            if (oDateTimePicker.Text != "")
                // Saving the 'Selected Date on Calendar' into DataGridView current cell  
                VaccineChartGrid.CurrentCell.Value = oDateTimePicker.Text.ToString();
        }

        void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
            // Hiding the control after use   
            oDateTimePicker.Visible = false;

        }

        private void clear()
        {
            lblRowID.Text = "";

        }

        private void LoadSerial()
        {
            //int i = 1;
            //foreach (DataGridViewRow row in VaccineChartGrid.Rows)
            //{
            //    row.Cells[0].Value = i; i++;
            //    row.Cells[0].ReadOnly = true;
            //}
        }

        private void VaccineChartGrid_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (VaccineChartGrid.CurrentCell.ColumnIndex == 1)
            //    LoadGridContent(e, @"Select Age from Age order by Age_ID asc", "Age");
            //else if (VaccineChartGrid.CurrentCell.ColumnIndex == 2)
            //    LoadGridContent(e, @"Select Vaccine from Vaccine order by Vaccine_ID asc", "Vaccine");
            //else 
            if (VaccineChartGrid.CurrentCell.ColumnIndex == 7)
                LoadGridContent(e, @"Select distinct Remark from VCD", "Remark");
            if (VaccineChartGrid.CurrentCell.ColumnIndex == 4)
            {
                AutoCompleteStringCollection AgeSource = new AutoCompleteStringCollection();

                AgeSource.Add("Pending");
                AgeSource.Add("Given");
                AgeSource.Add("Given today");
                AgeSource.Add("Rescheduled");
                AgeSource.Add("Not known");
                AgeSource.Add("Not given");

                TextBox Medicine = e.Control as TextBox;
                //  Medicine.TextChanged += new EventHandler(Age_TextChanged);
                if (Medicine != null)
                {
                    Medicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    Medicine.AutoCompleteCustomSource = AgeSource;
                    Medicine.AutoCompleteSource = AutoCompleteSource.CustomSource;

                }
            }
            if (tb == null)
            {
                tb = (DataGridViewTextBoxEditingControl)e.Control;
                tb.KeyDown += new KeyEventHandler(dataGridViewTextBox_KeyDown);
            }

        }

        private void dataGridViewTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            int Rowidx = 0; int colIndex = 0;
            if (VaccineChartGrid.CurrentCell != null)
            {
                Rowidx = VaccineChartGrid.CurrentCell.RowIndex != -1 ? VaccineChartGrid.CurrentCell.RowIndex : 0;
                colIndex = VaccineChartGrid.CurrentCell.ColumnIndex != -1 ? VaccineChartGrid.CurrentCell.ColumnIndex : 0;
            }
            if (e.KeyCode == Keys.F5 && (colIndex == 5 || colIndex == 6 || colIndex == 7))
            {
                int StepRowIndex = VaccineChartGrid.CurrentCell.RowIndex; int StepRowIndexPlus = StepRowIndex + 1;
                while (VaccineChartGrid.Rows[VaccineChartGrid.CurrentCell.RowIndex].Cells[4].Value.ToString() != VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString() && VaccineChartGrid.Rows.Count != StepRowIndex)
                {
                    StepRowIndex++; StepRowIndexPlus++;
                }
                VaccineChartGrid.CurrentCell = VaccineChartGrid.Rows[StepRowIndexPlus].Cells[colIndex];
                VaccineChartGrid.Refresh(); //VaccineChartGrid.RefreshEdit();
                e.Handled = true;
            }
        }

        private void VaccineChartGrid_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VaccineChartGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            LoadSerial();
        }

        private void VaccineChartGrid_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            LoadSerial();
        }

        private void VaccineChartGrid_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!isCellChanged)
            {
                int CurrentRowIndex = VaccineChartGrid.CurrentCell.RowIndex;
                int CurrentColumnIndex = VaccineChartGrid.CurrentCell.ColumnIndex;
                if (CurrentColumnIndex == 4)
                {
                    if (VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "GIVEN TODAY" ||
                        VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "GIVEN" ||
                        VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "PENDING")//||
                    //     VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "RESCHEDULED")
                    {
                        if (VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "GIVEN TODAY")
                        {
                            VaccineChartGrid.Rows[CurrentRowIndex].Cells[5].Value = Convert.ToDateTime(DateTime.Now.Date);
                            // CurrentDayVaccine = CurrentDayVaccine + VaccineChartGrid.Rows[CurrentRowIndex].Cells[2].Value.ToString() + ", ";
                        }
                        if (VaccineChartGrid.Rows[CurrentRowIndex].Cells[1].Value.ToString().ToUpper() != VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[1].Value.ToString().ToUpper() && VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "GIVEN TODAY")
                        {
                            int StepRowIndex = CurrentRowIndex + 1; int StepRowIndexPlus = CurrentRowIndex + 2;
                            while (VaccineChartGrid.Rows[StepRowIndex].Cells[1].Value.ToString().ToUpper() == VaccineChartGrid.Rows[StepRowIndexPlus].Cells[1].Value.ToString().ToUpper())
                            {
                                isCellChanged = true;
                                string Vaci = GetVaccineGap(VaccineChartGrid.Rows[CurrentRowIndex].Cells[2].Value.ToString());

                                DateTime DOBDueDate_date = Convert.ToDateTime(VaccineChartGrid.Rows[StepRowIndexPlus].Cells[3].Value.ToString());
                                NextVaccineDueDate = Convert.ToDateTime(VaccineChartGrid.Rows[CurrentRowIndex].Cells[3].Value.ToString()).AddDays(Convert.ToDouble(Vaci)).ToShortDateString();
                                DateTime NextVaccineDueDate_date = Convert.ToDateTime(NextVaccineDueDate);
                                if (DOBDueDate_date < NextVaccineDueDate_date)
                                {
                                    if (VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString() == "")
                                    {
                                        VaccineChartGrid.Rows[StepRowIndexPlus].Cells[6].Value = NextVaccineDueDate;
                                        VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value = "Rescheduled";
                                    }
                                }
                                else
                                {
                                    if (VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString() == "")
                                    {
                                        VaccineChartGrid.Rows[StepRowIndexPlus].Cells[6].Value = VaccineChartGrid.Rows[StepRowIndexPlus].Cells[3].Value.ToString();
                                    }
                                }

                                StepRowIndex++; StepRowIndexPlus++;
                                isCellChanged = false;
                            }
                            isCellChanged = true;
                            if (NextVaccineDueDate != "")
                            {
                                DateTime NextVaccineDue_date = Convert.ToDateTime(NextVaccineDueDate);
                                DateTime DOBDuedate = Convert.ToDateTime(VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[3].Value.ToString());
                                if (DOBDuedate < NextVaccineDue_date)
                                {
                                    if (VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[4].Value.ToString() == "")
                                    {
                                        VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[4].Value = "Rescheduled";
                                        VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[6].Value = NextVaccineDueDate;
                                    }
                                }
                                //else
                                //{
                                //    if (VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[4].Value.ToString() == "")
                                //    {
                                //        VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[6].Value = VaccineChartGrid.Rows[CurrentRowIndex + 1].Cells[3].Value.ToString();
                                //    }
                                //}
                            }
                            isCellChanged = false;
                        }
                        else
                        {
                            int StepRowIndex = CurrentRowIndex; int StepRowIndexPlus = CurrentRowIndex + 1;
                            while (VaccineChartGrid.Rows[StepRowIndex].Cells[1].Value.ToString().ToUpper() == VaccineChartGrid.Rows[StepRowIndexPlus].Cells[1].Value.ToString().ToUpper())
                            {
                                if (VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString().ToUpper() == "GIVEN TODAY")
                                {
                                    VaccineChartGrid.Rows[StepRowIndexPlus].Cells[5].Value = Convert.ToDateTime(DateTime.Now.Date);
                                }
                                if (VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString() == "")
                                    VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value = VaccineChartGrid.Rows[StepRowIndex].Cells[4].Value.ToString();
                                StepRowIndex++; StepRowIndexPlus++;
                            }
                        }
                    }
                    if (VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "PENDING" ||
                       VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "NOT KNOWN" ||
                       VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "NOT GIVEN" ||
                        VaccineChartGrid.Rows[CurrentRowIndex].Cells[4].Value.ToString().ToUpper() == "RESCHEDULED")
                    {
                        VaccineChartGrid.Rows[CurrentRowIndex].Cells[7].Value = "";
                    }
                }
            }
            foreach (DataGridViewRow dr in VaccineChartGrid.Rows)
            {
                if (dr.Cells[4].Value.ToString().ToUpper() == "PENDING")
                    ChangeColorCell(dr.Cells[4], Color.DarkRed, Color.LightPink);
                else if (dr.Cells[4].Value.ToString().ToUpper() == "GIVEN" || dr.Cells[4].Value.ToString().ToUpper() == "GIVEN TODAT")
                    ChangeColorCell(dr.Cells[4], Color.DarkGreen, Color.LightGreen);
                else if (dr.Cells[4].Value.ToString().ToUpper() == "RESCHEDULED")
                    ChangeColorCell(dr.Cells[4], Color.DarkBlue, Color.LightSkyBlue);
                else
                    ChangeColorCell(dr.Cells[4], Color.Black, Color.White);
            }
        }

        private void VaccineChartGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void VaccineChartGrid_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void VaccineChartGrid_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void VaccineChartGrid_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e != null && e.Button == MouseButtons.Right)
                if (e.ColumnIndex == 4 || e.ColumnIndex == 6)
                {
                    //Initialized a new DateTimePicker Control  
                    oDateTimePicker = new DateTimePicker();

                    //Adding DateTimePicker control into DataGridView   
                    VaccineChartGrid.Controls.Add(oDateTimePicker);

                    // Setting the format (i.e. 2014-10-10)  
                    oDateTimePicker.Format = DateTimePickerFormat.Short;

                    // It returns the retangular area that represents the Display area for a cell  
                    Rectangle oRectangle = VaccineChartGrid.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);

                    //Setting area for DateTimePicker Control  
                    oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);

                    // Setting Location  
                    oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);

                    // An event attached to dateTimePicker Control which is fired when DateTimeControl is closed  
                    oDateTimePicker.CloseUp += new EventHandler(oDateTimePicker_CloseUp);

                    // An event attached to dateTimePicker Control which is fired when any date is selected  
                    oDateTimePicker.TextChanged += new EventHandler(dateTimePicker_OnTextChange);

                    // Now make it visible  
                    oDateTimePicker.Visible = true;
                }
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            frmVaccineReortViewer viewer = new frmVaccineReortViewer(Convert.ToDateTime(lblDOB.Text), lblID.Text, lblName.Text);
            //viewer.DOB=Convert.ToDateTime(DOB);
            //viewer.PatientID = lblID.Text;
            viewer.MinimizeBox = true;
            if (DialogResult.Yes == MessageBox.Show("Do you want to print using Printer? ", "S V Medical Center", MessageBoxButtons.YesNo))
                viewer.IsDirectPrint = true;
            else
                viewer.IsDirectPrint = false;
            viewer.Show();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in VaccineChartGrid.Rows)
            {
                if (dr.Cells[4].Value.ToString() != "" || dr.Cells[5].Value.ToString() != "" || dr.Cells[6].Value.ToString() != "")
                {
                    string ID = dr.Cells[0].Value.ToString();
                    string Vaccine = GetVaccineID(dr.Cells[2].Value.ToString().Trim());
                    string Age = GetAgeID(dr.Cells[1].Value.ToString().Trim());
                    string VCDate = dr.Cells[3].Value.ToString();
                    string MDate = dr.Cells[6].Value.ToString();
                    string GDate = dr.Cells[5].Value.ToString();
                    string Status = dr.Cells[4].Value.ToString();
                    string Remark = dr.Cells[7].Value.ToString();
                    SaveMathod(lblID.Text, Vaccine, Age, VCDate, Remark, MDate, GDate, Status);
                    if (Status.ToUpper() == "PENDING")
                    {
                        if (PendingVaccine == "") PendingVaccine = dr.Cells[2].Value.ToString().Trim();
                        else PendingVaccine = (PendingVaccine + "," + dr.Cells[2].Value.ToString().Trim());
                    }
                    if (Status.ToUpper() == "GIVEN TODAY")
                    {
                        if (CurrentDayVaccine == "") CurrentDayVaccine = dr.Cells[2].Value.ToString().Trim();
                        else CurrentDayVaccine = (CurrentDayVaccine + "," + dr.Cells[2].Value.ToString().Trim());
                    }
                    if (Status.ToUpper() == "RESCHEDULED" || MDate != "")
                    {
                        if (NextVaccineDueDate == "")
                        {
                            if (NextVaccine == "") NextVaccine = dr.Cells[2].Value.ToString().Trim();
                            else NextVaccine = (NextVaccine + "," + dr.Cells[2].Value.ToString().Trim());
                            NextVaccineDueDate = Convert.ToDateTime(MDate).ToShortDateString();
                        }
                        else if (Convert.ToDateTime(MDate) <= Convert.ToDateTime(NextVaccineDueDate))
                        {
                            if (NextVaccine == "") NextVaccine = dr.Cells[2].Value.ToString().Trim();
                            else NextVaccine = (NextVaccine + "," + dr.Cells[2].Value.ToString().Trim());
                            NextVaccineDueDate = Convert.ToDateTime(MDate).ToShortDateString();
                        }
                    }
                }
                if (dr.Cells[4].Value.ToString() == "" && dr.Cells[5].Value.ToString() == "")
                {
                    if (NextVaccineDueDate == "")
                    {
                        int StepRowIndex = dr.Index; int StepRowIndexPlus = StepRowIndex + 1;
                        NextVaccine = VaccineChartGrid.Rows[StepRowIndex].Cells[2].Value.ToString().Trim();
                        NextVaccineDueDate = Convert.ToDateTime(VaccineChartGrid.Rows[StepRowIndex].Cells[3].Value.ToString()).ToShortDateString();
                        while (VaccineChartGrid.Rows[StepRowIndex].Cells[1].Value.ToString().ToUpper() == VaccineChartGrid.Rows[StepRowIndexPlus].Cells[1].Value.ToString().ToUpper())
                        {
                            if (NextVaccineDueDate != "")
                                if (Convert.ToDateTime(NextVaccineDueDate) <= Convert.ToDateTime(VaccineChartGrid.Rows[dr.Index].Cells[3].Value.ToString()))
                                {
                                    string MDate = dr.Cells[6].Value.ToString();
                                    NextVaccine = (NextVaccine + "," + VaccineChartGrid.Rows[StepRowIndexPlus].Cells[2].Value.ToString().Trim()); //NextVaccine = NextVaccine + VaccineChartGrid.Rows[StepRowIndexPlus].Cells[2].Value.ToString() + ", ";
                                    NextVaccineDueDate = Convert.ToDateTime(VaccineChartGrid.Rows[StepRowIndexPlus].Cells[3].Value.ToString()).ToShortDateString();
                                    StepRowIndex++; StepRowIndexPlus++;
                                    if (StepRowIndexPlus == VaccineChartGrid.Rows.Count)
                                        break;
                                }
                        } break;
                    }
                }

            }
            MessageBox.Show("Saved Successfully");
            TransferVaccinedetails _TransferVaccinedetails = new TransferVaccinedetails(ObjPrescription, CurrentDayVaccine, NextVaccine, NextVaccineDueDate, PendingVaccine);
            _TransferVaccinedetails.Show();
            this.Close();
        }

        private void VaccineChartGrid_EditModeChanged(object sender, EventArgs e)
        {

        }

        private void VaccineChartGrid_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (VaccineChartGrid.CurrentCell.ColumnIndex == 6)
            {
                VaccineChartGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void txtfullyvaccinater_Click(object sender, EventArgs e)
        {
            FullyVaccinatedtillDate _FullyVaccinatedtillDate = new FullyVaccinatedtillDate(this);
            _FullyVaccinatedtillDate.ShowDialog();
            int _Age = Convert.ToDateTime(DateTime.Now.Date.ToShortDateString()).Subtract(Convert.ToDateTime(DOB)).Days;

            int StepRowIndex = 0;
            if(VaccineChartGrid.Rows.Count>0)
            while (Convert.ToDateTime(VaccineChartGrid.Rows[StepRowIndex].Cells[3].Value.ToString()) <= Convert.ToDateTime(DateTime.Now.Date) && VaccineChartGrid.Rows.Count != StepRowIndex)
            {
                if (isGovernment)
                {
                    if (GetGovernment(VaccineChartGrid.Rows[StepRowIndex].Cells[2].Value.ToString()) == "1")
                    {
                        VaccineChartGrid.Rows[StepRowIndex].Cells[4].Value = "Given";
                        VaccineChartGrid.Rows[StepRowIndex].Cells[7].Value = GivenPlace;
                    }
                    else
                    {
                        string _VaccineAgeLimit = GetVaccineAgeLimit(VaccineChartGrid.Rows[StepRowIndex].Cells[2].Value.ToString());
                        if (_Age <= Convert.ToInt32(_VaccineAgeLimit))
                            VaccineChartGrid.Rows[StepRowIndex].Cells[4].Value = "Pending";
                        else
                            VaccineChartGrid.Rows[StepRowIndex].Cells[4].Value = "Not given";
                    }
                }
                else
                {
                    VaccineChartGrid.Rows[StepRowIndex].Cells[4].Value = "Given";
                    VaccineChartGrid.Rows[StepRowIndex].Cells[7].Value = GivenPlace;
                }
                StepRowIndex++;
                if (VaccineChartGrid.Rows.Count == StepRowIndex) break;

            }
            foreach (DataGridViewRow dr in VaccineChartGrid.Rows)
            {
                if (dr.Cells[4].Value.ToString().ToUpper() == "PENDING")
                    ChangeColorCell(dr.Cells[4], Color.DarkRed, Color.LightPink);
                else if (dr.Cells[4].Value.ToString().ToUpper() == "GIVEN" || dr.Cells[4].Value.ToString().ToUpper() == "GIVEN TODAT")
                    ChangeColorCell(dr.Cells[4], Color.DarkGreen, Color.LightGreen);
                else if (dr.Cells[4].Value.ToString().ToUpper() == "RESCHEDULED")
                    ChangeColorCell(dr.Cells[4], Color.DarkBlue, Color.LightSkyBlue);
                else
                    ChangeColorCell(dr.Cells[4], Color.Black, Color.White);
            }
        }

        public string GetGovernment(string Vaccine)
        {
            string _return = string.Empty;
            string VaccineID = GetVaccineID(Vaccine);
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"SELECT  [VC_Government]
  FROM [VC_Std] A where A.VC_Vaccine= '" + VaccineID + @"'";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                    _return = ds.Tables[0].Rows[0][0].ToString();
                con.Close();
            }

            return _return;
        }

        private void VaccineChartGrid_KeyDown(object sender, KeyEventArgs e)
        {
            int Rowidx = 0; int colIndex = 0;
            if (VaccineChartGrid.CurrentCell != null)
            {
                Rowidx = VaccineChartGrid.CurrentCell.RowIndex != -1 ? VaccineChartGrid.CurrentCell.RowIndex : 0;
                colIndex = VaccineChartGrid.CurrentCell.ColumnIndex != -1 ? VaccineChartGrid.CurrentCell.ColumnIndex : 0;
            }
            if (e.KeyCode == Keys.F5 && (colIndex == 5 || colIndex == 6 || colIndex == 7))
            {
                int StepRowIndex = VaccineChartGrid.CurrentCell.RowIndex; int StepRowIndexPlus = StepRowIndex + 1;
                while (VaccineChartGrid.Rows[VaccineChartGrid.CurrentCell.RowIndex].Cells[4].Value.ToString() != VaccineChartGrid.Rows[StepRowIndexPlus].Cells[4].Value.ToString() && VaccineChartGrid.Rows.Count != StepRowIndex)
                {
                    StepRowIndex++; StepRowIndexPlus++;
                }
                VaccineChartGrid.CurrentCell = VaccineChartGrid.Rows[StepRowIndexPlus].Cells[colIndex];
                VaccineChartGrid.Refresh(); //VaccineChartGrid.RefreshEdit();
                e.Handled = true;
            }
        }

        private void btnFlu_Click(object sender, EventArgs e)
        {
            NewFluVaccineBirthChart _flu = new NewFluVaccineBirthChart(ObjPrescription, DOB, Name, Id, Gender);
            _flu.Show();
        }

        private void btnRabies_Click(object sender, EventArgs e)
        {
            NewAntiRabiesVaccination _rabies = new NewAntiRabiesVaccination(ObjPrescription, DOB, Name, Id, Gender);
            _rabies.Show();
        }

    }
}
