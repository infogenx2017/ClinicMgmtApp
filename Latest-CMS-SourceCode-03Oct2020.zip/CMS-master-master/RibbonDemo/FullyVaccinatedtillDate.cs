﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class FullyVaccinatedtillDate : MetroFramework.Forms.MetroForm
    {
        NewVaccineBirthChart ObjNewVaccineBirthChart = null; string NextVaccineDueDate = string.Empty; string PendingVaccine = string.Empty;
        public FullyVaccinatedtillDate(NewVaccineBirthChart _ObjNewVaccineBirthChart)
        {
            InitializeComponent(); ObjNewVaccineBirthChart = _ObjNewVaccineBirthChart; radioGvt.Checked = true;
        }

        private void btnokay_Click(object sender, EventArgs e)
        {
            ObjNewVaccineBirthChart.isGovernment = radioGvt.Checked; ObjNewVaccineBirthChart.GivenPlace = txtGivenPlace.Text;
            this.Close();
        }

        private void radioGvt_CheckedChanged(object sender, EventArgs e)
        {
            if (radioGvt.Checked)
                txtGivenPlace.Text = "@ G.H";
            else
                txtGivenPlace.Text = "@ ";
        }

    }
}
