﻿namespace SVMApplication
{
    partial class ViewCMSreport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlGridAppointmentList = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ctrlCbxStatus = new MetroFramework.Controls.MetroComboBox();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.ctrlChkToday = new MetroFramework.Controls.MetroCheckBox();
            this.ctrlChkAdvance = new MetroFramework.Controls.MetroCheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.ctrlDateEnd = new System.Windows.Forms.DateTimePicker();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.ctrlDateStart = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridAppointmentList)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Teal;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.52577F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.47423F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlGridAppointmentList, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 134F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(970, 502);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // ctrlGridAppointmentList
            // 
            this.ctrlGridAppointmentList.AllowUserToAddRows = false;
            this.ctrlGridAppointmentList.AllowUserToDeleteRows = false;
            this.ctrlGridAppointmentList.AllowUserToResizeColumns = false;
            this.ctrlGridAppointmentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridAppointmentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlGridAppointmentList, 2);
            this.ctrlGridAppointmentList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridAppointmentList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridAppointmentList.Location = new System.Drawing.Point(3, 137);
            this.ctrlGridAppointmentList.MultiSelect = false;
            this.ctrlGridAppointmentList.Name = "ctrlGridAppointmentList";
            this.ctrlGridAppointmentList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridAppointmentList.Size = new System.Drawing.Size(964, 310);
            this.ctrlGridAppointmentList.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ctrlCbxStatus);
            this.groupBox1.Controls.Add(this.metroButton2);
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.Controls.Add(this.ctrlChkToday);
            this.groupBox1.Controls.Add(this.ctrlChkAdvance);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Location = new System.Drawing.Point(304, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(663, 128);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Quick Serach";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(282, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Type Of Appointment :";
            // 
            // ctrlCbxStatus
            // 
            this.ctrlCbxStatus.FormattingEnabled = true;
            this.ctrlCbxStatus.ItemHeight = 23;
            this.ctrlCbxStatus.Location = new System.Drawing.Point(401, 16);
            this.ctrlCbxStatus.Name = "ctrlCbxStatus";
            this.ctrlCbxStatus.Size = new System.Drawing.Size(256, 29);
            this.ctrlCbxStatus.TabIndex = 6;
            this.ctrlCbxStatus.SelectedIndexChanged += new System.EventHandler(this.ctrlCbxStatus_SelectedIndexChanged);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(532, 86);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(125, 23);
            this.metroButton2.TabIndex = 5;
            this.metroButton2.Text = "Clear";
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(392, 86);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(125, 23);
            this.metroButton1.TabIndex = 4;
            this.metroButton1.Text = "Serach";
            this.metroButton1.Click += new System.EventHandler(this.ctrlBtnSearch_Click);
            // 
            // ctrlChkToday
            // 
            this.ctrlChkToday.AutoSize = true;
            this.ctrlChkToday.Checked = true;
            this.ctrlChkToday.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ctrlChkToday.Location = new System.Drawing.Point(17, 19);
            this.ctrlChkToday.Name = "ctrlChkToday";
            this.ctrlChkToday.Size = new System.Drawing.Size(55, 15);
            this.ctrlChkToday.TabIndex = 3;
            this.ctrlChkToday.Text = "Today";
            this.ctrlChkToday.UseVisualStyleBackColor = true;
            this.ctrlChkToday.CheckedChanged += new System.EventHandler(this.ctrlChkToday_CheckedChanged);
            // 
            // ctrlChkAdvance
            // 
            this.ctrlChkAdvance.AutoSize = true;
            this.ctrlChkAdvance.Location = new System.Drawing.Point(99, 19);
            this.ctrlChkAdvance.Name = "ctrlChkAdvance";
            this.ctrlChkAdvance.Size = new System.Drawing.Size(107, 15);
            this.ctrlChkAdvance.TabIndex = 0;
            this.ctrlChkAdvance.Text = "Advance Search";
            this.ctrlChkAdvance.UseVisualStyleBackColor = true;
            this.ctrlChkAdvance.CheckedChanged += new System.EventHandler(this.ctrlChkAdvance_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.metroLabel2);
            this.groupBox3.Controls.Add(this.ctrlDateEnd);
            this.groupBox3.Controls.Add(this.metroLabel1);
            this.groupBox3.Controls.Add(this.ctrlDateStart);
            this.groupBox3.Location = new System.Drawing.Point(17, 42);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(322, 80);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Date Search";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(180, 19);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(29, 19);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "To :";
            // 
            // ctrlDateEnd
            // 
            this.ctrlDateEnd.CustomFormat = "";
            this.ctrlDateEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ctrlDateEnd.Location = new System.Drawing.Point(170, 47);
            this.ctrlDateEnd.Name = "ctrlDateEnd";
            this.ctrlDateEnd.Size = new System.Drawing.Size(112, 20);
            this.ctrlDateEnd.TabIndex = 3;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(38, 19);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(48, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "From :";
            // 
            // ctrlDateStart
            // 
            this.ctrlDateStart.CustomFormat = "";
            this.ctrlDateStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ctrlDateStart.Location = new System.Drawing.Point(28, 47);
            this.ctrlDateStart.Name = "ctrlDateStart";
            this.ctrlDateStart.Size = new System.Drawing.Size(112, 20);
            this.ctrlDateStart.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.metroButton3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox2.Location = new System.Drawing.Point(618, 453);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(349, 46);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Report Generate";
            // 
            // metroButton3
            // 
            this.metroButton3.Highlight = true;
            this.metroButton3.Location = new System.Drawing.Point(45, 15);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(284, 23);
            this.metroButton3.TabIndex = 5;
            this.metroButton3.Text = "Generate Report";
            this.metroButton3.Click += new System.EventHandler(this.MetroButton3_Click);
            // 
            // ViewCMSreport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ViewCMSreport";
            this.Size = new System.Drawing.Size(970, 502);
            this.Load += new System.EventHandler(this.ViewPAyment_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridAppointmentList)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView ctrlGridAppointmentList;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroCheckBox ctrlChkAdvance;
        private System.Windows.Forms.GroupBox groupBox3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.DateTimePicker ctrlDateEnd;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.DateTimePicker ctrlDateStart;
        private MetroFramework.Controls.MetroCheckBox ctrlChkToday;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroComboBox ctrlCbxStatus;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroButton metroButton3;
    }
}
