﻿using SVMApplication.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmHospitalMaster : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
        public frmHospitalMaster()
        {
            InitializeComponent();
            this.TopMost = true;
        }

     
        private void frmHospitalMaster_Load(object sender, EventArgs e)
        {
            LoadGrid();
            HospitalGrid_CellClick(null, null);
            ctrlTxtName.Focus();
            
        }

        private void ctrlSaveBtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(ctrlTxtCode.Text) && !string.IsNullOrWhiteSpace(ctrlTxtName.Text) &&
                !string.IsNullOrWhiteSpace(ctrlTxtAddress.Text) && !string.IsNullOrWhiteSpace(ctrlTxtCity.Text))
            {
                if (CheckName())
                {
                    ctrlSaveBtn.Text = "Update";
                    MessageBox.Show("Hospital ID already exist");
                    return;
                }
                else
                {
                    SaveMathod();
                    MessageBox.Show("Saved Successfully");
                    LoadGrid();
                }
            }
            else
            {
                MessageBox.Show("Please Fill All Records");
            }
        }


        private void ctrlNewBtn_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void ctrlbtnDelete_Click(object sender, EventArgs e)
        {
            
            if (ctrlGridHospital.SelectedRows.Count>0)
            {
              var id= ctrlGridHospital.Rows[ctrlGridHospital.SelectedRows[0].Index].Cells[0].Value.ToString();

                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete from Hospital where Hospital_ID=@id", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(id));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    Clear();
                }

            }
            


        }

        private void ctrlBtnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HospitalGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;

            if (e != null) Rowidx = e.RowIndex;

            if (Rowidx < 0)
                return;

            Clear();
            
            int rowIndex = ctrlGridHospital.Rows[Rowidx].Index;
            ctrlGridHospital.Rows[Rowidx].Cells[0].Selected = true;

            if (ctrlGridHospital == null)
                return;
            if (ctrlGridHospital.Rows[Rowidx].Cells[0].Selected == true)
            {

                if (Convert.ToString(ctrlGridHospital.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {

                    
                    ctrlTxtCode.Text = ctrlGridHospital.Rows[Rowidx].Cells[1].Value.ToString();
                    ctrlTxtName.Text = ctrlGridHospital.Rows[Rowidx].Cells[2].Value.ToString();
                    ctrlTxtCity.Text = ctrlGridHospital.Rows[Rowidx].Cells[3].Value.ToString();
                    ctrlTxtAddress.Text = ctrlGridHospital.Rows[Rowidx].Cells[4].Value.ToString();

                    ctrlTxtContact.Text = ctrlGridHospital.Rows[Rowidx].Cells[6].Value.ToString();
                    ctrlTxtEmail.Text = ctrlGridHospital.Rows[Rowidx].Cells[7].Value.ToString();
                    ctrlTxtWebsite.Text = ctrlGridHospital.Rows[Rowidx].Cells[8].Value.ToString();

                    ctrlSaveBtn.Text = "Update";
                }
                else
                    Clear();
            }
            else
                Clear();
        }

        private void ctrlGridHospital_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            HospitalGrid_CellClick(sender, e);
        }

        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ((TextBox)sender).Focus();
            }
        }



        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string querry = @"select * from Hospital order by Hospital_ID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                ctrlGridHospital.DataSource = ds.Tables[0];
                UpdateMasterRowColor();
            }
        }

        private void UpdateMasterRowColor()
        {
            int rowIndex = -1;

            string searchValue = "1";
            DataGridViewRow row = ctrlGridHospital.Rows
                .Cast<DataGridViewRow>()
                .Where(r => r.Cells["Master"].Value.ToString().Equals(searchValue))
                .First();
            rowIndex = row.Index;
            if (rowIndex > -1)
            {
                var res = ctrlGridHospital.Rows[rowIndex];
                res.DefaultCellStyle.BackColor = Color.LightSeaGreen;
            }
        }

        private string SaveMathod()
        {

            using (con)
            {
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Sp_Hospital", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Code", ctrlTxtCode.Text);
                cmd.Parameters.AddWithValue("@Name", ctrlTxtName.Text);
                cmd.Parameters.AddWithValue("@City", ctrlTxtCity.Text);
                cmd.Parameters.AddWithValue("@Address", ctrlTxtAddress.Text);

                cmd.Parameters.AddWithValue("@Contact", ctrlTxtContact.Text);
                cmd.Parameters.AddWithValue("@Email", ctrlTxtEmail.Text);
                cmd.Parameters.AddWithValue("@Website", ctrlTxtWebsite.Text);

               

                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void Clear()
        {
            ctrlTxtCode.Text = "";
            ctrlTxtName.Text = "";
            ctrlTxtCity.Text = "";
            ctrlTxtAddress.Text = "";
            ctrlTxtContact.Text = "";
            ctrlTxtEmail.Text = "";
            ctrlTxtWebsite.Text = "";
            ctrlSaveBtn.Text = "Save";
        }

        private bool CheckName()
        {
            bool rtnval = false;
            try
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string querry = @"select * from Hospital where code=@code ";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@code", ctrlTxtCode);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rtnval = true;
                    ctrlTxtCode.Text = ds.Tables[0].Rows[0]["Code"].ToString();
                    ctrlTxtName.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    ctrlTxtCity.Text = ds.Tables[0].Rows[0]["City"].ToString();
                    ctrlTxtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();

                    ctrlTxtContact.Text= ds.Tables[0].Rows[0]["Contact_No"].ToString();
                    ctrlTxtEmail.Text = ds.Tables[0].Rows[0]["Email_ID"].ToString();
                    ctrlTxtWebsite.Text = ds.Tables[0].Rows[0]["Website"].ToString();
                }
            }
            catch { return false; }
            return rtnval;
        }

        private void ctrlBtnMaster_Click(object sender, EventArgs e)
        {

            if (ctrlGridHospital.SelectedRows.Count > 0)
            {
                var row = ctrlGridHospital.Rows[ctrlGridHospital.SelectedRows[0].Index];
              

                using (con)
                {
                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    var id = row.Cells["Hospital_Id"].Value.ToString();

                    SqlCommand cmd = new SqlCommand("SetMasterHospital_SP", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", Convert.ToInt32(id));
                    cmd.ExecuteNonQuery();
                    //var res = ctrlGridHospital.SelectedRows[0];
                    //res.DefaultCellStyle.BackColor = Color.LightBlue;
                    //AppMain.DoctorCode= row.Cells["Code"].Value.ToString();
                    AppMain.HospitalId = Convert.ToInt32(id);
                    AppMain.IsMasterChanged = true;
                    LoadGrid();
                }
                MessageBox.Show("Sucessfully Set as a Master");
                
            }
            else
                MessageBox.Show("Please select atlest one value");
        }

        private void ctrlGridHospital_DoubleClick(object sender, EventArgs e)
        {
            ctrlBtnMaster_Click(this, null);
        }
    }
}
