﻿namespace SVMApplication
{
    partial class DashboardView
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.chartViewer = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctrlTabMonthView = new MetroFramework.Controls.MetroTabControl();
            this.ctrpPageMonthView = new MetroFramework.Controls.MetroTabPage();
            this.CtrlTxtAdd = new MetroFramework.Controls.MetroButton();
            this.ctrlCalendarEvents = new Calendar.NET.Calendar();
            this.ctrlPageEventList = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.metroButton7 = new MetroFramework.Controls.MetroButton();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.ctrlGridEvents = new System.Windows.Forms.DataGridView();
            this.ctrlTabPageGeneral = new MetroFramework.Controls.MetroTabPage();
            this.ctrlGbxGeneral = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.ctrlBtnViewPayment = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.ctrlLbluser = new System.Windows.Forms.Label();
            this.ctrlLblHospitalName = new System.Windows.Forms.Label();
            this.ctrlBtnReport = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartViewer)).BeginInit();
            this.ctrlTabMonthView.SuspendLayout();
            this.ctrpPageMonthView.SuspendLayout();
            this.ctrlPageEventList.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridEvents)).BeginInit();
            this.ctrlTabPageGeneral.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.02956F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.97044F));
            this.tableLayoutPanel1.Controls.Add(this.chartViewer, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.ctrlTabMonthView, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.7774F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 76.2226F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1065, 593);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // chartViewer
            // 
            chartArea1.Name = "ChartArea1";
            this.chartViewer.ChartAreas.Add(chartArea1);
            this.chartViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chartViewer.Legends.Add(legend1);
            this.chartViewer.Location = new System.Drawing.Point(780, 3);
            this.chartViewer.Name = "chartViewer";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.Name = "PatientDetails";
            this.chartViewer.Series.Add(series1);
            this.chartViewer.Size = new System.Drawing.Size(282, 134);
            this.chartViewer.TabIndex = 1;
            this.chartViewer.Text = "chart1";
            // 
            // ctrlTabMonthView
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlTabMonthView, 2);
            this.ctrlTabMonthView.Controls.Add(this.ctrpPageMonthView);
            this.ctrlTabMonthView.Controls.Add(this.ctrlPageEventList);
            this.ctrlTabMonthView.Controls.Add(this.ctrlTabPageGeneral);
            this.ctrlTabMonthView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTabMonthView.HotTrack = true;
            this.ctrlTabMonthView.Location = new System.Drawing.Point(3, 143);
            this.ctrlTabMonthView.Name = "ctrlTabMonthView";
            this.ctrlTabMonthView.SelectedIndex = 0;
            this.ctrlTabMonthView.Size = new System.Drawing.Size(1059, 447);
            this.ctrlTabMonthView.TabIndex = 2;
            // 
            // ctrpPageMonthView
            // 
            this.ctrpPageMonthView.BackColor = System.Drawing.Color.Teal;
            this.ctrpPageMonthView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ctrpPageMonthView.Controls.Add(this.CtrlTxtAdd);
            this.ctrpPageMonthView.Controls.Add(this.ctrlCalendarEvents);
            this.ctrpPageMonthView.HorizontalScrollbarBarColor = true;
            this.ctrpPageMonthView.Location = new System.Drawing.Point(4, 35);
            this.ctrpPageMonthView.Name = "ctrpPageMonthView";
            this.ctrpPageMonthView.Padding = new System.Windows.Forms.Padding(2);
            this.ctrpPageMonthView.Size = new System.Drawing.Size(1051, 408);
            this.ctrpPageMonthView.TabIndex = 0;
            this.ctrpPageMonthView.Text = "Month View";
            this.ctrpPageMonthView.ToolTipText = "Month Events";
            this.ctrpPageMonthView.UseVisualStyleBackColor = true;
            this.ctrpPageMonthView.VerticalScrollbarBarColor = true;
            // 
            // CtrlTxtAdd
            // 
            this.CtrlTxtAdd.Location = new System.Drawing.Point(197, 18);
            this.CtrlTxtAdd.Name = "CtrlTxtAdd";
            this.CtrlTxtAdd.Size = new System.Drawing.Size(148, 23);
            this.CtrlTxtAdd.TabIndex = 3;
            this.CtrlTxtAdd.Text = "Add Event";
            this.CtrlTxtAdd.Click += new System.EventHandler(this.CtrlTxtAdd_Click);
            // 
            // ctrlCalendarEvents
            // 
            this.ctrlCalendarEvents.AllowEditingEvents = true;
            this.ctrlCalendarEvents.CalendarDate = new System.DateTime(2019, 1, 28, 22, 55, 51, 833);
            this.ctrlCalendarEvents.CalendarView = Calendar.NET.CalendarViews.Month;
            this.ctrlCalendarEvents.DateHeaderFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarEvents.DayOfWeekFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarEvents.DaysFont = new System.Drawing.Font("Arial", 10F);
            this.ctrlCalendarEvents.DayViewTimeFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.ctrlCalendarEvents.DimDisabledEvents = true;
            this.ctrlCalendarEvents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCalendarEvents.HighlightCurrentDay = true;
            this.ctrlCalendarEvents.LoadPresetHolidays = true;
            this.ctrlCalendarEvents.Location = new System.Drawing.Point(2, 2);
            this.ctrlCalendarEvents.Name = "ctrlCalendarEvents";
            this.ctrlCalendarEvents.ShowArrowControls = true;
            this.ctrlCalendarEvents.ShowDashedBorderOnDisabledEvents = true;
            this.ctrlCalendarEvents.ShowDateInHeader = true;
            this.ctrlCalendarEvents.ShowDisabledEvents = false;
            this.ctrlCalendarEvents.ShowEventTooltips = true;
            this.ctrlCalendarEvents.ShowTodayButton = true;
            this.ctrlCalendarEvents.Size = new System.Drawing.Size(1043, 400);
            this.ctrlCalendarEvents.TabIndex = 2;
            this.ctrlCalendarEvents.TodayFont = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            // 
            // ctrlPageEventList
            // 
            this.ctrlPageEventList.BackColor = System.Drawing.Color.Teal;
            this.ctrlPageEventList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ctrlPageEventList.Controls.Add(this.metroPanel3);
            this.ctrlPageEventList.HorizontalScrollbarBarColor = true;
            this.ctrlPageEventList.Location = new System.Drawing.Point(4, 35);
            this.ctrlPageEventList.Name = "ctrlPageEventList";
            this.ctrlPageEventList.Padding = new System.Windows.Forms.Padding(3);
            this.ctrlPageEventList.Size = new System.Drawing.Size(1051, 408);
            this.ctrlPageEventList.TabIndex = 1;
            this.ctrlPageEventList.Text = "Events Details";
            this.ctrlPageEventList.ToolTipText = "Event Data";
            this.ctrlPageEventList.VerticalScrollbarBarColor = true;
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.groupBox2);
            this.metroPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(3, 3);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(1041, 398);
            this.metroPanel3.TabIndex = 3;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tableLayoutPanel2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1041, 398);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 185F));
            this.tableLayoutPanel2.Controls.Add(this.metroPanel2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.ctrlGridEvents, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1035, 379);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.metroButton7);
            this.metroPanel2.Controls.Add(this.metroButton6);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(853, 335);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(179, 41);
            this.metroPanel2.TabIndex = 1;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // metroButton7
            // 
            this.metroButton7.Location = new System.Drawing.Point(13, 13);
            this.metroButton7.Name = "metroButton7";
            this.metroButton7.Size = new System.Drawing.Size(75, 23);
            this.metroButton7.TabIndex = 3;
            this.metroButton7.Text = "Delete";
            this.metroButton7.Click += new System.EventHandler(this.ctrlBtnDelet_Click);
            // 
            // metroButton6
            // 
            this.metroButton6.Location = new System.Drawing.Point(94, 13);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(75, 23);
            this.metroButton6.TabIndex = 2;
            this.metroButton6.Text = "Update";
            this.metroButton6.Click += new System.EventHandler(this.ctrlBtnUpdate_Click);
            // 
            // ctrlGridEvents
            // 
            this.ctrlGridEvents.AllowUserToAddRows = false;
            this.ctrlGridEvents.AllowUserToDeleteRows = false;
            this.ctrlGridEvents.AllowUserToResizeColumns = false;
            this.ctrlGridEvents.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel2.SetColumnSpan(this.ctrlGridEvents, 2);
            this.ctrlGridEvents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridEvents.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridEvents.Location = new System.Drawing.Point(3, 3);
            this.ctrlGridEvents.MultiSelect = false;
            this.ctrlGridEvents.Name = "ctrlGridEvents";
            this.ctrlGridEvents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridEvents.Size = new System.Drawing.Size(1029, 326);
            this.ctrlGridEvents.TabIndex = 0;
            // 
            // ctrlTabPageGeneral
            // 
            this.ctrlTabPageGeneral.Controls.Add(this.ctrlGbxGeneral);
            this.ctrlTabPageGeneral.HorizontalScrollbarBarColor = true;
            this.ctrlTabPageGeneral.Location = new System.Drawing.Point(4, 35);
            this.ctrlTabPageGeneral.Name = "ctrlTabPageGeneral";
            this.ctrlTabPageGeneral.Size = new System.Drawing.Size(1051, 408);
            this.ctrlTabPageGeneral.TabIndex = 2;
            this.ctrlTabPageGeneral.Text = "General";
            this.ctrlTabPageGeneral.VerticalScrollbarBarColor = true;
            // 
            // ctrlGbxGeneral
            // 
            this.ctrlGbxGeneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGbxGeneral.Location = new System.Drawing.Point(0, 0);
            this.ctrlGbxGeneral.Name = "ctrlGbxGeneral";
            this.ctrlGbxGeneral.Size = new System.Drawing.Size(1051, 408);
            this.ctrlGbxGeneral.TabIndex = 2;
            this.ctrlGbxGeneral.TabStop = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Teal;
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.ctrlBtnReport, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.metroButton2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.ctrlBtnViewPayment, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.2F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.8F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(771, 134);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // metroButton2
            // 
            this.metroButton2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroButton2.Highlight = true;
            this.metroButton2.Location = new System.Drawing.Point(3, 97);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(148, 25);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButton2.TabIndex = 1;
            this.metroButton2.Text = "Appoinment";
            this.metroButton2.Click += new System.EventHandler(this.ctrlBtnAppontmentKLis_Click);
            // 
            // ctrlBtnViewPayment
            // 
            this.ctrlBtnViewPayment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlBtnViewPayment.Highlight = true;
            this.ctrlBtnViewPayment.Location = new System.Drawing.Point(157, 97);
            this.ctrlBtnViewPayment.Name = "ctrlBtnViewPayment";
            this.ctrlBtnViewPayment.Size = new System.Drawing.Size(148, 25);
            this.ctrlBtnViewPayment.Style = MetroFramework.MetroColorStyle.Teal;
            this.ctrlBtnViewPayment.TabIndex = 2;
            this.ctrlBtnViewPayment.Text = "View Payments";
            this.ctrlBtnViewPayment.Click += new System.EventHandler(this.ctrlBtnViewPayment_Click);
            // 
            // groupBox1
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.groupBox1, 5);
            this.groupBox1.Controls.Add(this.metroTile1);
            this.groupBox1.Controls.Add(this.ctrlLbluser);
            this.groupBox1.Controls.Add(this.ctrlLblHospitalName);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(765, 88);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // metroTile1
            // 
            this.metroTile1.Dock = System.Windows.Forms.DockStyle.Right;
            this.metroTile1.Location = new System.Drawing.Point(667, 16);
            this.metroTile1.Margin = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(95, 69);
            this.metroTile1.TabIndex = 2;
            this.metroTile1.Text = "Logout";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.TileImage = global::SVMApplication.Properties.Resources.logout;
            this.metroTile1.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.TileTextFontSize = MetroFramework.MetroTileTextSize.Tall;
            this.metroTile1.Click += new System.EventHandler(this.CtrlTileLogout_Click);
            // 
            // ctrlLbluser
            // 
            this.ctrlLbluser.AutoSize = true;
            this.ctrlLbluser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlLbluser.ForeColor = System.Drawing.Color.White;
            this.ctrlLbluser.Location = new System.Drawing.Point(7, 46);
            this.ctrlLbluser.Name = "ctrlLbluser";
            this.ctrlLbluser.Size = new System.Drawing.Size(179, 25);
            this.ctrlLbluser.TabIndex = 1;
            this.ctrlLbluser.Text = "Venkatesh - OG";
            // 
            // ctrlLblHospitalName
            // 
            this.ctrlLblHospitalName.AutoSize = true;
            this.ctrlLblHospitalName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlLblHospitalName.ForeColor = System.Drawing.Color.White;
            this.ctrlLblHospitalName.Location = new System.Drawing.Point(6, 16);
            this.ctrlLblHospitalName.Name = "ctrlLblHospitalName";
            this.ctrlLblHospitalName.Size = new System.Drawing.Size(444, 25);
            this.ctrlLblHospitalName.TabIndex = 0;
            this.ctrlLblHospitalName.Text = "Sri Venkateshwara Hospital - Coimbatoor";
            // 
            // ctrlBtnReport
            // 
            this.ctrlBtnReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlBtnReport.Highlight = true;
            this.ctrlBtnReport.Location = new System.Drawing.Point(311, 97);
            this.ctrlBtnReport.Name = "ctrlBtnReport";
            this.ctrlBtnReport.Size = new System.Drawing.Size(148, 25);
            this.ctrlBtnReport.Style = MetroFramework.MetroColorStyle.Teal;
            this.ctrlBtnReport.TabIndex = 4;
            this.ctrlBtnReport.Text = "Report";
            this.ctrlBtnReport.Click += new System.EventHandler(this.CtrlBtnReport_Click);
            // 
            // DashboardView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "DashboardView";
            this.Size = new System.Drawing.Size(1065, 593);
            this.Load += new System.EventHandler(this.DashboardView_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartViewer)).EndInit();
            this.ctrlTabMonthView.ResumeLayout(false);
            this.ctrpPageMonthView.ResumeLayout(false);
            this.ctrlPageEventList.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.metroPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridEvents)).EndInit();
            this.ctrlTabPageGeneral.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartViewer;
        private MetroFramework.Controls.MetroTabControl ctrlTabMonthView;
        private MetroFramework.Controls.MetroTabPage ctrpPageMonthView;
        private Calendar.NET.Calendar ctrlCalendarEvents;
        private MetroFramework.Controls.MetroTabPage ctrlPageEventList;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private MetroFramework.Controls.MetroButton metroButton2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView ctrlGridEvents;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroButton metroButton7;
        private MetroFramework.Controls.MetroButton metroButton6;
        private MetroFramework.Controls.MetroButton CtrlTxtAdd;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroTabPage ctrlTabPageGeneral;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox ctrlGbxGeneral;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label ctrlLbluser;
        private System.Windows.Forms.Label ctrlLblHospitalName;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroButton ctrlBtnViewPayment;
        private MetroFramework.Controls.MetroButton ctrlBtnReport;
    }
}
