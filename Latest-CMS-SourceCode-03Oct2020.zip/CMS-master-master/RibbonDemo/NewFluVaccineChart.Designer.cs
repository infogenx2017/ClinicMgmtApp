﻿using MetroFramework;

namespace SVMApplication
{
    partial class NewFluVaccineBirthChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.FluChartGrid = new System.Windows.Forms.DataGridView();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lblID = new MetroFramework.Controls.MetroLabel();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.lblDOB = new MetroFramework.Controls.MetroLabel();
            this.btnprint = new MetroFramework.Controls.MetroButton();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.lbl12 = new MetroFramework.Controls.MetroLabel();
            this.LblGender = new MetroFramework.Controls.MetroLabel();
            this.TypoidChartGrid = new System.Windows.Forms.DataGridView();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.TyphoidFirstDose = new System.Windows.Forms.DateTimePicker();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.FluFirstDose = new System.Windows.Forms.DateTimePicker();
            this.chechtyphoid = new MetroFramework.Controls.MetroCheckBox();
            this.checkRegular = new MetroFramework.Controls.MetroCheckBox();
            this.btntyphoidReset = new MetroFramework.Controls.MetroButton();
            this.btnFluReset = new MetroFramework.Controls.MetroButton();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.TyphoidEndYear = new System.Windows.Forms.DateTimePicker();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.FluEndYear = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.FluChartGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TypoidChartGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(-1, 484);
            this.lblRowID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(14, 20);
            this.lblRowID.TabIndex = 28;
            this.lblRowID.Text = "1";
            this.lblRowID.Visible = false;
            // 
            // FluChartGrid
            // 
            this.FluChartGrid.AllowUserToAddRows = false;
            this.FluChartGrid.AllowUserToDeleteRows = false;
            this.FluChartGrid.AllowUserToOrderColumns = true;
            this.FluChartGrid.AllowUserToResizeRows = false;
            this.FluChartGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.FluChartGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.FluChartGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.FluChartGrid.ColumnHeadersHeight = 34;
            this.FluChartGrid.Location = new System.Drawing.Point(32, 172);
            this.FluChartGrid.Margin = new System.Windows.Forms.Padding(4);
            this.FluChartGrid.Name = "FluChartGrid";
            this.FluChartGrid.RowHeadersVisible = false;
            this.FluChartGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.FluChartGrid.Size = new System.Drawing.Size(1125, 234);
            this.FluChartGrid.TabIndex = 27;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(32, 67);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(67, 20);
            this.metroLabel1.TabIndex = 39;
            this.metroLabel1.Text = "Patient ID";
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(863, 67);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(87, 20);
            this.metroLabel2.TabIndex = 39;
            this.metroLabel2.Text = "Date of Birth";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(32, 102);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(92, 20);
            this.metroLabel3.TabIndex = 39;
            this.metroLabel3.Text = "Patient Name";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.FontSize = MetroLabelSize.Tall;
            this.lblID.FontWeight = MetroLabelWeight.Bold;
            this.lblID.Location = new System.Drawing.Point(129, 64);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(100, 25);
            this.lblID.TabIndex = 39;
            this.lblID.Text = "Patient ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.FontSize = MetroLabelSize.Tall;
            this.lblName.FontWeight = MetroLabelWeight.Bold;
            this.lblName.Location = new System.Drawing.Point(129, 99);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(132, 25);
            this.lblName.TabIndex = 39;
            this.lblName.Text = "Patient Name";
            // 
            // lblDOB
            // 
            this.lblDOB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDOB.AutoSize = true;
            this.lblDOB.FontSize = MetroLabelSize.Tall;
            this.lblDOB.FontWeight = MetroLabelWeight.Bold;
            this.lblDOB.Location = new System.Drawing.Point(957, 64);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(126, 25);
            this.lblDOB.TabIndex = 39;
            this.lblDOB.Text = "Date of Birth";
            // 
            // btnprint
            // 
            this.btnprint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnprint.Location = new System.Drawing.Point(880, 739);
            this.btnprint.Margin = new System.Windows.Forms.Padding(4);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(152, 28);
            this.btnprint.TabIndex = 41;
            this.btnprint.Text = "Save && Print";
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // btnexit
            // 
            this.btnexit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(1040, 739);
            this.btnexit.Margin = new System.Windows.Forms.Padding(4);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(121, 28);
            this.btnexit.TabIndex = 42;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lbl12
            // 
            this.lbl12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(894, 102);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(56, 20);
            this.lbl12.TabIndex = 39;
            this.lbl12.Text = "Gender";
            // 
            // LblGender
            // 
            this.LblGender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LblGender.AutoSize = true;
            this.LblGender.FontSize = MetroLabelSize.Tall;
            this.LblGender.FontWeight = MetroLabelWeight.Bold;
            this.LblGender.Location = new System.Drawing.Point(957, 99);
            this.LblGender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblGender.Name = "LblGender";
            this.LblGender.Size = new System.Drawing.Size(78, 25);
            this.LblGender.TabIndex = 39;
            this.LblGender.Text = "Gender";
            // 
            // TypoidChartGrid
            // 
            this.TypoidChartGrid.AllowUserToAddRows = false;
            this.TypoidChartGrid.AllowUserToDeleteRows = false;
            this.TypoidChartGrid.AllowUserToOrderColumns = true;
            this.TypoidChartGrid.AllowUserToResizeRows = false;
            this.TypoidChartGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TypoidChartGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TypoidChartGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.TypoidChartGrid.ColumnHeadersHeight = 34;
            this.TypoidChartGrid.Location = new System.Drawing.Point(32, 484);
            this.TypoidChartGrid.Margin = new System.Windows.Forms.Padding(4);
            this.TypoidChartGrid.Name = "TypoidChartGrid";
            this.TypoidChartGrid.RowHeadersVisible = false;
            this.TypoidChartGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.TypoidChartGrid.Size = new System.Drawing.Size(1125, 234);
            this.TypoidChartGrid.TabIndex = 43;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(32, 131);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(39, 25);
            this.metroLabel4.TabIndex = 39;
            this.metroLabel4.Text = "Flu";
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(32, 421);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(84, 25);
            this.metroLabel5.TabIndex = 39;
            this.metroLabel5.Text = "Typhoid";
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroLabelSize.Tall;
            this.metroLabel6.Location = new System.Drawing.Point(666, 452);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(203, 25);
            this.metroLabel6.TabIndex = 39;
            this.metroLabel6.Text = "Typhoid first dose date :";
            // 
            // TyphoidFirstDose
            // 
            this.TyphoidFirstDose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TyphoidFirstDose.Location = new System.Drawing.Point(876, 455);
            this.TyphoidFirstDose.Name = "TyphoidFirstDose";
            this.TyphoidFirstDose.Size = new System.Drawing.Size(200, 22);
            this.TyphoidFirstDose.TabIndex = 44;
            this.TyphoidFirstDose.ValueChanged += new System.EventHandler(this.TyphoidFirstDose_ValueChanged);
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroLabelSize.Tall;
            this.metroLabel7.Location = new System.Drawing.Point(712, 139);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(162, 25);
            this.metroLabel7.TabIndex = 39;
            this.metroLabel7.Text = "Flu first dose date :";
            // 
            // FluFirstDose
            // 
            this.FluFirstDose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FluFirstDose.Location = new System.Drawing.Point(876, 142);
            this.FluFirstDose.Name = "FluFirstDose";
            this.FluFirstDose.Size = new System.Drawing.Size(200, 22);
            this.FluFirstDose.TabIndex = 44;
            this.FluFirstDose.ValueChanged += new System.EventHandler(this.FluFirstDose_ValueChanged);
            // 
            // chechtyphoid
            // 
            this.chechtyphoid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chechtyphoid.AutoSize = true;
            this.chechtyphoid.Checked = true;
            this.chechtyphoid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chechtyphoid.FontSize = MetroLinkSize.Tall;
            this.chechtyphoid.Location = new System.Drawing.Point(145, 426);
            this.chechtyphoid.Name = "chechtyphoid";
            this.chechtyphoid.Size = new System.Drawing.Size(207, 20);
            this.chechtyphoid.Style = MetroColorStyle.Green;
            this.chechtyphoid.TabIndex = 45;
            this.chechtyphoid.Text = "Typhoid vaccine type (TCV) ";
            this.chechtyphoid.CheckedChanged += new System.EventHandler(this.chechtyphoid_CheckedChanged);
            // 
            // checkRegular
            // 
            this.checkRegular.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.checkRegular.AutoSize = true;
            this.checkRegular.FontSize = MetroLinkSize.Medium;
            this.checkRegular.Location = new System.Drawing.Point(145, 452);
            this.checkRegular.Name = "checkRegular";
            this.checkRegular.Size = new System.Drawing.Size(125, 20);
            this.checkRegular.Style = MetroColorStyle.Green;
            this.checkRegular.TabIndex = 46;
            this.checkRegular.Text = "Regular (Vi-PS)";
            this.checkRegular.CheckedChanged += new System.EventHandler(this.checkRegular_CheckedChanged);
            // 
            // btntyphoidReset
            // 
            this.btntyphoidReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btntyphoidReset.Location = new System.Drawing.Point(1082, 454);
            this.btntyphoidReset.Name = "btntyphoidReset";
            this.btntyphoidReset.Size = new System.Drawing.Size(75, 23);
            this.btntyphoidReset.TabIndex = 47;
            this.btntyphoidReset.Text = "Reset";
            this.btntyphoidReset.Click += new System.EventHandler(this.btntyphoidReset_Click);
            // 
            // btnFluReset
            // 
            this.btnFluReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFluReset.Location = new System.Drawing.Point(1082, 142);
            this.btnFluReset.Name = "btnFluReset";
            this.btnFluReset.Size = new System.Drawing.Size(75, 23);
            this.btnFluReset.TabIndex = 47;
            this.btnFluReset.Text = "Reset";
            this.btnFluReset.Click += new System.EventHandler(this.btnFluReset_Click);
            // 
            // metroLabel8
            // 
            this.metroLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroLabelSize.Tall;
            this.metroLabel8.Location = new System.Drawing.Point(448, 452);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(82, 25);
            this.metroLabel8.TabIndex = 39;
            this.metroLabel8.Text = "Till year :";
            this.metroLabel8.Visible = false;
            // 
            // TyphoidEndYear
            // 
            this.TyphoidEndYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TyphoidEndYear.CustomFormat = "yyyy";
            this.TyphoidEndYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TyphoidEndYear.Location = new System.Drawing.Point(537, 455);
            this.TyphoidEndYear.Name = "TyphoidEndYear";
            this.TyphoidEndYear.ShowUpDown = true;
            this.TyphoidEndYear.Size = new System.Drawing.Size(77, 22);
            this.TyphoidEndYear.TabIndex = 44;
            this.TyphoidEndYear.Visible = false;
            this.TyphoidEndYear.ValueChanged += new System.EventHandler(this.TyphoidFirstDose_ValueChanged);
            // 
            // metroLabel9
            // 
            this.metroLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroLabelSize.Tall;
            this.metroLabel9.Location = new System.Drawing.Point(448, 139);
            this.metroLabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(82, 25);
            this.metroLabel9.TabIndex = 39;
            this.metroLabel9.Text = "Till year :";
            this.metroLabel9.Visible = false;
            // 
            // FluEndYear
            // 
            this.FluEndYear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.FluEndYear.CustomFormat = "yyyy";
            this.FluEndYear.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.FluEndYear.Location = new System.Drawing.Point(537, 142);
            this.FluEndYear.Name = "FluEndYear";
            this.FluEndYear.ShowUpDown = true;
            this.FluEndYear.Size = new System.Drawing.Size(77, 22);
            this.FluEndYear.TabIndex = 44;
            this.FluEndYear.Visible = false;
            this.FluEndYear.ValueChanged += new System.EventHandler(this.TyphoidFirstDose_ValueChanged);
            // 
            // NewFluVaccineBirthChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 785);
            this.Controls.Add(this.btnFluReset);
            this.Controls.Add(this.btntyphoidReset);
            this.Controls.Add(this.checkRegular);
            this.Controls.Add(this.chechtyphoid);
            this.Controls.Add(this.FluFirstDose);
            this.Controls.Add(this.FluEndYear);
            this.Controls.Add(this.TyphoidEndYear);
            this.Controls.Add(this.TyphoidFirstDose);
            this.Controls.Add(this.TypoidChartGrid);
            this.Controls.Add(this.btnprint);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.LblGender);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.FluChartGrid);
            this.MaximizeBox = false;
            this.Name = "NewFluVaccineBirthChart";
            this.Text = "Flu / Typoid Chart ...";
            this.Load += new System.EventHandler(this.NewVaccineChart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FluChartGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TypoidChartGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRowID;
        private System.Windows.Forms.DataGridView FluChartGrid;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lblID;
        private MetroFramework.Controls.MetroLabel lblName;
        private MetroFramework.Controls.MetroLabel lblDOB;
        private MetroFramework.Controls.MetroButton btnprint;
        private MetroFramework.Controls.MetroButton btnexit;
        private MetroFramework.Controls.MetroLabel lbl12;
        private MetroFramework.Controls.MetroLabel LblGender;
        private System.Windows.Forms.DataGridView TypoidChartGrid;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.DateTimePicker TyphoidFirstDose;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.DateTimePicker FluFirstDose;
        private MetroFramework.Controls.MetroCheckBox chechtyphoid;
        private MetroFramework.Controls.MetroCheckBox checkRegular;
        private MetroFramework.Controls.MetroButton btntyphoidReset;
        private MetroFramework.Controls.MetroButton btnFluReset;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.DateTimePicker TyphoidEndYear;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.DateTimePicker FluEndYear;
    }
}