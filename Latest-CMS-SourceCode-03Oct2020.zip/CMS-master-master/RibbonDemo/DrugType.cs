﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class DrugType : Form
    {
        SqlConnection con = null;
        public DrugType()
        {
            InitializeComponent();
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
            if (txtName.Text != "" && textBox1.Text != "" && txtremark.Text != "")
            {
                if (btnSave.Text == "Save")
                {
                    if (CheckName())
                    {
                        btnSave.Text = "Update";
                        MessageBox.Show("Name Already exist");
                        return;
                    }
                    else
                    {
                        SaveMathod();
                        MessageBox.Show("Saved Successfully");
                    }
                }
                else
                {
                    SaveMathod();

                    MessageBox.Show("Updated Successfully");
                }
                LoadGrid();
                clear();
            }
            else
            {
                MessageBox.Show("Please Fill All Records");
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select RowId,DrugTypeName,Remark,DisplayName from DrugType order by RowID asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];

            }

           
        }


        private bool CheckName()
        {
            bool rtnval = false;
            DataSet ds = new DataSet();
            con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            string querry = @"Select RowId,DrugTypeName,Remark,DisplayName from DrugType Where DrugTypeName=@DrugTypeName";
            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.AddWithValue("@DrugTypeName", txtName.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rtnval = true;
                lblRowID.Text = ds.Tables[0].Rows[0]["RowId"].ToString();
                txtremark.Text = ds.Tables[0].Rows[0]["Remark"].ToString();
                txtName.Text = ds.Tables[0].Rows[0]["DrugTypeName"].ToString();
                textBox1.Text = ds.Tables[0].Rows[0]["DisplayName"].ToString();
            }
            return rtnval;
        }
        private void clear()
        {
            lblRowID.Text = "";
            txtremark.Text = "";
            txtName.Text = "";
            btnSave.Text = "Save";
            textBox1.Text = "";
            txtName.Focus();
        }
        private string SaveMathod()
        {

            using (con)
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("SPUI_DrugType", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RowId", lblRowID.Text);
                cmd.Parameters.AddWithValue("@DrugTypeName", txtName.Text);
                cmd.Parameters.AddWithValue("@Remark", txtremark.Text);
                cmd.Parameters.AddWithValue("@DisplayName", textBox1.Text);
                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void Drug_Type_Load(object sender, EventArgs e)
        {
            LoadGrid();
            txtName.Focus();
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAddnew_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try{
            if (txtName.Text != "" && lblRowID.Text != "")
            {
                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From DrugType Where RowId =@ROWID", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@RowId", lblRowID.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    clear();
                }
                else
                {
                }
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_ext_Click(object sender, EventArgs e)
        {
            string res;
            res = Convert.ToString(MessageBox.Show("Are You want to Exit", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information));
            if (res == "Yes")
            {
                this.Close();
            }
            else
            {
            }
        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

            }
            else if (e.KeyCode == Keys.Escape)
            {
                dataGridView1.Focus();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtName.Focus();
            }
        }

        private void txtremark_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

                if (txtremark.Text != "")
                {
                    e.SuppressKeyPress = false;
                }
                else
                {
                    e.SuppressKeyPress = true;
                }
                

            }
            else if (e.KeyCode == Keys.Escape)
            {
                textBox1.Focus();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            clear();
            int rowIndex = dataGridView1.Rows[e.RowIndex].Index;
            dataGridView1.Rows[e.RowIndex].Cells[0].Selected = true;

            if (dataGridView1 == null)
                return;
            if (dataGridView1.Rows[e.RowIndex].Cells[0].Selected == true)
            {

                if (Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[0].Value) != String.Empty)
                {
                    //lblRowID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                    //txtName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                    //txtremark.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                    //textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

                    //viji modified
                    lblRowID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                    txtName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                    txtremark.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                    textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();

                    btnSave.Text = "Update";
                }
                else
                    clear();
            }
            else
                clear();
        }

        private void btnSave_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtremark.Focus();
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);

            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtName.Focus();
            }
        }        
    }
}
