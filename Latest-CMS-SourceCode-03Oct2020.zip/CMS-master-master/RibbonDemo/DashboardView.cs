﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Calendar.NET;
using System.Data.SqlClient;
using System.Configuration;
using SVMApplication.Helper;
using MetroFramework;

namespace SVMApplication
{
    public partial class DashboardView : UserControl
    {
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        List<HolidayEvent> HolidayEvents = new List<HolidayEvent>();
        public DashboardView()
        {
            InitializeComponent();
            Application.DoEvents();
            ctrlCalendarEvents.ClearAllEvents();
            ctrlCalendarEvents.LoadWithCurrentDate();

            ctrlTabMonthView.SizeMode = TabSizeMode.Fixed;
            ctrlTabMonthView.TextAlign = ContentAlignment.MiddleLeft;
            ctrlTabMonthView.FontWeight = MetroTabControlWeight.Bold;
        }

        private void DashboardView_Load(object sender, EventArgs e)
        {
            Application.DoEvents();
            ctrlTabMonthView.Update();
            LoadChartData();
            LoadEvents();
            LoadLabelData();
            ctrlTabMonthView.SelectedIndex = 0;
        }

        public List<string> PatientStatusLoad()
        {
            List<string> status = new List<string>();
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        status.Add(reader.GetString(1));
                    }

                }              
                con.Close();
            }

            return status;
        }

        public void LoadChartData()
        {
            string[] x = PatientStatusLoad().ToArray();        
            List<int> Yvalues = new List<int>();
            foreach (var item in x)
            {
                Yvalues.Add(GetPatientStatus(item));
            }
            chartViewer.Series[0].ChartType = SeriesChartType.Pie;
            chartViewer.Series[0].Points.DataBindXY(x, Yvalues.ToArray());
            chartViewer.Legends[0].Enabled = true;
            chartViewer.ChartAreas[0].Area3DStyle.Enable3D = true;          
        }

        private void LoadLabelData()
        {
            ctrlLblHospitalName.Text = AppMain.LoginHospital.Name + " - " + AppMain.LoginHospital.City;
            if (!string.IsNullOrWhiteSpace(AppMain.LoginUser.DoctorCode))
                ctrlLbluser.Text = AppMain.LoginUser.FullName + " - " + AppMain.LoginUser.DoctorCode;
            else
                ctrlLbluser.Text = AppMain.LoginUser.FullName;
        }

        private int GetPatientStatus(string value)
        {
            SqlConnection con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlCommand cm = null;
            if (AppMain.LoginUser.Type.ToUpper() == "ADMIN")
            {
                cm = new SqlCommand($"select count(*) from regappform3[a] inner join patientstatus[b] on A.status = b.ID where(CAST(date as date) = CAST(getdate() as date)And(b.name = '{value }') )", con);

            }
            else
            {
                cm = new SqlCommand($"select count(*) from regappform3[a] inner join patientstatus[b] on A.status = b.ID where(CAST(date as date) = CAST(getdate() as date)And(b.name = '{value }') And DoctorCode =@doctorCode )", con);
                cm.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
            }
            int count = Convert.ToInt32(cm.ExecuteScalar());
            return count;
        }

       private void LoadEvents()
        {
            ctrlGridEvents.DataSource = null;
            using (SqlConnection con1 = new SqlConnection(constr))
            {
                if (con1.State == ConnectionState.Closed)
                    con1.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("select A.ID as 'Event ID', A.EventDate as 'Event Date',A.EventText as 'Event Text',A.EnableTooltip,A.EventColor,A.EventTextColor from MonthEvnets[A]", con1);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Event List");
                ctrlGridEvents.DataSource = ds.Tables[0];

                SqlDataReader reader = cmd.ExecuteReader();
                HolidayEvents = new List<HolidayEvent>();
                while (reader.HasRows)
                {                  
                    while (reader.Read())
                    {
                        HolidayEvent @event = new HolidayEvent();
                        @event.Date = reader.GetDateTime(1);
                        @event.EventText= reader.GetString(2);
                        @event.TooltipEnabled = reader.GetBoolean(3);                              
                        @event.EventColor = Color.FromName(reader.GetString(4));
                   //     if (!@event.EventColor.IsKnownColor)
                            @event.EventColor = Color.Orange;
                        @event.EventTextColor = Color.FromName(reader.GetString(5));
                    //    if (!@event.EventTextColor.IsKnownColor)
                            @event.EventTextColor = Color.SkyBlue;
                        HolidayEvents.Add(@event);
                    }
                    reader.NextResult();
                }
            }

            ctrlCalendarEvents.ClearAllEvents();
            foreach (var item in HolidayEvents)
            {
                item.CustomRecurringFunction += ctrlCalendarEvents.AnyOneOftheDay;
                ctrlCalendarEvents.AddEvent(item);
            }
           


        }

        private void ctrlBtnAddEvent_Click(object sender, EventArgs e)
        {
            
            EventDetails eventDetails = new Calendar.NET.EventDetails();
            if (this.ctrlCalendarEvents.CalendarView == CalendarViews.Day)
                eventDetails.SetCalnderDate(ctrlCalendarEvents.CalendarDate);

            eventDetails.Event = new HolidayEvent();
            if (eventDetails.ShowDialog() == DialogResult.OK)
            {
                eventDetails.NewEvent.CustomRecurringFunction += ctrlCalendarEvents.AnyOneOftheDay;
                ctrlCalendarEvents.AddEvent(eventDetails.NewEvent);


                using (SqlConnection con1 = new SqlConnection(constr))
                {
                    if (con1.State == ConnectionState.Closed)
                        con1.Open();
                    SqlCommand cmd = new SqlCommand("Sp_AddEvents", con1);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EventText", eventDetails.NewEvent.EventText);
                    cmd.Parameters.AddWithValue("@EventDate", eventDetails.NewEvent.Date);

                    //if (!eventDetails.NewEvent.EventColor.IsKnownColor)
                        eventDetails.NewEvent.EventColor = Color.Orange;                  
                    //if (!eventDetails.NewEvent.EventTextColor.IsKnownColor)
                        eventDetails.NewEvent.EventTextColor = Color.SkyBlue;

                    cmd.Parameters.AddWithValue("@EventColor", eventDetails.NewEvent.EventColor.Name);
                    cmd.Parameters.AddWithValue("@EventTextColor", eventDetails.NewEvent.EventTextColor.Name);
                    cmd.Parameters.AddWithValue("@EnableTooltip", eventDetails.NewEvent.TooltipEnabled);
                    cmd.ExecuteNonQuery();
                   
                     cmd = new SqlCommand("select A.ID as 'Event ID', A.EventDate as 'Event Date',A.EventText as 'Event Text',A.EnableTooltip,A.EventColor,A.EventTextColor from MonthEvnets[A]", con1);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "Event List");
                    ctrlGridEvents.DataSource = ds.Tables[0];
                }



                // insert into MonthEvnets values(GETDATE(),'DashBoard Starting','Red','Yellow',0)
                LoadEvents();
            }
        }

        private void LoadAllEvents()
        {
            ctrlCalendarEvents.ClearAllEvents();
            ctrlCalendarEvents.LoadEvents(new List<HolidayEvent>());
        }

        private void CtrlTxtAdd_Click(object sender, EventArgs e)
        {
            ctrlBtnAddEvent_Click(this, null);
        }

        private void ctrlBtnDelet_Click(object sender, EventArgs e)
        {
            if (ctrlGridEvents.SelectedRows.Count > 0)
            {
                var id = ctrlGridEvents.Rows[ctrlGridEvents.SelectedRows[0].Index].Cells[0].Value.ToString();
                SqlConnection con = new SqlConnection(constr);
                DialogResult result = MessageBox.Show("Do You Want to delete the Curent Events?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete from MonthEvnets where ID=@id", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(id));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }

                    LoadEvents();
                }

            }
        }

        private void ctrlBtnUpdate_Click(object sender, EventArgs e)
        {
            int index = ctrlGridEvents.SelectedRows[0].Index;

            var currentEvent = HolidayEvents[index];

            EventDetails eventDetails = new Calendar.NET.EventDetails();
            eventDetails.Event = currentEvent;
            eventDetails.SetCalnderDate(currentEvent.Date);
            if (eventDetails.ShowDialog() == DialogResult.OK)
            {
                var id = ctrlGridEvents.Rows[ctrlGridEvents.SelectedRows[0].Index].Cells[0].Value.ToString();
                using (SqlConnection con1 = new SqlConnection(constr))
                {
                    if (con1.State == ConnectionState.Closed)
                        con1.Open();
                   
                    SqlCommand cmd = new SqlCommand("Sp_UpdateEvents", con1);
                    cmd.CommandType = CommandType.StoredProcedure; 

                    cmd.Parameters.AddWithValue("@EventID", id);
                    cmd.Parameters.AddWithValue("@EventText", eventDetails.NewEvent.EventText);
                    cmd.Parameters.AddWithValue("@EventDate", eventDetails.NewEvent.Date);

                    //if (!eventDetails.NewEvent.EventColor.IsNamedColor)
                        eventDetails.NewEvent.EventColor = Color.Orange;
                    //if (!eventDetails.NewEvent.EventTextColor.IsNamedColor)
                        eventDetails.NewEvent.EventTextColor = Color.SkyBlue;

                    cmd.Parameters.AddWithValue("@EventColor", eventDetails.NewEvent.EventColor.Name);
                    cmd.Parameters.AddWithValue("@EventTextColor", eventDetails.NewEvent.EventTextColor.Name);
                    cmd.Parameters.AddWithValue("@EnableTooltip", eventDetails.NewEvent.TooltipEnabled);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Data Updated Successfully");
                    LoadEvents();
                }
            }
        }

        private void ctrlBtnAppontmentKLis_Click(object sender, EventArgs e)
        {
            LoadGeneralScreen(0);
        }
     

        private void ctrlBtnViewPayment_Click(object sender, EventArgs e)
        {
            LoadGeneralScreen(1);
        }

        private void CtrlBtnReport_Click(object sender, EventArgs e)
        {
            LoadGeneralScreen(2);
        }

        private void LoadGeneralScreen(int number)
        {
            ctrlTabMonthView.SelectedIndex = 2;
            ctrlGbxGeneral.Controls.Clear();
            UserControl userControl = null;
            switch (number)
            {
                case 0:
                    userControl = new AppointmentList();
                    break;
                case 1:
                    userControl= new ViewPaymentReport();
                    break;
                case 2:
                    userControl = new ViewCMSreport();
                    break;
            }
            if (userControl != null)
            {
                userControl.Dock = DockStyle.Fill;
                ctrlGbxGeneral.Controls.Add(userControl);
            }
        }
        private void CtrlTileLogout_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.ParentForm is MainForm)
                {
                    if (DialogResult.Yes == MessageBox.Show("Do you want to close Application ?", "Information", MessageBoxButtons.YesNo))
                    {
                        MainForm form = (MainForm)this.ParentForm;
                        form.MainForm_FormClosing(this, null);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

       
    }
}
