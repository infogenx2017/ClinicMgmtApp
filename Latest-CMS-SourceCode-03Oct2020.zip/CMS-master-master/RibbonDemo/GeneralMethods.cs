﻿using CheckComboBoxTest;
using SVMApplication.Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public class GeneralMethods
    {
        string constr = "";
        public GeneralMethods()
        {
            constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        }
        public void PatientStatusLoad( ref System.Windows.Forms.ComboBox ctrlCbxStatus)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        internal string JoinSpecficItem(ref CheckedComboBox ctrlCbxLab)
        {
            List<string> res = new List<string>();
            for (int i = 0; i < ctrlCbxLab.Items.Count; i++)
            {
                if (ctrlCbxLab.GetItemChecked(i))
                {
                    ComboboxItem item = ctrlCbxLab.Items[i] as ComboboxItem;
                    res.Add(item.Value.ToString());
                }
            }
            if (res.Count > 0)
                return string.Join("-", res.ToArray());
            else
                return "";
          
        }

        internal void LoadCheckedValues(string joinString, ref CheckedComboBox ctrlCbxLab)
        {
            try
            {
                List<int> id = new List<int>();
                if (!joinString.Contains("-"))
                {
                    id.Add(Convert.ToInt32(joinString));
                }
                else
                {
                    var splitArray = joinString.Split('-');
                    for (int i = 0; i < splitArray.Length; i++)
                    {
                        id.Add(Convert.ToInt32(splitArray[i]));
                    }
                }

                foreach (var item in id)
                {
                    for (int i = 0; i < ctrlCbxLab.Items.Count; i++)
                    {
                        ComboboxItem value = ctrlCbxLab.Items[i] as ComboboxItem;
                        if (Convert.ToInt32(value.Value).Equals(item))
                            ctrlCbxLab.SetItemChecked(i, true);
                    }
                }
            }
            catch (Exception)
            {
            }
        

        }

        public void PatientAlergicLoad(ref CheckComboBoxTest.CheckedComboBox ctrlCbxStatus)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from AllergyMaster", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                int noKnownAllergyId = -1;
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);                       
                        item.Text = reader.GetString(1);

                        if(item.Text!= "No known drug allergies")
                        ctrlCbxStatus.Items.Add(item);
                        else
                            noKnownAllergyId = reader.GetInt32(0);
                    }

                }
                if (noKnownAllergyId > 0)
                {
                    ComboboxItem item = new ComboboxItem();
                    item.Value = noKnownAllergyId;
                    item.Text = "No known drug allergies";
                    ctrlCbxStatus.Items.Insert(0, item);
                }
                con.Close();
            }
        }

        public void PatientLabInvestigationsLoad(ref CheckComboBoxTest.CheckedComboBox ctrlCbxStatus)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from labinvestigation", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }

                con.Close();
            }
        }

        public void LoadDiagnosis(ref TextBox txtDiagnosis)
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select RowId,Diagnosis from Diagnosis ";
                SqlCommand cmd = new SqlCommand(querry, con);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                        namesCollection.Add(dr["Diagnosis"].ToString());
                }
                dr.Close();
                con.Close();
                txtDiagnosis.AutoCompleteMode = AutoCompleteMode.Append;
                txtDiagnosis.AutoCompleteSource = AutoCompleteSource.CustomSource;
                txtDiagnosis.AutoCompleteCustomSource = namesCollection;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public int GetDiagnosis(string digonis)
        {
            int id = -1;
            try
            {
                SqlConnection con = new SqlConnection(constr);
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select RowId from Diagnosis where Diagnosis=@digonis";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@digonis", digonis);
                id = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                id = -1;
            }
            return id;
        }

        public string GetDiagnosisName(int digonisId)
        {
            string name = "";

            if (digonisId <= 0)
                return "";
            try
            {
                SqlConnection con = new SqlConnection(constr);
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select Diagnosis from Diagnosis where RowId=@digonisId";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@digonisId", digonisId);
                name = Convert.ToString(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                name = "";
            }
            return name;
        }

        public string GetTreatmentBasedonEpres(string ePresNo)
        {

            List<string> namesCollection = new List<string>();
            try
            {
                SqlConnection con = new SqlConnection(constr);
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();

                string querry = @"select Icode from Prescription_DT where EPresNo = @epres";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@epres", ePresNo);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    while (dr.Read())
                        namesCollection.Add(dr["Icode"].ToString());
                }
                dr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);              
            }
            if (namesCollection.Count > 0)
                return string.Join(Environment.NewLine, namesCollection.ToArray());
            else
                return "";
        }


        public void DoctorNameLoad(ref System.Windows.Forms.ComboBox ctrlCbxDoctor)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxDoctor.Items.Clear();
                SqlCommand cmd = new SqlCommand("select UPPER(A.FULL_NAME),UPPER(A.DOCTORCODE) from USERS[A] inner join usertype[B] on a.TYPE=b.typeID where B.typeName='doctor'", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetString(1);
                        item.Text = reader.GetString(0);
                        ctrlCbxDoctor.Items.Add(item);
                    }

                }
                ctrlCbxDoctor.SelectedIndex = 0;

                con.Close();
            }
        }
    }
}
