﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    //public partial class SplashScreen : CSWinFormLayeredWindow.PerPixelAlphaForm
    public partial class SplashScreen : Form
    {
        public SplashScreen()
        {
            InitializeComponent();
            //this.SelectBitmap(Properties.Resources.logo_big);            
        }
        public int timeLeft { get; set; }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
                timeLeft = timeLeft - 1;
            else
            {

                timer1.Stop();
                frmLogin frmLogin = new frmLogin();
                this.Hide();
#if HASPD
                new MainForm(this).Show();
#else
                DialogResult res = frmLogin.ShowDialog(this);
                if (frmLogin.log.IsLoginSuceesfully)
                {
                    new MainForm(this).Show();                   
                }
                else
                {
                    this.Close();
                }
#endif


            }
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            timeLeft = 20;// (the 10 here describes how much seconds your splash screen will be displayed)
            timer1.Start();
        }
    }
}
