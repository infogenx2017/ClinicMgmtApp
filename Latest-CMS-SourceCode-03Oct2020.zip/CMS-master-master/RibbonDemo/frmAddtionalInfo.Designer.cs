﻿namespace SVMApplication
{
    partial class frmAddtionalInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.ctrlCbxLab = new CheckComboBoxTest.CheckedComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.ctrltxtAddtionalInformat = new System.Windows.Forms.RichTextBox();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(355, 237);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(107, 29);
            this.metroButton1.TabIndex = 3;
            this.metroButton1.Text = "Apply";
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroLabel1);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.metroLabel2);
            this.groupBox1.Controls.Add(this.ctrltxtAddtionalInformat);
            this.groupBox1.Location = new System.Drawing.Point(19, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(443, 178);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Details";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(6, 16);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(129, 19);
            this.metroLabel1.TabIndex = 1822;
            this.metroLabel1.Text = "Lab Investigations";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Location = new System.Drawing.Point(6, 38);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(427, 30);
            this.panel2.TabIndex = 1821;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel1.Controls.Add(this.metroButton3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.ctrlCbxLab, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(427, 30);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // metroButton3
            // 
            this.metroButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroButton3.Location = new System.Drawing.Point(364, 3);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(60, 24);
            this.metroButton3.TabIndex = 1818;
            this.metroButton3.Text = "ADD";
            this.metroButton3.Click += new System.EventHandler(this.MetroButton3_Click);
            // 
            // ctrlCbxLab
            // 
            this.ctrlCbxLab.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.ctrlCbxLab.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ctrlCbxLab.CheckOnClick = true;
            this.ctrlCbxLab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCbxLab.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.ctrlCbxLab.DropDownHeight = 1;
            this.ctrlCbxLab.FormattingEnabled = true;
            this.ctrlCbxLab.IntegralHeight = false;
            this.ctrlCbxLab.Location = new System.Drawing.Point(3, 3);
            this.ctrlCbxLab.Name = "ctrlCbxLab";
            this.ctrlCbxLab.Size = new System.Drawing.Size(355, 21);
            this.ctrlCbxLab.TabIndex = 1817;
            this.ctrlCbxLab.ValueSeparator = ", ";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(6, 71);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(158, 19);
            this.metroLabel2.TabIndex = 5;
            this.metroLabel2.Text = "Addtional Information";
            // 
            // ctrltxtAddtionalInformat
            // 
            this.ctrltxtAddtionalInformat.Location = new System.Drawing.Point(6, 93);
            this.ctrltxtAddtionalInformat.Name = "ctrltxtAddtionalInformat";
            this.ctrltxtAddtionalInformat.Size = new System.Drawing.Size(427, 65);
            this.ctrltxtAddtionalInformat.TabIndex = 4;
            this.ctrltxtAddtionalInformat.Text = "";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(242, 237);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(107, 29);
            this.metroButton2.TabIndex = 4;
            this.metroButton2.Text = "Close";
            this.metroButton2.Click += new System.EventHandler(this.MetroButton2_Click);
            // 
            // frmAddtionalInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Drawing.MetroBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(475, 278);
            this.ControlBox = false;
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmAddtionalInfo";
            this.Text = "Addtional Information";
            this.Load += new System.EventHandler(this.FrmAddtionalInfo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.RichTextBox ctrltxtAddtionalInformat;
        private MetroFramework.Controls.MetroButton metroButton2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private MetroFramework.Controls.MetroButton metroButton3;
        private CheckComboBoxTest.CheckedComboBox ctrlCbxLab;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}