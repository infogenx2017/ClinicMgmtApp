﻿namespace SVMApplication
{
    partial class NewDrug
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfdose = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txttamil = new System.Windows.Forms.TextBox();
            this.dgv_date = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FromMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ToYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ToMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DoseInUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Drug_ComboBox = new System.Windows.Forms.TextBox();
            this.cbdrugtype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Duration = new System.Windows.Forms.TextBox();
            this.txt_Itemcode = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtinstruction = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.strength_ComboBox = new System.Windows.Forms.ComboBox();
            this.txt2_strength = new System.Windows.Forms.TextBox();
            this.strength1_ComboBox = new System.Windows.Forms.ComboBox();
            this.txt1_strength = new System.Windows.Forms.TextBox();
            this.Interval_ComboBox = new System.Windows.Forms.ComboBox();
            this.txt_DefaultQty = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_Dose = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.RdoAgebased = new System.Windows.Forms.RadioButton();
            this.RdoWeightbased = new System.Windows.Forms.RadioButton();
            this.Rdofixed = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btndrugtype = new MetroFramework.Controls.MetroButton();
            this.BtnNew = new MetroFramework.Controls.MetroButton();
            this.BtnAdd = new MetroFramework.Controls.MetroButton();
            this.BtnRemove = new MetroFramework.Controls.MetroButton();
            this.BtnUpdate = new MetroFramework.Controls.MetroButton();
            this.btn_clr = new MetroFramework.Controls.MetroButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_date)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtfdose
            // 
            this.txtfdose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfdose.Location = new System.Drawing.Point(263, -3);
            this.txtfdose.Name = "txtfdose";
            this.txtfdose.Size = new System.Drawing.Size(42, 26);
            this.txtfdose.TabIndex = 9;
            this.txtfdose.Text = "0";
            this.txtfdose.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 30);
            this.label5.TabIndex = 50;
            this.label5.Text = "Instructions";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txttamil
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txttamil, 7);
            this.txttamil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txttamil.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttamil.Location = new System.Drawing.Point(103, 153);
            this.txttamil.Multiline = true;
            this.txttamil.Name = "txttamil";
            this.txttamil.Size = new System.Drawing.Size(586, 24);
            this.txttamil.TabIndex = 13;
            this.txttamil.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttamil_KeyDown);
            // 
            // dgv_date
            // 
            this.dgv_date.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_date.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_date.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dgv_date.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_date.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.FromMonth,
            this.ToYear,
            this.ToMonth,
            this.DoseInUnits});
            this.dgv_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_date.Location = new System.Drawing.Point(695, 33);
            this.dgv_date.Name = "dgv_date";
            this.tableLayoutPanel1.SetRowSpan(this.dgv_date, 5);
            this.dgv_date.Size = new System.Drawing.Size(312, 144);
            this.dgv_date.TabIndex = 14;
            this.dgv_date.Visible = false;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "FromYear";
            this.Column2.HeaderText = "FromYear";
            this.Column2.Name = "Column2";
            // 
            // FromMonth
            // 
            this.FromMonth.DataPropertyName = "FromMonth";
            this.FromMonth.HeaderText = "FromMonth";
            this.FromMonth.Name = "FromMonth";
            // 
            // ToYear
            // 
            this.ToYear.DataPropertyName = "ToYear";
            this.ToYear.HeaderText = "ToYear";
            this.ToYear.Name = "ToYear";
            // 
            // ToMonth
            // 
            this.ToMonth.DataPropertyName = "ToMonth";
            this.ToMonth.HeaderText = "ToMonth";
            this.ToMonth.Name = "ToMonth";
            // 
            // DoseInUnits
            // 
            this.DoseInUnits.DataPropertyName = "DoseInUnits";
            this.DoseInUnits.HeaderText = "Dose In Units";
            this.DoseInUnits.Name = "DoseInUnits";
            // 
            // Drug_ComboBox
            // 
            this.Drug_ComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Drug_ComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Drug_ComboBox.BackColor = System.Drawing.Color.White;
            this.Drug_ComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Drug_ComboBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Drug_ComboBox.Location = new System.Drawing.Point(103, 33);
            this.Drug_ComboBox.Name = "Drug_ComboBox";
            this.Drug_ComboBox.Size = new System.Drawing.Size(278, 26);
            this.Drug_ComboBox.TabIndex = 2;
            this.Drug_ComboBox.TextChanged += new System.EventHandler(this.Drug_ComboBox_TextChanged);
            this.Drug_ComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Drug_ComboBox_KeyDown);
            // 
            // cbdrugtype
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbdrugtype, 5);
            this.cbdrugtype.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbdrugtype.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbdrugtype.FormattingEnabled = true;
            this.cbdrugtype.Items.AddRange(new object[] {
            "As Needed",
            "4",
            "3",
            "2",
            "1"});
            this.cbdrugtype.Location = new System.Drawing.Point(487, 93);
            this.cbdrugtype.Name = "cbdrugtype";
            this.cbdrugtype.Size = new System.Drawing.Size(202, 27);
            this.cbdrugtype.TabIndex = 11;
            this.cbdrugtype.SelectedIndexChanged += new System.EventHandler(this.cbdrugtype_SelectedIndexChanged);
            this.cbdrugtype.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cbdrugtype_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(387, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 30);
            this.label1.TabIndex = 47;
            this.label1.Text = "Drug Type";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Duration
            // 
            this.Duration.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.SetColumnSpan(this.Duration, 5);
            this.Duration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Duration.Enabled = false;
            this.Duration.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Duration.ForeColor = System.Drawing.Color.Black;
            this.Duration.Location = new System.Drawing.Point(487, 63);
            this.Duration.Name = "Duration";
            this.Duration.Size = new System.Drawing.Size(202, 26);
            this.Duration.TabIndex = 10;
            // 
            // txt_Itemcode
            // 
            this.txt_Itemcode.BackColor = System.Drawing.Color.White;
            this.txt_Itemcode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Itemcode.Enabled = false;
            this.txt_Itemcode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Itemcode.Location = new System.Drawing.Point(103, 3);
            this.txt_Itemcode.Name = "txt_Itemcode";
            this.txt_Itemcode.Size = new System.Drawing.Size(278, 26);
            this.txt_Itemcode.TabIndex = 1;
            this.txt_Itemcode.Leave += new System.EventHandler(this.txt_Itemcode_Leave);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 30);
            this.label13.TabIndex = 33;
            this.label13.Text = "Item Code";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtinstruction
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtinstruction, 7);
            this.txtinstruction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtinstruction.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinstruction.Location = new System.Drawing.Point(103, 123);
            this.txtinstruction.Multiline = true;
            this.txtinstruction.Name = "txtinstruction";
            this.txtinstruction.Size = new System.Drawing.Size(586, 24);
            this.txtinstruction.TabIndex = 12;
            this.txtinstruction.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtinstruction_KeyDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(581, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 30);
            this.label17.TabIndex = 28;
            this.label17.Text = "=";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // strength_ComboBox
            // 
            this.strength_ComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.strength_ComboBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strength_ComboBox.FormattingEnabled = true;
            this.strength_ComboBox.Location = new System.Drawing.Point(648, 3);
            this.strength_ComboBox.Name = "strength_ComboBox";
            this.strength_ComboBox.Size = new System.Drawing.Size(41, 27);
            this.strength_ComboBox.TabIndex = 8;
            this.strength_ComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.strength_ComboBox_KeyDown);
            // 
            // txt2_strength
            // 
            this.txt2_strength.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt2_strength.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2_strength.Location = new System.Drawing.Point(601, 3);
            this.txt2_strength.Name = "txt2_strength";
            this.txt2_strength.Size = new System.Drawing.Size(41, 26);
            this.txt2_strength.TabIndex = 7;
            this.txt2_strength.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt2_strength_KeyDown);
            // 
            // strength1_ComboBox
            // 
            this.strength1_ComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.strength1_ComboBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strength1_ComboBox.FormattingEnabled = true;
            this.strength1_ComboBox.Location = new System.Drawing.Point(534, 3);
            this.strength1_ComboBox.Name = "strength1_ComboBox";
            this.strength1_ComboBox.Size = new System.Drawing.Size(41, 27);
            this.strength1_ComboBox.TabIndex = 6;
            this.strength1_ComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.strength1_ComboBox_KeyDown);
            // 
            // txt1_strength
            // 
            this.txt1_strength.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt1_strength.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1_strength.Location = new System.Drawing.Point(487, 3);
            this.txt1_strength.Name = "txt1_strength";
            this.txt1_strength.Size = new System.Drawing.Size(41, 26);
            this.txt1_strength.TabIndex = 5;
            this.txt1_strength.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt1_strength_KeyDown);
            // 
            // Interval_ComboBox
            // 
            this.Interval_ComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Interval_ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Interval_ComboBox.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Interval_ComboBox.FormattingEnabled = true;
            this.Interval_ComboBox.Items.AddRange(new object[] {
            "Vaccination",
            "As needed –தேவையானபோது",
            "4 times a day (4 வேளை) ",
            "3 times a day (3 வேளை) ",
            "2 times a day (2 வேளை) ",
            "Once a day  (1 வேளை) "});
            this.Interval_ComboBox.Location = new System.Drawing.Point(103, 63);
            this.Interval_ComboBox.Name = "Interval_ComboBox";
            this.Interval_ComboBox.Size = new System.Drawing.Size(278, 27);
            this.Interval_ComboBox.TabIndex = 3;
            this.Interval_ComboBox.TextChanged += new System.EventHandler(this.Interval_ComboBox_SelectedIndexChanged_1);
            this.Interval_ComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Interval_ComboBox_KeyDown);
            // 
            // txt_DefaultQty
            // 
            this.txt_DefaultQty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_DefaultQty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DefaultQty.Location = new System.Drawing.Point(103, 93);
            this.txt_DefaultQty.Name = "txt_DefaultQty";
            this.txt_DefaultQty.Size = new System.Drawing.Size(278, 26);
            this.txt_DefaultQty.TabIndex = 4;
            this.txt_DefaultQty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_DefaultQty_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 30);
            this.label11.TabIndex = 17;
            this.label11.Text = "Instructions";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_Dose
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txt_Dose, 5);
            this.txt_Dose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_Dose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dose.Location = new System.Drawing.Point(487, 33);
            this.txt_Dose.Name = "txt_Dose";
            this.txt_Dose.Size = new System.Drawing.Size(202, 26);
            this.txt_Dose.TabIndex = 9;
            this.txt_Dose.Text = "0";
            this.txt_Dose.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfdose_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 30);
            this.label9.TabIndex = 14;
            this.label9.Text = "Default Qty";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 30);
            this.label8.TabIndex = 13;
            this.label8.Text = "Divided Doses";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(387, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 30);
            this.label7.TabIndex = 12;
            this.label7.Text = "Dose/Kg/Day";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(387, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 30);
            this.label6.TabIndex = 11;
            this.label6.Text = "Strength";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(387, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 30);
            this.label3.TabIndex = 5;
            this.label3.Text = "Interval";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 30);
            this.label2.TabIndex = 3;
            this.label2.Text = "Medicine";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RdoAgebased
            // 
            this.RdoAgebased.AutoSize = true;
            this.RdoAgebased.Location = new System.Drawing.Point(100, 1);
            this.RdoAgebased.Name = "RdoAgebased";
            this.RdoAgebased.Size = new System.Drawing.Size(77, 17);
            this.RdoAgebased.TabIndex = 44;
            this.RdoAgebased.Text = "Age Based";
            this.RdoAgebased.UseVisualStyleBackColor = true;
            this.RdoAgebased.CheckedChanged += new System.EventHandler(this.RdoAgebased_CheckedChanged);
            // 
            // RdoWeightbased
            // 
            this.RdoWeightbased.AutoSize = true;
            this.RdoWeightbased.Location = new System.Drawing.Point(3, 1);
            this.RdoWeightbased.Name = "RdoWeightbased";
            this.RdoWeightbased.Size = new System.Drawing.Size(91, 17);
            this.RdoWeightbased.TabIndex = 45;
            this.RdoWeightbased.Text = "Weight based";
            this.RdoWeightbased.UseVisualStyleBackColor = true;
            this.RdoWeightbased.CheckedChanged += new System.EventHandler(this.RdoWeightbased_CheckedChanged);
            // 
            // Rdofixed
            // 
            this.Rdofixed.AutoSize = true;
            this.Rdofixed.Location = new System.Drawing.Point(183, 1);
            this.Rdofixed.Name = "Rdofixed";
            this.Rdofixed.Size = new System.Drawing.Size(78, 17);
            this.Rdofixed.TabIndex = 43;
            this.Rdofixed.Text = "Fixed Dose";
            this.Rdofixed.UseVisualStyleBackColor = true;
            this.Rdofixed.CheckedChanged += new System.EventHandler(this.Rdofixed_CheckedChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 9;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Controls.Add(this.label17, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txttamil, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.Drug_ComboBox, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.strength_ComboBox, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt2_strength, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.txt_Itemcode, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.strength1_ComboBox, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtinstruction, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txt1_strength, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.Interval_ComboBox, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txt_DefaultQty, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.txt_Dose, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.Duration, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.cbdrugtype, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.dgv_date, 8, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 311);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1010, 229);
            this.tableLayoutPanel1.TabIndex = 51;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Rdofixed);
            this.panel1.Controls.Add(this.RdoWeightbased);
            this.panel1.Controls.Add(this.RdoAgebased);
            this.panel1.Controls.Add(this.txtfdose);
            this.panel1.Location = new System.Drawing.Point(695, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(311, 19);
            this.panel1.TabIndex = 51;
            // 
            // panel2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel2, 7);
            this.panel2.Controls.Add(this.btndrugtype);
            this.panel2.Controls.Add(this.BtnNew);
            this.panel2.Controls.Add(this.BtnAdd);
            this.panel2.Controls.Add(this.BtnRemove);
            this.panel2.Controls.Add(this.BtnUpdate);
            this.panel2.Controls.Add(this.btn_clr);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(387, 183);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(620, 29);
            this.panel2.TabIndex = 52;
            // 
            // btndrugtype
            // 
            this.btndrugtype.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btndrugtype.Location = new System.Drawing.Point(170, 3);
            this.btndrugtype.Name = "btndrugtype";
            this.btndrugtype.Size = new System.Drawing.Size(77, 23);
            this.btndrugtype.TabIndex = 34;
            this.btndrugtype.Text = "Add Drug Type";
            this.btndrugtype.Click += new System.EventHandler(this.btndrugtype_Click);
            // 
            // BtnNew
            // 
            this.BtnNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnNew.Location = new System.Drawing.Point(253, 3);
            this.BtnNew.Name = "BtnNew";
            this.BtnNew.Size = new System.Drawing.Size(68, 23);
            this.BtnNew.TabIndex = 34;
            this.BtnNew.Text = "New";
            this.BtnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnAdd.Location = new System.Drawing.Point(327, 3);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(68, 23);
            this.BtnAdd.TabIndex = 15;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnRemove
            // 
            this.BtnRemove.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnRemove.Location = new System.Drawing.Point(401, 3);
            this.BtnRemove.Name = "BtnRemove";
            this.BtnRemove.Size = new System.Drawing.Size(68, 23);
            this.BtnRemove.TabIndex = 16;
            this.BtnRemove.Text = "Remove";
            this.BtnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnUpdate.Location = new System.Drawing.Point(475, 3);
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(68, 23);
            this.BtnUpdate.TabIndex = 17;
            this.BtnUpdate.Text = "Update";
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click);
            // 
            // btn_clr
            // 
            this.btn_clr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_clr.Location = new System.Drawing.Point(549, 3);
            this.btn_clr.Name = "btn_clr";
            this.btn_clr.Size = new System.Drawing.Size(68, 23);
            this.btn_clr.TabIndex = 18;
            this.btn_clr.Text = "Clear";
            this.btn_clr.Click += new System.EventHandler(this.btn_clr_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 235F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1016, 543);
            this.tableLayoutPanel2.TabIndex = 52;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1010, 302);
            this.dataGridView1.TabIndex = 52;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // NewDrug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "NewDrug";
            this.Size = new System.Drawing.Size(1016, 543);
            this.Load += new System.EventHandler(this.drug_Load);
            this.VisibleChanged += new System.EventHandler(this.NewDrug_VisibleChanged);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_date)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtfdose;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttamil;
        private System.Windows.Forms.DataGridView dgv_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn FromMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn ToYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ToMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn DoseInUnits;
        private System.Windows.Forms.TextBox Drug_ComboBox;
        private System.Windows.Forms.ComboBox cbdrugtype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Duration;
        private System.Windows.Forms.TextBox txt_Itemcode;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtinstruction;
        private MetroFramework.Controls.MetroButton btn_clr;
        private MetroFramework.Controls.MetroButton BtnUpdate;
        private MetroFramework.Controls.MetroButton BtnRemove;
        private MetroFramework.Controls.MetroButton BtnAdd;
        private MetroFramework.Controls.MetroButton BtnNew;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox strength_ComboBox;
        private System.Windows.Forms.TextBox txt2_strength;
        private System.Windows.Forms.ComboBox strength1_ComboBox;
        private System.Windows.Forms.TextBox txt1_strength;
        private System.Windows.Forms.ComboBox Interval_ComboBox;
        private System.Windows.Forms.TextBox txt_DefaultQty;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_Dose;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton RdoAgebased;
        private System.Windows.Forms.RadioButton RdoWeightbased;
        private System.Windows.Forms.RadioButton Rdofixed;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private MetroFramework.Controls.MetroButton btndrugtype;
    }
}
