﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using SVMApplication.Helper;

namespace SVMApplication
{
    public partial class Search : MetroFramework.Forms.MetroForm
    {
        public static NewPrescription t = null;
        public Search(NewPrescription _t)
        {
            InitializeComponent();
            this.TopMost = true;
            t = _t;
            phoneload();
            nameload();
            IDLoad();
            ctrlSearchto.Value = DateTime.Now;
            ctrlSearchfrom.Value = DateTime.Today.AddMonths(-1);
        }
        private void nameload()
        {

            using (SqlConnection con = new SqlConnection(t.constr))
            {
                SqlCommand cmd = new SqlCommand("select Name from regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtSearchName.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }
        private void phoneload()
        {

            using (SqlConnection con = new SqlConnection(t.constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT PhoneNo FROM regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtSearchMobileNo.AutoCompleteCustomSource = MyCollection;

                con.Close();
            }
        }
        private void IDLoad()
        {
            //using (SqlConnection con = new SqlConnection(t.constr))
            //{
            //    SqlCommand cmd = new SqlCommand("SELECT PatiantID FROM [regappform3] where convert(varchar(10), Date,120) =  CONVERT(date, getdate()) order by Date desc", con);
            //    con.Open();
            //    SqlDataReader reader = cmd.ExecuteReader();
            //    AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
            //    while (reader.Read())
            //        MyCollection.Add(reader.GetString(0));
            //    txtSearchID.AutoCompleteCustomSource = MyCollection;
            //    con.Close();
            //}

            using (SqlConnection con = new SqlConnection(t.constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT PatiantID FROM [regappform3] where (PatiantID!='' And Hospital_Id=@ID And DoctorCode =@doctorCode)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();

                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                txtSearchID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
           // DoVisible(true);
            DataSet ds = t.LoadOldPrescriptionDS(ctrlSearchfrom.Value, ctrlSearchto.Value, DateCheck.Checked, " ", txtSearchID.Text.StartsWith(AppMain.DoctorCode) ? txtSearchID.Text : $"{AppMain.DoctorCode} - " + txtSearchID.Text, txtSearchEPresNo.Text, txtSearchName.Text, txtSearchMobileNo.Text);

            if (ds.Tables[0].Rows.Count == 0) { MessageBox.Show("No Data to Display!"); return; }
            OpView _op = new OpView(ds);
            _op.TopMost = true;
            _op.ShowDialog();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DateCheck_CheckedChanged(object sender, EventArgs e)
        {
            ctrlSearchfrom.Enabled = DateCheck.Checked;
            ctrlSearchto.Enabled = DateCheck.Checked;
        }
    }
}
