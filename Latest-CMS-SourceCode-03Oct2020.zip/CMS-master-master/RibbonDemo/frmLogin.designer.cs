﻿namespace SVMApplication
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.ctrlChkShowPassword = new System.Windows.Forms.CheckBox();
            this.ctrlCbxUser = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtUserName = new MetroFramework.Controls.MetroTextBox();
            this.ctrlTxtPassword = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.ctrlBtnLogin = new MetroFramework.Controls.MetroButton();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.ctrlChkSavePassword = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // ctrlChkShowPassword
            // 
            this.ctrlChkShowPassword.Location = new System.Drawing.Point(151, 232);
            this.ctrlChkShowPassword.Name = "ctrlChkShowPassword";
            this.ctrlChkShowPassword.Size = new System.Drawing.Size(15, 17);
            this.ctrlChkShowPassword.TabIndex = 7;
            this.ctrlChkShowPassword.UseVisualStyleBackColor = true;
            this.ctrlChkShowPassword.CheckedChanged += new System.EventHandler(this.Password_CheckedChanged);
            // 
            // ctrlCbxUser
            // 
            this.ctrlCbxUser.FormattingEnabled = true;
            this.ctrlCbxUser.ItemHeight = 23;
            this.ctrlCbxUser.Location = new System.Drawing.Point(153, 177);
            this.ctrlCbxUser.Name = "ctrlCbxUser";
            this.ctrlCbxUser.Size = new System.Drawing.Size(270, 29);
            this.ctrlCbxUser.TabIndex = 5;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(23, 84);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(83, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "User Name";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(23, 141);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(73, 19);
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "Password";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(23, 187);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(93, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Type of User";
            // 
            // ctrlTxtUserName
            // 
            this.ctrlTxtUserName.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.ctrlTxtUserName.Location = new System.Drawing.Point(153, 63);
            this.ctrlTxtUserName.Multiline = true;
            this.ctrlTxtUserName.Name = "ctrlTxtUserName";
            this.ctrlTxtUserName.PromptText = "User Name";
            this.ctrlTxtUserName.Size = new System.Drawing.Size(270, 40);
            this.ctrlTxtUserName.TabIndex = 1;
            // 
            // ctrlTxtPassword
            // 
            this.ctrlTxtPassword.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.ctrlTxtPassword.Location = new System.Drawing.Point(153, 120);
            this.ctrlTxtPassword.Name = "ctrlTxtPassword";
            this.ctrlTxtPassword.PromptText = "Password";
            this.ctrlTxtPassword.Size = new System.Drawing.Size(270, 40);
            this.ctrlTxtPassword.TabIndex = 3;
            this.ctrlTxtPassword.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(23, 230);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(113, 19);
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "Show password";
            // 
            // ctrlBtnLogin
            // 
            this.ctrlBtnLogin.Location = new System.Drawing.Point(270, 266);
            this.ctrlBtnLogin.Name = "ctrlBtnLogin";
            this.ctrlBtnLogin.Size = new System.Drawing.Size(153, 23);
            this.ctrlBtnLogin.TabIndex = 10;
            this.ctrlBtnLogin.Text = "Submit";
            this.ctrlBtnLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            this.ctrlBtnLogin.Click += new System.EventHandler(this.ctrlBtnLogin_Click);
            this.ctrlBtnLogin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ctrlBtnLogin_KeyDown);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(282, 230);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(109, 19);
            this.metroLabel5.TabIndex = 8;
            this.metroLabel5.Text = "Save password";
            // 
            // ctrlChkSavePassword
            // 
            this.ctrlChkSavePassword.Location = new System.Drawing.Point(406, 232);
            this.ctrlChkSavePassword.Name = "ctrlChkSavePassword";
            this.ctrlChkSavePassword.Size = new System.Drawing.Size(15, 17);
            this.ctrlChkSavePassword.TabIndex = 9;
            this.ctrlChkSavePassword.UseVisualStyleBackColor = true;
            this.ctrlChkSavePassword.CheckedChanged += new System.EventHandler(this.ctrlChkSavePassword_CheckedChanged);
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(446, 301);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.ctrlChkSavePassword);
            this.Controls.Add(this.ctrlBtnLogin);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.ctrlTxtPassword);
            this.Controls.Add(this.ctrlTxtUserName);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.ctrlCbxUser);
            this.Controls.Add(this.ctrlChkShowPassword);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLogin";
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.None;
            this.Text = "CMS Login";
            this.TextAlign = System.Windows.Forms.VisualStyles.HorizontalAlign.Center;
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmLogin_FormClosed);
            this.Load += new System.EventHandler(this.frmLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox ctrlChkShowPassword;
        private MetroFramework.Controls.MetroComboBox ctrlCbxUser;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox ctrlTxtUserName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtPassword;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroButton ctrlBtnLogin;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.CheckBox ctrlChkSavePassword;
    }
}