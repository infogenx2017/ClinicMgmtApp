﻿using MetroFramework;

namespace SVMApplication
{
    partial class NewVaccineBirthChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.VaccineChartGrid = new System.Windows.Forms.DataGridView();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.lblID = new MetroFramework.Controls.MetroLabel();
            this.lblName = new MetroFramework.Controls.MetroLabel();
            this.lblDOB = new MetroFramework.Controls.MetroLabel();
            this.btnsave = new MetroFramework.Controls.MetroButton();
            this.btnprint = new MetroFramework.Controls.MetroButton();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.lbl12 = new MetroFramework.Controls.MetroLabel();
            this.LblGender = new MetroFramework.Controls.MetroLabel();
            this.txtfullyvaccinater = new MetroFramework.Controls.MetroButton();
            this.btnFlu = new MetroFramework.Controls.MetroButton();
            this.btnRabies = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.VaccineChartGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(-1, 484);
            this.lblRowID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(14, 20);
            this.lblRowID.TabIndex = 28;
            this.lblRowID.Text = "1";
            this.lblRowID.Visible = false;
            // 
            // VaccineChartGrid
            // 
            this.VaccineChartGrid.AllowUserToAddRows = false;
            this.VaccineChartGrid.AllowUserToDeleteRows = false;
            this.VaccineChartGrid.AllowUserToOrderColumns = true;
            this.VaccineChartGrid.AllowUserToResizeRows = false;
            this.VaccineChartGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.VaccineChartGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.VaccineChartGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.VaccineChartGrid.ColumnHeadersHeight = 34;
            this.VaccineChartGrid.Location = new System.Drawing.Point(35, 135);
            this.VaccineChartGrid.Margin = new System.Windows.Forms.Padding(4);
            this.VaccineChartGrid.Name = "VaccineChartGrid";
            this.VaccineChartGrid.RowHeadersVisible = false;
            this.VaccineChartGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.VaccineChartGrid.Size = new System.Drawing.Size(1246, 544);
            this.VaccineChartGrid.TabIndex = 27;
            this.VaccineChartGrid.EditModeChanged += new System.EventHandler(this.VaccineChartGrid_EditModeChanged);
            this.VaccineChartGrid.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.VaccineChartGrid_CellBeginEdit);
            this.VaccineChartGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.VaccineChartGrid.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellContentDoubleClick);
            this.VaccineChartGrid.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellDoubleClick);
            this.VaccineChartGrid.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellEndEdit);
            this.VaccineChartGrid.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.VaccineChartGrid_CellMouseClick);
            this.VaccineChartGrid.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.VaccineChartGrid_CellMouseDoubleClick);
            this.VaccineChartGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.VaccineChartGrid_CellValueChanged);
            this.VaccineChartGrid.CurrentCellDirtyStateChanged += new System.EventHandler(this.VaccineChartGrid_CurrentCellDirtyStateChanged);
            this.VaccineChartGrid.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.VaccineChartGrid_EditingControlShowing);
            this.VaccineChartGrid.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.VaccineChartGrid_RowsAdded);
            this.VaccineChartGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.VaccineChartGrid_KeyDown);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(32, 67);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(67, 20);
            this.metroLabel1.TabIndex = 39;
            this.metroLabel1.Text = "Patient ID";
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(1041, 67);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(87, 20);
            this.metroLabel2.TabIndex = 39;
            this.metroLabel2.Text = "Date of Birth";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(32, 102);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(92, 20);
            this.metroLabel3.TabIndex = 39;
            this.metroLabel3.Text = "Patient Name";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.FontSize = MetroLabelSize.Tall;
            this.lblID.FontWeight =  MetroLabelWeight.Bold;
            this.lblID.Location = new System.Drawing.Point(129, 64);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(100, 25);
            this.lblID.TabIndex = 39;
            this.lblID.Text = "Patient ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.FontSize = MetroLabelSize.Tall;
            this.lblName.FontWeight =  MetroLabelWeight.Bold;
            this.lblName.Location = new System.Drawing.Point(129, 99);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(132, 25);
            this.lblName.TabIndex = 39;
            this.lblName.Text = "Patient Name";
            // 
            // lblDOB
            // 
            this.lblDOB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDOB.AutoSize = true;
            this.lblDOB.FontSize = MetroLabelSize.Tall;
            this.lblDOB.FontWeight =  MetroLabelWeight.Bold;
            this.lblDOB.Location = new System.Drawing.Point(1152, 62);
            this.lblDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(126, 25);
            this.lblDOB.TabIndex = 39;
            this.lblDOB.Text = "Date of Birth";
            // 
            // btnsave
            // 
            this.btnsave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnsave.Location = new System.Drawing.Point(910, 692);
            this.btnsave.Margin = new System.Windows.Forms.Padding(4);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(182, 28);
            this.btnsave.TabIndex = 40;
            this.btnsave.Text = "Save";
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnprint
            // 
            this.btnprint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnprint.Location = new System.Drawing.Point(720, 692);
            this.btnprint.Margin = new System.Windows.Forms.Padding(4);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(182, 28);
            this.btnprint.TabIndex = 41;
            this.btnprint.Text = "Print";
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // btnexit
            // 
            this.btnexit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(1100, 692);
            this.btnexit.Margin = new System.Windows.Forms.Padding(4);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(182, 28);
            this.btnexit.TabIndex = 42;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lbl12
            // 
            this.lbl12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl12.AutoSize = true;
            this.lbl12.Location = new System.Drawing.Point(1041, 102);
            this.lbl12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(56, 20);
            this.lbl12.TabIndex = 39;
            this.lbl12.Text = "Gender";
            // 
            // LblGender
            // 
            this.LblGender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LblGender.AutoSize = true;
            this.LblGender.FontSize = MetroLabelSize.Tall;
            this.LblGender.FontWeight =  MetroLabelWeight.Bold;
            this.LblGender.Location = new System.Drawing.Point(1152, 97);
            this.LblGender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblGender.Name = "LblGender";
            this.LblGender.Size = new System.Drawing.Size(78, 25);
            this.LblGender.TabIndex = 39;
            this.LblGender.Text = "Gender";
            // 
            // txtfullyvaccinater
            // 
            this.txtfullyvaccinater.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtfullyvaccinater.Location = new System.Drawing.Point(530, 692);
            this.txtfullyvaccinater.Margin = new System.Windows.Forms.Padding(4);
            this.txtfullyvaccinater.Name = "txtfullyvaccinater";
            this.txtfullyvaccinater.Size = new System.Drawing.Size(182, 28);
            this.txtfullyvaccinater.TabIndex = 41;
            this.txtfullyvaccinater.Text = "Vaccination status till date";
            this.txtfullyvaccinater.Click += new System.EventHandler(this.txtfullyvaccinater_Click);
            // 
            // btnFlu
            // 
            this.btnFlu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFlu.Location = new System.Drawing.Point(340, 692);
            this.btnFlu.Margin = new System.Windows.Forms.Padding(4);
            this.btnFlu.Name = "btnFlu";
            this.btnFlu.Size = new System.Drawing.Size(182, 28);
            this.btnFlu.TabIndex = 41;
            this.btnFlu.Text = "Flu / Typhoid";
            this.btnFlu.Click += new System.EventHandler(this.btnFlu_Click);
            // 
            // btnRabies
            // 
            this.btnRabies.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRabies.Location = new System.Drawing.Point(150, 692);
            this.btnRabies.Margin = new System.Windows.Forms.Padding(4);
            this.btnRabies.Name = "btnRabies";
            this.btnRabies.Size = new System.Drawing.Size(182, 28);
            this.btnRabies.TabIndex = 41;
            this.btnRabies.Text = "Anti-Rabies";
            this.btnRabies.Click += new System.EventHandler(this.btnRabies_Click);
            // 
            // NewVaccineBirthChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1315, 738);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnRabies);
            this.Controls.Add(this.btnFlu);
            this.Controls.Add(this.txtfullyvaccinater);
            this.Controls.Add(this.btnprint);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.LblGender);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lblDOB);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.VaccineChartGrid);
            this.MaximizeBox = false;
            this.Name = "NewVaccineBirthChart";
            this.Text = "Vaccine Chart ...";
            this.Load += new System.EventHandler(this.NewVaccineChart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.VaccineChartGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRowID;
        private System.Windows.Forms.DataGridView VaccineChartGrid;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel lblID;
        private MetroFramework.Controls.MetroLabel lblName;
        private MetroFramework.Controls.MetroLabel lblDOB;
        private MetroFramework.Controls.MetroButton btnsave;
        private MetroFramework.Controls.MetroButton btnprint;
        private MetroFramework.Controls.MetroButton btnexit;
        private MetroFramework.Controls.MetroLabel lbl12;
        private MetroFramework.Controls.MetroLabel LblGender;
        private MetroFramework.Controls.MetroButton txtfullyvaccinater;
        private MetroFramework.Controls.MetroButton btnFlu;
        private MetroFramework.Controls.MetroButton btnRabies;
    }
}