﻿using MetroFramework;

namespace SVMApplication
{
    partial class FullyVaccinatedtillDate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnokay = new MetroFramework.Controls.MetroButton();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.radioGvt = new System.Windows.Forms.RadioButton();
            this.radioPvt = new System.Windows.Forms.RadioButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtGivenPlace = new MetroFramework.Controls.MetroTextBox();
            this.SuspendLayout();
            // 
            // btnokay
            // 
            this.btnokay.Location = new System.Drawing.Point(285, 176);
            this.btnokay.Margin = new System.Windows.Forms.Padding(4);
            this.btnokay.Name = "btnokay";
            this.btnokay.Size = new System.Drawing.Size(90, 28);
            this.btnokay.TabIndex = 25;
            this.btnokay.Text = "OK";
            this.btnokay.Click += new System.EventHandler(this.btnokay_Click);
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.Appearance = System.Windows.Forms.Appearance.Button;
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.Location = new System.Drawing.Point(0, 0);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.TabIndex = 0;
            this.metroRadioButton1.Text = "Government";
            this.metroRadioButton1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroRadioButton1.UseVisualStyleBackColor = false;
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.Location = new System.Drawing.Point(0, 0);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.TabIndex = 0;
            this.metroRadioButton2.UseVisualStyleBackColor = false;
            // 
            // radioGvt
            // 
            this.radioGvt.AutoSize = true;
            this.radioGvt.Location = new System.Drawing.Point(23, 106);
            this.radioGvt.Name = "radioGvt";
            this.radioGvt.Size = new System.Drawing.Size(145, 21);
            this.radioGvt.TabIndex = 26;
            this.radioGvt.TabStop = true;
            this.radioGvt.Text = "Essential vaccines";
            this.radioGvt.UseVisualStyleBackColor = true;
            this.radioGvt.CheckedChanged += new System.EventHandler(this.radioGvt_CheckedChanged);
            // 
            // radioPvt
            // 
            this.radioPvt.AutoSize = true;
            this.radioPvt.Location = new System.Drawing.Point(193, 106);
            this.radioPvt.Name = "radioPvt";
            this.radioPvt.Size = new System.Drawing.Size(103, 21);
            this.radioPvt.TabIndex = 27;
            this.radioPvt.TabStop = true;
            this.radioPvt.Text = "All vaccines";
            this.radioPvt.UseVisualStyleBackColor = true;
            this.radioPvt.CheckedChanged += new System.EventHandler(this.radioGvt_CheckedChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroLabelSize.Tall;
            this.metroLabel1.Location = new System.Drawing.Point(23, 71);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(364, 25);
            this.metroLabel1.TabIndex = 28;
            this.metroLabel1.Text = "Kindly choose which Sector you vaccinated ?";
            // 
            // txtGivenPlace
            // 
            this.txtGivenPlace.FontSize = MetroTextBoxSize.Medium;
            this.txtGivenPlace.Location = new System.Drawing.Point(23, 133);
            this.txtGivenPlace.Name = "txtGivenPlace";
            this.txtGivenPlace.PromptText = "Given Place ?";
            this.txtGivenPlace.Size = new System.Drawing.Size(352, 30);
            this.txtGivenPlace.TabIndex = 29;
            // 
            // FullyVaccinatedtillDate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 218);
            this.ControlBox = false;
            this.Controls.Add(this.txtGivenPlace);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.radioPvt);
            this.Controls.Add(this.radioGvt);
            this.Controls.Add(this.btnokay);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FullyVaccinatedtillDate";
            this.Resizable = false;
            this.Text = "Vaccination status till today ...";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnokay;
        private System.Windows.Forms.RadioButton radioGvt;
        private System.Windows.Forms.RadioButton radioPvt;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtGivenPlace;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton1;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton2;
    }
}