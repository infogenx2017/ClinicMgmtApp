﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using SVMApplication.Helper;
using ExcelIntegration;

namespace SVMApplication
{
    public partial class ViewCMSreport : UserControl
    {
        string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public ViewCMSreport()
        {
            InitializeComponent();
        }

        public void PatientStatusLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }

                }
                ctrlCbxStatus.Items.Insert(0, new ComboboxItem(-1, "ALL"));
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        private void ctrlChkToday_CheckedChanged(object sender, EventArgs e)
        {
            if (ctrlChkToday.Checked)
            {
                ctrlChkAdvance.Checked = false;
            }
        }

        private void ctrlChkAdvance_CheckedChanged(object sender, EventArgs e)
        {
            if (ctrlChkAdvance.Checked)
            {
                ctrlChkToday.Checked = false;
            }
        }

        private void ctrlBtnSearch_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void Search()
        {
            GetPaymentDetails();
           
        }

        private void GetPaymentDetails()
        {
            SqlConnection con = new SqlConnection(constr);
            {
                SqlCommand cmd = new SqlCommand("GetCMSDetails", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();


                cmd.Parameters.AddWithValue("@type", ctrlCbxStatus.Text);
                cmd.Parameters.AddWithValue("@dCode", AppMain.DoctorCode);
                cmd.Parameters.AddWithValue("@serach", ctrlChkAdvance.Checked ? 'B' : 'A');
                cmd.Parameters.AddWithValue("@start", ctrlDateStart.Value);
                cmd.Parameters.AddWithValue("@end", ctrlDateEnd.Value);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                ctrlGridAppointmentList.DataSource = table;
            }
        }

  

        private void ViewPAyment_Load(object sender, EventArgs e)
        {
            PatientStatusLoad();
            Search();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            ctrlGridAppointmentList.DataSource = null;
           
        }

        private void ctrlCbxStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            Search();
        }

        private void MetroButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if(ctrlGridAppointmentList.Rows.Count>0)
                {
                    ExcelData excelData = new ExcelData();
                    foreach (DataGridViewRow item in ctrlGridAppointmentList.Rows)
                    {
                        
                        string epresno =Convert.ToString(item.Cells["EPres NO"].Value);
                        string P_Name = Convert.ToString(item.Cells["P_Name"].Value);
                        string address = Convert.ToString(item.Cells["Address"].Value);
                        string contact = Convert.ToString(item.Cells["Contact No"].Value);
                        string age = Convert.ToString(item.Cells["Age"].Value);
                        string gender = Convert.ToString(item.Cells["Gender"].Value);
                        string labInvestigations = Convert.ToString(item.Cells["LabInvestigations"].Value);
                        string addtionalInformation = Convert.ToString(item.Cells["AddtionalInformation"].Value);
                        string patientStatus = Convert.ToString(item.Cells["Patient Status"].Value);
                        string datedetails = Convert.ToString(item.Cells["DateDetails"].Value);
                        string area = Convert.ToString(item.Cells["Area"].Value);
                        string patientId = Convert.ToString(item.Cells["PatiantID"].Value);
                        string date = Convert.ToString(item.Cells["Date"].Value);
                        string apNo = Convert.ToString(item.Cells["ApNo"].Value);
                        string dateOfBirth = Convert.ToString(item.Cells["DateOfBirth"].Value);
                        string diagnosisRowID = Convert.ToString(item.Cells["DiagnosisRowID"].Value);
                        int diogonisId = string.IsNullOrWhiteSpace(diagnosisRowID) ? -1 : Convert.ToInt32(diagnosisRowID);

                        string finalDiagnosisId = Convert.ToString(item.Cells["FinalDiagnosisId"].Value);
                        int finalDiogonisId = string.IsNullOrWhiteSpace(finalDiagnosisId) ? -1 : Convert.ToInt32(finalDiagnosisId);

                       
                        excelData.CommonDetails = new CommonDetails()
                        {

                            RegistrationNo = "78365GHJ76",
                            NameOfDoctor = "Dr.S.Srinivas.MBBS,DCH",
                            RegisterOfPatients = "",
                            Date = DateTime.Now.ToShortDateString(),
                            Footer1 = "Note : If electronic records are maintained and / or existing registers capture this information,a monthly print",
                            Footer2 = "outs / copy shall be taken authenticated by the hospital authorities"
                        };
                        excelData.PatientDetails.Add(new PatientDetails()
                        {
                            SNo = (item.Index+1).ToString(),
                            PatientName = P_Name,
                            Address = address,
                            ContactNo = contact,
                            Age = age,
                            PatienSextName = gender,
                            ProvisDiagnosis = new GeneralMethods().GetDiagnosisName(diogonisId),
                            Investigation = GetLabInvestigations(labInvestigations),
                            FinalDiagnosis = new GeneralMethods().GetDiagnosisName(finalDiogonisId),
                            Treatment = new GeneralMethods().GetTreatmentBasedonEpres(epresno),
                            Result = patientStatus,
                            AddtionalInformation = addtionalInformation,
                            InitialOfMedOfficer = ""
                        });                 
                    }

                    ExcelManager excelManager = new ExcelManager();
                    excelManager.GenerateExcel(excelData);

                }
            }
            catch (Exception)
            {

               
            }

          
        }

        private string GetLabInvestigations(string joinString)
        {
            try
            {
                List<int> id = new List<int>();
                if (!joinString.Contains("-"))
                {
                    id.Add(Convert.ToInt32(joinString));
                }
                else
                {
                    var splitArray = joinString.Split('-');
                    for (int i = 0; i < splitArray.Length; i++)
                    {
                        id.Add(Convert.ToInt32(splitArray[i]));
                    }
                }

                List<string> labInvest = new List<string>();

                using (SqlConnection con = new SqlConnection(constr))
                {
                    ctrlCbxStatus.Items.Clear();
                    SqlCommand cmd = new SqlCommand("select * from labinvestigation", con);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {
                            if (id.Contains(reader.GetInt32(0)))
                                labInvest.Add(reader.GetString(1));
                        }

                    }

                    con.Close();
                }

                if (labInvest.Count > 0)
                    return string.Join(Environment.NewLine, labInvest.ToArray());
                else
                    return "";
            }
            catch (Exception)
            {

                return "";
            }
         
        }
    }
}
