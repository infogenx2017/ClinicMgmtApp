﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class frmConfirmSave : Form
    {
         string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();



        public string CashType
        {
            get { return ctrlCbxCashType.Text; }
            private set { ctrlCbxCashType.Text = value; }
        }


        public string HaveInsurance
        {
            get { return ctrlCbxInsurance.Text; }
            private set { ctrlCbxInsurance.Text = value; }
        }

        public int FinalDiagonisID
        {
            get { return new GeneralMethods().GetDiagnosis(txtDiagnosis.Text) ; }
           
        }


        public frmConfirmSave()
        {
            InitializeComponent();
            LoadCategory();
            ctrlDateReview.Value = DateTime.Today.AddDays(2);
            ctrlCbxCashType.SelectedIndex = 0;
            ctrlCbxInsurance.SelectedIndex = 0;
            lblDiogonis.Enabled = false;
            txtDiagnosis.Enabled = false;
        }

        public frmConfirmSave(string txtDiognis)
        {
            InitializeComponent();
            LoadCategory();
            ctrlDateReview.Value = DateTime.Today.AddDays(2);
            ctrlCbxCashType.SelectedIndex = 0;
            ctrlCbxInsurance.SelectedIndex = 0;

            if(!string.IsNullOrWhiteSpace(txtDiognis))
            {
                lblDiogonis.Enabled = true;
                txtDiagnosis.Enabled = true;
                txtDiagnosis.Text = txtDiognis;
            }
            else
            {
                lblDiogonis.Enabled = false;
                txtDiagnosis.Enabled = false;
            }
        }

        void LoadCategory()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select RowID,Category,Amount from AmountCategory ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbCategory.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
                cbCategory.ValueMember = "RowID";
                cbCategory.DisplayMember = "Category";
                con.Close();
                cbCategory.SelectedIndex = 0;
            }

        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cm = new SqlCommand("select count(*) from Diagnosis where Diagnosis='" + txtDiagnosis.Text + "'", con);
                int count = Convert.ToInt32(cm.ExecuteScalar());

                if (count == 0)
                {
                    SqlCommand cmds = new SqlCommand("insert into Diagnosis(Diagnosis) values('" + txtDiagnosis.Text + "')", con);
                    cmds.ExecuteNonQuery();
                }
            }
        
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void FrmConfirmSave_Load(object sender, EventArgs e)
        {
            new GeneralMethods().LoadDiagnosis(ref txtDiagnosis);
        }
    }
}
