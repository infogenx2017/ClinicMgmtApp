﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using SVMApplication.Helper;

namespace SVMApplication
{
    public partial class frmFluVaccineReortViewer : Form
    {
        // PrescriptionPrint prescriptionPrint = null;
        public DataSet VaccineDataset = null;
        public DateTime? DOB = null;
        public string PatientID = string.Empty; public string PatientName = string.Empty;
        public bool IsDirectPrint = false;

        public frmFluVaccineReortViewer(DateTime _DOB, string _PatientID, string _PatientName)
        {
            InitializeComponent();
            VaccineDataset = new DataSet(); DOB = _DOB; PatientID = _PatientID; PatientName = _PatientName;
        }

        private void frmReortViewer_Load(object sender, EventArgs e)
        {
            if (IsDirectPrint)
                DirectPrintChecked();
            else
                ReportPrintwithPreview();
        }

        private void ReportPrintwithPreview()
        {
            var res = VaccineDataset.Tables["Vaccine"];
            var cr = new ReportDocument();
            cr.Load(@"C:\Report\FluVaccineReport.rpt");
            cr.SetDatabaseLogon(AppMain.DbUser, AppMain.DbPassword);
            cr.SetParameterValue(0, DOB); cr.SetParameterValue(1, PatientID); cr.SetParameterValue(2, PatientName);
           // cr.Database.Tables[0].SetDataSource(VaccineDataset.Tables["Vaccine"]);
            ctrlViwerPrescritionreportViewer.ReportSource = null;
            ctrlViwerPrescritionreportViewer.ReportSource = cr;
            ctrlViwerPrescritionreportViewer.Refresh();
        }


        private void DirectPrintChecked()
        {

            var rprt = new ReportDocument();
            rprt.Load(@"C:\Report\FluVaccineReport.rpt");
            rprt.SetDatabaseLogon(AppMain.DbUser, AppMain.DbPassword);
            rprt.SetParameterValue(0, DOB); rprt.SetParameterValue(1, PatientID); rprt.SetParameterValue(2, PatientName);

            ctrlViwerPrescritionreportViewer.ReportSource = rprt;
            ctrlViwerPrescritionreportViewer.Refresh();
            rprt.PrintToPrinter(1, true, 1, 1);
        }
    }
}
