﻿namespace SVMApplication
{
    partial class NewAge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRowID = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtAge = new MetroFramework.Controls.MetroTextBox();
            this.btnsave = new MetroFramework.Controls.MetroButton();
            this.btnclear = new MetroFramework.Controls.MetroButton();
            this.btndelete = new MetroFramework.Controls.MetroButton();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.AgeGrid = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.AgeGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRowID
            // 
            this.lblRowID.AutoSize = true;
            this.lblRowID.Location = new System.Drawing.Point(24, 284);
            this.lblRowID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRowID.Name = "lblRowID";
            this.lblRowID.Size = new System.Drawing.Size(14, 20);
            this.lblRowID.TabIndex = 18;
            this.lblRowID.Text = "1";
            this.lblRowID.Visible = false;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(26, 262);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(34, 20);
            this.metroLabel1.TabIndex = 19;
            this.metroLabel1.Text = "Age";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(72, 260);
            this.txtAge.Margin = new System.Windows.Forms.Padding(4);
            this.txtAge.Name = "txtAge";
            this.txtAge.PromptText = "Enter Age";
            this.txtAge.Size = new System.Drawing.Size(262, 28);
            this.txtAge.TabIndex = 22;
            this.txtAge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_KeyDown);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(22, 307);
            this.btnsave.Margin = new System.Windows.Forms.Padding(4);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(72, 28);
            this.btnsave.TabIndex = 23;
            this.btnsave.Text = "Save";
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(102, 307);
            this.btnclear.Margin = new System.Windows.Forms.Padding(4);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(72, 28);
            this.btnclear.TabIndex = 24;
            this.btnclear.Text = "New";
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(182, 307);
            this.btndelete.Margin = new System.Windows.Forms.Padding(4);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(72, 28);
            this.btndelete.TabIndex = 25;
            this.btndelete.Text = "Delete";
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnexit
            // 
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(262, 307);
            this.btnexit.Margin = new System.Windows.Forms.Padding(4);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(72, 28);
            this.btnexit.TabIndex = 26;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // AgeGrid
            // 
            this.AgeGrid.AllowUserToAddRows = false;
            this.AgeGrid.AllowUserToDeleteRows = false;
            this.AgeGrid.AllowUserToOrderColumns = true;
            this.AgeGrid.AllowUserToResizeRows = false;
            this.AgeGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AgeGrid.ColumnHeadersHeight = 34;
            this.AgeGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.AgeGrid.Location = new System.Drawing.Point(24, 64);
            this.AgeGrid.Margin = new System.Windows.Forms.Padding(4);
            this.AgeGrid.Name = "AgeGrid";
            this.AgeGrid.RowHeadersVisible = false;
            this.AgeGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AgeGrid.Size = new System.Drawing.Size(310, 185);
            this.AgeGrid.TabIndex = 17;
            this.AgeGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // NewAge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 375);
            this.Controls.Add(this.lblRowID);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.AgeGrid);
            this.MaximizeBox = false;
            this.Name = "NewAge";
            this.Text = "Age";
            this.Load += new System.EventHandler(this.NewVaccine_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AgeGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblRowID;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtAge;
        private MetroFramework.Controls.MetroButton btnsave;
        private MetroFramework.Controls.MetroButton btnclear;
        private MetroFramework.Controls.MetroButton btndelete;
        private MetroFramework.Controls.MetroButton btnexit;
        private System.Windows.Forms.DataGridView AgeGrid;
    }
}