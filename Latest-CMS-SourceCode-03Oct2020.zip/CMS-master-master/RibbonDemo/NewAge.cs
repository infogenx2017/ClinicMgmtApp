﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SVMApplication
{
    public partial class NewAge : MetroFramework.Forms.MetroForm
    {
        SqlConnection con = null;
        public NewAge()
        {
            InitializeComponent();
        }
        void LoadGrid()
        {
            using (con)
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select Age_ID,Age from Age order by Age_ID,
Age asc";
                SqlCommand cmd = new SqlCommand(querry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                AgeGrid.DataSource = ds.Tables[0];
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtAge.Text != "")
            {
                if (btnsave.Text == "Save")
                {
                    if (CheckName())
                    {
                        btnsave.Text = "Update";
                        MessageBox.Show("Age already exist");
                        return;
                    }
                    else
                    {
                        SaveMathod();
                        MessageBox.Show("Saved Successfully");
                    }
                }
                else
                {
                    SaveMathod();

                    MessageBox.Show("Updated Successfully");
                }
                LoadGrid();
                clear();
            }
            else
            {
                MessageBox.Show("Please Fill All Records");
            }
        }

        private bool CheckName()
        {
            bool rtnval = false;
            try
            {
                DataSet ds = new DataSet();
                con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @"Select Age_ID,Age from Age Where Age=@Age";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rtnval = true;
                    lblRowID.Text = ds.Tables[0].Rows[0]["Age_ID"].ToString();
                    txtAge.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                }
            }
            catch { lblRowID.Text = lblRowID.Text = AgeGrid.Rows != null ? (AgeGrid.Rows.Count + 1).ToString() : "1"; }
            return rtnval;
        }


        private string SaveMathod()
        {

            using (con)
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand("Age_SP", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Age_ID", Convert.ToInt32(lblRowID.Text));
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.ExecuteNonQuery();
            }
            return "";
        }

        private void clear()
        {
            lblRowID.Text = "";
            txtAge.Text = "";
            btnsave.Text = "Save";

        }

        private void NewVaccine_Load(object sender, EventArgs e)
        {
            LoadGrid();
            dataGridView1_CellClick(null, null);
            txtAge.Focus();
        }
        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                base.ProcessDialogKey(Keys.Tab);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ((TextBox)sender).Focus();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Rowidx = 0;
            if (e != null) Rowidx = e.RowIndex;
            clear();
            int rowIndex = AgeGrid.Rows[Rowidx].Index;
            AgeGrid.Rows[Rowidx].Cells[0].Selected = true;

            if (AgeGrid == null)
                return;
            if (AgeGrid.Rows[Rowidx].Cells[0].Selected == true)
            {
                if (Convert.ToString(AgeGrid.Rows[Rowidx].Cells[0].Value) != String.Empty)
                {
                    lblRowID.Text = AgeGrid.Rows[Rowidx].Cells[0].Value.ToString();
                    txtAge.Text = AgeGrid.Rows[Rowidx].Cells[1].Value.ToString();
                    btnsave.Text = "Update";
                }
                else
                    clear();
            }
            else
                clear();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtAge.Text != "" && lblRowID.Text != "")
            {
                DialogResult result = MessageBox.Show("Do You Want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (result.Equals(DialogResult.OK))
                {
                    using (con)
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        SqlCommand cmd = new SqlCommand("Delete From Age Where Age_ID =@Age_ID", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@Age_ID", Convert.ToInt32(lblRowID.Text));
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Deleted Successfully");
                    }
                    LoadGrid();
                    clear();
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            clear();
            lblRowID.Text = (AgeGrid.Rows.Count+1).ToString();
        }



    }
}
