﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmSearchUserConfirmation : MetroFramework.Forms.MetroForm
    {
        public int SelectedIndex = 0;
        public frmSearchUserConfirmation(DataTable table)
        {
            InitializeComponent();
            SelectedIndex = 0;
            ctrlGridSearchUsers.DataSource = table;
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            SelectedIndex =0;
            this.Close();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            int index = ctrlGridSearchUsers.CurrentRow.Index;
            SelectedIndex = index;
            this.Close();
        }
    }
}
