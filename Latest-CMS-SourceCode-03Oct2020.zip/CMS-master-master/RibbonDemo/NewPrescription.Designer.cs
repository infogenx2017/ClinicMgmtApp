﻿namespace SVMApplication
{
    partial class NewPrescription
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.chkOld = new System.Windows.Forms.CheckBox();
            this.cmb_apno = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtpatiantID = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.txtDiagnosis = new System.Windows.Forms.TextBox();
            this.txtPresNo = new System.Windows.Forms.TextBox();
            this.ctrlLblPatientHis = new System.Windows.Forms.TextBox();
            this.ctrlDateDOB = new System.Windows.Forms.DateTimePicker();
            this.txtage = new System.Windows.Forms.TextBox();
            this.ctrldataGridPrescription = new System.Windows.Forms.DataGridView();
            this.SNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Medicine = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dose = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DividedDoses = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Interval = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Instructions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Instrunctions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtheight = new System.Windows.Forms.TextBox();
            this.txtweight = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.ctrlCbxAlergy = new CheckComboBoxTest.CheckedComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnsave = new MetroFramework.Controls.MetroButton();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.txtbmi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ctrlCbxStatus = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.txtClinical = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.ctrlAddClinicallabel = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlTxtFamilyHis = new System.Windows.Forms.TextBox();
            this.ctrlTxtPastIllness = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.ctrlTxtBirthHist = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_language = new System.Windows.Forms.ComboBox();
            this.ctrlTxtUHID = new System.Windows.Forms.TextBox();
            this.ctrlTxtFullAddress = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.txtAdvice = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtdatetime = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPrint = new MetroFramework.Controls.MetroButton();
            this.btnVaccine = new MetroFramework.Controls.MetroButton();
            this.btnVPP = new MetroFramework.Controls.MetroButton();
            this.btnClear = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrldataGridPrescription)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chkOld
            // 
            this.chkOld.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.chkOld.AutoSize = true;
            this.chkOld.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.chkOld.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOld.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.chkOld.Location = new System.Drawing.Point(652, 538);
            this.chkOld.Margin = new System.Windows.Forms.Padding(0);
            this.chkOld.Name = "chkOld";
            this.chkOld.Size = new System.Drawing.Size(79, 23);
            this.chkOld.TabIndex = 245;
            this.chkOld.Text = "Old ";
            this.chkOld.UseVisualStyleBackColor = false;
            this.chkOld.Visible = false;
            this.chkOld.CheckedChanged += new System.EventHandler(this.chkOld_CheckedChanged);
            // 
            // cmb_apno
            // 
            this.cmb_apno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmb_apno.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_apno.FormattingEnabled = true;
            this.cmb_apno.Location = new System.Drawing.Point(109, 22);
            this.cmb_apno.Name = "cmb_apno";
            this.cmb_apno.Size = new System.Drawing.Size(71, 25);
            this.cmb_apno.TabIndex = 0;
            this.cmb_apno.DropDownClosed += new System.EventHandler(this.cmb_apno_DropDownClosed);
            // 
            // txtAddress
            // 
            this.txtAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtAddress, 2);
            this.txtAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAddress.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(1104, 22);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(232, 25);
            this.txtAddress.TabIndex = 6;
            this.txtAddress.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAddress_KeyUp);
            // 
            // txtpatiantID
            // 
            this.txtpatiantID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtpatiantID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtpatiantID, 2);
            this.txtpatiantID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtpatiantID.Enabled = false;
            this.txtpatiantID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatiantID.Location = new System.Drawing.Point(186, 22);
            this.txtpatiantID.Name = "txtpatiantID";
            this.txtpatiantID.Size = new System.Drawing.Size(97, 25);
            this.txtpatiantID.TabIndex = 1;
            this.txtpatiantID.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtpatiantID_KeyUp);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 1;
            this.numericUpDown1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDown1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown1.Location = new System.Drawing.Point(289, 72);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(73, 25);
            this.numericUpDown1.TabIndex = 11;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            98,
            0,
            0,
            0});
            this.numericUpDown1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtweight_KeyPress);
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPhoneNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPhoneNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhoneNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNo.Location = new System.Drawing.Point(3, 72);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(100, 25);
            this.txtPhoneNo.TabIndex = 8;
            this.txtPhoneNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPhoneNo_KeyDown);
            this.txtPhoneNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPhoneNo_KeyPress);
            // 
            // txtDiagnosis
            // 
            this.txtDiagnosis.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtDiagnosis.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtDiagnosis, 9);
            this.txtDiagnosis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiagnosis.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiagnosis.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtDiagnosis.Location = new System.Drawing.Point(109, 103);
            this.txtDiagnosis.Name = "txtDiagnosis";
            this.txtDiagnosis.Size = new System.Drawing.Size(540, 25);
            this.txtDiagnosis.TabIndex = 16;
            this.txtDiagnosis.TextChanged += new System.EventHandler(this.txtDiagnosis_TextChanged);
            // 
            // txtPresNo
            // 
            this.txtPresNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPresNo.Enabled = false;
            this.txtPresNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPresNo.Location = new System.Drawing.Point(3, 22);
            this.txtPresNo.Name = "txtPresNo";
            this.txtPresNo.Size = new System.Drawing.Size(100, 25);
            this.txtPresNo.TabIndex = 240;
            // 
            // ctrlLblPatientHis
            // 
            this.ctrlLblPatientHis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlLblPatientHis.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlLblPatientHis.Location = new System.Drawing.Point(734, 72);
            this.ctrlLblPatientHis.Name = "ctrlLblPatientHis";
            this.ctrlLblPatientHis.Size = new System.Drawing.Size(126, 25);
            this.ctrlLblPatientHis.TabIndex = 14;
            // 
            // ctrlDateDOB
            // 
            this.ctrlDateDOB.CalendarFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlDateDOB.CustomFormat = "dd/MM/yyyy";
            this.ctrlDateDOB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlDateDOB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlDateDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ctrlDateDOB.Location = new System.Drawing.Point(734, 22);
            this.ctrlDateDOB.Name = "ctrlDateDOB";
            this.ctrlDateDOB.Size = new System.Drawing.Size(126, 25);
            this.ctrlDateDOB.TabIndex = 4;
            this.ctrlDateDOB.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // txtage
            // 
            this.txtage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtage.Enabled = false;
            this.txtage.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtage.Location = new System.Drawing.Point(866, 22);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(232, 25);
            this.txtage.TabIndex = 5;
            // 
            // ctrldataGridPrescription
            // 
            this.ctrldataGridPrescription.AllowUserToOrderColumns = true;
            this.ctrldataGridPrescription.AllowUserToResizeRows = false;
            this.ctrldataGridPrescription.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrldataGridPrescription.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ctrldataGridPrescription.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ctrldataGridPrescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ctrldataGridPrescription.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SNo,
            this.Medicine,
            this.Quantity,
            this.Dose,
            this.DividedDoses,
            this.Interval,
            this.Instructions,
            this.Instrunctions});
            this.tableLayoutPanel1.SetColumnSpan(this.ctrldataGridPrescription, 17);
            this.ctrldataGridPrescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrldataGridPrescription.Location = new System.Drawing.Point(6, 142);
            this.ctrldataGridPrescription.Margin = new System.Windows.Forms.Padding(6);
            this.ctrldataGridPrescription.Name = "ctrldataGridPrescription";
            this.ctrldataGridPrescription.Size = new System.Drawing.Size(1327, 171);
            this.ctrldataGridPrescription.TabIndex = 15;
            this.ctrldataGridPrescription.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.ctrldataGridPrescription_CellValueChanged);
            this.ctrldataGridPrescription.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.ctrldataGridPrescription_EditingControlShowing_1);
            this.ctrldataGridPrescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ctrldataGridPrescription_KeyUp);
            // 
            // SNo
            // 
            this.SNo.DataPropertyName = "SNo";
            this.SNo.FillWeight = 1.100788F;
            this.SNo.HeaderText = "SNo";
            this.SNo.Name = "SNo";
            this.SNo.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Medicine
            // 
            this.Medicine.DataPropertyName = "Medicine";
            this.Medicine.FillWeight = 5.750391F;
            this.Medicine.HeaderText = "Medicine";
            this.Medicine.Name = "Medicine";
            this.Medicine.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.FillWeight = 9.064916F;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            // 
            // Dose
            // 
            this.Dose.DataPropertyName = "Dose";
            this.Dose.FillWeight = 17.74291F;
            this.Dose.HeaderText = "Dose";
            this.Dose.Name = "Dose";
            // 
            // DividedDoses
            // 
            this.DividedDoses.DataPropertyName = "DividedDoses";
            this.DividedDoses.FillWeight = 109.4881F;
            this.DividedDoses.HeaderText = "DividedDoses";
            this.DividedDoses.Name = "DividedDoses";
            // 
            // Interval
            // 
            this.Interval.DataPropertyName = "Duration";
            this.Interval.HeaderText = "Interval";
            this.Interval.Name = "Interval";
            // 
            // Instructions
            // 
            this.Instructions.DataPropertyName = "Instructions";
            this.Instructions.FillWeight = 456.8523F;
            this.Instructions.HeaderText = "Instructions";
            this.Instructions.Name = "Instructions";
            // 
            // Instrunctions
            // 
            this.Instrunctions.DataPropertyName = "Insttamil";
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Instrunctions.DefaultCellStyle = dataGridViewCellStyle1;
            this.Instrunctions.HeaderText = "Instructions";
            this.Instrunctions.Name = "Instrunctions";
            // 
            // txtname
            // 
            this.txtname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtname, 6);
            this.txtname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(289, 22);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(360, 25);
            this.txtname.TabIndex = 2;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            this.txtname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtname_KeyDown);
            this.txtname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtname_KeyPress);
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(3, 108);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 19);
            this.label15.TabIndex = 231;
            this.label15.Text = "Diagnosis:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtheight
            // 
            this.txtheight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtheight.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtheight.Location = new System.Drawing.Point(512, 72);
            this.txtheight.Name = "txtheight";
            this.txtheight.Size = new System.Drawing.Size(92, 25);
            this.txtheight.TabIndex = 13;
            this.txtheight.TextChanged += new System.EventHandler(this.txtheight_TextChanged);
            this.txtheight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtweight_KeyPress);
            // 
            // txtweight
            // 
            this.txtweight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtweight.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtweight.Location = new System.Drawing.Point(388, 72);
            this.txtweight.Name = "txtweight";
            this.txtweight.Size = new System.Drawing.Size(73, 25);
            this.txtweight.TabIndex = 12;
            this.txtweight.TextChanged += new System.EventHandler(this.txtweight_TextChanged);
            this.txtweight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtweight_KeyPress);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 15;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.639812F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.265256F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.068348F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.319906F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.479858F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.479858F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.031483F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.448845F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.79977F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.43958F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.978014F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.03936F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 11, 4);
            this.tableLayoutPanel1.Controls.Add(this.label24, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label23, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnsave, 14, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtPresNo, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmb_apno, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.genderComboBox, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDiagnosis, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtbmi, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.ctrlLblPatientHis, 11, 3);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ctrldataGridPrescription, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label10, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.label11, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.label14, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.label12, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtAddress, 13, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtpatiantID, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtname, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.ctrlCbxStatus, 12, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 12, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown1, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtweight, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtheight, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.label17, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label18, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.label21, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label5, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ctrlDateDOB, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtPhoneNo, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label19, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.cb_language, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtage, 12, 1);
            this.tableLayoutPanel1.Controls.Add(this.ctrlTxtUHID, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.ctrlTxtFullAddress, 13, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.chkOld, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtdatetime, 11, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 12, 8);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1339, 566);
            this.tableLayoutPanel1.TabIndex = 257;
            // 
            // panel2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel2, 2);
            this.panel2.Controls.Add(this.tableLayoutPanel7);
            this.panel2.Location = new System.Drawing.Point(734, 103);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(364, 30);
            this.panel2.TabIndex = 1822;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel7.Controls.Add(this.metroButton3, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.ctrlCbxAlergy, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(364, 30);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // metroButton3
            // 
            this.metroButton3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroButton3.Highlight = true;
            this.metroButton3.Location = new System.Drawing.Point(301, 3);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(60, 24);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButton3.TabIndex = 18;
            this.metroButton3.Text = "ADD";
            this.metroButton3.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroButton3.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // ctrlCbxAlergy
            // 
            this.ctrlCbxAlergy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ctrlCbxAlergy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ctrlCbxAlergy.CheckOnClick = true;
            this.ctrlCbxAlergy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCbxAlergy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.ctrlCbxAlergy.DropDownHeight = 1;
            this.ctrlCbxAlergy.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ctrlCbxAlergy.FormattingEnabled = true;
            this.ctrlCbxAlergy.IntegralHeight = false;
            this.ctrlCbxAlergy.Location = new System.Drawing.Point(3, 3);
            this.ctrlCbxAlergy.Name = "ctrlCbxAlergy";
            this.ctrlCbxAlergy.Size = new System.Drawing.Size(292, 26);
            this.ctrlCbxAlergy.TabIndex = 17;
            this.ctrlCbxAlergy.ValueSeparator = ", ";
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label24, 2);
            this.label24.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label24.Location = new System.Drawing.Point(186, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(97, 19);
            this.label24.TabIndex = 1818;
            this.label24.Text = "UHID";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(655, 108);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(73, 19);
            this.label23.TabIndex = 1816;
            this.label23.Text = "Allergy";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnsave
            // 
            this.btnsave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnsave.Highlight = true;
            this.btnsave.Location = new System.Drawing.Point(1214, 103);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(122, 30);
            this.btnsave.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnsave.TabIndex = 22;
            this.btnsave.Text = "Save";
            this.btnsave.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // genderComboBox
            // 
            this.genderComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.genderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.genderComboBox.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.genderComboBox.Location = new System.Drawing.Point(655, 22);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(73, 25);
            this.genderComboBox.TabIndex = 3;
            // 
            // txtbmi
            // 
            this.txtbmi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtbmi.Enabled = false;
            this.txtbmi.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbmi.Location = new System.Drawing.Point(655, 72);
            this.txtbmi.Name = "txtbmi";
            this.txtbmi.Size = new System.Drawing.Size(73, 25);
            this.txtbmi.TabIndex = 238;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(109, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 19);
            this.label3.TabIndex = 256;
            this.label3.Text = "App No";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 19);
            this.label4.TabIndex = 256;
            this.label4.Text = "E-Pres-No";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(655, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 19);
            this.label10.TabIndex = 256;
            this.label10.Text = "BMI";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(734, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 19);
            this.label11.TabIndex = 256;
            this.label11.Text = "HC in cms";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(655, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 19);
            this.label14.TabIndex = 256;
            this.label14.Text = "Gender";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label12, 2);
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(1104, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(232, 19);
            this.label12.TabIndex = 256;
            this.label12.Text = "Area and Address";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 2);
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(186, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 19);
            this.label1.TabIndex = 256;
            this.label1.Text = "Patient ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label2, 6);
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(289, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(360, 19);
            this.label2.TabIndex = 256;
            this.label2.Text = "Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctrlCbxStatus
            // 
            this.ctrlCbxStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCbxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ctrlCbxStatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlCbxStatus.FormattingEnabled = true;
            this.ctrlCbxStatus.Items.AddRange(new object[] {
            "Observation",
            "Admitted",
            "Referred"});
            this.ctrlCbxStatus.Location = new System.Drawing.Point(866, 72);
            this.ctrlCbxStatus.Name = "ctrlCbxStatus";
            this.ctrlCbxStatus.Size = new System.Drawing.Size(232, 25);
            this.ctrlCbxStatus.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(866, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(232, 19);
            this.label20.TabIndex = 256;
            this.label20.Text = "Result";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label7, 2);
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(289, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 19);
            this.label7.TabIndex = 256;
            this.label7.Text = "Temp";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label8, 2);
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(388, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 19);
            this.label8.TabIndex = 256;
            this.label8.Text = "Weight";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label9, 2);
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(512, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 19);
            this.label9.TabIndex = 256;
            this.label9.Text = "Height";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Enabled = false;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(368, 78);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 12);
            this.label17.TabIndex = 256;
            this.label17.Text = "F";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Enabled = false;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(467, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 12);
            this.label18.TabIndex = 256;
            this.label18.Text = "Kgs";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label21.Location = new System.Drawing.Point(610, 78);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(39, 12);
            this.label21.TabIndex = 256;
            this.label21.Text = "Cms";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel2, 10);
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 322);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel1.SetRowSpan(this.tableLayoutPanel2, 3);
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 241F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(646, 241);
            this.tableLayoutPanel2.TabIndex = 1212;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.label25, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.txtClinical, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.ctrlAddClinicallabel, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel8, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(642, 241);
            this.tableLayoutPanel3.TabIndex = 219;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label25.Location = new System.Drawing.Point(622, 0);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 19);
            this.label25.TabIndex = 233;
            this.label25.Text = "⓪";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label25.Click += new System.EventHandler(this.ctrlAddClinical_Click);
            // 
            // txtClinical
            // 
            this.txtClinical.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtClinical.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel3.SetColumnSpan(this.txtClinical, 3);
            this.txtClinical.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtClinical.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtClinical.HideSelection = false;
            this.txtClinical.Location = new System.Drawing.Point(0, 79);
            this.txtClinical.Margin = new System.Windows.Forms.Padding(0);
            this.txtClinical.Multiline = true;
            this.txtClinical.Name = "txtClinical";
            this.txtClinical.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtClinical.Size = new System.Drawing.Size(642, 162);
            this.txtClinical.TabIndex = 19;
            this.txtClinical.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtClinical_KeyDown);
            this.txtClinical.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtClinical_KeyUp);
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(603, 19);
            this.label16.TabIndex = 231;
            this.label16.Text = "Clinical Notes:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctrlAddClinicallabel
            // 
            this.ctrlAddClinicallabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlAddClinicallabel.AutoSize = true;
            this.ctrlAddClinicallabel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ctrlAddClinicallabel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlAddClinicallabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ctrlAddClinicallabel.Location = new System.Drawing.Point(603, 0);
            this.ctrlAddClinicallabel.Margin = new System.Windows.Forms.Padding(0);
            this.ctrlAddClinicallabel.Name = "ctrlAddClinicallabel";
            this.ctrlAddClinicallabel.Size = new System.Drawing.Size(19, 19);
            this.ctrlAddClinicallabel.TabIndex = 231;
            this.ctrlAddClinicallabel.Text = "⓪";
            this.ctrlAddClinicallabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ctrlAddClinicallabel.Click += new System.EventHandler(this.PatientHistory_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel8.ColumnCount = 3;
            this.tableLayoutPanel3.SetColumnSpan(this.tableLayoutPanel8, 3);
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 214F));
            this.tableLayoutPanel8.Controls.Add(this.ctrlTxtFamilyHis, 2, 1);
            this.tableLayoutPanel8.Controls.Add(this.ctrlTxtPastIllness, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label29, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.label30, 2, 0);
            this.tableLayoutPanel8.Controls.Add(this.ctrlTxtBirthHist, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 19);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(642, 60);
            this.tableLayoutPanel8.TabIndex = 234;
            // 
            // ctrlTxtFamilyHis
            // 
            this.ctrlTxtFamilyHis.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlTxtFamilyHis.Location = new System.Drawing.Point(428, 17);
            this.ctrlTxtFamilyHis.Margin = new System.Windows.Forms.Padding(0);
            this.ctrlTxtFamilyHis.Multiline = true;
            this.ctrlTxtFamilyHis.Name = "ctrlTxtFamilyHis";
            this.ctrlTxtFamilyHis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlTxtFamilyHis.Size = new System.Drawing.Size(214, 43);
            this.ctrlTxtFamilyHis.TabIndex = 262;
            this.ctrlTxtFamilyHis.TextChanged += new System.EventHandler(this.CtrlTxtPersonalInfo_TextChanged);
            // 
            // ctrlTxtPastIllness
            // 
            this.ctrlTxtPastIllness.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlTxtPastIllness.Location = new System.Drawing.Point(214, 17);
            this.ctrlTxtPastIllness.Margin = new System.Windows.Forms.Padding(0);
            this.ctrlTxtPastIllness.Multiline = true;
            this.ctrlTxtPastIllness.Name = "ctrlTxtPastIllness";
            this.ctrlTxtPastIllness.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlTxtPastIllness.Size = new System.Drawing.Size(214, 43);
            this.ctrlTxtPastIllness.TabIndex = 261;
            this.ctrlTxtPastIllness.TextChanged += new System.EventHandler(this.CtrlTxtPersonalInfo_TextChanged);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label28.Location = new System.Drawing.Point(0, 0);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(214, 17);
            this.label28.TabIndex = 257;
            this.label28.Text = "Birth History";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label29.Location = new System.Drawing.Point(214, 0);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(214, 17);
            this.label29.TabIndex = 258;
            this.label29.Text = "Past Illness";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label30.Location = new System.Drawing.Point(428, 0);
            this.label30.Margin = new System.Windows.Forms.Padding(0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(214, 17);
            this.label30.TabIndex = 259;
            this.label30.Text = "Family History";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctrlTxtBirthHist
            // 
            this.ctrlTxtBirthHist.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ctrlTxtBirthHist.Location = new System.Drawing.Point(0, 17);
            this.ctrlTxtBirthHist.Margin = new System.Windows.Forms.Padding(0);
            this.ctrlTxtBirthHist.Multiline = true;
            this.ctrlTxtBirthHist.Name = "ctrlTxtBirthHist";
            this.ctrlTxtBirthHist.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlTxtBirthHist.Size = new System.Drawing.Size(214, 43);
            this.ctrlTxtBirthHist.TabIndex = 260;
            this.ctrlTxtBirthHist.TextChanged += new System.EventHandler(this.CtrlTxtPersonalInfo_TextChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(734, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 19);
            this.label5.TabIndex = 256;
            this.label5.Text = "DOB";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(3, 50);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 19);
            this.label13.TabIndex = 256;
            this.label13.Text = "Phone No";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(109, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 19);
            this.label19.TabIndex = 256;
            this.label19.Text = "Language";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(866, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(232, 19);
            this.label6.TabIndex = 256;
            this.label6.Text = "Age";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cb_language
            // 
            this.cb_language.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_language.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_language.FormattingEnabled = true;
            this.cb_language.Items.AddRange(new object[] {
            "English",
            "தமிழ்"});
            this.cb_language.Location = new System.Drawing.Point(109, 72);
            this.cb_language.Name = "cb_language";
            this.cb_language.Size = new System.Drawing.Size(71, 25);
            this.cb_language.TabIndex = 9;
            this.cb_language.SelectedIndexChanged += new System.EventHandler(this.rb_tamil_CheckedChanged);
            // 
            // ctrlTxtUHID
            // 
            this.ctrlTxtUHID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ctrlTxtUHID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlTxtUHID, 2);
            this.ctrlTxtUHID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtUHID.Location = new System.Drawing.Point(186, 72);
            this.ctrlTxtUHID.Name = "ctrlTxtUHID";
            this.ctrlTxtUHID.Size = new System.Drawing.Size(97, 25);
            this.ctrlTxtUHID.TabIndex = 10;
            this.ctrlTxtUHID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ctrlTxtUHID_KeyDown);
            // 
            // ctrlTxtFullAddress
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlTxtFullAddress, 2);
            this.ctrlTxtFullAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtFullAddress.Location = new System.Drawing.Point(1104, 53);
            this.ctrlTxtFullAddress.Multiline = true;
            this.ctrlTxtFullAddress.Name = "ctrlTxtFullAddress";
            this.tableLayoutPanel1.SetRowSpan(this.ctrlTxtFullAddress, 2);
            this.ctrlTxtFullAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlTxtFullAddress.Size = new System.Drawing.Size(232, 44);
            this.ctrlTxtFullAddress.TabIndex = 7;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel6, 5);
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(655, 322);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel1.SetRowSpan(this.tableLayoutPanel6, 2);
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(681, 209);
            this.tableLayoutPanel6.TabIndex = 1819;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(681, 209);
            this.tableLayoutPanel4.TabIndex = 1213;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.Controls.Add(this.txtAdvice, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label27, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label26, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label22, 2, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(677, 209);
            this.tableLayoutPanel5.TabIndex = 219;
            // 
            // txtAdvice
            // 
            this.txtAdvice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtAdvice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel5.SetColumnSpan(this.txtAdvice, 3);
            this.txtAdvice.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAdvice.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdvice.HideSelection = false;
            this.txtAdvice.Location = new System.Drawing.Point(0, 19);
            this.txtAdvice.Margin = new System.Windows.Forms.Padding(0);
            this.txtAdvice.Multiline = true;
            this.txtAdvice.Name = "txtAdvice";
            this.txtAdvice.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAdvice.Size = new System.Drawing.Size(677, 190);
            this.txtAdvice.TabIndex = 20;
            this.txtAdvice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtClinical_KeyDown);
            this.txtAdvice.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtClinical_KeyUp);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label27.Location = new System.Drawing.Point(631, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 19);
            this.label27.TabIndex = 231;
            this.label27.Text = "⓪";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label27.Click += new System.EventHandler(this.ctrlAddAdvice_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label26.Location = new System.Drawing.Point(0, 0);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(631, 19);
            this.label26.TabIndex = 1819;
            this.label26.Text = "Advice :";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label22.Location = new System.Drawing.Point(650, 0);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(27, 19);
            this.label22.TabIndex = 232;
            this.label22.Text = "⓪";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label22.Click += new System.EventHandler(this.PatientAddtionalInfo_Click);
            // 
            // txtdatetime
            // 
            this.txtdatetime.Location = new System.Drawing.Point(734, 537);
            this.txtdatetime.Name = "txtdatetime";
            this.txtdatetime.Size = new System.Drawing.Size(44, 25);
            this.txtdatetime.TabIndex = 258;
            this.txtdatetime.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tableLayoutPanel1.SetColumnSpan(this.panel1, 3);
            this.panel1.Controls.Add(this.btnPrint);
            this.panel1.Controls.Add(this.btnVaccine);
            this.panel1.Controls.Add(this.btnVPP);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Location = new System.Drawing.Point(866, 537);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(470, 26);
            this.panel1.TabIndex = 1814;
            // 
            // btnPrint
            // 
            this.btnPrint.Highlight = true;
            this.btnPrint.Location = new System.Drawing.Point(360, 2);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(100, 22);
            this.btnPrint.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnPrint.TabIndex = 21;
            this.btnPrint.Text = "Print";
            this.btnPrint.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnPrint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // btnVaccine
            // 
            this.btnVaccine.Highlight = true;
            this.btnVaccine.Location = new System.Drawing.Point(144, 2);
            this.btnVaccine.Name = "btnVaccine";
            this.btnVaccine.Size = new System.Drawing.Size(100, 22);
            this.btnVaccine.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnVaccine.TabIndex = 24;
            this.btnVaccine.Text = "Vaccine";
            this.btnVaccine.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnVaccine.Click += new System.EventHandler(this.btnVaccine_Click);
            // 
            // btnVPP
            // 
            this.btnVPP.Highlight = true;
            this.btnVPP.Location = new System.Drawing.Point(252, 2);
            this.btnVPP.Name = "btnVPP";
            this.btnVPP.Size = new System.Drawing.Size(100, 22);
            this.btnVPP.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnVPP.TabIndex = 23;
            this.btnVPP.Text = "View Previous ";
            this.btnVPP.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnVPP.Click += new System.EventHandler(this.btnVPP_Click);
            // 
            // btnClear
            // 
            this.btnClear.Highlight = true;
            this.btnClear.Location = new System.Drawing.Point(36, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 22);
            this.btnClear.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "Clear";
            this.btnClear.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnClear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // NewPrescription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "NewPrescription";
            this.Size = new System.Drawing.Size(1339, 566);
            this.Load += new System.EventHandler(this.Prescription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctrldataGridPrescription)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkOld;
        private System.Windows.Forms.ComboBox cmb_apno;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtpatiantID;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.TextBox txtDiagnosis;
        private System.Windows.Forms.TextBox txtPresNo;
        private System.Windows.Forms.TextBox ctrlLblPatientHis;
        private System.Windows.Forms.DateTimePicker ctrlDateDOB;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.DataGridView ctrldataGridPrescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn SNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Medicine;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dose;
        private System.Windows.Forms.DataGridViewTextBoxColumn DividedDoses;
        private System.Windows.Forms.DataGridViewTextBoxColumn Interval;
        private System.Windows.Forms.DataGridViewTextBoxColumn Instructions;
        private System.Windows.Forms.DataGridViewTextBoxColumn Instrunctions;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtheight;
        private System.Windows.Forms.TextBox txtweight;
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.TextBox txtbmi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtClinical;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cb_language;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox ctrlCbxStatus;
        private System.Windows.Forms.TextBox txtdatetime;
        private MetroFramework.Controls.MetroButton btnPrint;
        private MetroFramework.Controls.MetroButton btnsave;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private MetroFramework.Controls.MetroButton btnClear;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private MetroFramework.Controls.MetroButton btnVPP;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label ctrlAddClinicallabel;
        private MetroFramework.Controls.MetroButton btnVaccine;
        private System.Windows.Forms.TextBox ctrlTxtUHID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox ctrlTxtFullAddress;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAdvice;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private MetroFramework.Controls.MetroButton metroButton3;
        private CheckComboBoxTest.CheckedComboBox ctrlCbxAlergy;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.TextBox ctrlTxtFamilyHis;
        private System.Windows.Forms.TextBox ctrlTxtPastIllness;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox ctrlTxtBirthHist;
    }
}
