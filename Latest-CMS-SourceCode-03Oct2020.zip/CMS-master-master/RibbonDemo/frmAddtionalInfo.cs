﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmAddtionalInfo : MetroFramework.Forms.MetroForm
    {
        PersonalInformation personalInformation = null;
        bool isold = false;
        public frmAddtionalInfo(ref PersonalInformation personalInfo,bool isOldcheck)
        {
            InitializeComponent();
            personalInformation = personalInfo;
            isold = isOldcheck;


        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            personalInformation.AddtionalInformation = ctrltxtAddtionalInformat.Text;
            personalInformation.LabInvestigations = new GeneralMethods().JoinSpecficItem(ref ctrlCbxLab);
            this.DialogResult = DialogResult.OK;
        }

        private void MetroButton2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void MetroButton3_Click(object sender, EventArgs e)
        {
            frmLabInvestigator frmLabInvestigator = new frmLabInvestigator();
            frmLabInvestigator.ShowDialog();
            if (frmLabInvestigator.IsModified)
            {
                ctrlCbxLab.Text = string.Empty;
                new GeneralMethods().PatientLabInvestigationsLoad(ref ctrlCbxLab);
            }

        }

        private void FrmAddtionalInfo_Load(object sender, EventArgs e)
        {
            new GeneralMethods().PatientLabInvestigationsLoad(ref ctrlCbxLab);
            if (true)
            {
                ctrltxtAddtionalInformat.Text = personalInformation.AddtionalInformation;
                new GeneralMethods().LoadCheckedValues(personalInformation.LabInvestigations, ref ctrlCbxLab);
            }
        }
    }
}
