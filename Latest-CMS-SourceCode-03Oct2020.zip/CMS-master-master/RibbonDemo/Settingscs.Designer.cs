﻿namespace SVMApplication
{
    partial class Settingscs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroStyleExtender1 = new MetroFramework.Components.MetroStyleExtender(this.components);
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
            this.btnApply = new MetroFramework.Controls.MetroButton();
            this.btnCancel = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxLabel = new MetroFramework.Controls.MetroTextBox();
            this.metroComboBoxLabel = new MetroFramework.Controls.MetroComboBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this._lFontColor = new System.Windows.Forms.Button();
            this._lBackColor = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkBold = new MetroFramework.Controls.MetroCheckBox();
            this._CFontColor = new System.Windows.Forms.Button();
            this._CBackColor = new System.Windows.Forms.Button();
            this.metroComboBoxControl = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxSControl = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBoxControl = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.btnDefaults = new MetroFramework.Controls.MetroButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this._RFontColor = new System.Windows.Forms.Button();
            this._RBackColor = new System.Windows.Forms.Button();
            this.metroComboBoxRibbon = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxRibbon = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            //((System.ComponentModel.ISupportInitialize)(this.metroStyleExtender1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = null;
            // 
            // propertyGrid1
            // 
            this.propertyGrid1.BackColor = System.Drawing.Color.White;
            this.propertyGrid1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propertyGrid1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.propertyGrid1.LineColor = System.Drawing.SystemColors.ControlDark;
            this.propertyGrid1.Location = new System.Drawing.Point(1025, 78);
            this.propertyGrid1.Margin = new System.Windows.Forms.Padding(4);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new System.Drawing.Size(396, 571);
            this.propertyGrid1.TabIndex = 6;
            this.propertyGrid1.Visible = false;
            this.propertyGrid1.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propertyGrid1_PropertyValueChanged);
            // 
            // btnApply
            // 
            this.btnApply.Location = new System.Drawing.Point(609, 336);
            this.btnApply.Margin = new System.Windows.Forms.Padding(4);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(100, 31);
            this.btnApply.TabIndex = 7;
            this.btnApply.Text = "Apply";
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(729, 336);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 31);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Close";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(16, 79);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(75, 20);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Back Color";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(16, 208);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(65, 20);
            this.metroLabel2.TabIndex = 9;
            this.metroLabel2.Text = "Font Size";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(140, 79);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(73, 20);
            this.metroLabel4.TabIndex = 9;
            this.metroLabel4.Text = "Font Color";
            // 
            // metroTextBoxLabel
            // 
            this.metroTextBoxLabel.Location = new System.Drawing.Point(127, 204);
            this.metroTextBoxLabel.Margin = new System.Windows.Forms.Padding(4);
            this.metroTextBoxLabel.Name = "metroTextBoxLabel";
            this.metroTextBoxLabel.PromptText = "Font Size";
            this.metroTextBoxLabel.Size = new System.Drawing.Size(112, 28);
            this.metroTextBoxLabel.TabIndex = 10;
            this.metroTextBoxLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBoxLabel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBoxLabel_KeyPress);
            this.metroTextBoxLabel.KeyUp += new System.Windows.Forms.KeyEventHandler(this.metroTextBoxLabel_KeyUp);
            // 
            // metroComboBoxLabel
            // 
            this.metroComboBoxLabel.ForeColor = System.Drawing.Color.Black;
            this.metroComboBoxLabel.FormattingEnabled = true;
            this.metroComboBoxLabel.ItemHeight = 24;
            this.metroComboBoxLabel.Location = new System.Drawing.Point(16, 23);
            this.metroComboBoxLabel.Margin = new System.Windows.Forms.Padding(4);
            this.metroComboBoxLabel.Name = "metroComboBoxLabel";
            this.metroComboBoxLabel.Size = new System.Drawing.Size(221, 30);
            this.metroComboBoxLabel.TabIndex = 11;
            // 
            // colorDialog1
            // 
            this.colorDialog1.AnyColor = true;
            this.colorDialog1.FullOpen = true;
            // 
            // colorDialog2
            // 
            this.colorDialog2.AnyColor = true;
            this.colorDialog2.FullOpen = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.metroCheckBox1);
            this.groupBox1.Controls.Add(this._lFontColor);
            this.groupBox1.Controls.Add(this._lBackColor);
            this.groupBox1.Controls.Add(this.metroComboBoxLabel);
            this.groupBox1.Controls.Add(this.metroLabel1);
            this.groupBox1.Controls.Add(this.metroTextBoxLabel);
            this.groupBox1.Controls.Add(this.metroLabel2);
            this.groupBox1.Controls.Add(this.metroLabel4);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(31, 78);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(253, 246);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Label\'s Font";
            // 
            // _lFontColor
            // 
            this._lFontColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._lFontColor.Location = new System.Drawing.Point(140, 106);
            this._lFontColor.Margin = new System.Windows.Forms.Padding(4);
            this._lFontColor.Name = "_lFontColor";
            this._lFontColor.Size = new System.Drawing.Size(100, 81);
            this._lFontColor.TabIndex = 0;
            this._lFontColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._lFontColor.UseVisualStyleBackColor = true;
            this._lFontColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // _lBackColor
            // 
            this._lBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._lBackColor.Location = new System.Drawing.Point(16, 106);
            this._lBackColor.Margin = new System.Windows.Forms.Padding(4);
            this._lBackColor.Name = "_lBackColor";
            this._lBackColor.Size = new System.Drawing.Size(100, 81);
            this._lBackColor.TabIndex = 0;
            this._lBackColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._lBackColor.UseVisualStyleBackColor = true;
            this._lBackColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.chkBold);
            this.groupBox2.Controls.Add(this._CFontColor);
            this.groupBox2.Controls.Add(this._CBackColor);
            this.groupBox2.Controls.Add(this.metroComboBoxControl);
            this.groupBox2.Controls.Add(this.metroLabel3);
            this.groupBox2.Controls.Add(this.metroTextBoxSControl);
            this.groupBox2.Controls.Add(this.metroTextBoxControl);
            this.groupBox2.Controls.Add(this.metroLabel5);
            this.groupBox2.Controls.Add(this.metroLabel6);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(301, 78);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(253, 246);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Control\'s Font";
            // 
            // chkBold
            // 
            this.chkBold.AutoSize = true;
            this.chkBold.Location = new System.Drawing.Point(16, 58);
            this.chkBold.Name = "chkBold";
            this.chkBold.Size = new System.Drawing.Size(50, 17);
            this.chkBold.TabIndex = 12;
            this.chkBold.Text = "Bold";
            // 
            // _CFontColor
            // 
            this._CFontColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._CFontColor.Location = new System.Drawing.Point(136, 106);
            this._CFontColor.Margin = new System.Windows.Forms.Padding(4);
            this._CFontColor.Name = "_CFontColor";
            this._CFontColor.Size = new System.Drawing.Size(100, 81);
            this._CFontColor.TabIndex = 0;
            this._CFontColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._CFontColor.UseVisualStyleBackColor = true;
            this._CFontColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // _CBackColor
            // 
            this._CBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._CBackColor.Location = new System.Drawing.Point(16, 106);
            this._CBackColor.Margin = new System.Windows.Forms.Padding(4);
            this._CBackColor.Name = "_CBackColor";
            this._CBackColor.Size = new System.Drawing.Size(100, 81);
            this._CBackColor.TabIndex = 0;
            this._CBackColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._CBackColor.UseVisualStyleBackColor = true;
            this._CBackColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // metroComboBoxControl
            // 
            this.metroComboBoxControl.ForeColor = System.Drawing.Color.Black;
            this.metroComboBoxControl.FormattingEnabled = true;
            this.metroComboBoxControl.ItemHeight = 24;
            this.metroComboBoxControl.Location = new System.Drawing.Point(16, 23);
            this.metroComboBoxControl.Margin = new System.Windows.Forms.Padding(4);
            this.metroComboBoxControl.Name = "metroComboBoxControl";
            this.metroComboBoxControl.Size = new System.Drawing.Size(221, 30);
            this.metroComboBoxControl.TabIndex = 11;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(16, 79);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(75, 20);
            this.metroLabel3.TabIndex = 9;
            this.metroLabel3.Text = "Back Color";
            // 
            // metroTextBoxSControl
            // 
            this.metroTextBoxSControl.Location = new System.Drawing.Point(186, 204);
            this.metroTextBoxSControl.Margin = new System.Windows.Forms.Padding(4);
            this.metroTextBoxSControl.Name = "metroTextBoxSControl";
            this.metroTextBoxSControl.PromptText = "Font Size";
            this.metroTextBoxSControl.Size = new System.Drawing.Size(59, 28);
            this.metroTextBoxSControl.TabIndex = 10;
            this.metroTextBoxSControl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBoxSControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBoxLabel_KeyPress);
            this.metroTextBoxSControl.KeyUp += new System.Windows.Forms.KeyEventHandler(this.metroTextBoxLabel_KeyUp);
            // 
            // metroTextBoxControl
            // 
            this.metroTextBoxControl.Location = new System.Drawing.Point(123, 204);
            this.metroTextBoxControl.Margin = new System.Windows.Forms.Padding(4);
            this.metroTextBoxControl.Name = "metroTextBoxControl";
            this.metroTextBoxControl.PromptText = "Font Size";
            this.metroTextBoxControl.Size = new System.Drawing.Size(59, 28);
            this.metroTextBoxControl.TabIndex = 10;
            this.metroTextBoxControl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBoxControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBoxLabel_KeyPress);
            this.metroTextBoxControl.KeyUp += new System.Windows.Forms.KeyEventHandler(this.metroTextBoxLabel_KeyUp);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(16, 208);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(65, 20);
            this.metroLabel5.TabIndex = 9;
            this.metroLabel5.Text = "Font Size";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(140, 79);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(73, 20);
            this.metroLabel6.TabIndex = 9;
            this.metroLabel6.Text = "Font Color";
            // 
            // btnDefaults
            // 
            this.btnDefaults.Location = new System.Drawing.Point(469, 336);
            this.btnDefaults.Margin = new System.Windows.Forms.Padding(4);
            this.btnDefaults.Name = "btnDefaults";
            this.btnDefaults.Size = new System.Drawing.Size(117, 31);
            this.btnDefaults.TabIndex = 7;
            this.btnDefaults.Text = "Set-Defaults";
            this.btnDefaults.Click += new System.EventHandler(this.btnDefaults_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this._RFontColor);
            this.groupBox3.Controls.Add(this._RBackColor);
            this.groupBox3.Controls.Add(this.metroComboBoxRibbon);
            this.groupBox3.Controls.Add(this.metroLabel7);
            this.groupBox3.Controls.Add(this.metroTextBoxRibbon);
            this.groupBox3.Controls.Add(this.metroLabel8);
            this.groupBox3.Controls.Add(this.metroLabel9);
            this.groupBox3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(575, 78);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(253, 246);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ribbon\'s Font";
            // 
            // _RFontColor
            // 
            this._RFontColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._RFontColor.Location = new System.Drawing.Point(136, 106);
            this._RFontColor.Margin = new System.Windows.Forms.Padding(4);
            this._RFontColor.Name = "_RFontColor";
            this._RFontColor.Size = new System.Drawing.Size(100, 81);
            this._RFontColor.TabIndex = 0;
            this._RFontColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._RFontColor.UseVisualStyleBackColor = true;
            this._RFontColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // _RBackColor
            // 
            this._RBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._RBackColor.Location = new System.Drawing.Point(16, 106);
            this._RBackColor.Margin = new System.Windows.Forms.Padding(4);
            this._RBackColor.Name = "_RBackColor";
            this._RBackColor.Size = new System.Drawing.Size(100, 81);
            this._RBackColor.TabIndex = 0;
            this._RBackColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this._RBackColor.UseVisualStyleBackColor = true;
            this._RBackColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // metroComboBoxRibbon
            // 
            this.metroComboBoxRibbon.ForeColor = System.Drawing.Color.Black;
            this.metroComboBoxRibbon.FormattingEnabled = true;
            this.metroComboBoxRibbon.ItemHeight = 24;
            this.metroComboBoxRibbon.Location = new System.Drawing.Point(16, 23);
            this.metroComboBoxRibbon.Margin = new System.Windows.Forms.Padding(4);
            this.metroComboBoxRibbon.Name = "metroComboBoxRibbon";
            this.metroComboBoxRibbon.Size = new System.Drawing.Size(221, 30);
            this.metroComboBoxRibbon.TabIndex = 11;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(16, 79);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(94, 20);
            this.metroLabel7.TabIndex = 9;
            this.metroLabel7.Text = "Tab Selection ";
            // 
            // metroTextBoxRibbon
            // 
            this.metroTextBoxRibbon.Location = new System.Drawing.Point(127, 204);
            this.metroTextBoxRibbon.Margin = new System.Windows.Forms.Padding(4);
            this.metroTextBoxRibbon.Name = "metroTextBoxRibbon";
            this.metroTextBoxRibbon.PromptText = "Font Size";
            this.metroTextBoxRibbon.Size = new System.Drawing.Size(112, 28);
            this.metroTextBoxRibbon.TabIndex = 10;
            this.metroTextBoxRibbon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBoxRibbon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBoxLabel_KeyPress);
            this.metroTextBoxRibbon.KeyUp += new System.Windows.Forms.KeyEventHandler(this.metroTextBoxLabel_KeyUp);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(16, 208);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(65, 20);
            this.metroLabel8.TabIndex = 9;
            this.metroLabel8.Text = "Font Size";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(140, 79);
            this.metroLabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(67, 20);
            this.metroLabel9.TabIndex = 9;
            this.metroLabel9.Text = "Tab Color";
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.Location = new System.Drawing.Point(16, 58);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(50, 17);
            this.metroCheckBox1.TabIndex = 12;
            this.metroCheckBox1.Text = "Bold";
            // 
            // Settingscs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 385);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.propertyGrid1);
            this.Controls.Add(this.btnDefaults);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.btnCancel);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Settingscs";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.Text = "Settings...";
            this.Load += new System.EventHandler(this.Settingscs_Load);
           // ((System.ComponentModel.ISupportInitialize)(this.metroStyleExtender1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Components.MetroStyleExtender metroStyleExtender1;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private System.Windows.Forms.PropertyGrid propertyGrid1;
        private MetroFramework.Controls.MetroButton btnApply;
        private MetroFramework.Controls.MetroButton btnCancel;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox metroTextBoxLabel;
        private MetroFramework.Controls.MetroComboBox metroComboBoxLabel;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroComboBox metroComboBoxControl;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox metroTextBoxControl;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.Button _lBackColor;
        private System.Windows.Forms.Button _lFontColor;
        private System.Windows.Forms.Button _CFontColor;
        private System.Windows.Forms.Button _CBackColor;
        private MetroFramework.Controls.MetroButton btnDefaults;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button _RFontColor;
        private System.Windows.Forms.Button _RBackColor;
        private MetroFramework.Controls.MetroComboBox metroComboBoxRibbon;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox metroTextBoxRibbon;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroCheckBox chkBold;
        private MetroFramework.Controls.MetroTextBox metroTextBoxSControl;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
    }
}