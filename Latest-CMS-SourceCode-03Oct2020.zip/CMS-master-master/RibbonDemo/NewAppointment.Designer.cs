﻿namespace SVMApplication
{
    partial class NewAppointment
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.ctrlTxtFullAddress = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPresNo = new System.Windows.Forms.TextBox();
            this.cmb_apno = new System.Windows.Forms.ComboBox();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.txtbmi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpatiantID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.ctrlCbxStatus = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtweight = new System.Windows.Forms.TextBox();
            this.txtheight = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txthead = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.ctrlTxtUHID = new System.Windows.Forms.TextBox();
            this.txtdatetime = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkOld = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnsaveapp = new System.Windows.Forms.Button();
            this.btncategory = new System.Windows.Forms.Button();
            this.txtdateSearch = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ctrlDateDOB = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cb_language = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAmountRecived = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.ctrlCbxDoctor = new System.Windows.Forms.ComboBox();
            this.AppointMentList = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ctrlBtnDeleteAppointmrnt = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AppointMentList)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 15;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.361637F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.776646F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.353002F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 6.625628F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.827244F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.801365F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.801365F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.801365F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.659047F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.58861F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.70205F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 11.70205F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlTxtFullAddress, 13, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtAddress, 13, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtPresNo, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmb_apno, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.genderComboBox, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtbmi, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label10, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.label11, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.label14, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.label12, 13, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtpatiantID, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtname, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.ctrlCbxStatus, 12, 3);
            this.tableLayoutPanel1.Controls.Add(this.label20, 12, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.numericUpDown1, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtweight, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtheight, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.label17, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label18, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.label21, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnsearch, 13, 5);
            this.tableLayoutPanel1.Controls.Add(this.txthead, 11, 3);
            this.tableLayoutPanel1.Controls.Add(this.label16, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.ctrlTxtUHID, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtdatetime, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 12, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtdateSearch, 12, 5);
            this.tableLayoutPanel1.Controls.Add(this.label22, 12, 4);
            this.tableLayoutPanel1.Controls.Add(this.label5, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.ctrlDateDOB, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtage, 12, 1);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtPhoneNo, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label19, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.cb_language, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label15, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtAmountRecived, 10, 5);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.ctrlCbxDoctor, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.AppointMentList, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 12, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1159, 602);
            this.tableLayoutPanel1.TabIndex = 258;
            // 
            // ctrlTxtFullAddress
            // 
            this.ctrlTxtFullAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ctrlTxtFullAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlTxtFullAddress, 2);
            this.ctrlTxtFullAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtFullAddress.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlTxtFullAddress.Location = new System.Drawing.Point(906, 53);
            this.ctrlTxtFullAddress.Multiline = true;
            this.ctrlTxtFullAddress.Name = "ctrlTxtFullAddress";
            this.tableLayoutPanel1.SetRowSpan(this.ctrlTxtFullAddress, 2);
            this.ctrlTxtFullAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ctrlTxtFullAddress.Size = new System.Drawing.Size(250, 44);
            this.ctrlTxtFullAddress.TabIndex = 16;
            // 
            // txtAddress
            // 
            this.txtAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtAddress, 2);
            this.txtAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAddress.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(906, 22);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(250, 25);
            this.txtAddress.TabIndex = 15;
            this.txtAddress.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // txtPresNo
            // 
            this.txtPresNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPresNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPresNo.Location = new System.Drawing.Point(3, 22);
            this.txtPresNo.Name = "txtPresNo";
            this.txtPresNo.Size = new System.Drawing.Size(93, 25);
            this.txtPresNo.TabIndex = 1;
            // 
            // cmb_apno
            // 
            this.cmb_apno.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmb_apno.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_apno.FormattingEnabled = true;
            this.cmb_apno.Location = new System.Drawing.Point(102, 22);
            this.cmb_apno.Name = "cmb_apno";
            this.cmb_apno.Size = new System.Drawing.Size(65, 25);
            this.cmb_apno.TabIndex = 3;
            // 
            // genderComboBox
            // 
            this.genderComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.genderComboBox.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.genderComboBox.Location = new System.Drawing.Point(579, 22);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(76, 25);
            this.genderComboBox.TabIndex = 9;
            // 
            // txtbmi
            // 
            this.txtbmi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtbmi.Enabled = false;
            this.txtbmi.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbmi.Location = new System.Drawing.Point(579, 72);
            this.txtbmi.Name = "txtbmi";
            this.txtbmi.Size = new System.Drawing.Size(76, 25);
            this.txtbmi.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(102, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "App No";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "E-Pres-No";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(579, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 19);
            this.label10.TabIndex = 38;
            this.label10.Text = "BMI";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(661, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 19);
            this.label11.TabIndex = 40;
            this.label11.Text = "HC in cms";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(579, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 19);
            this.label14.TabIndex = 8;
            this.label14.Text = "Gender";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label12, 2);
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(906, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(250, 19);
            this.label12.TabIndex = 14;
            this.label12.Text = "Area and Address";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 2);
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(173, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Patient ID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtpatiantID
            // 
            this.txtpatiantID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtpatiantID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtpatiantID, 2);
            this.txtpatiantID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtpatiantID.Enabled = false;
            this.txtpatiantID.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpatiantID.Location = new System.Drawing.Point(173, 22);
            this.txtpatiantID.Name = "txtpatiantID";
            this.txtpatiantID.Size = new System.Drawing.Size(88, 25);
            this.txtpatiantID.TabIndex = 5;
            this.txtpatiantID.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtpatiantID_KeyUp);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label2, 6);
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(267, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(306, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtname
            // 
            this.txtname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.txtname, 6);
            this.txtname.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(267, 22);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(306, 25);
            this.txtname.TabIndex = 7;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            this.txtname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtname_KeyDown);
            // 
            // ctrlCbxStatus
            // 
            this.ctrlCbxStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ctrlCbxStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ctrlCbxStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCbxStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ctrlCbxStatus.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlCbxStatus.FormattingEnabled = true;
            this.ctrlCbxStatus.Items.AddRange(new object[] {
            ""});
            this.ctrlCbxStatus.Location = new System.Drawing.Point(752, 72);
            this.ctrlCbxStatus.Name = "ctrlCbxStatus";
            this.ctrlCbxStatus.Size = new System.Drawing.Size(148, 25);
            this.ctrlCbxStatus.TabIndex = 45;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label20.Location = new System.Drawing.Point(752, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(148, 19);
            this.label20.TabIndex = 44;
            this.label20.Text = "Result";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label7, 2);
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(267, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 19);
            this.label7.TabIndex = 25;
            this.label7.Text = "Temp";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 1;
            this.numericUpDown1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDown1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDown1.Location = new System.Drawing.Point(267, 72);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(45, 25);
            this.numericUpDown1.TabIndex = 27;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            98,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label8, 2);
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(339, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 19);
            this.label8.TabIndex = 29;
            this.label8.Text = "Weight";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label9, 2);
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(455, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 19);
            this.label9.TabIndex = 32;
            this.label9.Text = "Height";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtweight
            // 
            this.txtweight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtweight.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtweight.Location = new System.Drawing.Point(339, 72);
            this.txtweight.Name = "txtweight";
            this.txtweight.Size = new System.Drawing.Size(76, 25);
            this.txtweight.TabIndex = 31;
            this.txtweight.TextChanged += new System.EventHandler(this.txtheight_TextChanged);
            // 
            // txtheight
            // 
            this.txtheight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtheight.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtheight.Location = new System.Drawing.Point(455, 72);
            this.txtheight.Name = "txtheight";
            this.txtheight.Size = new System.Drawing.Size(76, 25);
            this.txtheight.TabIndex = 33;
            this.txtheight.TextChanged += new System.EventHandler(this.txtheight_TextChanged);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Enabled = false;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label17.Location = new System.Drawing.Point(318, 78);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 12);
            this.label17.TabIndex = 256;
            this.label17.Text = "F";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Enabled = false;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label18.Location = new System.Drawing.Point(421, 78);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(28, 12);
            this.label18.TabIndex = 35;
            this.label18.Text = "Kgs";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.228571F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label21.Location = new System.Drawing.Point(537, 72);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 24);
            this.label21.TabIndex = 36;
            this.label21.Text = "Cms";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnsearch
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.btnsearch, 2);
            this.btnsearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnsearch.Location = new System.Drawing.Point(904, 122);
            this.btnsearch.Margin = new System.Windows.Forms.Padding(1);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(254, 28);
            this.btnsearch.TabIndex = 2;
            this.btnsearch.Text = "Search";
            this.btnsearch.Visible = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txthead
            // 
            this.txthead.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txthead.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthead.Location = new System.Drawing.Point(661, 72);
            this.txthead.Name = "txthead";
            this.txthead.Size = new System.Drawing.Size(85, 25);
            this.txthead.TabIndex = 42;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label16, 2);
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(173, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 19);
            this.label16.TabIndex = 23;
            this.label16.Text = "UHID";
            // 
            // ctrlTxtUHID
            // 
            this.ctrlTxtUHID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ctrlTxtUHID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlTxtUHID, 2);
            this.ctrlTxtUHID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlTxtUHID.Location = new System.Drawing.Point(173, 72);
            this.ctrlTxtUHID.Name = "ctrlTxtUHID";
            this.ctrlTxtUHID.Size = new System.Drawing.Size(88, 25);
            this.ctrlTxtUHID.TabIndex = 24;
            this.ctrlTxtUHID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ctrlTxtUHID_KeyDown);
            // 
            // txtdatetime
            // 
            this.txtdatetime.Location = new System.Drawing.Point(3, 548);
            this.txtdatetime.Name = "txtdatetime";
            this.txtdatetime.Size = new System.Drawing.Size(64, 25);
            this.txtdatetime.TabIndex = 1219;
            this.txtdatetime.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.chkOld);
            this.panel1.Location = new System.Drawing.Point(102, 548);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(45, 51);
            this.panel1.TabIndex = 1224;
            // 
            // chkOld
            // 
            this.chkOld.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.chkOld.AutoSize = true;
            this.chkOld.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.chkOld.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOld.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.chkOld.Location = new System.Drawing.Point(4, 20);
            this.chkOld.Margin = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.chkOld.Name = "chkOld";
            this.chkOld.Size = new System.Drawing.Size(55, 23);
            this.chkOld.TabIndex = 245;
            this.chkOld.Text = "Old ";
            this.chkOld.UseVisualStyleBackColor = false;
            this.chkOld.Visible = false;
            this.chkOld.CheckedChanged += new System.EventHandler(this.chkOld_CheckedChanged);
            // 
            // panel2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel2, 3);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnsaveapp);
            this.panel2.Controls.Add(this.btncategory);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(752, 548);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(404, 51);
            this.panel2.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(6, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Clear";
            this.button1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // btnsaveapp
            // 
            this.btnsaveapp.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaveapp.Location = new System.Drawing.Point(270, 8);
            this.btnsaveapp.Name = "btnsaveapp";
            this.btnsaveapp.Size = new System.Drawing.Size(125, 32);
            this.btnsaveapp.TabIndex = 2;
            this.btnsaveapp.Text = "Save Appointment";
            this.btnsaveapp.Click += new System.EventHandler(this.btnsaveapp_Click);
            // 
            // btncategory
            // 
            this.btncategory.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncategory.Location = new System.Drawing.Point(137, 8);
            this.btncategory.Name = "btncategory";
            this.btncategory.Size = new System.Drawing.Size(125, 32);
            this.btncategory.TabIndex = 1;
            this.btncategory.Text = "Category";
            this.btncategory.Click += new System.EventHandler(this.btncategory_Click);
            // 
            // txtdateSearch
            // 
            this.txtdateSearch.CalendarFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateSearch.CustomFormat = "dd/MM/yyyy";
            this.txtdateSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtdateSearch.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateSearch.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtdateSearch.Location = new System.Drawing.Point(752, 124);
            this.txtdateSearch.Name = "txtdateSearch";
            this.txtdateSearch.Size = new System.Drawing.Size(148, 25);
            this.txtdateSearch.TabIndex = 1;
            this.txtdateSearch.Visible = false;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label22.Location = new System.Drawing.Point(752, 100);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(148, 19);
            this.label22.TabIndex = 0;
            this.label22.Text = "Viewing Date";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label22.Visible = false;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(661, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 19);
            this.label5.TabIndex = 10;
            this.label5.Text = "DOB";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctrlDateDOB
            // 
            this.ctrlDateDOB.CalendarFont = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlDateDOB.CustomFormat = "dd/MM/yyyy";
            this.ctrlDateDOB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlDateDOB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlDateDOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ctrlDateDOB.Location = new System.Drawing.Point(661, 22);
            this.ctrlDateDOB.Name = "ctrlDateDOB";
            this.ctrlDateDOB.Size = new System.Drawing.Size(85, 25);
            this.ctrlDateDOB.TabIndex = 11;
            this.ctrlDateDOB.ValueChanged += new System.EventHandler(this.ctrlDateDOB_ValueChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(752, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 19);
            this.label6.TabIndex = 12;
            this.label6.Text = "Age";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtage
            // 
            this.txtage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtage.Enabled = false;
            this.txtage.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtage.Location = new System.Drawing.Point(752, 22);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(148, 25);
            this.txtage.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(3, 50);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 19);
            this.label13.TabIndex = 18;
            this.label13.Text = "Phone No";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPhoneNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPhoneNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhoneNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNo.Location = new System.Drawing.Point(3, 72);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(93, 25);
            this.txtPhoneNo.TabIndex = 19;
            this.txtPhoneNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPhoneNo_KeyDown);
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label19.Location = new System.Drawing.Point(102, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 19);
            this.label19.TabIndex = 21;
            this.label19.Text = "Language";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cb_language
            // 
            this.cb_language.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cb_language.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_language.FormattingEnabled = true;
            this.cb_language.Items.AddRange(new object[] {
            "English",
            "தமிழ்"});
            this.cb_language.Location = new System.Drawing.Point(102, 72);
            this.cb_language.Name = "cb_language";
            this.cb_language.Size = new System.Drawing.Size(65, 25);
            this.cb_language.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label15, 2);
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(579, 100);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(167, 21);
            this.label15.TabIndex = 48;
            this.label15.Text = "Amount Recived";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label15.Visible = false;
            // 
            // txtAmountRecived
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.txtAmountRecived, 2);
            this.txtAmountRecived.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAmountRecived.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountRecived.Location = new System.Drawing.Point(579, 124);
            this.txtAmountRecived.Name = "txtAmountRecived";
            this.txtAmountRecived.Size = new System.Drawing.Size(167, 25);
            this.txtAmountRecived.TabIndex = 49;
            this.txtAmountRecived.Visible = false;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.SetColumnSpan(this.label23, 5);
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label23.Location = new System.Drawing.Point(3, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(309, 19);
            this.label23.TabIndex = 46;
            this.label23.Text = "Doctor Name";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ctrlCbxDoctor
            // 
            this.ctrlCbxDoctor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ctrlCbxDoctor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlCbxDoctor, 5);
            this.ctrlCbxDoctor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlCbxDoctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ctrlCbxDoctor.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlCbxDoctor.FormattingEnabled = true;
            this.ctrlCbxDoctor.Items.AddRange(new object[] {
            ""});
            this.ctrlCbxDoctor.Location = new System.Drawing.Point(3, 124);
            this.ctrlCbxDoctor.Name = "ctrlCbxDoctor";
            this.ctrlCbxDoctor.Size = new System.Drawing.Size(309, 25);
            this.ctrlCbxDoctor.TabIndex = 47;
            this.ctrlCbxDoctor.SelectedIndexChanged += new System.EventHandler(this.CtrlCbxDoctor_SelectedIndexChanged);
            // 
            // AppointMentList
            // 
            this.AppointMentList.AllowUserToAddRows = false;
            this.AppointMentList.AllowUserToDeleteRows = false;
            this.AppointMentList.AllowUserToResizeColumns = false;
            this.AppointMentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.AppointMentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.AppointMentList, 15);
            this.AppointMentList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AppointMentList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.AppointMentList.Location = new System.Drawing.Point(3, 154);
            this.AppointMentList.MultiSelect = false;
            this.AppointMentList.Name = "AppointMentList";
            this.AppointMentList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AppointMentList.Size = new System.Drawing.Size(1153, 335);
            this.AppointMentList.TabIndex = 3;
            // 
            // panel3
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel3, 3);
            this.panel3.Controls.Add(this.ctrlBtnDeleteAppointmrnt);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(752, 495);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(404, 47);
            this.panel3.TabIndex = 4;
            // 
            // ctrlBtnDeleteAppointmrnt
            // 
            this.ctrlBtnDeleteAppointmrnt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ctrlBtnDeleteAppointmrnt.Location = new System.Drawing.Point(239, 8);
            this.ctrlBtnDeleteAppointmrnt.Name = "ctrlBtnDeleteAppointmrnt";
            this.ctrlBtnDeleteAppointmrnt.Size = new System.Drawing.Size(156, 32);
            this.ctrlBtnDeleteAppointmrnt.TabIndex = 0;
            this.ctrlBtnDeleteAppointmrnt.Text = "Delete Appointment";
            this.ctrlBtnDeleteAppointmrnt.Click += new System.EventHandler(this.ctrlBtnDeleteAppointmrnt_Click);
            // 
            // NewAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "NewAppointment";
            this.Size = new System.Drawing.Size(1159, 602);
            this.Load += new System.EventHandler(this.NewAppointment_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AppointMentList)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox txtPresNo;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.ComboBox cmb_apno;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.DateTimePicker ctrlDateDOB;
        private System.Windows.Forms.TextBox txtbmi;
        private System.Windows.Forms.TextBox txthead;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpatiantID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cb_language;
        private System.Windows.Forms.ComboBox ctrlCbxStatus;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtweight;
        private System.Windows.Forms.TextBox txtheight;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox chkOld;
        private System.Windows.Forms.Button btnsaveapp;
        private System.Windows.Forms.Button btncategory;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtdatetime;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox ctrlTxtUHID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ctrlTxtFullAddress;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox ctrlCbxDoctor;
        private System.Windows.Forms.DateTimePicker txtdateSearch;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAmountRecived;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView AppointMentList;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button ctrlBtnDeleteAppointmrnt;
    }
}
