﻿using ClassLibrary;
using SVMApplication.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SVMApplication
{
    public partial class frmLogin : MetroFramework.Forms.MetroForm
    {
        public Login log = new Login();
        public frmLogin()
        {
            InitializeComponent();
            ctrlTxtPassword.UseSystemPasswordChar = true;
        }

       

        // login
        private void ctrlBtnLogin_Click(object sender, EventArgs e)
        {
            AppMain.LoginUser = new LoginUser();
            DataTable table = new DataTable();
            table = log.LoginApplication(ctrlTxtUserName.Text, ctrlTxtPassword.Text,ctrlCbxUser.GetSelectedValueAsInt());
            if (table.Rows.Count > 0)
            {
                //ID USERNAME    PASS TYPE    FULL_NAME TEL EMAIL DOCTORCODE

                log.CurrentUser = table.Rows[0]["FULL_NAME"].ToString();
                if (table.Rows[0]["TYPE"].ToString().ToLower() == "1")
                {
                    log.IsAdmin = true;                    
                }
                SetCurrentUserDetail(table);

                log.IsLoginSuceesfully = true;

                //Save User name and Password for local reference
                if(ctrlChkSavePassword.Checked)
                {
                    SaveAuthentication();
                }

                this.Hide();

            }
            else
            {
                MessageBox.Show("Username Or Password Are Incorrect");
            }
        }

        private static void SetCurrentUserDetail (DataTable table)
        {
            AppMain.LoginUser.Id = Convert.ToInt32(table.Rows[0]["ID"]);
            AppMain.LoginUser.Type = Convert.ToString(table.Rows[0]["UserType"]);
            AppMain.LoginUser.UserName = table.Rows[0]["USERNAME"].ToString();
            AppMain.LoginUser.PassWord = table.Rows[0]["PASS"].ToString();
            AppMain.LoginUser.FullName = table.Rows[0]["FULL_NAME"].ToString();
            AppMain.LoginUser.MobileNo = table.Rows[0]["TEL"].ToString();
            AppMain.LoginUser.Email = table.Rows[0]["EMAIL"].ToString();
            AppMain.LoginUser.DoctorCode = table.Rows[0]["DOCTORCODE"].ToString();

            if (string.IsNullOrWhiteSpace(AppMain.LoginUser.DoctorCode))
            {
                AppMain.DoctorCode = "SV";
            }
            else
                AppMain.DoctorCode = AppMain.LoginUser.DoctorCode;

        }

        // show the password characters or not
        private void Password_CheckedChanged(object sender, EventArgs e)
        {
            if(ctrlChkShowPassword.Checked)
            {
                ctrlTxtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                ctrlTxtPassword.UseSystemPasswordChar = true;
            }
        }

       
        private void LoadUserType()
        {
            UserType t = new UserType();

            DataTable dataTable = t.GetUserType();
            
            ctrlCbxUser.Items.Clear();

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                ComboboxItem item = new ComboboxItem();
                item.Value = Convert.ToInt32(dataTable.Rows[i]["typeID"]);
                item.Text = (dataTable.Rows[i]["typeName"].ToString());

                ctrlCbxUser.Items.Add(item);
            }


        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            LoadUserType();          
            if(!string.IsNullOrWhiteSpace(Properties.Settings.Default.username)
                && !string.IsNullOrWhiteSpace(Properties.Settings.Default.password))
            RestoreAuthentication();
        }

        private void frmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            log.IsLoginSuceesfully = false;
        }

        private void ctrlChkSavePassword_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void SaveAuthentication()
        {
            Properties.Settings.Default.username = ctrlTxtUserName.Text;
            Properties.Settings.Default.password = ctrlTxtPassword.Text;
            Properties.Settings.Default.typeOfUser = ctrlCbxUser.Text;
            Properties.Settings.Default.Save();

        }

        private void RestoreAuthentication()
        {
            ctrlTxtUserName.Text = Properties.Settings.Default.username;
            ctrlTxtPassword.Text = Properties.Settings.Default.password;
            int index= ctrlCbxUser.FindStringExact(Properties.Settings.Default.typeOfUser);
            ctrlCbxUser.SelectedIndex = index;
        }

        private void ClearAuthentication()
        {
            string clear = "";
            Properties.Settings.Default.username = clear;
            Properties.Settings.Default.password = clear;
            Properties.Settings.Default.typeOfUser = clear;
            Properties.Settings.Default.Save();
        }

        private void ctrlBtnLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                ctrlBtnLogin_Click(this, null);
        }
    }
}
