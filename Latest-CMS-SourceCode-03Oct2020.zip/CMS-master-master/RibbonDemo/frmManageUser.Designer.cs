﻿namespace SVMApplication
{
    partial class frmManageUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlGridUser = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.ctrlTxtPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ctrlTxtEmail = new System.Windows.Forms.TextBox();
            this.ctrlTxtUserName = new System.Windows.Forms.TextBox();
            this.ctrlTxtFullName = new System.Windows.Forms.TextBox();
            this.ctrlTxtTEL = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ctrlTxtID = new System.Windows.Forms.TextBox();
            this.BTN_DELETE = new System.Windows.Forms.Button();
            this.BTN_UPDATE = new System.Windows.Forms.Button();
            this.BTN_NEW_USER = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ctrlCbxUserType = new MetroFramework.Controls.MetroComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ctrlTxtDoctorCode = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridUser)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctrlGridUser
            // 
            this.ctrlGridUser.AllowUserToAddRows = false;
            this.ctrlGridUser.AllowUserToDeleteRows = false;
            this.ctrlGridUser.AllowUserToOrderColumns = true;
            this.ctrlGridUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ctrlGridUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.ctrlGridUser, 2);
            this.ctrlGridUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlGridUser.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ctrlGridUser.Location = new System.Drawing.Point(3, 239);
            this.ctrlGridUser.Name = "ctrlGridUser";
            this.ctrlGridUser.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ctrlGridUser.Size = new System.Drawing.Size(750, 191);
            this.ctrlGridUser.TabIndex = 0;
            this.ctrlGridUser.Click += new System.EventHandler(this.ctrlGridUser_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 38;
            this.label5.Text = "Password : ";
            // 
            // ctrlTxtPassword
            // 
            this.ctrlTxtPassword.Location = new System.Drawing.Point(123, 138);
            this.ctrlTxtPassword.Name = "ctrlTxtPassword";
            this.ctrlTxtPassword.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtPassword.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(367, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 36;
            this.label4.Text = "Email : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(380, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 35;
            this.label3.Text = "Tel : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 34;
            this.label2.Text = "Full Name : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 33;
            this.label1.Text = "Username : ";
            // 
            // ctrlTxtEmail
            // 
            this.ctrlTxtEmail.Location = new System.Drawing.Point(433, 58);
            this.ctrlTxtEmail.Name = "ctrlTxtEmail";
            this.ctrlTxtEmail.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtEmail.TabIndex = 32;
            // 
            // ctrlTxtUserName
            // 
            this.ctrlTxtUserName.Location = new System.Drawing.Point(123, 99);
            this.ctrlTxtUserName.Name = "ctrlTxtUserName";
            this.ctrlTxtUserName.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtUserName.TabIndex = 31;
            // 
            // ctrlTxtFullName
            // 
            this.ctrlTxtFullName.Location = new System.Drawing.Point(123, 60);
            this.ctrlTxtFullName.Name = "ctrlTxtFullName";
            this.ctrlTxtFullName.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtFullName.TabIndex = 30;
            // 
            // ctrlTxtTEL
            // 
            this.ctrlTxtTEL.Location = new System.Drawing.Point(433, 19);
            this.ctrlTxtTEL.Name = "ctrlTxtTEL";
            this.ctrlTxtTEL.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtTEL.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 20);
            this.label6.TabIndex = 40;
            this.label6.Text = "ID : ";
            // 
            // ctrlTxtID
            // 
            this.ctrlTxtID.Location = new System.Drawing.Point(123, 19);
            this.ctrlTxtID.Name = "ctrlTxtID";
            this.ctrlTxtID.ReadOnly = true;
            this.ctrlTxtID.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtID.TabIndex = 39;
            // 
            // BTN_DELETE
            // 
            this.BTN_DELETE.BackColor = System.Drawing.Color.Black;
            this.BTN_DELETE.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_DELETE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(74)))));
            this.BTN_DELETE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_DELETE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_DELETE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_DELETE.ForeColor = System.Drawing.Color.White;
            this.BTN_DELETE.Location = new System.Drawing.Point(145, 14);
            this.BTN_DELETE.Name = "BTN_DELETE";
            this.BTN_DELETE.Size = new System.Drawing.Size(97, 33);
            this.BTN_DELETE.TabIndex = 41;
            this.BTN_DELETE.Text = "Delete";
            this.BTN_DELETE.UseVisualStyleBackColor = false;
            this.BTN_DELETE.Click += new System.EventHandler(this.ctrlBtnDelete_Click);
            // 
            // BTN_UPDATE
            // 
            this.BTN_UPDATE.BackColor = System.Drawing.Color.Black;
            this.BTN_UPDATE.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_UPDATE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(74)))));
            this.BTN_UPDATE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_UPDATE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_UPDATE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_UPDATE.ForeColor = System.Drawing.Color.White;
            this.BTN_UPDATE.Location = new System.Drawing.Point(33, 14);
            this.BTN_UPDATE.Name = "BTN_UPDATE";
            this.BTN_UPDATE.Size = new System.Drawing.Size(97, 33);
            this.BTN_UPDATE.TabIndex = 42;
            this.BTN_UPDATE.Text = "Update";
            this.BTN_UPDATE.UseVisualStyleBackColor = false;
            this.BTN_UPDATE.Click += new System.EventHandler(this.CtrlBtnUpdate_Click);
            // 
            // BTN_NEW_USER
            // 
            this.BTN_NEW_USER.BackColor = System.Drawing.Color.Black;
            this.BTN_NEW_USER.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_NEW_USER.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(189)))), ((int)(((byte)(74)))));
            this.BTN_NEW_USER.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(226)))), ((int)(((byte)(86)))));
            this.BTN_NEW_USER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_NEW_USER.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_NEW_USER.ForeColor = System.Drawing.Color.White;
            this.BTN_NEW_USER.Location = new System.Drawing.Point(258, 13);
            this.BTN_NEW_USER.Name = "BTN_NEW_USER";
            this.BTN_NEW_USER.Size = new System.Drawing.Size(179, 33);
            this.BTN_NEW_USER.TabIndex = 43;
            this.BTN_NEW_USER.Text = "Create New User";
            this.BTN_NEW_USER.UseVisualStyleBackColor = false;
            this.BTN_NEW_USER.Click += new System.EventHandler(this.ctrlBtnNewUser_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 676F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.ctrlGridUser, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 60);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 176F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(756, 433);
            this.tableLayoutPanel1.TabIndex = 44;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.ctrlTxtDoctorCode);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.ctrlCbxUserType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.ctrlTxtID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ctrlTxtUserName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ctrlTxtEmail);
            this.groupBox1.Controls.Add(this.ctrlTxtPassword);
            this.groupBox1.Controls.Add(this.ctrlTxtTEL);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ctrlTxtFullName);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(670, 170);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Details";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(367, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 20);
            this.label7.TabIndex = 42;
            this.label7.Text = "Type : ";
            // 
            // ctrlCbxUserType
            // 
            this.ctrlCbxUserType.Enabled = false;
            this.ctrlCbxUserType.FormattingEnabled = true;
            this.ctrlCbxUserType.ItemHeight = 23;
            this.ctrlCbxUserType.Location = new System.Drawing.Point(433, 97);
            this.ctrlCbxUserType.Name = "ctrlCbxUserType";
            this.ctrlCbxUserType.Size = new System.Drawing.Size(189, 29);
            this.ctrlCbxUserType.TabIndex = 41;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BTN_UPDATE);
            this.groupBox2.Controls.Add(this.BTN_NEW_USER);
            this.groupBox2.Controls.Add(this.BTN_DELETE);
            this.groupBox2.Location = new System.Drawing.Point(3, 179);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(480, 54);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Actions";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(367, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 20);
            this.label8.TabIndex = 44;
            this.label8.Text = "Code: ";
            // 
            // ctrlTxtDoctorCode
            // 
            this.ctrlTxtDoctorCode.Enabled = false;
            this.ctrlTxtDoctorCode.Location = new System.Drawing.Point(433, 138);
            this.ctrlTxtDoctorCode.Name = "ctrlTxtDoctorCode";
            this.ctrlTxtDoctorCode.Size = new System.Drawing.Size(189, 20);
            this.ctrlTxtDoctorCode.TabIndex = 43;
            // 
            // frmManageUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 513);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "frmManageUser";
            this.Text = "Manage User";
            this.Load += new System.EventHandler(this.frmManageUser_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ctrlGridUser)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView ctrlGridUser;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox ctrlTxtPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ctrlTxtEmail;
        private System.Windows.Forms.TextBox ctrlTxtUserName;
        private System.Windows.Forms.TextBox ctrlTxtFullName;
        private System.Windows.Forms.TextBox ctrlTxtTEL;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ctrlTxtID;
        private System.Windows.Forms.Button BTN_DELETE;
        private System.Windows.Forms.Button BTN_UPDATE;
        private System.Windows.Forms.Button BTN_NEW_USER;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private MetroFramework.Controls.MetroComboBox ctrlCbxUserType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ctrlTxtDoctorCode;
    }
}