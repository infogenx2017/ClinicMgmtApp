﻿using MetroFramework;

namespace SVMApplication
{
    partial class OpView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrltxtTotalNoOfpatient = new MetroFramework.Controls.MetroTextBox();
            this.txtpatientid = new MetroFramework.Controls.MetroTextBox();
            this.panel5 = new MetroFramework.Controls.MetroPanel();
            this.label7 = new MetroFramework.Controls.MetroLabel();
            this.btnexit = new MetroFramework.Controls.MetroButton();
            this.btnEdit = new MetroFramework.Controls.MetroButton();
            this.btnprint = new MetroFramework.Controls.MetroButton();
            this.directprintcheckbox = new System.Windows.Forms.CheckBox();
            this.label5 = new MetroFramework.Controls.MetroLabel();
            this.label6 = new MetroFramework.Controls.MetroLabel();
            this.panel2 = new MetroFramework.Controls.MetroPanel();
            this.label3 = new MetroFramework.Controls.MetroLabel();
            this.txtepressno = new MetroFramework.Controls.MetroTextBox();
            this.ctrllistbxEpresNo = new System.Windows.Forms.ListBox();
            this.panelVisible = new MetroFramework.Controls.MetroPanel();
            this.ctrlTxtReviewDate = new MetroFramework.Controls.MetroTextBox();
            this.label19 = new MetroFramework.Controls.MetroLabel();
            this.CategaryLbl = new MetroFramework.Controls.MetroLabel();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.label1 = new MetroFramework.Controls.MetroLabel();
            this.txtAddress = new MetroFramework.Controls.MetroTextBox();
            this.hclbl = new MetroFramework.Controls.MetroLabel();
            this.txtHC = new MetroFramework.Controls.MetroTextBox();
            this.prescriptionGrid = new System.Windows.Forms.DataGridView();
            this.panel4 = new MetroFramework.Controls.MetroPanel();
            this.label17 = new MetroFramework.Controls.MetroLabel();
            this.textBox2 = new MetroFramework.Controls.MetroTextBox();
            this.textBox1 = new MetroFramework.Controls.MetroTextBox();
            this.textBox15 = new MetroFramework.Controls.MetroTextBox();
            this.txttemp = new MetroFramework.Controls.MetroTextBox();
            this.txtbmi = new MetroFramework.Controls.MetroTextBox();
            this.label15 = new MetroFramework.Controls.MetroLabel();
            this.ctrltxtVisitDate = new MetroFramework.Controls.MetroTextBox();
            this.label14 = new MetroFramework.Controls.MetroLabel();
            this.txtDiagnosis = new MetroFramework.Controls.MetroTextBox();
            this.label18 = new MetroFramework.Controls.MetroLabel();
            this.txtweight = new MetroFramework.Controls.MetroTextBox();
            this.label11 = new MetroFramework.Controls.MetroLabel();
            this.txtgender = new MetroFramework.Controls.MetroTextBox();
            this.txtheight = new MetroFramework.Controls.MetroTextBox();
            this.txtage = new MetroFramework.Controls.MetroTextBox();
            this.txtname = new MetroFramework.Controls.MetroTextBox();
            this.label10 = new MetroFramework.Controls.MetroLabel();
            this.label9 = new MetroFramework.Controls.MetroLabel();
            this.label8 = new MetroFramework.Controls.MetroLabel();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelVisible.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prescriptionGrid)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // ctrltxtTotalNoOfpatient
            // 
            this.ctrltxtTotalNoOfpatient.Enabled = false;
            this.ctrltxtTotalNoOfpatient.Location = new System.Drawing.Point(10, 35);
            this.ctrltxtTotalNoOfpatient.Name = "ctrltxtTotalNoOfpatient";
            this.ctrltxtTotalNoOfpatient.Size = new System.Drawing.Size(118, 20);
            this.ctrltxtTotalNoOfpatient.TabIndex = 123;
            // 
            // txtpatientid
            // 
            this.txtpatientid.Enabled = false;
            this.txtpatientid.Location = new System.Drawing.Point(616, 54);
            this.txtpatientid.Name = "txtpatientid";
            this.txtpatientid.Size = new System.Drawing.Size(220, 20);
            this.txtpatientid.TabIndex = 7;
            this.txtpatientid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpatientid_KeyDown);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.btnexit);
            this.panel5.Controls.Add(this.btnEdit);
            this.panel5.Controls.Add(this.btnprint);
            this.panel5.Controls.Add(this.directprintcheckbox);
            this.panel5.Controls.Add(this.ctrltxtTotalNoOfpatient);
            this.panel5.HorizontalScrollbarBarColor = true;
            this.panel5.HorizontalScrollbarHighlightOnWheel = false;
            this.panel5.HorizontalScrollbarSize = 10;
            this.panel5.Location = new System.Drawing.Point(12, 528);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(822, 62);
            this.panel5.TabIndex = 122;
            this.panel5.VerticalScrollbarBarColor = true;
            this.panel5.VerticalScrollbarHighlightOnWheel = false;
            this.panel5.VerticalScrollbarSize = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(7, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 19);
            this.label7.TabIndex = 0;
            this.label7.Text = "Total No of Patients";
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(729, 26);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(86, 30);
            this.btnexit.TabIndex = 1;
            this.btnexit.Text = "Exit";
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Enabled = false;
            this.btnEdit.Location = new System.Drawing.Point(542, 26);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(86, 30);
            this.btnEdit.TabIndex = 0;
            this.btnEdit.Text = "Edit";
            this.btnEdit.Click += new System.EventHandler(this.ctrllistbxEpresNo_DoubleClick);
            // 
            // btnprint
            // 
            this.btnprint.Highlight = true;
            this.btnprint.Location = new System.Drawing.Point(636, 26);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(86, 30);
            this.btnprint.TabIndex = 0;
            this.btnprint.Text = "Print";
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // directprintcheckbox
            // 
            this.directprintcheckbox.AutoSize = true;
            this.directprintcheckbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.directprintcheckbox.ForeColor = System.Drawing.Color.White;
            this.directprintcheckbox.Location = new System.Drawing.Point(637, 6);
            this.directprintcheckbox.Name = "directprintcheckbox";
            this.directprintcheckbox.Size = new System.Drawing.Size(90, 17);
            this.directprintcheckbox.TabIndex = 119;
            this.directprintcheckbox.Text = "Direct Print";
            this.directprintcheckbox.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.FontWeight =  MetroLabelWeight.Bold;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(527, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 19);
            this.label5.TabIndex = 85;
            this.label5.Text = "Patient ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
           // this.label6.FontSize = MetroLabelSize.Medium;;
            this.label6.FontWeight =  MetroLabelWeight.Bold;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(61, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "E.Pres.No";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label6);
            this.panel2.HorizontalScrollbarBarColor = true;
            this.panel2.HorizontalScrollbarHighlightOnWheel = false;
            this.panel2.HorizontalScrollbarSize = 10;
            this.panel2.Location = new System.Drawing.Point(12, 55);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(205, 27);
            this.panel2.TabIndex = 89;
            this.panel2.VerticalScrollbarBarColor = true;
            this.panel2.VerticalScrollbarHighlightOnWheel = false;
            this.panel2.VerticalScrollbarSize = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.FontWeight =  MetroLabelWeight.Bold;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(230, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 19);
            this.label3.TabIndex = 128;
            this.label3.Text = "E.Pres.No";
            // 
            // txtepressno
            // 
            this.txtepressno.Enabled = false;
            this.txtepressno.Location = new System.Drawing.Point(325, 55);
            this.txtepressno.Name = "txtepressno";
            this.txtepressno.Size = new System.Drawing.Size(192, 20);
            this.txtepressno.TabIndex = 1;
            this.txtepressno.TextChanged += new System.EventHandler(this.txtepressno_TextChanged);
            this.txtepressno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtepressno_KeyDown);
            // 
            // ctrllistbxEpresNo
            // 
            this.ctrllistbxEpresNo.FormattingEnabled = true;
            this.ctrllistbxEpresNo.Location = new System.Drawing.Point(12, 84);
            this.ctrllistbxEpresNo.Name = "ctrllistbxEpresNo";
            this.ctrllistbxEpresNo.Size = new System.Drawing.Size(205, 433);
            this.ctrllistbxEpresNo.TabIndex = 129;
            this.ctrllistbxEpresNo.Click += new System.EventHandler(this.listBox2_Click);
            this.ctrllistbxEpresNo.DoubleClick += new System.EventHandler(this.ctrllistbxEpresNo_DoubleClick);
            // 
            // panelVisible
            // 
            this.panelVisible.Controls.Add(this.ctrlTxtReviewDate);
            this.panelVisible.Controls.Add(this.label19);
            this.panelVisible.Controls.Add(this.CategaryLbl);
            this.panelVisible.Controls.Add(this.cbCategory);
            this.panelVisible.Controls.Add(this.label1);
            this.panelVisible.Controls.Add(this.txtAddress);
            this.panelVisible.Controls.Add(this.hclbl);
            this.panelVisible.Controls.Add(this.txtHC);
            this.panelVisible.Controls.Add(this.prescriptionGrid);
            this.panelVisible.Controls.Add(this.panel4);
            this.panelVisible.Controls.Add(this.textBox2);
            this.panelVisible.Controls.Add(this.textBox1);
            this.panelVisible.Controls.Add(this.textBox15);
            this.panelVisible.Controls.Add(this.txttemp);
            this.panelVisible.Controls.Add(this.txtbmi);
            this.panelVisible.Controls.Add(this.label15);
            this.panelVisible.Controls.Add(this.ctrltxtVisitDate);
            this.panelVisible.Controls.Add(this.label14);
            this.panelVisible.Controls.Add(this.txtDiagnosis);
            this.panelVisible.Controls.Add(this.label18);
            this.panelVisible.Controls.Add(this.txtweight);
            this.panelVisible.Controls.Add(this.label11);
            this.panelVisible.Controls.Add(this.txtgender);
            this.panelVisible.Controls.Add(this.txtheight);
            this.panelVisible.Controls.Add(this.txtage);
            this.panelVisible.Controls.Add(this.txtname);
            this.panelVisible.Controls.Add(this.label10);
            this.panelVisible.Controls.Add(this.label9);
            this.panelVisible.Controls.Add(this.label8);
            this.panelVisible.Enabled = false;
            this.panelVisible.HorizontalScrollbarBarColor = true;
            this.panelVisible.HorizontalScrollbarHighlightOnWheel = false;
            this.panelVisible.HorizontalScrollbarSize = 10;
            this.panelVisible.Location = new System.Drawing.Point(225, 81);
            this.panelVisible.Name = "panelVisible";
            this.panelVisible.Size = new System.Drawing.Size(614, 441);
            this.panelVisible.TabIndex = 138;
            this.panelVisible.VerticalScrollbarBarColor = true;
            this.panelVisible.VerticalScrollbarHighlightOnWheel = false;
            this.panelVisible.VerticalScrollbarSize = 10;
            // 
            // ctrlTxtReviewDate
            // 
            this.ctrlTxtReviewDate.Location = new System.Drawing.Point(457, 70);
            this.ctrlTxtReviewDate.Name = "ctrlTxtReviewDate";
            this.ctrlTxtReviewDate.Size = new System.Drawing.Size(155, 20);
            this.ctrlTxtReviewDate.TabIndex = 169;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(370, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(76, 19);
            this.label19.TabIndex = 170;
            this.label19.Text = "ReviewDate";
            // 
            // CategaryLbl
            // 
            this.CategaryLbl.AutoSize = true;
            this.CategaryLbl.Location = new System.Drawing.Point(370, 16);
            this.CategaryLbl.Name = "CategaryLbl";
            this.CategaryLbl.Size = new System.Drawing.Size(63, 19);
            this.CategaryLbl.TabIndex = 168;
            this.CategaryLbl.Text = "Category";
            // 
            // cbCategory
            // 
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Location = new System.Drawing.Point(457, 14);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(155, 21);
            this.cbCategory.TabIndex = 167;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(173, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 19);
            this.label1.TabIndex = 166;
            this.label1.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(231, 14);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(133, 48);
            this.txtAddress.TabIndex = 165;
            // 
            // hclbl
            // 
            this.hclbl.AutoSize = true;
            this.hclbl.Location = new System.Drawing.Point(173, 73);
            this.hclbl.Name = "hclbl";
            this.hclbl.Size = new System.Drawing.Size(27, 19);
            this.hclbl.TabIndex = 164;
            this.hclbl.Text = "HC";
            // 
            // txtHC
            // 
            this.txtHC.Location = new System.Drawing.Point(231, 72);
            this.txtHC.Name = "txtHC";
            this.txtHC.Size = new System.Drawing.Size(133, 20);
            this.txtHC.TabIndex = 163;
            // 
            // prescriptionGrid
            // 
            this.prescriptionGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prescriptionGrid.Location = new System.Drawing.Point(5, 194);
            this.prescriptionGrid.Name = "prescriptionGrid";
            this.prescriptionGrid.Size = new System.Drawing.Size(605, 242);
            this.prescriptionGrid.TabIndex = 161;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label17);
            this.panel4.HorizontalScrollbarBarColor = true;
            this.panel4.HorizontalScrollbarHighlightOnWheel = false;
            this.panel4.HorizontalScrollbarSize = 10;
            this.panel4.Location = new System.Drawing.Point(5, 159);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(605, 27);
            this.panel4.TabIndex = 160;
            this.panel4.VerticalScrollbarBarColor = true;
            this.panel4.VerticalScrollbarHighlightOnWheel = false;
            this.panel4.VerticalScrollbarSize = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.FontSize = MetroLabelSize.Medium;
            this.label17.FontWeight =  MetroLabelWeight.Bold;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(228, 4);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 19);
            this.label17.TabIndex = 0;
            this.label17.Text = "Prescription";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(488, 104);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(25, 20);
            this.textBox2.TabIndex = 159;
            this.textBox2.Text = "Kgs";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(417, 104);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(25, 20);
            this.textBox1.TabIndex = 159;
            this.textBox1.Text = "Cms";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(557, 104);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(25, 20);
            this.textBox15.TabIndex = 159;
            this.textBox15.Text = "°F";
            // 
            // txttemp
            // 
            this.txttemp.Location = new System.Drawing.Point(516, 104);
            this.txttemp.Name = "txttemp";
            this.txttemp.Size = new System.Drawing.Size(38, 20);
            this.txttemp.TabIndex = 147;
            // 
            // txtbmi
            // 
            this.txtbmi.Location = new System.Drawing.Point(53, 102);
            this.txtbmi.Name = "txtbmi";
            this.txtbmi.Size = new System.Drawing.Size(113, 20);
            this.txtbmi.TabIndex = 146;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(2, 105);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 19);
            this.label15.TabIndex = 157;
            this.label15.Text = "BMI";
            // 
            // ctrltxtVisitDate
            // 
            this.ctrltxtVisitDate.Location = new System.Drawing.Point(457, 42);
            this.ctrltxtVisitDate.Name = "ctrltxtVisitDate";
            this.ctrltxtVisitDate.Size = new System.Drawing.Size(155, 20);
            this.ctrltxtVisitDate.TabIndex = 145;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(370, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 19);
            this.label14.TabIndex = 156;
            this.label14.Text = "VisitDate";
            // 
            // txtDiagnosis
            // 
            this.txtDiagnosis.Location = new System.Drawing.Point(71, 131);
            this.txtDiagnosis.Name = "txtDiagnosis";
            this.txtDiagnosis.Size = new System.Drawing.Size(539, 20);
            this.txtDiagnosis.TabIndex = 148;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(2, 132);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 19);
            this.label18.TabIndex = 162;
            this.label18.Text = "Diagnosis";
            // 
            // txtweight
            // 
            this.txtweight.Location = new System.Drawing.Point(448, 104);
            this.txtweight.Name = "txtweight";
            this.txtweight.Size = new System.Drawing.Size(38, 20);
            this.txtweight.TabIndex = 144;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(172, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 19);
            this.label11.TabIndex = 152;
            this.label11.Text = "Height / Weight / Temperature :";
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(53, 70);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(113, 20);
            this.txtgender.TabIndex = 142;
            // 
            // txtheight
            // 
            this.txtheight.Location = new System.Drawing.Point(376, 104);
            this.txtheight.Name = "txtheight";
            this.txtheight.Size = new System.Drawing.Size(38, 20);
            this.txtheight.TabIndex = 143;
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(53, 42);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(113, 20);
            this.txtage.TabIndex = 141;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(53, 14);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(113, 20);
            this.txtname.TabIndex = 140;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(2, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 19);
            this.label10.TabIndex = 151;
            this.label10.Text = "Sex";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(2, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 19);
            this.label9.TabIndex = 150;
            this.label9.Text = "Age";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(2, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 19);
            this.label8.TabIndex = 149;
            this.label8.Text = "Name";
            // 
            // OpView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 603);
            this.Controls.Add(this.panelVisible);
            this.Controls.Add(this.ctrllistbxEpresNo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtepressno);
            this.Controls.Add(this.txtpatientid);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.MaximizeBox = false;
            this.Name = "OpView";
            this.Resizable = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Prescription Details";
            this.Load += new System.EventHandler(this.OpView_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelVisible.ResumeLayout(false);
            this.panelVisible.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prescriptionGrid)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox ctrltxtTotalNoOfpatient;
        private MetroFramework.Controls.MetroTextBox txtpatientid;
        private MetroFramework.Controls.MetroPanel panel5;
        private MetroFramework.Controls.MetroButton btnexit;
        private MetroFramework.Controls.MetroButton btnprint;
        private System.Windows.Forms.CheckBox directprintcheckbox;
        private MetroFramework.Controls.MetroLabel label7;
        private MetroFramework.Controls.MetroLabel label5;
        private MetroFramework.Controls.MetroLabel label6;
        private MetroFramework.Controls.MetroPanel panel2;
        private MetroFramework.Controls.MetroLabel label3;
        private MetroFramework.Controls.MetroTextBox txtepressno;
        private System.Windows.Forms.ListBox ctrllistbxEpresNo;
        private MetroFramework.Controls.MetroPanel panelVisible;
        private MetroFramework.Controls.MetroTextBox ctrlTxtReviewDate;
        private MetroFramework.Controls.MetroLabel label19;
        private MetroFramework.Controls.MetroLabel CategaryLbl;
        private System.Windows.Forms.ComboBox cbCategory;
        private MetroFramework.Controls.MetroLabel label1;
        private MetroFramework.Controls.MetroTextBox txtAddress;
        private MetroFramework.Controls.MetroLabel hclbl;
        private MetroFramework.Controls.MetroTextBox txtHC;
        private System.Windows.Forms.DataGridView prescriptionGrid;
        private MetroFramework.Controls.MetroPanel panel4;
        private MetroFramework.Controls.MetroLabel label17;
        private MetroFramework.Controls.MetroTextBox txttemp;
        private MetroFramework.Controls.MetroTextBox txtbmi;
        private MetroFramework.Controls.MetroLabel label15;
        private MetroFramework.Controls.MetroTextBox ctrltxtVisitDate;
        private MetroFramework.Controls.MetroLabel label14;
        private MetroFramework.Controls.MetroTextBox txtDiagnosis;
        private MetroFramework.Controls.MetroLabel label18;
        private MetroFramework.Controls.MetroTextBox txtweight;
        private MetroFramework.Controls.MetroLabel label11;
        private MetroFramework.Controls.MetroTextBox txtgender;
        private MetroFramework.Controls.MetroTextBox txtheight;
        private MetroFramework.Controls.MetroTextBox txtage;
        private MetroFramework.Controls.MetroTextBox txtname;
        private MetroFramework.Controls.MetroLabel label10;
        private MetroFramework.Controls.MetroLabel label9;
        private MetroFramework.Controls.MetroLabel label8;
        private MetroFramework.Controls.MetroTextBox textBox15;
        private MetroFramework.Controls.MetroTextBox textBox2;
        private MetroFramework.Controls.MetroTextBox textBox1;
        private MetroFramework.Controls.MetroButton btnEdit;

    }
}