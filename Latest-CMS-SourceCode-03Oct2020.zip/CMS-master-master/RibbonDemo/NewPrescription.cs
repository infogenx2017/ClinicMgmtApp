﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
using System.Globalization;
using SVMApplication.Helper;
using MetroFramework.Controls;

namespace SVMApplication
{

    public partial class NewPrescription : UserControl
    {
        private bool _print = true;
        public string constr = ConfigurationManager.AppSettings["ConnectionInfo"].ToString();
        public string Clinicalfilelocation = ConfigurationManager.AppSettings["Clinicalfilelocation"].ToString();
        public string AdviceTamilfilelocation = ConfigurationManager.AppSettings["AdviceTamilfilelocation"].ToString();
        public string AdviceEnglishfilelocation = ConfigurationManager.AppSettings["AdviceEnglishfilelocation"].ToString();
        string prescno = "", appointmentno = "", patientno = "";
      
        int yearDiff;
        int monthdiff;
        int daysdiff;
        string MaxSeq = string.Empty;
        string ApNo = string.Empty;
        public static DataSet dataretrive = new DataSet();
        public string epressno;
        public string patientid;
        public string Applno;
        public static string CString = "";
        public static string AdviceString = "";
        public static string SetValueForEpresNoRpt = "";
        public MainForm mAinFOrm = null;
        PersonalInformation personalInformation = new PersonalInformation();

        
        public NewPrescription(MainForm _main)
        {
            InitializeComponent();
            mAinFOrm = _main;
            AutoCompleteStringCollection divDoes = new AutoCompleteStringCollection();
            divDoes.Add("45");
            divDoes.Add("35");
            divDoes.Add("25");
            divDoes.Add("10");

            txtPhoneNo.MaxLength = 10;

            // this.KeyDown += new KeyEventHandler(Prescription_Details_KeyDown);
            FillDropDownAppNo();
            if (dataretrive.Tables.Count > 0)
            {
                loaddatas(dataretrive);
                dataretrive.Tables.Clear();
                ctrldataGridPrescription.Columns[7].Visible = false;
            }
            else
            {
                txtname.Text = "";
                txtPhoneNo.Text = "";
                txtAddress.Text = "";
                txtage.Text = "";
                //dateTimePicker1.Text = DateTime.Now.ToShortDateString();
                genderComboBox.Text = "Male";
                //GetData();
            }
        }

        #region IN6TECH EVENTS

        public void Prescription_Load(object sender, EventArgs e)
        {
            if (sender != null)
                return;
            ctrlDateDOB.MaxDate = DateTime.Now;
            txtname.Text = "";
            txtAddress.Text = "";
            txtage.Text = "";
            txtPhoneNo.Text = "";
            txtPresNo.ForeColor = Properties.Settings.Default.CFontColor;
            FillDropDownAppNo();
            cb_language.SelectedIndex = 1;
            ctrlCbxStatus.SelectedIndex = 0;
            numericUpDown1.Value = 98;
            genderComboBox.SelectedIndex = 0;
            txtdatetime.Text = DateTime.Now.ToString();
            GetData();
            autonumber();
            SetColumWidth();

            ctrldataGridPrescription.Columns[2].HeaderText = "Qty"; ;
            ctrldataGridPrescription.Columns[7].Visible = false;
            new GeneralMethods().LoadDiagnosis(ref txtDiagnosis);
            LoadMedician();
            LoadDefaultDropDownValues();
            chkOld_CheckedChanged(null, null);
            this.Focus();

            List<Control> LabelControl = new List<Control>();
            List<Control> OtherControl = new List<Control>();
            UpdatePrescriptionControls(ref LabelControl, ref OtherControl, tableLayoutPanel1);
            foreach (Control c in LabelControl)
                StaticIN6.UpdateColorLabels(c);
            foreach (Control c in OtherControl)
                StaticIN6.UpdateColorControls(c, this);

            
        }

        private void SetColumWidth()
        {
            ctrldataGridPrescription.Columns[0].Width = 50;
            ctrldataGridPrescription.Columns[1].Width = ctrldataGridPrescription.Width / 4;
            ctrldataGridPrescription.Columns[2].Width = 60;
            ctrldataGridPrescription.Columns[3].Width = 100;
            ctrldataGridPrescription.Columns[4].Width = ctrldataGridPrescription.Width / 5;
            ctrldataGridPrescription.Columns[5].Width = 100;
        }
        private void UpdatePrescriptionControls(ref List<Control> LabelControl, ref List<Control> OtherControl, TableLayoutPanel _tableLayoutPanel)
        {
            Control _c = null;
            Control _oc = null;

            foreach (Control c in _tableLayoutPanel.Controls)
                if ((c.Name.Contains("label") || c.Name.Contains("chk") || c.Name.Contains("btn")) && c.Enabled)
                { LabelControl.Add(c); _c = c; }
                else if (c.Name.Contains("table"))
                {
                    if (_tableLayoutPanel.Name.ToString() != "tableLayoutPanel1" && _tableLayoutPanel.Name.ToString() != "tableLayoutPanel2")
                        LabelControl.Add(_tableLayoutPanel); _c = _tableLayoutPanel;
                    UpdatePrescriptionControls(ref LabelControl, ref OtherControl, (TableLayoutPanel)c);
                }
                else if (!c.Name.Contains("label") && !c.Name.Contains("chk") && !c.Name.Contains("btn"))
                { OtherControl.Add(c); _oc = c; }

        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime todaydate = DateTime.Now.Date; ;
            DateTime clickedDate = ctrlDateDOB.Value.Date;

            //CalculateDate(todaydate, clickedDate);
            DateDifference(todaydate, clickedDate);
            //txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon " + daysdiff + "Days";

            if (yearDiff > 0 && monthdiff > 0 && daysdiff > 0)
            {
                txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon " + daysdiff + "Days";
            }
            else if (yearDiff > 0 && monthdiff > 0 && daysdiff == 0)
            {
                txtage.Text = yearDiff + "Yrs " + monthdiff + "Mon ";
            }
            else if (yearDiff > 0 && monthdiff == 0 && daysdiff > 0)
            {
                txtage.Text = yearDiff + "Yrs " + daysdiff + "Days";
            }
            else if (yearDiff > 0 && monthdiff == 0 && daysdiff == 0)
            {
                txtage.Text = yearDiff + "Yrs ";
            }
            else if (yearDiff == 0 && monthdiff > 0 && daysdiff > 0)
            {
                txtage.Text = monthdiff + "Mon " + daysdiff + "Days";
            }
            else if (yearDiff == 0 && monthdiff > 0 && daysdiff == 0)
            {
                txtage.Text = monthdiff + "Mon ";
            }
            else if (yearDiff == 0 && monthdiff == 0 && daysdiff > 0)
            {
                txtage.Text = daysdiff + "Days";
            }
            else if (yearDiff == 0 && monthdiff == 0 && daysdiff == 0)
            {
                txtage.Text = daysdiff + "Days";
            }



            if (yearDiff <= 5)
                ctrlLblPatientHis.Enabled = true;
            else
            { ctrlLblPatientHis.ReadOnly = false; ctrlLblPatientHis.ForeColor = Properties.Settings.Default.CFontColor; }

            if (txtweight.Text != "" && _print)
                LoadDrugCalculation();
            _print = true;
        }
        private void chkOld_CheckedChanged(object sender, EventArgs e)
        {
            if (((Ribbon)mAinFOrm.Controls[1]).QuickAcessToolbar.Items.Count > 0)
            {
                object _control = ((Ribbon)mAinFOrm.Controls[1]).QuickAcessToolbar.Items[2];
                if (chkOld.Checked)
                {
                    ((RibbonButton)_control).SmallImage = Properties.Resources.Check16;
                    ((RibbonButton)_control).SmallImage.Tag = "Checked";
                    ((RibbonButton)_control).ToolTipImage = Properties.Resources.Check16;
                    ((RibbonButton)_control).ToolTipTitle = "Old";
                    ((RibbonButton)_control).ToolTipTitle = "To Enable Old; Please click here ...";
                }
                else
                {
                    ((RibbonButton)_control).SmallImage = Properties.Resources.unCheck16;
                    ((RibbonButton)_control).SmallImage.Tag = "Unchecked";
                    ((RibbonButton)_control).ToolTipImage = Properties.Resources.unCheck16;
                    ((RibbonButton)_control).ToolTipTitle = "New";
                    ((RibbonButton)_control).ToolTipTitle = "To Disable Old; Please click here ...";
                }
            }
            if (chkOld.Checked == true)
            {
                txtpatiantID.Enabled = true;
                txtpatiantID.Focus();
            }
            else
            {
                ClearOldValues();
                GetData();
                autonumber();
                txtpatiantID.ReadOnly = false;
                txtpatiantID.ForeColor = Properties.Settings.Default.CFontColor;
                cmb_apno.Focus();
            }
        }
        private void txtweight_TextChanged(object sender, EventArgs e)
        {

        }
        private void txtheight_TextChanged(object sender, EventArgs e)
        {
            if (txtweight.Text != "" && txtheight.Text != "")
                CalculateBMI(Convert.ToDouble(txtweight.Text), Convert.ToDouble(txtheight.Text));
        }
        private void txtDiagnosis_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txtDiagnosis.Text != "")
                {
                    txtDiagnosis.Text = txtDiagnosis.Text.Substring(0, 1).ToUpper() + txtDiagnosis.Text.Substring(1);
                    txtDiagnosis.SelectionStart = txtDiagnosis.Text.Length;
                    SqlConnection con = new SqlConnection(constr);
                    DataSet ds = new DataSet();
                    con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                    string querry = @"Select RowID,DiagnosisHTML,AdviceTamil from Diagnosis Where Diagnosis=@Diagnosis";

                    if (cb_language.Text.ToUpper() == "ENGLISH")
                        querry = @"Select RowID,DiagnosisHTML,AdviceEnglish as Advice from Diagnosis Where Diagnosis=@Diagnosis";
                    else
                        querry = @"Select RowID,DiagnosisHTML,AdviceTamil as Advice from Diagnosis Where Diagnosis=@Diagnosis";

                    SqlCommand cmd = new SqlCommand(querry, con);
                    cmd.Parameters.AddWithValue("@Diagnosis", txtDiagnosis.Text.Trim());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        // lblDiagnosisRowID.Text = ds.Tables[0].Rows[0]["RowID"].ToString();
                        System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                        rtBox.Rtf = ds.Tables[0].Rows[0]["DiagnosisHTML"].ToString();
                        txtClinical.Text = rtBox.Text;
                        rtBox.Rtf = ds.Tables[0].Rows[0]["Advice"].ToString();
                        txtAdvice.Text = rtBox.Text;
                    }
                    else
                    {
                        txtClinical.Text = "";
                        txtAdvice.Text = "";
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ctrldataGridPrescription_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (txtweight.Text != "")
            {
                if (e.ColumnIndex == 1 && e.RowIndex != -1)
                {
                    int Rowid = e.RowIndex;

                    if (ctrldataGridPrescription.Rows[Rowid].Cells[1].Value != "")
                    {
                        SqlConnection con = new SqlConnection(constr);
                        DataSet ds = new DataSet();
                        con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                        string querry = @"Select isnull(StrMg,0)[StrMg], ISNULL(StrML,0)[StrML],isnull(Dose,0)[Dose],DivDose,Inst,Insttamil,DQty,str1U,Str2U," +
                                        " DrugBased,DrugType,B.DrugTypeName,B.DisplayName,A.Duration,A.Fixeddose  from Drug[A] Left Join DrugType[B] On a.DrugType=B.RowID " +
                                        " Where Drug=@Drug";
                        SqlCommand cmd = new SqlCommand(querry, con);
                        cmd.Parameters.AddWithValue("@Drug", ctrldataGridPrescription.Rows[Rowid].Cells[1].Value);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(ds);
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "1")
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = e.RowIndex + 1;
                                ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = ds.Tables[0].Rows[0]["DQty"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = ds.Tables[0].Rows[0]["Fixeddose"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = ds.Tables[0].Rows[0]["DivDose"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = ds.Tables[0].Rows[0]["Inst"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();
                            }
                            else if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "2")
                            {

                                DateTime todaydate = DateTime.Now;
                                DateTime clickedDate = ctrlDateDOB.Value.Date;
                                CalculateDate(todaydate, clickedDate);
                                DataTable dt = fillAgeBasedCalculation(monthdiff, yearDiff, ctrldataGridPrescription.Rows[Rowid].Cells[1].Value.ToString());
                                if (dt.Rows.Count > 0)
                                {
                                    ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = e.RowIndex + 1;
                                    ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = dt.Rows[0]["DQty"].ToString();
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = dt.Rows[0]["Dose"].ToString();
                                    ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = dt.Rows[0]["DivDose"].ToString();
                                    ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString();
                                    ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = dt.Rows[0]["Inst"].ToString();
                                    ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();
                                }
                                else
                                {
                                    ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = e.RowIndex + 1;
                                    ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = "";
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = "";
                                    ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = "";
                                    ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = "";
                                    ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = "";
                                    ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = "";
                                }
                            }
                            else if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "3")
                            {
                                double Weight = 0;
                                if (txtweight.Text != "")
                                    Weight = Convert.ToDouble(txtweight.Text);
                                ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = ds.Tables[0].Rows[0]["DQty"].ToString();

                                double Dose = Convert.ToDouble(ds.Tables[0].Rows[0]["Dose"].ToString());
                                double divDOse = 1;
                                if (ds.Tables[0].Rows[0]["DivDose"].ToString() != "" && !ds.Tables[0].Rows[0]["DivDose"].ToString().StartsWith("As"))
                                    if (ds.Tables[0].Rows[0]["DivDose"].ToString().Substring(0, 1).ToUpper() == "O")
                                        divDOse = 1;
                                    else
                                        divDOse = Convert.ToDouble(ds.Tables[0].Rows[0]["DivDose"].ToString().Substring(0, 1));

                                double doseperkg = Dose * Weight;
                                double doseperint = 0;
                                doseperint = doseperkg / divDOse;
                                double fnl = 0;
                                double StrMg = Convert.ToDouble(ds.Tables[0].Rows[0]["StrMg"].ToString());
                                double StrML = Convert.ToDouble(ds.Tables[0].Rows[0]["StrML"].ToString());
                                double str = StrMg / StrML;

                                //double Weight = 0; 
                                //if (txtweight.Text != "")
                                //    Weight = Convert.ToDouble(txtweight.Text);
                                //if (ds.Tables[0].Rows[0]["str1U"].ToString() == "ml")
                                //    fnl = PerDose * Weight / StrML;
                                //else
                                fnl = doseperint / str;
                                //if (ds.Tables[0].Rows[0]["DrugTypeName"].ToString() == "Tablet" || ds.Tables[0].Rows[0]["DrugTypeName"].ToString() == "Drops")

                                if (ds.Tables[0].Rows[0]["str1U"].ToString() == "ml")
                                {
                                    ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                    double dd = Math.Round(fnl, 1);
                                    string asd = dd.ToString().Split('.')[0];
                                    if (Convert.ToInt32(asd) == 0)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Convert.ToDouble(dd.ToString().Split('.')[0]).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) <= 2)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Convert.ToDouble(dd.ToString().Split('.')[0]) + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 2 && Convert.ToInt32(asd) <= 7)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + .5).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 7)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();

                                }
                                else if (ds.Tables[0].Rows[0]["str1U"].ToString() == "Tab")
                                {
                                    ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                    double dd = Math.Round(fnl, 2);
                                    string asd = "";
                                    if (dd.ToString().Split('.').Length > 1)
                                    {
                                        asd = dd.ToString().Split('.')[1].PadRight(2, '0');
                                        string apnval = Convert.ToDouble(dd.ToString().Split('.')[0]).ToString() == "0" ? "" : Convert.ToDouble(dd.ToString().Split('.')[0]).ToString();

                                        if (Convert.ToInt32(asd) == 0)
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                        else if (Convert.ToInt32(asd) <= 37)
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 1/4 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                        else if (Convert.ToInt32(asd) > 37 && Convert.ToInt32(asd) <= 62)
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 1/2 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                        else if (Convert.ToInt32(asd) > 62 && Convert.ToInt32(asd) <= 87)
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 3/4 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                        else if (Convert.ToInt32(asd) > 87)
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                        else
                                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 2).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    }
                                    else
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0])).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();

                                }
                                else if (ds.Tables[0].Rows[0]["str1U"].ToString() == ".ml")
                                {
                                    ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Convert.ToDouble(Math.Round(fnl, 1).ToString()).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                }
                                else
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                //  else
                                //  ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + "ml";
                                ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = ds.Tables[0].Rows[0]["DivDose"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = ds.Tables[0].Rows[0]["Inst"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();


                            }
                            else
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = "";
                            }
                        }
                        else
                        {
                            ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                            ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = "";
                        }


                    }
                }
                else
                {
                    // MessageBox.Show("Please Enter the Weight");
                }
                rb_tamil_CheckedChanged(null, null);

            }


        }
        private void ctrldataGridPrescription_EditingControlShowing_1(object sender, DataGridViewEditingControlShowingEventArgs e)
        {

            if (ctrldataGridPrescription.CurrentCell.ColumnIndex == 1)
            {
                SqlDataReader dreader;
                SqlConnection conn = new SqlConnection(constr);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                AutoCompleteStringCollection Durgsource = new AutoCompleteStringCollection();
                cmd.CommandText = "Select Drug from Drug";
                conn.Open();
                dreader = cmd.ExecuteReader();
                if (dreader.HasRows == true)
                {
                    while (dreader.Read())
                        Durgsource.Add(dreader["Drug"].ToString());
                }
                else
                {
                    MessageBox.Show("Data not Found");
                }
                dreader.Close();


                //ComboBox txtBusID = e.Control as ComboBox;
                TextBox Medicine = e.Control as TextBox;
                Medicine.TextChanged += new EventHandler(Medicine_TextChanged); if (Medicine != null)
                {
                    Medicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    Medicine.AutoCompleteCustomSource = Durgsource;
                    Medicine.AutoCompleteSource = AutoCompleteSource.CustomSource;

                }

            }
            else
            {
                TextBox prodCode = e.Control as TextBox;
                if (prodCode != null)
                {
                    prodCode.AutoCompleteMode = AutoCompleteMode.None;
                }
            }
        }

        void Medicine_TextChanged(object sender, EventArgs e)
        {
            TextBox richTextBoxGuess = ((TextBox)sender);

            if (richTextBoxGuess.Text.Length <= 0) return;
            string s = richTextBoxGuess.Text.Substring(0, 1);
            if (s != s.ToUpper())
            {
                int curSelStart = richTextBoxGuess.SelectionStart;
                int curSelLength = richTextBoxGuess.SelectionLength;
                richTextBoxGuess.SelectionStart = 0;
                richTextBoxGuess.SelectionLength = 1;
                richTextBoxGuess.SelectedText = s.ToUpper();
                richTextBoxGuess.SelectionStart = curSelStart;
                richTextBoxGuess.SelectionLength = curSelLength;
            }
        }
        private void ctrldataGridPrescription_KeyUp(object sender, KeyEventArgs e)
        {
            for (int i = 0; i < ctrldataGridPrescription.Rows.Count - 1; i++)
            {
                ctrldataGridPrescription.Rows[i].Cells[0].Value = i + 1;
            }
        }
        private void rb_tamil_CheckedChanged(object sender, EventArgs e)
        {
            SetColumWidth();

            ctrldataGridPrescription.Columns[2].HeaderText = "Qty"; ;
            if (cb_language.Text.Trim() == "English")
            {
                ctrldataGridPrescription.Columns[7].Visible = false;
                ctrldataGridPrescription.Columns[6].Visible = true;
            }
            else
            {
                ctrldataGridPrescription.Columns[6].Visible = false;
                ctrldataGridPrescription.Columns[7].Visible = true;
            }
        }
        private void txtname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                // chkOld_CheckedChanged(null, null);
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "N", txtpatiantID.Text.StartsWith(AppMain.DoctorCode) ? txtpatiantID.Text : $"{AppMain.DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);

            }

        }
        private void txtPhoneNo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                //  chkOld_CheckedChanged(null, null);
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "P", txtpatiantID.Text.StartsWith(AppMain.DoctorCode) ? txtpatiantID.Text : $"{AppMain.DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);


            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
           
            DialogResult res = MessageBox.Show("Do you want to Save ?", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (res ==DialogResult.Yes)
                btnSave_Click();
        }
        private void btnprint_Click(object sender, EventArgs e)
        {
            btnPrint_Click();
            //  btnClear_Click();
        }
        private void btnclear_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are You want to Clear All ?", "SVM", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (res == DialogResult.Yes)
                btnClear_Click();

        }
        private void ctrlAddClinical_Click(object sender, EventArgs e)
        {
            AddfilesinTextBox(Clinicalfilelocation, txtClinical);
        }
        private void AddfilesinTextBox(string location, TextBox txt)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = location;
            openFileDialog1.Title = "Browse rtf Files";

            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;

            openFileDialog1.DefaultExt = "rtf";
            openFileDialog1.Filter = "Rtf files (*.rtf)|*.rtf";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            openFileDialog1.ReadOnlyChecked = true;
            openFileDialog1.ShowReadOnly = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Create the RichTextBox. (Requires a reference to System.Windows.Forms.)
                System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();

                // Get the contents of the RTF file. When the contents of the file are   
                // stored in the string (rtfText), the contents are encoded as UTF-16.  
                //List<string> rtfText = System.IO.File.ReadLines(openFileDialog1.FileName);

                rtBox.LoadFile(openFileDialog1.FileName);
                if (txt.Text == "") txt.Text = rtBox.Text.Replace("\n", System.Environment.NewLine);
                else
                    if (DialogResult.Yes == MessageBox.Show("Do you want to replace the Text?", "S V Medical Center", MessageBoxButtons.YesNo))
                        txt.Text = rtBox.Text.Replace("\n", System.Environment.NewLine);
                    else
                        txt.AppendText(rtBox.Text.Replace("\n", System.Environment.NewLine));
                txt.Focus();
            }
        }
        public void AddClinicalNotes(string _text)
        {
            TextBox txt = txtClinical;
            if (txt.Text == "") txt.Text = _text.Replace("\n", System.Environment.NewLine);
            else
                if (DialogResult.Yes == MessageBox.Show("Do you want to replace the Clinical Notes Text?", "S V Medical Center", MessageBoxButtons.YesNo))
                    txt.Text = _text.Replace("\n", System.Environment.NewLine);
                else
                    txt.AppendText(_text.Replace("\n", System.Environment.NewLine));
            txt.Focus();
        }

        public void AddAdvice(string _text)
        {
            TextBox txt = txtAdvice;
            if (txt.Text == "") txt.Text = _text.Replace("\n", System.Environment.NewLine);
            else
                if (DialogResult.Yes == MessageBox.Show("Do you want to replace the Advice Text?", "S V Medical Center", MessageBoxButtons.YesNo))
                    txt.Text = _text.Replace("\n", System.Environment.NewLine);
                else
                    txt.AppendText(_text.Replace("\n", System.Environment.NewLine));
            txt.Focus();
        }
       
        private void ctrlAddAdvice_Click(object sender, EventArgs e)
        {
            if (cb_language.Text.ToUpper() == "ENGLISH")
                AddfilesinTextBox(AdviceEnglishfilelocation, txtAdvice);
            else
                AddfilesinTextBox(AdviceTamilfilelocation, txtAdvice);
        }
        private void txtClinical_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.Right)
            {
                txt_KeyDown((TextBox)sender);
            }
        }
        private void txtClinical_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.Right)
            {
                txt_KeyUp((TextBox)sender);
            }
        }
        private void txt_KeyDown(TextBox txt)
        {
            List<int> countlst = new List<int>();
            string[] _st = txt.Text.Split('$');
            string u = txt.Text.Substring(_st[0].Length);//Select(0, 13);
            txt.Focus();
            txt.Select(_st[0].Length, 1);
        }
        private void txt_KeyUp(TextBox txt)
        {
            List<int> countlst = new List<int>();
            string[] _st = txt.Text.Split('$');
            string u = txt.Text.Substring(_st[0].Length);//Select(0, 13);
            //txt.Focus();
            //txt.Select(_st[0].Length, 1);
            int count = 0; int idx = 0;
            foreach (string s in _st)
            {
                count = count + s.Length;
                if (count <= txt.SelectionStart)
                {
                    txt.Focus();
                    txt.Select(_st[idx].Length, 1);
                }
                idx++;
            }
        }
        private void txtpatiantID_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                // chkOld_CheckedChanged(null, null);
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "I", txtpatiantID.Text.StartsWith($"{AppMain.DoctorCode} - ") ? txtpatiantID.Text : $"{$"{AppMain.DoctorCode}"} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text);

            }
        }

        #endregion

        #region IN6TECH METHODS

        public void myControl_KeyUp(object sender, KeyEventArgs e)
        {
            if (!e.Handled)
                if ((e.Control == true || e.Alt == true) && e.KeyCode == Keys.S)
                { btnSave_Click(); e.Handled = true; }
                else if ((e.Control == true || e.Alt == true) && e.KeyCode == Keys.P)
                { btnPrint_Click(); e.Handled = true; }
                else if ((e.Alt == true) && e.KeyCode == Keys.C)
                { btnClear_Click(); e.Handled = true; }
                else if ((e.Alt == true) && e.KeyCode == Keys.O)
                { chkOld.Checked = (!chkOld.Checked); e.Handled = true; }
                else if (e.KeyCode == Keys.F1)
                { NewDiagnosis _dia = new NewDiagnosis(); _dia.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F2)
                { Category _cat = new Category(); _cat.ShowDialog(); e.Handled = true; }
                else if (e.KeyCode == Keys.F3)
                { //MainForm.DoVisible(false, true); e.Handled = true; 
                }
                else if (e.KeyCode == Keys.F4)
                { //MainForm.DoVisible(true); e.Handled = true; 
                }
                else if (e.KeyCode == Keys.F6)
                {
                    if (this.ActiveControl == txtAddress)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.Area, txtAddress.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtAddress.Text = "";
                            AddressLoad();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == txtname)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.Name, txtname.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtname.Text = "";
                            nameload();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == txtPhoneNo)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.PhoneNo, txtPhoneNo.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            txtPhoneNo.Text = "";
                            phoneload();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == ctrlTxtUHID)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.UHID, ctrlTxtUHID.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            ctrlTxtUHID.Text = "";
                            UHIDLoad();
                        }
                        e.Handled = true;
                    }
                    else if (this.ActiveControl == ctrlTxtFullAddress)
                    {
                        frmEditAndDelete frmEditAndDelete = new frmEditAndDelete(Editmode.FullAddress, ctrlTxtFullAddress.Text);
                        DialogResult res = frmEditAndDelete.ShowDialog();
                        if (res == DialogResult.OK)
                        {
                            ctrlTxtFullAddress.Text = "";                          
                        }
                        e.Handled = true;
                    }
                }
        }
        public void btnSave_Click()
        {
            try
            {
                string _save = "";
                _save = _save + ((cmb_apno.Text != "") ? "" : "App No, ");
                _save = _save + ((txtname.Text != "") ? "" : "Name, ");
                _save = _save + ((txtage.Text != "") ? "" : "Age, ");
                if (_save == "")
                {
                    if (Save())
                    {
                        MessageBox.Show("Prescription has saved successfully!"); Prescription_Load(null, null);
                        btnClear_Click();
                    }
                }
                else
                {
                    MessageBox.Show("Please fill " + _save.ToString().Remove(_save.Length - 2, 2) + " details :(");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void btnPrint_Click()
        {
            try
            {
                string _print = "";
                _print = _print + ((cmb_apno.Text != "") ? "" : "App No, ");
                _print = _print + ((genderComboBox.Text != "") ? "" : "Gender, ");
                _print = _print + ((ctrlDateDOB.Text != "") ? "" : "Date of Birth, ");
                _print = _print + ((txtage.Text != "") ? "" : "Age, ");
                _print = _print + ((txtname.Text != "") ? "" : "Name, ");
                _print = _print + ((txtweight.Text != "") ? "" : "Weight, ");
               // _print = _print + ((txtDiagnosis.Text != "") ? "" : "Diagnosis, ");
                _print = _print + ((txtAddress.Text != "") ? "" : "Address, ");
                _print = _print + ((txtPhoneNo.Text != "") ? "" : "Phone No, ");
              //  _print = _print + ((ctrldataGridPrescription.Rows.Count > 1) ? "" : "Prescription, ");

                if (_print == "")
                {
                    if (Save())
                    {
                        MessageBox.Show("Prescription has saved successfully!"); //Prescription_Load(null, null);
                        Print(prescno, appointmentno, patientno);
                        btnClear_Click();
                    }

                }
                else
                {
                    MessageBox.Show("Please fill " + _print.ToString().Remove(_print.Length - 2, 2) + " details :(");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void loaddatas(DataSet ds)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                cmb_apno.Text = ds.Tables[0].Rows[0]["ApNo"].ToString();
                txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                genderComboBox.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                ctrlDateDOB.Text = ds.Tables[0].Rows[0]["DateDetails"].ToString();
                txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                txtPhoneNo.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
                txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
                txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
                ctrlLblPatientHis.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
                numericUpDown1.Value = decimal.Parse(ds.Tables[0].Rows[0]["Temp"].ToString());
                ctrlTxtUHID.Text = ds.Tables[0].Rows[0]["UHID"].ToString();



                personalInformation = new PersonalInformation();
                personalInformation.FullAddress =ds.Tables[0].Rows[0]["FullAddress"]?.ToString();
                personalInformation.AllergicDrugs =ds.Tables[0].Rows[0]["AllergicDrugs"]?.ToString();
                personalInformation.BirthHistory =ds.Tables[0].Rows[0]["BirthHistory"]?.ToString();
                personalInformation.PastIllness =ds.Tables[0].Rows[0]["PastIllness"]?.ToString();
                personalInformation.FamilyHistory =ds.Tables[0].Rows[0]["FamilyHistory"]?.ToString();
                //personalInformation.LabInvestigations =ds.Tables[0].Rows[0]["LabInvestigations"]?.ToString();
                //personalInformation.AddtionalInformation =ds.Tables[0].Rows[0]["AddtionalInformation"]?.ToString();

                ctrlTxtBirthHist.Text = personalInformation.BirthHistory;
                ctrlTxtFamilyHis.Text = personalInformation.FamilyHistory;
                ctrlTxtPastIllness.Text = personalInformation.PastIllness;
                ctrlTxtFullAddress.Text = personalInformation.FullAddress;
                new GeneralMethods().LoadCheckedValues(personalInformation.AllergicDrugs, ref ctrlCbxAlergy);

                ctrldataGridPrescription.DataSource = null;
                ctrldataGridPrescription.AutoGenerateColumns = false;

                ds.Tables.Clear();
            }
        }

        public void nameload()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("select Name from regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtname.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void AddressLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT distinct Address FROM regappform3 where (address!='' And Hospital_Id=@ID and DoctorCode =@doctorCode)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtAddress.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void IDLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
               // string query = "SELECT PatiantID FROM [Srivm].[dbo].[regappform3] where (PatiantID!='' And Hospital_Id=@ID And DoctorCode =@doctorCode)";
                string query = "SELECT PatiantID FROM [regappform3] where (PatiantID!='' And Hospital_Id=@ID And DoctorCode =@doctorCode)";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();

                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                    MyCollection.Add(reader.GetString(0));
                txtpatiantID.AutoCompleteCustomSource = MyCollection;
                con.Close();
            }
        }

        public void phoneload()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT PhoneNo FROM regappform3 where Hospital_Id=@ID and DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    MyCollection.Add(reader.GetString(0));
                }
                txtPhoneNo.AutoCompleteCustomSource = MyCollection;

                con.Close();
            }
        }

        public void UHIDLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                SqlCommand cmd = new SqlCommand("SELECT UHID FROM regappform3 where Hospital_Id=@ID and  DoctorCode =@doctorCode", con);
                con.Open();
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                        MyCollection.Add(reader.GetString(0));
                }
                ctrlTxtUHID.AutoCompleteCustomSource = MyCollection;

                con.Close();
            }
        }

        public void PatientStatusLoad()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                ctrlCbxStatus.Items.Clear();
                SqlCommand cmd = new SqlCommand("select * from PatientStatus", con);
                con.Open();               
                SqlDataReader reader = cmd.ExecuteReader();
                AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        ComboboxItem item = new ComboboxItem();
                        item.Value = reader.GetInt32(0);
                        item.Text = reader.GetString(1);
                        ctrlCbxStatus.Items.Add(item);
                    }
                       
                }
                ctrlCbxStatus.SelectedIndex = 0;

                con.Close();
            }
        }

        public void GetData()
        {
            SqlConnection con = new SqlConnection(constr);

            {
                con.Open();
                //txtdatetime.Text = DateTime.Now.ToString();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("select * from Presnew1", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Presnew1");

                //ctrldataGridPrescription1.DataSource = ds.Tables["Presnew1"];
                string Query = "if (select COUNT(*) from regappform3 where year(date)=@Year and MONTH(Date)=@Month)>0 " +
                               "     select isnull(max(right(EPresNo,2)),0)+1 from regappform3 where year(date)=@Year and MONTH(Date)=@Month and EPresNo!='Direct'  " +
                               " else  " +
                               "     select 1";
                cmd = new SqlCommand(Query, con);
                var month = Convert.ToDateTime(txtdatetime.Text).Month;
                var year = Convert.ToDateTime(txtdatetime.Text).Year;
                cmd.Parameters.AddWithValue("@Month", month);
                cmd.Parameters.AddWithValue("@Year", year);
                MaxSeq = Convert.ToString(cmd.ExecuteScalar());
                if (string.IsNullOrEmpty(MaxSeq))
                    MaxSeq = "1";
                //Query = "if (select sno from autogenerate where convert(date,Date)=convert(date,@Date) )>0 " +
                //               "     select sno from autogenerate where convert(date,Date)=convert(date,@Date)  " +
                //               " else  " +
                //               "     select 1";

                Query = "if (select COUNT(*) from regappform3 where  convert(date,Date)=convert(date,@Date))>0 " +
                              "    select isnull(MAX(cast(ApNo as int)),0)+1 from regappform3 where( convert(date,Date)=convert(date,@Date) And Hospital_Id=@ID and DoctorCode=@doctorCode )" +
                              " else  " +
                              "     select 1";
                cmd = new SqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@ID", AppMain.HospitalId); 
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                cmd.Parameters.AddWithValue("@Date", Convert.ToDateTime(txtdatetime.Text));
                ApNo = Convert.ToString(cmd.ExecuteScalar());
                cmb_apno.Text = ApNo;



                string querry = "select EPresNo from regappform3 where year(date)=@Year and MONTH(Date)=@Month and Hospital_id=@hosp_id and DoctorCode=@doctorCode ";
                cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@Month", month);
                cmd.Parameters.AddWithValue("@Year", year);
                cmd.Parameters.AddWithValue("@hosp_id", AppMain.HospitalId);
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds, "EpresNo");

                List<int> id = new List<int>();
                foreach (DataRow item in ds.Tables["EpresNo"].Rows)
                {

                    try
                    {
                        string[] var = item[0].ToString().Split('-');
                        id.Add(Convert.ToInt32(var[var.Length - 1]));

                    }
                    catch
                    {

                    }
                }
                MaxSeq = string.Empty;
                if (id.Count == 0)
                    MaxSeq = "1";
                else
                    MaxSeq = Convert.ToString((id.Max() + 1));

                if (string.IsNullOrEmpty(ApNo))
                    ApNo = "1";

                cmd = new SqlCommand("select * from Presnew1", con);
                sda = new SqlDataAdapter(cmd);
                sda.Fill(ds, "Presnew1");
                Query = "Select isnull(MAX(cast(substring(PatiantID,5,5) as int)),0)+1 from regappform3 where Hospital_id=@hosp_id and DoctorCode=@doctorCode ";
                cmd = new SqlCommand(Query, con);
                cmd.Parameters.AddWithValue("@hosp_id", AppMain.HospitalId);
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                string MaxSeqpAT = Convert.ToString(cmd.ExecuteScalar());
                if (string.IsNullOrEmpty(MaxSeq))
                    MaxSeqpAT = "1";
                //txtpatiantID.Text = "SV" + MaxSeqpAT.PadLeft(3, '0');
                txtpatiantID.Text = $"{AppMain.DoctorCode} - " + MaxSeqpAT;
                con.Close();
            }
            txtPresNo.Text = string.Concat(Convert.ToDateTime(txtdatetime.Text).Year.ToString(), "-", Convert.ToDateTime(txtdatetime.Text).Month.ToString().PadLeft(2, '0'), "-", MaxSeq.PadLeft(2, '0'));
            cmb_apno.Text = ApNo;
        }

        private int GetDiagnosisRowID(string Diagnosis)
        {
            int id = 0;
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT [RowId] FROM [Diagnosis] where [Diagnosis] ='" + Diagnosis + "'", con);
                con.Open();
                id = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }
            return id;
        }

        private string GetCategory(int ID)
        {
            string name = "";
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("SELECT [Category] FROM [AmountCategory] where [RowID] ='" + ID + "'", con);
                con.Open();
                name = Convert.ToString(cmd.ExecuteScalar());
                con.Close();
            }
            return name;
        }

        private void ClearData()
        {
            cmb_apno.Text = "";
            cmb_apno.Text = "";
            txtname.Text = "";
            genderComboBox.Text = "Male";
            ctrlDateDOB.Text = "";
            txtage.Text = "";
            txtweight.Text = "";
            txtheight.Text = "";
            txtbmi.Text = "";
            txtPresNo.Text = "";
            txtDiagnosis.Text = "";
            txtpatiantID.Text = "";
            ctrlLblPatientHis.Text = "";
            txtPhoneNo.Text = "";
            txtAddress.Text = "";
            txtClinical.Text = "";
            txtAdvice.Text = "";
            ctrlTxtUHID.Text = "";
            FillDropDownAppNo();

             new GeneralMethods().LoadDiagnosis(ref txtDiagnosis);
            LoadMedician();
            // LoadCategory();

            LoadDefaultDropDownValues();
            ctrldataGridPrescription.DataSource = null;
            ctrldataGridPrescription.Rows.Clear();
        }

       

        public DataSet LoadSearch(string name = "", string phoneNumber = "")
        {
            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(ConfigurationManager.AppSettings["ConnectionInfo"].ToString());
            if (con.State == ConnectionState.Closed)
                con.Open();
            string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo " +
                            " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                            " where A.PhoneNo like '" + phoneNumber + "' or A.Name like N'" + name + "' order by EPresNo desc";
            SqlCommand cmd = new SqlCommand(querry, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
                return ds;
            return new DataSet();
        }

        private DataTable SetInitialRow()
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dtRow;
                dt.Columns.Add("SNo");
                dt.Columns.Add("Medicine");
                dt.Columns.Add("Quantity");
                dt.Columns.Add("Dose");
                dt.Columns.Add("dividedDoses"); dt.Columns.Add("Interval"); dt.Columns.Add("InstructionEnglish"); dt.Columns.Add("InstructionTamil");
                dt.Columns.Add("Instructions");
                int Count = 1;
                for (int i = 0; i < Count; i++)
                {
                    dtRow = dt.NewRow();
                    dt.Rows.Add(dtRow);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }

        private DataTable SaveBeforeGetdata()
        {
            //try
            //{
            DataTable dtCurrentTable = SetInitialRow();
            DataRow drCurrentRow = null;
            for (int i = 0; i < ctrldataGridPrescription.Rows.Count; i++)
            {
                if (Convert.ToString(ctrldataGridPrescription.Rows[i].Cells[1].Value) != "")
                {
                    dtCurrentTable.Rows[i]["SNo"] = ctrldataGridPrescription.Rows[i].Cells[0].Value;
                    dtCurrentTable.Rows[i]["Medicine"] = ctrldataGridPrescription.Rows[i].Cells[1].Value;
                    dtCurrentTable.Rows[i]["Quantity"] = ctrldataGridPrescription.Rows[i].Cells[2].Value;
                    dtCurrentTable.Rows[i]["Dose"] = ctrldataGridPrescription.Rows[i].Cells[3].Value;
                    dtCurrentTable.Rows[i]["dividedDoses"] = ctrldataGridPrescription.Rows[i].Cells[4].Value;
                    dtCurrentTable.Rows[i]["Interval"] = ctrldataGridPrescription.Rows[i].Cells[5].Value;
                    dtCurrentTable.Rows[i]["InstructionEnglish"] = ctrldataGridPrescription.Rows[i].Cells[6].Value;
                    dtCurrentTable.Rows[i]["InstructionTamil"] = ctrldataGridPrescription.Rows[i].Cells[7].Value;
                    dtCurrentTable.Rows[i]["Instructions"] = ctrldataGridPrescription.Rows[i].Cells[5].Value;
                    if (dtCurrentTable.Rows.Count < ctrldataGridPrescription.Rows.Count)
                    {
                        drCurrentRow = dtCurrentTable.NewRow();
                        dtCurrentTable.Rows.Add(drCurrentRow);
                    }
                }
                if (i == ctrldataGridPrescription.Rows.Count - 1) break;
            }
            return dtCurrentTable;
        }

        private void ClearOldValues()
        {
            genderComboBox.SelectedIndex = 0;
            cb_language.SelectedIndex = 1;
            ctrlDateDOB.Text = string.Empty;
            txtage.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtPhoneNo.Text = string.Empty;
            ctrldataGridPrescription.DataSource = null;
            ctrldataGridPrescription.AutoGenerateColumns = false;
            btnClear_Click();
        }

        public void btnClear_Click()
        {
            ClearData();
            //chkOld.Checked = true;
            //  numericUpDown1.ResetText();
            numericUpDown1.Value = 98;
            txtpatiantID.Enabled = chkOld.Checked;// txtpatiantID.Enabled = false;
            cmb_apno.Text = "";
            txtname.Text = "";
            ctrlDateDOB.Text = "";
            txtage.Text = "";
            txtweight.Text = "";
            txtAddress.Text = "";
            txtheight.Text = "";
            txtbmi.Text = "";
            txtPresNo.Text = "";
            txtClinical.Text = "";
            txtAdvice.Text = "";
            txtDiagnosis.Text = "";
            ctrlLblPatientHis.Text = "";
            chkOld.Checked = false;
            cb_language.SelectedIndex = 1;
            txtPhoneNo.Text = "";
            txtbmi.ReadOnly = false;
            txtbmi.ForeColor = Properties.Settings.Default.CFontColor;
            txtPhoneNo.Text = "";
            txtAddress.Text = "";
            GetData();
            autonumber();
            genderComboBox.SelectedIndex = 0;
            ctrldataGridPrescription.DataSource = null;
            ctrldataGridPrescription.Rows.Clear();
            personalInformation = new PersonalInformation();
            ctrlCbxAlergy.Text = "";
            ctrlTxtFullAddress.Text = "";
            //ctrlDateDOB.Value = DateTime.Now;
            ctrlTxtBirthHist.Text = personalInformation.BirthHistory;
            ctrlTxtFamilyHis.Text = personalInformation.FamilyHistory;
            ctrlTxtPastIllness.Text = personalInformation.PastIllness;
        }

        bool Save()
        {
            try
            {
                bool _return = false;

                if (chkOld.Checked)
                {
                    bool isExist = IsExistingPatientID(txtpatiantID.Text);
                    if (!isExist)
                    {
                        MessageBox.Show("Please Chosse valid Patient Details", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }

                }
                   
                frmConfirmSave _frmConfirmSave = new frmConfirmSave(txtDiagnosis.Text);
                if (DialogResult.OK == _frmConfirmSave.ShowDialog())
                {



                    int status = 1;
                    status = ctrlCbxStatus.GetSelectedValueAsInt();
                    SqlConnection con = new SqlConnection(constr);
                    {
                        con.Open();
                        //SqlCommand uhID = new SqlCommand($"select count(*) from regappform3 WHERE uhid='{ctrlTxtUHID.Text}'", con);
                        //int countuhID = Convert.ToInt32(uhID.ExecuteScalar());
                        //if (countuhID > 0)
                        //{
                        //    DialogResult res = MessageBox.Show($"The Given UHID number {ctrlTxtUHID.Text} is Already exisit. Do you want to continue ?", "Information", MessageBoxButtons.OKCancel,MessageBoxIcon.Information);
                        //    if (res == DialogResult.Cancel)
                        //        return false;
                        //}
                        prescno = txtPresNo.Text;
                        patientno = txtpatiantID.Text;
                        appointmentno = cmb_apno.Text;

                        SqlCommand cmd = new SqlCommand("SPUI_Prescription_NEW", con);
                     
                        cmd.Parameters.AddWithValue("@EPresNo", txtPresNo.Text);
                        cmd.Parameters.AddWithValue("@ApNo", Convert.ToInt32(cmb_apno.Text));
                        cmd.Parameters.AddWithValue("@UpressNo", txtPresNo.Text);
                        cmd.Parameters.AddWithValue("@PatiantID", txtpatiantID.Text);
                        cmd.Parameters.AddWithValue("@Name", txtname.Text);
                        cmd.Parameters.AddWithValue("@LastName", "");
                        cmd.Parameters.AddWithValue("@MiddleName", "");
                        cmd.Parameters.AddWithValue("@Gender", genderComboBox.Text);
                        cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Text);
                        cmd.Parameters.AddWithValue("@DateDetails", Convert.ToString(ctrlDateDOB.Value.ToString("yyyy/MM/dd")));
                        cmd.Parameters.AddWithValue("@Age", txtage.Text);
                        cmd.Parameters.AddWithValue("@Temp", numericUpDown1.Text);
                        cmd.Parameters.AddWithValue("@Weigt", txtweight.Text);
                        cmd.Parameters.AddWithValue("@Height", txtheight.Text);
                        cmd.Parameters.AddWithValue("@BMI", txtbmi.Text);
                        cmd.Parameters.AddWithValue("@Headcircum", ctrlLblPatientHis.Text);
                        cmd.Parameters.AddWithValue("@Status", status);
                        cmd.Parameters.Add("@DateOfBirth", SqlDbType.DateTime).Value = Convert.ToString(ctrlDateDOB.Value);
                        cmd.Parameters.Add("@ReviewDate", SqlDbType.DateTime).Value = Convert.ToString(_frmConfirmSave.ctrlDateReview.Value);
                        cmd.Parameters.AddWithValue("@Hospital_ID", AppMain.HospitalId);
                        cmd.Parameters.AddWithValue("@UHID_Value", ctrlTxtUHID.Text);
                        cmd.Parameters.AddWithValue("@DoctorCode", AppMain.DoctorCode);

                        cmd.Parameters.AddWithValue("@CashType", _frmConfirmSave.CashType);
                        cmd.Parameters.AddWithValue("@HaveInsurance", _frmConfirmSave.HaveInsurance);

                        cmd.Parameters.AddWithValue("@FullAddress", personalInformation.FullAddress= ctrlTxtFullAddress.Text);
                        cmd.Parameters.AddWithValue("@AllergicDrugs ", personalInformation.AllergicDrugs= new GeneralMethods().JoinSpecficItem(ref ctrlCbxAlergy) );
                        cmd.Parameters.AddWithValue("@BirthHistory ", personalInformation.BirthHistory);
                        cmd.Parameters.AddWithValue("@PastIllness ", personalInformation.PastIllness);
                        cmd.Parameters.AddWithValue("@FamilyHistory ", personalInformation.FamilyHistory);
                        cmd.Parameters.AddWithValue("@LabInvestigations ", personalInformation.LabInvestigations);
                        cmd.Parameters.AddWithValue("@AddtionalInformation ", personalInformation.AddtionalInformation);

                        if(_frmConfirmSave.FinalDiagonisID>0)
                        cmd.Parameters.AddWithValue("@FinalDiagnosisId ", _frmConfirmSave.FinalDiagonisID);

                        string XMlDt1 = "";
                        DataTable dtCurrentTable = SaveBeforeGetdata();
                        dtCurrentTable.TableName = "Prescription_DT";

                        using (StringWriter sw = new StringWriter())
                        {
                            dtCurrentTable.WriteXml(sw);
                            XMlDt1 = sw.ToString();
                        }
                        cmd.Parameters.Add("@cby", SqlDbType.VarChar).Value = "111";
                        cmd.Parameters.Add("@XmlString", SqlDbType.VarChar).Value = XMlDt1;
                        cmd.Parameters.Add("@DiagnosisRowID", SqlDbType.VarChar).Value = GetDiagnosisRowID(txtDiagnosis.Text);
                        System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                        rtBox.Text = txtClinical.Text;
                        cmd.Parameters.Add("@DiagnosisHTML", SqlDbType.VarChar).Value = rtBox.Rtf;
                        rtBox.Text = "";
                        for (int i = 0; i < txtAdvice.Lines.Length; i++)
                        {
                            if (rtBox.Text == "")
                                rtBox.Text = (txtAdvice.Lines[i].ToString());
                            else
                                rtBox.AppendText(Environment.NewLine+ txtAdvice.Lines[i].ToString());
                        }
                        cmd.Parameters.Add("@DiagnosisAdvice", SqlDbType.VarChar).Value = rtBox.Rtf;
                        txtdatetime.Text = DateTime.Now.ToString();
                        cmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = Convert.ToString(txtdatetime.Text);  //NextReveiew                        
                        cmd.Parameters.Add("@CategoryID", SqlDbType.VarChar).Value = _frmConfirmSave.cbCategory.SelectedValue;
                        cmd.Parameters.Add("@AmountRecived", SqlDbType.VarChar).Value = 0;
                        cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txtAddress.Text;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.ExecuteNonQuery();

                        SqlCommand cm = new SqlCommand("select count(*) from Diagnosis where Diagnosis='" + txtDiagnosis.Text + "'", con);
                        int count = Convert.ToInt32(cm.ExecuteScalar());
                        int value = 0;

                        if (count == 0)
                        {
                            SqlCommand cmds = new SqlCommand("insert into Diagnosis(Diagnosis) values('" + txtDiagnosis.Text + "')", con);
                            cmds.ExecuteNonQuery();

                            SqlCommand cmds1 = new SqlCommand("select max(RowId) from Diagnosis", con);
                            value = Convert.ToInt32(cmds1.ExecuteScalar());
                        }

                        if (value != 0)
                        {
                            SqlCommand cmds = new SqlCommand("update regappform3 set DiagnosisRowID=" + value + " where EPresNo='" + txtPresNo.Text + "' and PatiantID='" + txtpatiantID.Text + "'", con);
                            cmds.ExecuteNonQuery();
                        }
                        foreach (DataRow dr in dtCurrentTable.Rows)
                        {
                            SqlCommand cmdsUpdate = new SqlCommand("  update [Prescription_DT] set devideDose =N'" + dr.ItemArray[4].ToString() + "' where EPresNo='" + txtPresNo.Text + "' and Icode='" + dr.ItemArray[1].ToString() + "'", con);
                            cmdsUpdate.ExecuteNonQuery();
                            cmdsUpdate = new SqlCommand("  update [Prescription_DT] set InstructionTamil =N'" + dr.ItemArray[7].ToString() + "' where EPresNo='" + txtPresNo.Text + "' and Icode='" + dr.ItemArray[1].ToString() + "'", con);
                            cmdsUpdate.ExecuteNonQuery();

                        }
                        updateauto();
                        // MessageBox.Show("Record Saved Successfully!.");
                        //saveapp();
                        con.Close();
                        _return = true;
                    }
                }
                return _return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        void Print(string prescno = "", string appointmentno = "", string patientno = "")
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("select a.Age,a.CategoryID,a.Gender,a.CategoryID,a.HeadCircum,a.ReviewDate,a.Date," +
                    "a.DiagnosisAdvice as Advice,a.DiagnosisHTML as ClinialNotes, (a.Name+' '+a.LastName) as FullName," +
                    "a.Address,a.Temp,a.Height,a.Weigt as Weight,a.UHID as UHID,AllergicDrugs as Allergy,FullAddress as FullAddress,BirthHistory," +
                    "PastIllness,FamilyHistory," +
                    "LabInvestigations,AddtionalInformation,a.DiagnosisAdvice as Advice,a.PatiantID as Pres,");
                sb.AppendLine("c.Icode as Medicine,c.Qty as Nos,c.Dose,c.devideDose as " +
                    "Frequency,c.Instruction,c.Interval as" +
                    " Interval,c.InstructionEnglish as InstructionEnglish,c.InstructionTamil as InstructionTamil ");
                sb.AppendLine(",d.Diagnosis as Dignosis ");
                sb.AppendLine(",e.Inst as Description,e.Duration");
                sb.AppendLine("from regappform3 a");
                sb.AppendLine("left join  Diagnosis d on  d.RowId=a.DiagnosisRowID");
                sb.AppendLine("left join  Prescription_DT c on c.EPresNo='" + prescno + "'");
                sb.AppendLine("left join Drug e On  c.Icode =e.Drug");
                sb.AppendLine("where  PatiantID='" + patientno + "' and ApNo='" + appointmentno + "' and a.EPresNo='" + prescno + "'");
                SqlCommand cmd = new SqlCommand(sb.ToString(), con);

                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds);
                con.Close();

                DataTable details = new DataTable("Details");
                details.Columns.Add("FullName", typeof(string));
                details.Columns.Add("Address", typeof(string));
                details.Columns.Add("Temp", typeof(string));
                details.Columns.Add("Pres", typeof(string));
                details.Columns.Add("Height", typeof(string));
                details.Columns.Add("Weight", typeof(string));
                details.Columns.Add("Dignosis", typeof(string));
                details.Columns.Add("Advice", typeof(string));
                details.Columns.Add("Age", typeof(string));
                details.Columns.Add("Gender", typeof(string));
                details.Columns.Add("HC", typeof(string));
                details.Columns.Add("ReviewDate", typeof(string));
                details.Columns.Add("ClinicalNotes", typeof(string));
                details.Columns.Add("Category", typeof(string));
                details.Columns.Add("PatientID", typeof(string));
                details.Columns.Add("VisitedDate", typeof(string));
                details.Columns.Add("UHID", typeof(string));
                details.Columns.Add("Allergy", typeof(string));
                details.Columns.Add("FullAddress", typeof(string));



                DataTable drugDetails = new DataTable("Drugdetails");
                drugDetails.Columns.Add("Medicine", typeof(string));
                drugDetails.Columns.Add("Nos", typeof(double));
                drugDetails.Columns.Add("Dose", typeof(string));
                drugDetails.Columns.Add("Interval", typeof(string));
                drugDetails.Columns.Add("Frequency", typeof(string));
                drugDetails.Columns.Add("Duration", typeof(string));
                drugDetails.Columns.Add("Description", typeof(string));
                drugDetails.Columns.Add("IntervalFrequency", typeof(string));

                var res = ds.Tables[0];
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    int index = ds.Tables[0].Rows.IndexOf(item);
                    //if (index == ds.Tables[0].Rows.Count - 1)
                    //    break;

                    if (index == 0)
                    {
                        DataRow dRow = details.NewRow();
                        dRow["FullName"] = item["FullName"];
                        dRow["Address"] = item["Address"];
                        dRow["Temp"] = FloatingConverter(item["Temp"].ToString());
                        dRow["Pres"] = prescno;
                        dRow["PatientID"] = patientno;
                        dRow["Height"] = FloatingConverter(item["Height"].ToString());
                        dRow["Weight"] = FloatingConverter(item["Weight"].ToString());
                        dRow["Dignosis"] = item["Dignosis"];
                        dRow["Age"] = item["Age"];
                        dRow["Gender"] = item["Gender"];
                        dRow["HC"] = item["HeadCircum"];
                        dRow["ReviewDate"] = item["ReviewDate"];
                        dRow["UHID"] = item["UHID"];
                        dRow["FullAddress"] = item["FullAddress"];
                        dRow["Allergy"] = GetAlergyForReport(Convert.ToString(item["Allergy"]));


                        string birthHistory=Convert.ToString( item["BirthHistory"]);
                        string pastIllness = Convert.ToString(item["PastIllness"]);
                        string familyHistory = Convert.ToString(item["FamilyHistory"]);

                        StringBuilder historyWithClinicalNotes = new StringBuilder();
                        if (!string.IsNullOrWhiteSpace(birthHistory))
                        {                          
                            historyWithClinicalNotes.AppendLine($"Birth History :{birthHistory}");
                        }

                        if (!string.IsNullOrWhiteSpace(pastIllness))
                        {
                            historyWithClinicalNotes.AppendLine($"Past Illness :{pastIllness}");                          
                        }

                        if (!string.IsNullOrWhiteSpace(familyHistory))
                        {
                            historyWithClinicalNotes.AppendLine($"Family History :{familyHistory}");                         
                        }

                        System.Windows.Forms.RichTextBox rtBox = new System.Windows.Forms.RichTextBox();
                        rtBox.Rtf = item["ClinialNotes"].ToString();

                        string clinialNotesFully = rtBox.Text.Trim();
                        if (!string.IsNullOrWhiteSpace(clinialNotesFully))
                            historyWithClinicalNotes.AppendLine(clinialNotesFully);


                        dRow["ClinicalNotes"] = historyWithClinicalNotes.ToString();


                        StringBuilder advice = new StringBuilder();
                        string labInvestigation = Convert.ToString(item["LabInvestigations"]);
                        string addtionalInfo = Convert.ToString(item["AddtionalInformation"]);


                        rtBox.Rtf = item["Advice"].ToString();

                        string adviceFully = rtBox.Text.Trim();
                        if (!string.IsNullOrWhiteSpace(adviceFully))
                            advice.AppendLine(adviceFully);


                        if (!string.IsNullOrWhiteSpace(labInvestigation))
                        {                     
                            advice.AppendLine($"Lab Investigations :{LabInvestigationLoad(labInvestigation)}");                          
                        }

                        if (!string.IsNullOrWhiteSpace(addtionalInfo))
                        {
                            advice.AppendLine($"Addtional Information :{addtionalInfo}");                         
                        }


                        dRow["Advice"] = advice.ToString();

                        //   dRow["Advice"] = item["Advice"];
                        dRow["VisitedDate"] = item["Date"];
                        try
                        {
                            string iDate = item["ReviewDate"].ToString();
                            DateTime oDate = Convert.ToDateTime(iDate);
                            dRow["ReviewDate"] = oDate.Day.ToString("00") + "/" + oDate.Month + "/" + oDate.Year;
                        }
                        catch
                        {
                            dRow["ReviewDate"] = item["ReviewDate"].ToString(); ;
                        }
                        //   dRow["ClinicalNotes"] = item["ClinialNotes"].ToString();
                        dRow["Category"] = GetCategory(Convert.ToInt32(item["CategoryID"].ToString()));
                        details.Rows.Add(dRow);
                    }
                    if (item["Medicine"].ToString() == "") break;
                    var medicine = (index + 1) + "." + item["Medicine"].ToString();
                    var quantity = item["Nos"].ToString();
                    var dose = item["Dose"].ToString();
                    var dividedDose = item["Frequency"].ToString();
                    var interval = item["Interval"].ToString();
                    var instruction = item["InstructionEnglish"].ToString();
                    if (cb_language.Text.ToUpper() == "ENGLISH")
                        instruction = item["InstructionEnglish"].ToString();
                    else
                        instruction = item["InstructionTamil"].ToString();
                    var intervalFrequency = dividedDose.ToString() + " - " + interval.ToString();
                    if (interval.ToString().StartsWith("As"))
                        intervalFrequency = dividedDose.ToString();
                    else intervalFrequency = dividedDose.ToString() + " - " + interval.ToString();
                    //  intervalFrequency = intervalFrequency.Replace("Hourly", "hrs");
                    drugDetails.Rows.Add(medicine, quantity, dose, interval, dividedDose, interval, instruction, intervalFrequency);
                }
                ds.Tables.Add(details);
                ds.Tables.Add(drugDetails);

            }
            LoadPrescriptionPrint(ds);
            ClearData();
            appointmentno = "";
            prescno = "";
            patientno = "";

        }

        internal string GetAlergyForReport(string joinString)
        {
            string allergy = "";
            try
            {
                List<int> id = new List<int>();
                if (!joinString.Contains("-"))
                {
                    id.Add(Convert.ToInt32(joinString));
                }
                else
                {
                    var splitArray = joinString.Split('-');
                    for (int i = 0; i < splitArray.Length; i++)
                    {
                        id.Add(Convert.ToInt32(splitArray[i]));
                    }
                }
                List<string> res = new List<string>();
                using (SqlConnection con = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("select * from AllergyMaster", con);
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                    while (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {

                            if (id.Contains(reader.GetInt32(0)))
                                res.Add(reader.GetString(1));
                        }

                    }
                    allergy= String.Join(", ", res.ToArray());
                    con.Close();
                }
            }
            catch (Exception)
            {
                allergy = "";
            }
            return allergy;

        }

        private string LabInvestigationLoad(string labInvestigation)
        {
            string res = "";
            try
            {
                
                List<int> id = new List<int>();
                if (!labInvestigation.Contains("-"))
                {
                    id.Add(Convert.ToInt32(labInvestigation));
                }
                else
                {
                    var splitArray = labInvestigation.Split('-');
                    for (int i = 0; i < splitArray.Length; i++)
                    {
                        id.Add(Convert.ToInt32(splitArray[i]));
                    }
                }


                    using (SqlConnection mycon = new SqlConnection(constr))
                    {
                        SqlCommand cmd1 = new SqlCommand("select * from labinvestigation", mycon);
                        mycon.Open();
                        SqlDataReader reader = cmd1.ExecuteReader();
                        AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
                        while (reader.Read())
                        {
                        if (!reader.IsDBNull(0))
                        {
                            if (id.Contains(reader.GetInt32(0)))
                            {
                                res += (reader.GetString(1));
                                res += (" ");
                            }
                        }

                        }

                        mycon.Close();
                    }
               
            }
            catch (Exception)
            {
                res = "";
            }

            return res.Trim();
        }

        private void LoadPrescriptionPrint(DataSet prescriptionValues)
        {
            frmReortViewer viewer = new frmReortViewer();
            viewer.PrescriptionDataset = prescriptionValues;
            viewer.MinimizeBox = true;
            if (DialogResult.Yes == MessageBox.Show("Do you want to print using Printer? ", "S V Medical Center", MessageBoxButtons.YesNo))
                viewer.IsDirectPrint = true;
            else
                viewer.IsDirectPrint = false;
            viewer.Show();

        }

        private string FloatingConverter(string value)
        {
            string output = "";
            try
            {
                if (double.Parse(value) == Convert.ToInt32(double.Parse(value)))
                {
                    output = Convert.ToInt32(double.Parse(value)).ToString("D");
                }
                else
                {
                    output = value;
                }

            }
            catch
            {
                output = value;
            }
            return output;
        }

        private void autonumber()
        {
            int count = 0, sno = 0, newno = 0;
            SqlConnection con = new SqlConnection(constr);
        Loop:
            SqlCommand cmd = new SqlCommand("select count(*) from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            count = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            SqlCommand cmd1 = new SqlCommand("select sno from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            sno = Convert.ToInt32(cmd1.ExecuteScalar());
            con.Close();

            if (count == 0)
            {
                cmb_apno.Text = "1";
            }
            else
            {
                newno = sno + 1;
                int present = 0;
                SqlCommand cmd3 = new SqlCommand("select count(*) from regappform3 where convert(date,Date)=Convert(date,getdate()) and ApNo='" + newno.ToString() + "'", con);
                con.Open();
                present = Convert.ToInt32(cmd3.ExecuteScalar());
                con.Close();

                if (present == 0)
                {
                    cmb_apno.Text = newno.ToString();
                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("update autogenerate set sno=sno+1 where convert(date,date)=Convert(date,getdate())", con);
                    con.Open();
                    cmd2.ExecuteNonQuery();
                    con.Close();
                    goto Loop;
                }

            }
        }

        private void updateauto()
        {
            int count = 0, sno = 0;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand("select count(*) from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            count = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();

            SqlCommand cmd1 = new SqlCommand("select sno from autogenerate where Convert(date,Date)=Convert(date,getdate())", con);
            con.Open();
            sno = Convert.ToInt32(cmd1.ExecuteScalar());
            con.Close();

            if (count == 0)
            {
                SqlCommand cmd2 = new SqlCommand("insert into autogenerate values(getdate(),1)", con);
                con.Open();
                cmd2.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                if (Convert.ToInt32(cmb_apno.Text) == sno + 1)
                {
                    SqlCommand cmd2 = new SqlCommand("update autogenerate set sno='" + Convert.ToInt32(cmb_apno.Text) + "' where convert(date,date)=Convert(date,getdate())", con);
                    con.Open();
                    cmd2.ExecuteNonQuery();
                    con.Close();
                }
                else
                {
                    SqlCommand cmdc = new SqlCommand("select count(*) from regappform3 where Convert(date,Date)=Convert(date,getdate()) and ApNo='" + cmb_apno.Text + "' ", con);
                    con.Open();
                    count = Convert.ToInt32(cmdc.ExecuteScalar());
                    con.Close();

                    if (count == 0)
                    {

                    }
                    else
                    {
                        MessageBox.Show("Appointment Number Aleady Exits");
                    }

                }
            }
        }

        void CalculateBMI(double w, double h)
        {
            txtbmi.Text = Math.Round((w / (h * h)) * 10000, 2).ToString();
        }

        void CallNewPage()
        {

        }

       

        private void LoadMedician()
        {
            AutoCompleteStringCollection DrugCollection = new AutoCompleteStringCollection();
            AutoCompleteStringCollection MedicineCollection = new AutoCompleteStringCollection();
            SqlConnection con = new SqlConnection(constr);

            {
                con.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("select Drug from Drug ", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    MedicineCollection.Add(reader["Drug"].ToString());
                }
                con.Close();
            }

        }

        public void autoinc()
        {
            int id = 0;
            string alp = AppMain.DoctorCode;
            string id_final = "";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select *  from Drug", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                SqlCommand cmd = new SqlCommand("select max(Sno) from Drug", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    id = Convert.ToInt32(dr[0].ToString());
                    id = id + 1;
                    id_final = Convert.ToString(id);
                    txtpatiantID.Text = (alp + id_final).ToString().PadLeft(2, '0');
                    this.
                    txtpatiantID.Enabled = true;//txtpatiantID.Enabled = false;
                }
                else
                {
                }
                dr.Close();
            }
            else
            {
                id = id + 1;
                id_final = Convert.ToString(id);
                txtpatiantID.Text = id_final.ToString();
                txtpatiantID.Enabled = true;//txtpatiantID.Enabled = false;
            }
        }

        private DataTable fillAgeBasedCalculation(int Month, int year, string Icode)
        {
            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            //string querry = @" SELECT A.DQty,B.DoseInUnits[Dose],A.DivDose,A.Inst FROM Drug[A] Left Join DrugAgeBased[B] On A.Icode=B.ICode " +
            //                " Where @year Between FromYear and ToYear and @Month between FromMonth and ToMonth and A.Drug=@Icode";

            //string querry = @" SELECT A.DQty,B.DoseInUnits[Dose],A.DivDose,A.Inst FROM Drug[A] Left Join DrugAgeBased[B] On A.Icode=B.ICode " +
            //               " Where ((@year Between FromYear and ToYear) or FromYear=@year or ToYear=@year) and ((@Month between FromMonth and ToMonth) or FromMonth=@Month or ToMonth=@Month)and A.Drug=@Icode";


            //string querry = @" SELECT A.DQty,B.DoseInUnits[Dose],A.DivDose,A.Inst FROM Drug[A] Left Join DrugAgeBased[B] On A.Icode=B.ICode " +
            //               " Where " + year + " Between FromYear and ToYear and " + Month + " between FromMonth and ToMonth and A.Drug=@Icode";

            string querry = @"SELECT A.DQty,B.DoseInUnits[Dose],A.DivDose,A.Inst FrOM Drug[A] Left" +
                           " Join DrugAgeBased[B] On A.Icode=B.ICode Where  A.Drug=@Icode and " +
                         "CONVERT(Date,DATEADD(month,-" + Month + ",(Convert(Date,DATEADD(year,-" + year + ",+GETDATE())))),101) Between " +
  "Convert(Date, DATEADD(month, DATEDIFF(month, 0,    DATEADD(month, DATEDIFF(month, 0,( CONVERT(Date,DATEADD(month,-ToMonth, (Convert(Date,DATEADD(year,-ToYear,GETDATE()))))))),0)     ), 0) ,101)" +
 "and" +
  " Convert(Date,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,   DATEADD(month,-FromMonth, (Convert(Date,DATEADD(year,-FromYear,GETDATE()))))  )+1,0)),101)   ";
            SqlCommand cmd = new SqlCommand(querry, con);
            //cmd.Parameters.AddWithValue("@Month", Month);
            //cmd.Parameters.AddWithValue("@year", year);
            cmd.Parameters.AddWithValue("@Icode", Icode);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds.Tables[0];
        }

        public void DateDifference(DateTime d1, DateTime d2)
        {
            int[] monthDay = new int[12] { 31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            int year;
            int month;
            int day;

            DateTime fromDate;


            DateTime toDate;

            int increment;

            if (d1 > d2)
            {
                fromDate = d2;
                toDate = d1;
            }
            else
            {
                fromDate = d1;
                toDate = d2;
            }

            /// 
            /// Day Calculation
            /// 
            increment = 0;

            if (fromDate.Day > toDate.Day)
            {
                increment = monthDay[fromDate.Month - 1];

            }
            /// if it is february month
            /// if it's to day is less then from day
            if (increment == -1)
            {
                if (DateTime.IsLeapYear(fromDate.Year))
                {
                    // leap year february contain 29 days
                    increment = 29;
                }
                else
                {
                    increment = 28;
                }
            }
            if (increment != 0)
            {
                day = (toDate.Day + increment) - fromDate.Day;
                increment = 1;
            }
            else
            {
                day = toDate.Day - fromDate.Day;
            }

            ///
            ///month calculation
            ///
            if ((fromDate.Month + increment) > toDate.Month)
            {
                month = (toDate.Month + 12) - (fromDate.Month + increment);
                increment = 1;
            }
            else
            {
                month = (toDate.Month) - (fromDate.Month + increment);
                increment = 0;
            }

            ///
            /// year calculation
            ///
            year = toDate.Year - (fromDate.Year + increment);

            yearDiff = year;
            monthdiff = month;
            daysdiff = day;

        }

        void CalculateDate(DateTime todaydate, DateTime clickedDate)
        {
            DateTime Cday = todaydate;
            DateTime Bday = clickedDate;
            if ((Cday.Year - Bday.Year) > 0 ||
        (((Cday.Year - Bday.Year) == 0) && ((Bday.Month < Cday.Month) ||
          ((Bday.Month == Cday.Month) && (Bday.Day <= Cday.Day)))))
            {
                int DaysInBdayMonth = DateTime.DaysInMonth(Bday.Year, Bday.Month);
                int DaysRemain = Cday.Day + (DaysInBdayMonth - Bday.Day);

                if (Cday.Month > Bday.Month)
                {
                    this.yearDiff = Cday.Year - Bday.Year;
                    this.monthdiff = Cday.Month - (Bday.Month + 1) + Math.Abs(DaysRemain / DaysInBdayMonth);
                    this.daysdiff = (DaysRemain % DaysInBdayMonth + DaysInBdayMonth) % DaysInBdayMonth;
                }
                else if (Cday.Month == Bday.Month)
                {
                    if (Cday.Day >= Bday.Day)
                    {
                        this.yearDiff = Cday.Year - Bday.Year;
                        this.monthdiff = 0;
                        this.daysdiff = Cday.Day - Bday.Day;
                    }
                    else
                    {
                        this.yearDiff = (Cday.Year - 1) - Bday.Year;
                        this.monthdiff = 11;
                        this.daysdiff = DateTime.DaysInMonth(Bday.Year, Bday.Month) - (Bday.Day - Cday.Day);
                    }
                }
                else
                {
                    this.yearDiff = (Cday.Year - 1) - Bday.Year;
                    this.monthdiff = Cday.Month + (11 - Bday.Month) + Math.Abs(DaysRemain / DaysInBdayMonth);
                    this.daysdiff = (DaysRemain % DaysInBdayMonth + DaysInBdayMonth) % DaysInBdayMonth;
                }
            }
        }

        void LoadDrugCalculation()
        {
            for (int Rowid = 0; Rowid < ctrldataGridPrescription.Rows.Count; Rowid++)
            {
                if (ctrldataGridPrescription.Rows[Rowid].Cells[1].Value != null && ctrldataGridPrescription.Rows[Rowid].Cells[1].Value != "")
                {
                    SqlConnection con = new SqlConnection(constr);
                    DataSet ds = new DataSet();
                    con = new SqlConnection(constr);
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                    string querry = @"Select isnull(StrMg,0)[StrMg], ISNULL(StrML,0)[StrML],isnull(Dose,0)[Dose],DivDose,Inst,Insttamil,DQty,str1U,Str2U," +
                                    " DrugBased,DrugType,B.DrugTypeName,B.DisplayName,A.Duration,A.Fixeddose  from Drug[A] Left Join DrugType[B] On a.DrugType=B.RowID " +
                                    " Where Drug=@Drug";
                    SqlCommand cmd = new SqlCommand(querry, con);
                    cmd.Parameters.AddWithValue("@Drug", ctrldataGridPrescription.Rows[Rowid].Cells[1].Value.ToString());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "1")
                        {
                            ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                            ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = ds.Tables[0].Rows[0]["DQty"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = ds.Tables[0].Rows[0]["Fixeddose"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = ds.Tables[0].Rows[0]["DivDose"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = ds.Tables[0].Rows[0]["Inst"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();
                        }
                        else if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "2")
                        {
                            ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                            DateTime todaydate = DateTime.Now;
                            DateTime clickedDate = ctrlDateDOB.Value.Date;
                            CalculateDate(todaydate, clickedDate);
                            DataTable dt = fillAgeBasedCalculation(monthdiff, yearDiff, ctrldataGridPrescription.Rows[Rowid].Cells[1].Value.ToString());
                            if (dt.Rows.Count > 0)
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = dt.Rows[0]["DQty"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = dt.Rows[0]["Dose"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = dt.Rows[0]["DivDose"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString(); ;
                                ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = dt.Rows[0]["Inst"].ToString();
                                ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();
                            }
                            else
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = "";
                                ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = "";
                            }
                        }
                        else if (ds.Tables[0].Rows[0]["DrugBased"].ToString() == "3")
                        {

                            double Weight = 0;
                            if (txtweight.Text != "")
                                Weight = Convert.ToDouble(txtweight.Text);
                            ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = ds.Tables[0].Rows[0]["DQty"].ToString();

                            double Dose = Convert.ToDouble(ds.Tables[0].Rows[0]["Dose"].ToString());
                            double divDOse = 1;
                            if (ds.Tables[0].Rows[0]["DivDose"].ToString() != "" && !ds.Tables[0].Rows[0]["DivDose"].ToString().StartsWith("As"))
                                if (ds.Tables[0].Rows[0]["DivDose"].ToString().Substring(0, 1).ToUpper() == "O")
                                    divDOse = 1;
                                else
                                    divDOse = Convert.ToDouble(ds.Tables[0].Rows[0]["DivDose"].ToString().Substring(0, 1));

                            double doseperkg = Dose * Weight;
                            double doseperint = 0;
                            doseperint = doseperkg / divDOse;
                            double fnl = 0;
                            double StrMg = Convert.ToDouble(ds.Tables[0].Rows[0]["StrMg"].ToString());
                            double StrML = Convert.ToDouble(ds.Tables[0].Rows[0]["StrML"].ToString());
                            double str = StrMg / StrML;

                            //double Weight = 0; 
                            //if (txtweight.Text != "")
                            //    Weight = Convert.ToDouble(txtweight.Text);
                            //if (ds.Tables[0].Rows[0]["str1U"].ToString() == "ml")
                            //    fnl = PerDose * Weight / StrML;
                            //else
                            fnl = doseperint / str;
                            //if (ds.Tables[0].Rows[0]["DrugTypeName"].ToString() == "Tablet" || ds.Tables[0].Rows[0]["DrugTypeName"].ToString() == "Drops")

                            if (ds.Tables[0].Rows[0]["str1U"].ToString() == "ml")
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                double dd = Math.Round(fnl, 1);
                                string asd = "";
                                if (dd.ToString().Split('.').Length > 1)
                                {
                                    asd = dd.ToString().Split('.')[1];
                                    if (Convert.ToInt32(asd) == 0)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Convert.ToDouble(dd.ToString().Split('.')[0]).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) <= 2)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Convert.ToDouble(dd.ToString().Split('.')[0]) + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 2 && Convert.ToInt32(asd) <= 7)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + .5).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 7)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                }
                                else
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                            }
                            else if (ds.Tables[0].Rows[0]["str1U"].ToString() == "Tab")
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                double dd = Math.Round(fnl, 2);
                                string asd = "";
                                if (dd.ToString().Split('.').Length > 1)
                                {
                                    asd = dd.ToString().Split('.')[1].PadRight(2, '0');
                                    string apnval = Convert.ToDouble(dd.ToString().Split('.')[0]).ToString() == "0" ? "" : Convert.ToDouble(dd.ToString().Split('.')[0]).ToString();

                                    if (Convert.ToInt32(asd) == 0)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) <= 37)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 1/4 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 37 && Convert.ToInt32(asd) <= 62)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 1/2 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 62 && Convert.ToInt32(asd) <= 87)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = apnval + " 3/4 " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else if (Convert.ToInt32(asd) > 87)
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0]) + 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                    else
                                        ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 2).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                                }
                                else
                                    ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = (Convert.ToDouble(dd.ToString().Split('.')[0])).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();

                            }
                            else if (ds.Tables[0].Rows[0]["str1U"].ToString() == ".ml")
                            {
                                ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                            }
                            else
                                ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + " " + ds.Tables[0].Rows[0]["DisplayName"].ToString();
                            //  else
                            //  ctrldataGridPrescription1.Rows[Rowid].Cells[3].Value = Math.Round(fnl, 1).ToString() + "ml";
                            ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = ds.Tables[0].Rows[0]["DivDose"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = ds.Tables[0].Rows[0]["Inst"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = ds.Tables[0].Rows[0]["Insttamil"].ToString();
                            ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = ds.Tables[0].Rows[0]["Duration"].ToString();

                            ctrldataGridPrescription.Rows[Rowid].Cells[0].Value = Rowid + 1;
                        }
                        else
                        {
                            ctrldataGridPrescription.Rows[Rowid].Cells[2].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[3].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[4].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[5].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[6].Value = "";
                            ctrldataGridPrescription.Rows[Rowid].Cells[7].Value = "";
                        }
                    }
                    else
                    {
                        //ctrldataGridPrescription1.Rows[Rowid].Cells[2].Value = "";
                        //ctrldataGridPrescription1.Rows[Rowid].Cells[3].Value = "";
                        //ctrldataGridPrescription1.Rows[Rowid].Cells[4].Value = "";
                        //ctrldataGridPrescription1.Rows[Rowid].Cells[5].Value = "";
                        //ctrldataGridPrescription1.Rows[Rowid].Cells[6].Value = "";
                        ctrldataGridPrescription.DataSource = null;
                    }
                }
            }
        }

        void LoadPerviousePatientList()
        {
            try
            {
                SqlConnection con = new SqlConnection(constr);
                DataSet ds = new DataSet();
                con = new SqlConnection(constr);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                string Conditions = "";
                if (txtpatiantID.Text != "")
                    Conditions += " And A.PatiantID =@PatiantID";
                if (txtPhoneNo.Text != "")
                    Conditions += " And A.PhoneNo =@PhoneNo";
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Age,Temp,Weigt,Height,BMI,HeadCircum,DiagnosisRowID,A.DiagnosisHTML" +
                                " ,B.Diagnosis,A.Date,A.PatiantID,A.LastName,A.MiddleName,A.PhoneNo,DiagnosisAdvice " +
                                " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                                " where 1=1 " + Conditions + "; select  row_number() over (order by EPresNo) as SNo, " +
                                " Icode[Medicine],Qty[Quantity],Dose[Dose],devideDose[dividedDoses],Instruction[Instructions] " +
                                " from Prescription_DT where  EPresNo=(Select A.EPresNo from regappform3[A] Where 1=1 " + Conditions + ")";
                SqlCommand cmd = new SqlCommand(querry, con);
                cmd.Parameters.AddWithValue("@PatiantID", txtpatiantID.Text);
                cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Text);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                    genderComboBox.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                    ctrlDateDOB.Text = ds.Tables[0].Rows[0]["DateDetails"].ToString();
                    txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                    txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
                    txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
                    txtbmi.Text = ds.Tables[0].Rows[0]["BMI"].ToString();
                    //ate_clnotes.TextEditor.Rtf = ds.Tables[0].Rows[0]["DiagnosisHTML"].ToString(); ate_clnotes.Refresh();
                    //ate_advice.TextEditor.Rtf = ds.Tables[0].Rows[0]["DiagnosisAdvice"].ToString(); ate_advice.Refresh();
                    txtDiagnosis.Text = ds.Tables[0].Rows[0]["Diagnosis"].ToString();
                    //lblDiagnosisRowID.Text = ds.Tables[0].Rows[0]["DiagnosisRowID"].ToString();
                    txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                    txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                    //txtmiddleName.Text = ds.Tables[0].Rows[0]["MiddleName"].ToString();
                    //txtlastname.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
                    ctrlLblPatientHis.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
                    txtPhoneNo.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
                    ctrldataGridPrescription.DataSource = null;
                    ctrldataGridPrescription.AutoGenerateColumns = false;
                    ctrldataGridPrescription.DataSource = ds.Tables[1];
                }
                else
                {
                    genderComboBox.Text = "Male";
                    ctrlDateDOB.Text = "";
                    txtage.Text = "";
                    txtweight.Text = "";
                    txtheight.Text = "";
                    txtbmi.Text = "";
                    ctrlLblPatientHis.Text = "";
                    //ate_clnotes.TextEditor.Rtf = "";
                    //ate_advice.TextEditor.Rtf = "";
                    txtDiagnosis.Text = "";
                    //txtdatetime.Text = "";
                    DataTable dt1 = SetInitialRow();
                    ctrldataGridPrescription.DataSource = null;
                    ctrldataGridPrescription.AutoGenerateColumns = false;
                    ctrldataGridPrescription.DataSource = dt1.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private DataTable GetDrugTable()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select Icode,Drug[Drug] from Drug where isnull(Drug,'')<>'' ", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
            }
            return ds.Tables[0];
        }

        private void TemparatureFormat()
        {
            if (numericUpDown1.Value == Convert.ToInt32(numericUpDown1.Value))
            {
                int value = Convert.ToInt32(numericUpDown1.Value);
                string number = Convert.ToString(value);

                string outputValue = "";
                foreach (char item in number)
                {
                    if (item == '.')
                    {
                        numericUpDown1.Text = outputValue;
                        break;
                    }
                    else
                    {
                        outputValue += item;
                    }
                }

            }
        }

        //void LoadCategory()
        //{
        //    DataSet ds = new DataSet();
        //    SqlConnection con = new SqlConnection(constr);
        //    {
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand("select RowID,Category,Amount from AmountCategory ", con);
        //        SqlDataAdapter da = new SqlDataAdapter(cmd);
        //        da.Fill(ds);
        //        cbCategory.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
        //        cbCategory.ValueMember = "RowID";
        //        cbCategory.DisplayMember = "Category";


        //        //  lblActualAmt.Text = ds.Tables[0].Rows[0]["Amount"].ToString();
        //        con.Close();
        //    }

        //}

        public void FillDropDownAppNo()
        {
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(constr);
            {
                con.Open();
                cmb_apno.DataSource = null;
                //SqlCommand cmd = new SqlCommand("select ApNo,PatiantID from regappform3 where Convert(date,Date)=Convert(date,getDate())  order by Cast(ApNo as int) asc ", con);//and EPresNo=''
                SqlCommand cmd = new SqlCommand("select ApNo, PatiantID from regappform3 where (Convert(date, Date) = Convert(date, getDate()) and Hospital_Id = @hospID and DoctorCode = @doctorCode)  order by Cast(ApNo as int) asc",con);
                cmd.Parameters.AddWithValue("@hospID", Convert.ToInt32(AppMain.HospitalId));
                cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
              
                da.Fill(ds);

                cmb_apno.DataSource = ds.Tables[0]; // Bind combobox with datasource.  
                cmb_apno.ValueMember = "ApNo";
                cmb_apno.DisplayMember = "ApNo";
                con.Close();
            }

        }

     

        void LoadOldPrescription(DateTime from, DateTime to, bool _considerDate, string _considerField, string id = "", string Epresno = "", string name = "", string phoneNumber = "",string UHID=null)
        {

            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            if (_considerField.ToUpper() == "P")
            { name = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "N")
            { phoneNumber = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "E")
            { phoneNumber = ""; name = ""; id = ""; }
            if (_considerField.ToUpper() == "I")
            { phoneNumber = ""; name = ""; Epresno = ""; }
            string _datefilter = (_considerDate) ? " or( Date between '" + from.ToString("yyyy/MM/dd") + "' and '" + to.AddDays(1).ToString("yyyy/MM/dd") + "')" : "";

            //string querry1 = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,
            //                    Age,DateOfBirth,A.PatiantID,A.Date,A.MiddleName,A.LastName,A.PhoneNo " +
            //                " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
            //                " where (A.PhoneNo like '" + phoneNumber + "'" +
            //                " or A.Name like N'" + name +
            //                "' or A.EPresNo like N'" + Epresno + "' or A.UHID like N'" + UHID +
            //                "' or A.PatiantID like N'" + id + "')" + _datefilter
            //                + "order by EPresNo desc";




            string querry = "";
            if (_considerField.ToUpper() == "P")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PhoneNo like '{phoneNumber}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "E")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID ,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.EPresNo like '{Epresno}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "N")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID ,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.Name like '{name}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "I")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.PatiantID like '{id}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }
            else if (_considerField.ToUpper() == "UH")
            {
                querry = $@"select A.EPresNo,ApNo,Name,Gender,DateDetails,Address,Age,DateOfBirth,A.PatiantID,A.Date,
		        A.MiddleName,A.LastName,A.PhoneNo,A.UHID,
                FullAddress,AllergicDrugs,BirthHistory,PastIllness,FamilyHistory,LabInvestigations,AddtionalInformation
                from regappform3[A] Left Join Diagnosis[B]
                On A.DiagnosisRowID = B.RowId  where(A.UHID like '{UHID}' and DoctorCode =@doctorCode) order by EPresNo desc";
            }

            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable resultTable = ds.Tables[0];
            int searchIndex = 0;
            //if (resultTable.Rows.Count>1)
            //{             
            //    frmSearchUserConfirmation frm = new frmSearchUserConfirmation(resultTable);
            //    frm.ShowDialog();
            //    searchIndex = frm.SelectedIndex;
            //}
            if (resultTable.Rows.Count > 0)
            {
                // txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                txtAddress.Text = resultTable.Rows[searchIndex]["Address"].ToString();               
                txtpatiantID.Text = resultTable.Rows[searchIndex]["PatiantID"].ToString();
                txtname.Text = resultTable.Rows[searchIndex]["Name"].ToString();
                genderComboBox.Text = resultTable.Rows[searchIndex]["Gender"].ToString();
                if (resultTable.Columns.Contains("DateOfBirth"))
                    if (resultTable.Rows[searchIndex]["DateOfBirth"].ToString() != "")
                        ctrlDateDOB.Value = Convert.ToDateTime(resultTable.Rows[searchIndex]["DateOfBirth"].ToString());
                //txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                //txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                //txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                //txtmiddleName.Text = ds.Tables[0].Rows[0]["MiddleName"].ToString();
                //txtlastname.Text = ds.Tables[0].Rows[0]["LastName"].ToString();
                txtPhoneNo.Text = resultTable.Rows[searchIndex]["PhoneNo"].ToString();
                ctrlTxtUHID.Text= resultTable.Rows[searchIndex]["UHID"].ToString();
                ctrldataGridPrescription.DataSource = null;
                ctrldataGridPrescription.AutoGenerateColumns = false;
                personalInformation = new PersonalInformation();
                personalInformation.FullAddress = resultTable.Rows[searchIndex]["FullAddress"]?.ToString();
                personalInformation.AllergicDrugs = resultTable.Rows[searchIndex]["AllergicDrugs"]?.ToString();
                personalInformation.BirthHistory = resultTable.Rows[searchIndex]["BirthHistory"]?.ToString();
                personalInformation.PastIllness = resultTable.Rows[searchIndex]["PastIllness"]?.ToString();
                personalInformation.FamilyHistory = resultTable.Rows[searchIndex]["FamilyHistory"]?.ToString();
                //personalInformation.LabInvestigations = resultTable.Rows[searchIndex]["LabInvestigations"]?.ToString();
                //personalInformation.AddtionalInformation = resultTable.Rows[searchIndex]["AddtionalInformation"]?.ToString();

                ctrlTxtBirthHist.Text = personalInformation.BirthHistory;
                ctrlTxtFamilyHis.Text = personalInformation.FamilyHistory;
                ctrlTxtPastIllness.Text = personalInformation.PastIllness;
                ctrlTxtFullAddress.Text = personalInformation.FullAddress;
                new GeneralMethods().LoadCheckedValues(personalInformation.AllergicDrugs, ref ctrlCbxAlergy);
                


            }
            
        }

        public void SetOldPrescriptions(DataSet ds)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtPresNo.Text = ds.Tables[0].Rows[0]["EPresNo"].ToString();
                txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                txtpatiantID.Text = ds.Tables[0].Rows[0]["PatiantID"].ToString();
                txtname.Text = ds.Tables[0].Rows[0]["Name"].ToString();
                genderComboBox.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                if (ds.Tables[0].Columns.Contains("DateOfBirth"))
                    if (ds.Tables[0].Rows[0]["DateOfBirth"].ToString() != "")
                        ctrlDateDOB.Value = Convert.ToDateTime(ds.Tables[0].Rows[0]["DateOfBirth"].ToString());
                txtage.Text = ds.Tables[0].Rows[0]["Age"].ToString();
                txtdatetime.Text = ds.Tables[0].Rows[0]["Date"].ToString();
                txtPhoneNo.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
                txtheight.Text = ds.Tables[0].Rows[0]["Height"].ToString();
                txtweight.Text = ds.Tables[0].Rows[0]["Weigt"].ToString();
                txtbmi.Text = ds.Tables[0].Rows[0]["BMI"].ToString();
                numericUpDown1.Text = ds.Tables[0].Rows[0]["Temp"].ToString();
                ctrlLblPatientHis.Text = ds.Tables[0].Rows[0]["HeadCircum"].ToString();
                txtAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                txtDiagnosis.Text = ds.Tables[0].Rows[0]["Diagnosis"].ToString();
                ctrlTxtUHID.Text = ds.Tables[0].Rows[0]["UHID"].ToString();
                cmb_apno.Text = ds.Tables[0].Rows[0]["ApNo"].ToString();
                ctrlCbxStatus.Text= ds.Tables[0].Rows[0]["Patient Status"].ToString();
                ctrldataGridPrescription.DataSource = null;
                ctrldataGridPrescription.AutoGenerateColumns = false;

                personalInformation = new PersonalInformation();
                personalInformation.FullAddress = ds.Tables[0].Rows[0]["FullAddress"]?.ToString();
                personalInformation.AllergicDrugs = ds.Tables[0].Rows[0]["AllergicDrugs"]?.ToString();
                personalInformation.BirthHistory = ds.Tables[0].Rows[0]["BirthHistory"]?.ToString();
                personalInformation.PastIllness = ds.Tables[0].Rows[0]["PastIllness"]?.ToString();
                personalInformation.FamilyHistory = ds.Tables[0].Rows[0]["FamilyHistory"]?.ToString();
                //personalInformation.LabInvestigations = resultTable.Rows[searchIndex]["LabInvestigations"]?.ToString();
                //personalInformation.AddtionalInformation = resultTable.Rows[searchIndex]["AddtionalInformation"]?.ToString();

                ctrlTxtBirthHist.Text = personalInformation.BirthHistory;
                ctrlTxtFamilyHis.Text = personalInformation.FamilyHistory;
                ctrlTxtPastIllness.Text = personalInformation.PastIllness;
                ctrlTxtFullAddress.Text = personalInformation.FullAddress;
                new GeneralMethods().LoadCheckedValues(personalInformation.AllergicDrugs, ref ctrlCbxAlergy);
            }
        }

        public DataSet LoadOldPrescriptionDS(DateTime from, DateTime to, bool _considerDate, string _considerField, string id = "", string Epresno = "", string name = "", string phoneNumber = "")
        {

            SqlConnection con = new SqlConnection(constr);
            DataSet ds = new DataSet();
            con = new SqlConnection(constr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
            if (_considerField.ToUpper() == "P")
            { name = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "N")
            { phoneNumber = ""; Epresno = ""; id = ""; }
            if (_considerField.ToUpper() == "E")
            { phoneNumber = ""; name = ""; id = ""; }
            if (_considerField.ToUpper() == "I")
            { phoneNumber = ""; name = ""; Epresno = ""; }
            string _datefilter = (_considerDate) ? " and ( Date between '" + from.ToString("yyyy/MM/dd") + "' and '" + to.AddDays(1).ToString("yyyy/MM/dd") + "')" : "";

            string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,
                                Address,Age,DateOfBirth,A.PatiantID,A.Date,
                                        A.MiddleName,A.LastName,A.PhoneNo,A.UHID " +
                            " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                            " where ((A.Hospital_Id =@ID) AND    A.PhoneNo like '" + phoneNumber + "' or A.Name like N'" + name + "' or A.EPresNo like N'" + Epresno + "' or A.PatiantID like N'" + id + "')" + _datefilter
                            + "order by EPresNo desc";
            SqlCommand cmd = new SqlCommand(querry, con);
            cmd.Parameters.AddWithValue("@ID",Convert.ToInt32(AppMain.HospitalId));
            cmd.Parameters.AddWithValue("@DoctoCode",AppMain.DoctorCode);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;

        }

        #endregion


        private void txtname_TextChanged(object sender, EventArgs e)
        {
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;

            txtname.Text = textInfo.ToTitleCase(txtname.Text.ToLower());
            txtname.Focus();
            txtname.SelectionStart = txtname.Text.Length; // add some logic if length is 0
            txtname.SelectionLength = 0;
            //TextBox richTextBoxGuess = ((TextBox)sender);

            //if (richTextBoxGuess.Text.Length <= 0) return;
            //string s = richTextBoxGuess.Text.Substring(0, 1);
            //if (s != s.ToUpper())
            //{
            //    int curSelStart = richTextBoxGuess.SelectionStart;
            //    int curSelLength = richTextBoxGuess.SelectionLength;
            //    richTextBoxGuess.SelectionStart = 0;
            //    richTextBoxGuess.SelectionLength = 1;
            //    richTextBoxGuess.SelectedText = s.ToUpper();
            //    richTextBoxGuess.SelectionStart = curSelStart;
            //    richTextBoxGuess.SelectionLength = curSelLength;
            //}
        }

        private void btnVPP_Click(object sender, EventArgs e)
        {
            DataSet ds = LoadOldPrescriptionDS(new DateTime(), new DateTime(), false, "I", txtpatiantID.Text.ToString());

            if (ds.Tables[0].Rows.Count == 0) { MessageBox.Show("No Data to Display!"); return; }
            OpView _op = new OpView(ds);
            _op.TopMost = true;
            _op.ShowDialog();
        }


        private void cmb_apno_DropDownClosed(object sender, EventArgs e)
        {
            LoadBasedonApno();
        }

        void LoadBasedonApno()
        {
            if (cmb_apno.SelectedIndex >= 0)
            {
                string _selVal = ((System.Data.DataRowView)(cmb_apno.Items[cmb_apno.SelectedIndex])).Row.ItemArray[0].ToString();
                SqlConnection con = new SqlConnection(constr);
                DataSet ds = new DataSet();
                if (con.State == ConnectionState.Closed)
                    con.Open();
                AutoCompleteStringCollection namesCollection = new AutoCompleteStringCollection();
                string querry = @" select A.EPresNo,ApNo,Name,Gender,DateDetails,Age,A.Temp,A.PatiantID,A.Date,A.MiddleName,
                                  A.LastName,A.PhoneNo,A.Address,A.Weigt,A.Height,A.HeadCircum,A.UHID ,A.FullAddress,A.AllergicDrugs,A.BirthHistory,
                                    A.PastIllness,A.FamilyHistory,
                                    A.LabInvestigations,A.AddtionalInformation" +
                                " from regappform3[A] Left Join Diagnosis[B] On A.DiagnosisRowID=B.RowId " +
                                " where A.ApNo=@ApNo and Convert(date,Date)=Convert(date,getDate())";
                SqlCommand cmd = new SqlCommand(querry, con);

                //cmd.Parameters.AddWithValue("@ApNo", cmb_apno.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@ApNo", _selVal);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        loaddatas(ds);
                    }
                    else
                    {
                        ClearOldValues();
                        Prescription_Load(null, null);
                    }
            }
        }



        private void txtname_KeyPress(object sender, KeyPressEventArgs e)
        {
            //e.KeyChar = Char.ToUpper(e.KeyChar);

        }

        private void txtAddress_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtAddress.Text.Length > 0)
                txtAddress.Text = Char.ToUpper(txtAddress.Text[0]) + txtAddress.Text.Remove(0, 1);
            txtAddress.SelectionStart = txtAddress.Text.Length; // add some logic if length is 0
            txtAddress.SelectionLength = 0; txtAddress.Focus();

        }

        private void btnVaccine_Click(object sender, EventArgs e)
        {
            if (txtname.Text != "")
            {
                NewVaccineBirthChart _NewVaccineBirthChart = new NewVaccineBirthChart(this,Convert.ToString(ctrlDateDOB.Value.ToString("yyyy/MM/dd")), txtname.Text, txtpatiantID.Text, genderComboBox.Text);
                _NewVaccineBirthChart.ShowDialog();
            }
            else
                MessageBox.Show("Please Enter the Patient", "SVM");
        }

        private void ctrlTxtUHID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Tab || e.KeyCode == Keys.Enter)
            {
                //  chkOld_CheckedChanged(null, null);
                if (chkOld.Checked)
                    LoadOldPrescription(DateTime.Now, DateTime.Now, false, "UH", txtpatiantID.Text.StartsWith(AppMain.DoctorCode) ? txtpatiantID.Text : $"{AppMain.DoctorCode} - " + txtpatiantID.Text, "", txtname.Text, txtPhoneNo.Text,ctrlTxtUHID.Text);


            }
        }

        private void txtweight_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (sender is TextBox)
            {
                if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.')) || ((TextBox)sender).Text.Contains('.') && (e.KeyChar == '.'))
                    e.Handled = true;
            }
            else if (sender is NumericUpDown)
            {
                if ((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.')) || ((NumericUpDown)sender).Text.ToString().Contains('.') && (e.KeyChar == '.'))
                    e.Handled = true;
            }
        }

        private void txtPhoneNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void PatientHistory_Click(object sender, EventArgs e)
        {
            frmHistory frmHistory = new frmHistory(ref personalInformation,chkOld.Checked);
            frmHistory.ShowDialog();

            ctrlTxtBirthHist.Text = personalInformation.BirthHistory;
            ctrlTxtFamilyHis.Text = personalInformation.FamilyHistory;
            ctrlTxtPastIllness.Text = personalInformation.PastIllness;
        }

        private void PatientAddtionalInfo_Click(object sender, EventArgs e)
        {
            frmAddtionalInfo frmAddtionalInfo = new frmAddtionalInfo(ref personalInformation, chkOld.Checked);
            frmAddtionalInfo.ShowDialog();
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            frmAlergicDrugs frmAlergicDrugs = new frmAlergicDrugs();
           DialogResult res= frmAlergicDrugs.ShowDialog();
         
            if (frmAlergicDrugs.IsModified)
            {
                ctrlCbxAlergy.Text = string.Empty;
                new GeneralMethods().PatientAlergicLoad(ref ctrlCbxAlergy);
            }
            //if (frmAlergicDrugs.IsAdded)
            //new GeneralMethods().LoadCheckedValues(personalInformation.AllergicDrugs, ref ctrlCbxAlergy);
        }

        public void LoadDefaultDropDownValues()
        {
            nameload();
            IDLoad();
            AddressLoad();
            phoneload();
            UHIDLoad();
            PatientStatusLoad();
            new GeneralMethods().PatientAlergicLoad(ref ctrlCbxAlergy);
        }

        private void CtrlTxtPersonalInfo_TextChanged(object sender, EventArgs e)
        {
            if(this.ActiveControl== ctrlTxtBirthHist)
            {
                personalInformation.BirthHistory = ctrlTxtBirthHist.Text;                       
            }
            else if (this.ActiveControl == ctrlTxtFamilyHis)
            {
                personalInformation.FamilyHistory = ctrlTxtFamilyHis.Text;
            }
            else if (this.ActiveControl == ctrlTxtPastIllness)
            {
                personalInformation.PastIllness = ctrlTxtPastIllness.Text;
            }
        }

        public bool IsExistingPatientID(string id)
        {
            bool isExist = false;
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "select count(*) from regappform3 where PatiantID=@patientID";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.Parameters.AddWithValue("@patientID", id);

                var MaxSeq = Convert.ToInt32(cmd.ExecuteScalar());
                isExist = MaxSeq > 0 ? true : false;
                con.Close();
            }
            return isExist;
        }

    }

    public class PersonalInformation
    {
        public string FullAddress { get; set; }
        public string AllergicDrugs { get; set; }
        public string BirthHistory { get; set; }
        public string PastIllness { get; set; }
        public string FamilyHistory { get; set; }
        public string LabInvestigations { get; set; }
        public string AddtionalInformation { get; set; }

    }
}
