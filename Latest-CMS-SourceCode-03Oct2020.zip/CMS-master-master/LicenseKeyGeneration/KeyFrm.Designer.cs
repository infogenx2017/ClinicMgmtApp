﻿namespace LicenseKeyGeneration
{
    partial class KeyFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlLblCmpName = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtCmpName = new MetroFramework.Controls.MetroTextBox();
            this.ctrlCbxSetupType = new MetroFramework.Controls.MetroComboBox();
            this.ctrlLblSetupType = new MetroFramework.Controls.MetroLabel();
            this.ctrlTxtNoOfDays = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblNoOfDays = new MetroFramework.Controls.MetroLabel();
            this.ctrlBtnKeyGenerate = new MetroFramework.Controls.MetroButton();
            this.ctrlTxtLicenseKey = new MetroFramework.Controls.MetroTextBox();
            this.ctrlLblLicenseKey = new MetroFramework.Controls.MetroLabel();
            this.ctrlBtnClose = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // ctrlLblCmpName
            // 
            this.ctrlLblCmpName.AutoSize = true;
            this.ctrlLblCmpName.Location = new System.Drawing.Point(41, 87);
            this.ctrlLblCmpName.Name = "ctrlLblCmpName";
            this.ctrlLblCmpName.Size = new System.Drawing.Size(113, 19);
            this.ctrlLblCmpName.TabIndex = 0;
            this.ctrlLblCmpName.Text = "Company Name :";
            // 
            // ctrlTxtCmpName
            // 
            this.ctrlTxtCmpName.Location = new System.Drawing.Point(185, 87);
            this.ctrlTxtCmpName.Name = "ctrlTxtCmpName";
            this.ctrlTxtCmpName.Size = new System.Drawing.Size(282, 23);
            this.ctrlTxtCmpName.TabIndex = 1;
            // 
            // ctrlCbxSetupType
            // 
            this.ctrlCbxSetupType.FormattingEnabled = true;
            this.ctrlCbxSetupType.ItemHeight = 23;
            this.ctrlCbxSetupType.Location = new System.Drawing.Point(185, 129);
            this.ctrlCbxSetupType.Name = "ctrlCbxSetupType";
            this.ctrlCbxSetupType.Size = new System.Drawing.Size(282, 29);
            this.ctrlCbxSetupType.TabIndex = 2;
            // 
            // ctrlLblSetupType
            // 
            this.ctrlLblSetupType.AutoSize = true;
            this.ctrlLblSetupType.Location = new System.Drawing.Point(41, 131);
            this.ctrlLblSetupType.Name = "ctrlLblSetupType";
            this.ctrlLblSetupType.Size = new System.Drawing.Size(80, 19);
            this.ctrlLblSetupType.TabIndex = 3;
            this.ctrlLblSetupType.Text = "Setup Type :";
            // 
            // ctrlTxtNoOfDays
            // 
            this.ctrlTxtNoOfDays.Location = new System.Drawing.Point(185, 176);
            this.ctrlTxtNoOfDays.MaxLength = 3;
            this.ctrlTxtNoOfDays.Name = "ctrlTxtNoOfDays";
            this.ctrlTxtNoOfDays.Size = new System.Drawing.Size(282, 23);
            this.ctrlTxtNoOfDays.TabIndex = 5;
            this.ctrlTxtNoOfDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ctrlTxtNoOfDays_KeyPress);
            // 
            // ctrlLblNoOfDays
            // 
            this.ctrlLblNoOfDays.AutoSize = true;
            this.ctrlLblNoOfDays.Location = new System.Drawing.Point(41, 176);
            this.ctrlLblNoOfDays.Name = "ctrlLblNoOfDays";
            this.ctrlLblNoOfDays.Size = new System.Drawing.Size(87, 19);
            this.ctrlLblNoOfDays.TabIndex = 4;
            this.ctrlLblNoOfDays.Text = "No. Of Days :";
            // 
            // ctrlBtnKeyGenerate
            // 
            this.ctrlBtnKeyGenerate.Location = new System.Drawing.Point(358, 264);
            this.ctrlBtnKeyGenerate.Name = "ctrlBtnKeyGenerate";
            this.ctrlBtnKeyGenerate.Size = new System.Drawing.Size(109, 30);
            this.ctrlBtnKeyGenerate.TabIndex = 6;
            this.ctrlBtnKeyGenerate.Text = "Key Generate";
            this.ctrlBtnKeyGenerate.Click += new System.EventHandler(this.ctrlBtnKeyGenerate_Click);
            // 
            // ctrlTxtLicenseKey
            // 
            this.ctrlTxtLicenseKey.Location = new System.Drawing.Point(185, 217);
            this.ctrlTxtLicenseKey.Name = "ctrlTxtLicenseKey";
            this.ctrlTxtLicenseKey.Size = new System.Drawing.Size(282, 23);
            this.ctrlTxtLicenseKey.TabIndex = 8;
            // 
            // ctrlLblLicenseKey
            // 
            this.ctrlLblLicenseKey.AutoSize = true;
            this.ctrlLblLicenseKey.Location = new System.Drawing.Point(41, 217);
            this.ctrlLblLicenseKey.Name = "ctrlLblLicenseKey";
            this.ctrlLblLicenseKey.Size = new System.Drawing.Size(81, 19);
            this.ctrlLblLicenseKey.TabIndex = 7;
            this.ctrlLblLicenseKey.Text = "License Key :";
            // 
            // ctrlBtnClose
            // 
            this.ctrlBtnClose.Location = new System.Drawing.Point(243, 264);
            this.ctrlBtnClose.Name = "ctrlBtnClose";
            this.ctrlBtnClose.Size = new System.Drawing.Size(109, 30);
            this.ctrlBtnClose.TabIndex = 9;
            this.ctrlBtnClose.Text = "Close";
            this.ctrlBtnClose.Click += new System.EventHandler(this.ctrlBtnClose_Click);
            // 
            // KeyFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 317);
            this.Controls.Add(this.ctrlBtnClose);
            this.Controls.Add(this.ctrlTxtLicenseKey);
            this.Controls.Add(this.ctrlLblLicenseKey);
            this.Controls.Add(this.ctrlBtnKeyGenerate);
            this.Controls.Add(this.ctrlTxtNoOfDays);
            this.Controls.Add(this.ctrlLblNoOfDays);
            this.Controls.Add(this.ctrlLblSetupType);
            this.Controls.Add(this.ctrlCbxSetupType);
            this.Controls.Add(this.ctrlTxtCmpName);
            this.Controls.Add(this.ctrlLblCmpName);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "KeyFrm";
            this.Text = "Key Generation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KeyFrm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel ctrlLblCmpName;
        private MetroFramework.Controls.MetroTextBox ctrlTxtCmpName;
        private MetroFramework.Controls.MetroComboBox ctrlCbxSetupType;
        private MetroFramework.Controls.MetroLabel ctrlLblSetupType;
        private MetroFramework.Controls.MetroTextBox ctrlTxtNoOfDays;
        private MetroFramework.Controls.MetroLabel ctrlLblNoOfDays;
        private MetroFramework.Controls.MetroButton ctrlBtnKeyGenerate;
        private MetroFramework.Controls.MetroTextBox ctrlTxtLicenseKey;
        private MetroFramework.Controls.MetroLabel ctrlLblLicenseKey;
        private MetroFramework.Controls.MetroButton ctrlBtnClose;
    }
}

