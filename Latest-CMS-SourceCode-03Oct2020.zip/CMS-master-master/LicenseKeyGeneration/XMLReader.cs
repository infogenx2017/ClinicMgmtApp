﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace LicenseKeyGeneration
{
    public partial class XMLReader : Form
    {
        public XMLReader()
        {
            InitializeComponent();
        }


//        private void LoadXML()
//        {
//            int a = 0;
//            try
//            {
//                using (XmlReader reader = XmlReader.Create(@"E:\F-DRIVE FILES\CMS\Database\29-09-2019\regappform3\XML_F52E.xml"))
//                {
//                    while (reader.Read())
//                    {
                      
//                        if ((reader.NodeType == XmlNodeType.Element) && (reader.Name == "a"))
//                        {
//                            if (reader.HasAttributes)
//                            {
//                                var EPresNo = reader.GetAttribute("EPresNo");
//                                var ApNo = reader.GetAttribute("ApNo");
//                                var PatiantID = reader.GetAttribute("PatiantID");
//                                var LastName = reader.GetAttribute("LastName");
//                                var MiddleName = reader.GetAttribute("MiddleName");
//                                var Gender = reader.GetAttribute("Gender");
//                                var PhoneNo = reader.GetAttribute("PhoneNo");
//                                var DateDetails = reader.GetAttribute("DateDetails");
//                                var Age = reader.GetAttribute("Age");
//                                var Temp = reader.GetAttribute("Temp");
//                                var Weigt = reader.GetAttribute("Weigt");
//                                var Height = reader.GetAttribute("Height");
//                                var BMI = reader.GetAttribute("BMI");
//                                var HeadCircum = reader.GetAttribute("HeadCircum");
//                                var DiagnosisRowID = reader.GetAttribute("DiagnosisRowID");
//                                var DiagnosisHTML = reader.GetAttribute("DiagnosisHTML");
//                                var DiagnosisAdvice = reader.GetAttribute("DiagnosisAdvice");
//                                var ReviewDate = reader.GetAttribute("ReviewDate");
//                                var CategoryID = reader.GetAttribute("CategoryID");
//                                var AmountRecived = reader.GetAttribute("AmountRecived");
//                                var Address = reader.GetAttribute("Address");
//                                var Cby = reader.GetAttribute("Cby");
//                                var Cdt = reader.GetAttribute("Cdt");
//                                var Mby = reader.GetAttribute("Mby");
//                                var Mdt = reader.GetAttribute("Mdt");
//                                var Status = 1;// reader.GetAttribute("Status");
//                                var DateOfBirth = reader.GetAttribute("DateOfBirth");
//                                var Date = reader.GetAttribute("Date");
//                                var Hospital_Id = reader.GetAttribute("Hospital_Id");
//                                var UHID = reader.GetAttribute("UHID");
//                                var DoctorCode = reader.GetAttribute("DoctorCode");
//                                var cashType = reader.GetAttribute("cashType");
//                                var HaveInsurance = reader.GetAttribute("HaveInsurance");
//                                var FullAddress = reader.GetAttribute("FullAddress");
//                                var AllergicDrugs = reader.GetAttribute("AllergicDrugs");
//                                var BirthHistory = reader.GetAttribute("BirthHistory");
//                                var PastIllness = reader.GetAttribute("PastIllness");
//                                var FamilyHistory = reader.GetAttribute("FamilyHistory");
//                                var LabInvestigations = reader.GetAttribute("LabInvestigations");
//                                var AddtionalInformation = reader.GetAttribute("AddtionalInformation");
//                                var FinalDiagnosisId = reader.GetAttribute("FinalDiagnosisId");
//                                a++;

//                                string constr = "";
//                                using (SqlConnection con = new SqlConnection(constr))
//                                {
//                                    SqlCommand cmd = new SqlCommand("update regappform3 set	
//ApNo = @ApNo
//PatiantID = @PatiantID
//Name = @Name
//LastName = @LastName
//MiddleName = @MiddleName
//Gender = @Gender
//PhoneNo = @PhoneNo
//DateDetails = @DateDetails
//Age = @Age
//Temp = @Temp
//Weigt = @Weigt
//Height = @Height
//BMI = @BMI
//HeadCircum = @HeadCircum
//DiagnosisRowID = @DiagnosisRowID
//DiagnosisHTML = @DiagnosisHTML
//DiagnosisAdvice = @DiagnosisAdvice
//ReviewDate = @ReviewDate
//CategoryID = @CategoryID
//AmountRecived = @AmountRecived
//Address = @Address
//Cby = @Cby
//Cdt = @Cdt
//Mby = @Mby
//Mdt = @Mdt
//Status = @Status
//DateOfBirth = @DateOfBirth
//Date = @Date
//Hospital_Id = @Hospital_Id
//UHID = @UHID
//DoctorCode = @DoctorCode
//cashType = @cashType
//HaveInsurance = @HaveInsurance
//FullAddress = @FullAddress
//AllergicDrugs = @AllergicDrugs
//BirthHistory = @BirthHistory
//PastIllness = @PastIllness
//FamilyHistory = @FamilyHistory
//LabInvestigations = @LabInvestigations
//AddtionalInformation = @AddtionalInformation
//FinalDiagnosisId = @FinalDiagnosisId", con);
//                                    con.Open();
//                                    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(AppMain.HospitalId));
//                                    cmd.Parameters.AddWithValue("@doctorCode", AppMain.DoctorCode);
//                                    SqlDataReader reader = cmd.ExecuteReader();
//                                    AutoCompleteStringCollection MyCollection = new AutoCompleteStringCollection();
//                                    while (reader.Read())
//                                    {
//                                        MyCollection.Add(reader.GetString(0));
//                                    }
//                                    txtname.AutoCompleteCustomSource = MyCollection;
//                                    con.Close();
//                                }
//                            }
//                        }
//                    }
//                }

//            }
//            catch (Exception ed)
//            {

               
//            }
          
//        }

        private void XMLReader_Load(object sender, EventArgs e)
        {
           // LoadXML();
        }
    }
}
