﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LicenseKeyGeneration
{
    public class KeyGeneration
    {
        private char[] charValueOne = new char[] {'A','B','C','D','E','F','G','H','J','K',
        'L','M'};
        private char[] charValueTwo = new char[] {'N','O','P','Q','R','S','T','U','V','W','X',
        'Y','Z'};
        private char[] charValues = new char[] {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O',
        'P','Q','R','S','T','U','V','W','X','Y','Z'};
        private int[] numValueOne = new int[] { 0, 1, 2};
        private int[] numValueTwo = new int[] { 5, 6, 7};

        private int numIndex;
        private int charIndex;
        private int _days;

        private string exChar;

        public KeyGeneration()
        {
            numIndex = 0;
            charIndex = 0;
            exChar = "LI";
        }

        public KeyGeneration(int days) : this()
        {
            _days = days;
        }

        public string GenerateKey()
        {
            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\ProgrammeExe", true);

            if (registryKey != null)
            {
                GetValues(registryKey);
            }
            else
            {
                SetValues(registryKey);
            }
            string keys =Convert.ToString(ExecuteAlgorithm());
            return keys;
        }

        private void GetValues(RegistryKey registryKey)
        {
            charIndex = Convert.ToInt32(registryKey.GetValue("charIndex"));
            numIndex = Convert.ToInt32(registryKey.GetValue("numIndex"));

            registryKey.Close();
        }

        private void SetValues(RegistryKey registryKey)
        {
            registryKey = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\ProgrammeExe", RegistryKeyPermissionCheck.Default);

            registryKey.SetValue("charIndex", charIndex, RegistryValueKind.String);
            registryKey.SetValue("numIndex", numIndex, RegistryValueKind.String);

            registryKey.Close();
        }

        public void UpdateValues()
        {
            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\ProgrammeExe", true);
            if(registryKey!=null)
            {
                registryKey.SetValue("charIndex", charIndex, RegistryValueKind.String);
                registryKey.SetValue("numIndex", numIndex, RegistryValueKind.String);

                registryKey.Close();
            }
        }

        private StringBuilder ExecuteAlgorithm()
        {
            StringBuilder key = new StringBuilder();
            int cIndex = charIndex;
            int nIndex = numIndex;

            key = GetChar(key, cIndex);
            key = key.Append('S');
            int valOne = FindIndex(charValueOne[cIndex]);
            int valTwo = FindIndex(charValueTwo[cIndex]);
            key = GetCharIndex(key, valOne,valTwo);
            key = GetNumCount(key, nIndex);
            nIndex++;
            cIndex++;

            if (cIndex > charValueOne.Length - 1)
                cIndex = 0;
            if (nIndex > numValueOne.Length - 1)
                nIndex = 0;

            key = GetChar(key, cIndex);
            key = key.Append('B');
            valOne = FindIndex(charValueOne[cIndex]);
            valTwo = FindIndex(charValueTwo[cIndex]);
            key = GetCharIndex(key, valOne, valTwo);
            key = GetNumCount(key, nIndex);
            nIndex++;
            cIndex++;

            if (cIndex > charValueOne.Length - 1)
                cIndex = 0;
            if (nIndex > numValueOne.Length - 1)
                nIndex = 0;

            charIndex = cIndex;
            numIndex = nIndex;

            key = key.Append(exChar);
            key = key.Append(_days);

            return key;
        }

        private int FindIndex(char val)
        {
            int index = Array.IndexOf(charValues, val);
            return index+1;
        }

        private StringBuilder GetChar(StringBuilder key, int cIndex)
        {
            key = key.Append(charValueOne[cIndex]);
            key = key.Append(charValueTwo[cIndex]);
            return key;
        }

        private StringBuilder GetCharIndex(StringBuilder key,int valOne,int valTwo)
        {
            int index = valOne + valTwo;
            key = key.Append(index);
            return key;
        }

        private StringBuilder GetNumCount(StringBuilder key, int nIndex)
        {
            int keyCount = numValueOne[nIndex] + numValueTwo[nIndex];
            key = key.Append(keyCount);
            return key;
        }
    }
}
