﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LicenseKeyGeneration
{
    public partial class KeyFrm : MetroFramework.Forms.MetroForm
    {
        private KeyGeneration keyGeneration;
        private bool isUpdate;
        public enum SetupType
        {
            Trial,
            Standard
        }

        public KeyFrm()
        {
            InitializeComponent();
            //Load setup types
            LoadSetupType();
        }

        private void LoadSetupType()
        {
            int enumCount = Enum.GetValues(typeof(SetupType)).Length;
            if (enumCount > 0)
            {
                SetupType[] setupTypes = Enum.GetValues(typeof(SetupType)).Cast<SetupType>().ToArray();
                if (setupTypes.Length > 0)
                {
                    for (int i = 0; i < setupTypes.Length; i++)
                    {
                        ctrlCbxSetupType.Items.Add(setupTypes[i]);
                    }
                }
            }
        }

        private void ctrlBtnKeyGenerate_Click(object sender, EventArgs e)
        {
            if (ValidateFields())
            {
                int noOfDays = Convert.ToInt32(ctrlTxtNoOfDays.Text);
                keyGeneration = new KeyGeneration(noOfDays);
                string key = keyGeneration.GenerateKey();
                if (!string.IsNullOrWhiteSpace(key))
                {
                    var binary= StringToBinary(key);
                    ctrlTxtLicenseKey.Text = binary;
                    isUpdate = false;
                }
            }
        }
        private  string StringToBinary(string data)
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
                sb.Append(Convert.ToString(c, 2).PadLeft(8, '0'));
            }
            return sb.ToString();
        }
        private bool ValidateFields()
        {
            bool isValid = true;
            if (string.IsNullOrEmpty(ctrlTxtCmpName.Text))
            {
                MessageBox.Show("Please enter valid company name.", "Key Generation - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                isValid = false;
                ctrlTxtCmpName.Focus();
                return isValid;
            }
            if (string.IsNullOrEmpty(ctrlCbxSetupType.Text))
            {
                MessageBox.Show("Please select setup type.", "Key Generation - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                isValid = false;
                ctrlCbxSetupType.Focus();
                return isValid;
            }
            if (string.IsNullOrEmpty(ctrlTxtNoOfDays.Text))
            {
                MessageBox.Show("Please enter no.of days.", "Key Generation - Validate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                isValid = false;
                ctrlTxtNoOfDays.Focus();
                return isValid;
            }
            return isValid;
        }

        private void ctrlBtnClose_Click(object sender, EventArgs e)
        {
            if (keyGeneration != null)
            {
                Update();
            }
            else
                this.Close();
        }

        private void Update()
        {
            keyGeneration.UpdateValues();
            isUpdate = true;
            this.Close();
        }

        private void KeyFrm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (keyGeneration != null && isUpdate == false)
            {
                keyGeneration.UpdateValues();
                isUpdate = true;
                this.Close();
            }
        }

        private void ctrlTxtNoOfDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar)) && (e.KeyChar != '8'))
            {
                e.Handled = true;
                MessageBox.Show("Please give numeric input", "Key Generation - Validate", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
